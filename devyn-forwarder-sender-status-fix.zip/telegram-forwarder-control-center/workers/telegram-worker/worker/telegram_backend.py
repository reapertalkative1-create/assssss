"""Telegram access behind a small interface so the account logic can be tested without Telegram.

TelethonBackend is the real implementation. Sessions are Telethon StringSessions held in memory only:
the worker never writes session files to disk. FloodWait is never slept through silently: the exact wait
Telegram asked for is surfaced to the caller (flood_sleep_threshold=0)."""
import asyncio
from dataclasses import dataclass
from typing import Any, Protocol


class BackendError(Exception):
    """A Telegram-side failure reduced to a stable code (no message text, which might contain personal data)."""

    def __init__(self, code: str, retry_after: int | None = None):
        super().__init__(code)
        self.code, self.retry_after = code, retry_after


def can_post_message(entity,permissions,message):
    if permissions is None or getattr(permissions,'has_left',False):return False
    if getattr(entity,'broadcast',False):return bool(getattr(permissions,'is_creator',False) or getattr(permissions,'post_messages',False))
    if getattr(permissions,'is_admin',False):return True
    participant=getattr(permissions,'participant',None)
    if getattr(participant,'left',False):return False
    rights=getattr(participant,'banned_rights',None) or getattr(entity,'default_banned_rights',None)
    if getattr(permissions,'is_banned',False) and rights is None:return False
    if not getattr(permissions,'has_default_permissions',False) and not getattr(permissions,'is_banned',False):return False
    if rights and (getattr(rights,'view_messages',False) or getattr(rights,'send_messages',False)):return False
    if getattr(message,'photo',None):restricted=('send_media','send_photos')
    elif getattr(message,'video',None):restricted=('send_media','send_videos')
    elif getattr(message,'sticker',None):restricted=('send_media','send_stickers')
    elif getattr(message,'document',None):restricted=('send_media','send_docs')
    elif getattr(message,'poll',None):restricted=('send_polls',)
    else:restricted=('send_plain',)
    return not rights or not any(getattr(rights,flag,False) for flag in restricted)


@dataclass(frozen=True)
class UserInfo:
    telegram_user_id: int
    username: str | None


@dataclass(frozen=True)
class SignInResult:
    kind: str  # "authorized" | "password_needed"
    user: UserInfo | None = None


@dataclass(frozen=True)
class ChatInfo:
    ok: bool                     # the account can see the chat
    can_send: bool | None = None  # the account may write to it (best effort; the send itself is the final authority)
    title: str | None = None


@dataclass(frozen=True)
class MessageFacts:
    chat_id: int
    message_id: int
    text: str                    # stays on the worker (used only for keyword filters); never sent to the API or logged
    kind: str                    # text|photo|video|voice|audio|sticker|document|other
    outgoing: bool = False
    is_service: bool = False


class TelegramBackend(Protocol):
    async def prime(self, handle: Any) -> None: ...
    async def resolve_chats(self, handle: Any, chat_ids: list[int]) -> dict[int, ChatInfo]: ...
    async def latest_message_id(self, handle: Any, chat_id: int) -> int: ...
    async def history_since(self, handle: Any, chat_id: int, min_id: int, limit: int) -> list[MessageFacts]: ...
    def watch(self, handle: Any, chat_ids: set[int], callback: Any) -> Any: ...
    def unwatch(self, handle: Any, token: Any) -> None: ...
    async def forward(self, handle: Any, source: int, message_id: int, dest: int, mode: str) -> int | None: ...
    async def send_code(self, phone: str) -> Any: ...
    async def sign_in_code(self, handle: Any, code: str) -> SignInResult: ...
    async def sign_in_password(self, handle: Any, password: str) -> UserInfo: ...
    def session_string(self, handle: Any) -> str: ...
    async def connect(self, session: str) -> tuple[Any, UserInfo]: ...
    def is_connected(self, handle: Any) -> bool: ...
    async def disconnect(self, handle: Any) -> None: ...
    async def log_out(self, handle: Any) -> None: ...


def map_error(exc: BaseException) -> BackendError:
    from telethon import errors as e

    if str(getattr(exc,'message','')).upper().startswith('FROZEN_'):
        return BackendError('account_frozen')
    if isinstance(exc, BackendError):
        return exc
    if isinstance(exc, e.FloodWaitError):
        return BackendError("flood_wait", int(exc.seconds))           # whole account must wait
    if isinstance(exc, e.SlowModeWaitError):
        return BackendError("slow_mode", int(exc.seconds))            # only this chat: not an account-wide wait
    table = [
        (e.PeerFloodError, 'account_spam_restricted'),
        (e.PhoneNumberInvalidError, "phone_invalid"), (e.PhoneNumberBannedError, "phone_banned"),
        (e.PhoneNumberFloodError, "phone_flood"), (e.PhoneCodeInvalidError, "code_invalid"),
        (e.PhoneCodeEmptyError, "code_invalid"), (e.PhoneCodeExpiredError, "code_expired"),
        (e.PasswordHashInvalidError, "password_invalid"), (e.ApiIdInvalidError, "telegram_api_id_invalid"),
        (e.AuthKeyUnregisteredError, "auth_key_unregistered"), (e.AuthKeyDuplicatedError, "auth_key_duplicated"),
        (e.UserDeactivatedBanError, "user_deactivated"), (e.UserDeactivatedError, "user_deactivated"),
        (e.SessionRevokedError, "session_revoked"), (e.SessionExpiredError, "session_revoked"),
        (e.ChatWriteForbiddenError, "destination_forbidden"), (e.ChatAdminRequiredError, "destination_forbidden"),
        (e.UserBannedInChannelError, "destination_forbidden"), (e.ChatSendMediaForbiddenError, "destination_forbidden"),
        (e.ChatSendPlainForbiddenError, "destination_forbidden"), (e.UserIsBlockedError, "destination_forbidden"),
        (e.ChatRestrictedError, "destination_forbidden"), (e.ChannelPrivateError, "chat_unavailable"),
        (e.ChannelInvalidError, "chat_unavailable"), (e.PeerIdInvalidError, "chat_unavailable"),
        (e.MessageIdInvalidError, "message_not_found"), (e.MessageEmptyError, "message_not_found"),
        (e.ChatForwardsRestrictedError, "forward_restricted"), (e.MediaEmptyError, "media_unsupported"),
    ]
    for cls, code in table:
        if isinstance(exc, cls):
            return BackendError(code)
    if isinstance(exc, (ConnectionError, OSError, asyncio.TimeoutError)):
        return BackendError("network_error")
    return BackendError("telegram_error")


def _facts(msg) -> MessageFacts:
    if msg.sticker:
        kind = "sticker"
    elif msg.photo:
        kind = "photo"
    elif msg.voice:
        kind = "voice"
    elif msg.audio:
        kind = "audio"
    elif msg.video or msg.video_note or msg.gif:
        kind = "video"
    elif msg.document:
        kind = "document"
    elif msg.media:
        kind = "other"
    else:
        kind = "text"
    return MessageFacts(int(msg.chat_id), int(msg.id), msg.message or "", kind, bool(msg.out), bool(getattr(msg, "action", None)))


def _user_info(me) -> UserInfo:
    return UserInfo(int(me.id), getattr(me, "username", None))


class _Handle:
    def __init__(self, client, phone: str | None = None, phone_code_hash: str | None = None):
        self.client, self.phone, self.phone_code_hash = client, phone, phone_code_hash


class TelethonBackend:
    def __init__(self, api_id: int, api_hash: str):
        self._api_id, self._api_hash = api_id, api_hash
        self._proxy = None

    def set_proxy(self,proxy):
        self._proxy={'proxy_type':proxy['protocol'],'addr':proxy['host'],'port':proxy['port'],'rdns':True,'username':proxy.get('username'),'password':proxy.get('password')}


    def _new_client(self, session: str = ""):
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        return TelegramClient(StringSession(session), self._api_id, self._api_hash, flood_sleep_threshold=0, proxy=self._proxy)

    async def send_code(self, phone: str) -> _Handle:
        client = self._new_client()
        try:
            await client.connect()
            sent = await client.send_code_request(phone)
        except BaseException as exc:
            await self._quiet_disconnect(client)
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise map_error(exc) from None
        return _Handle(client, phone, sent.phone_code_hash)

    async def sign_in_code(self, handle: _Handle, code: str) -> SignInResult:
        from telethon import errors as e

        try:
            await handle.client.sign_in(phone=handle.phone, code=code, phone_code_hash=handle.phone_code_hash)
        except e.SessionPasswordNeededError:
            return SignInResult("password_needed")
        except Exception as exc:
            raise map_error(exc) from None
        return SignInResult("authorized", _user_info(await handle.client.get_me()))

    async def sign_in_password(self, handle: _Handle, password: str) -> UserInfo:
        try:
            await handle.client.sign_in(password=password)
            return _user_info(await handle.client.get_me())
        except Exception as exc:
            raise map_error(exc) from None

    def session_string(self, handle: _Handle) -> str:
        return handle.client.session.save()

    async def connect(self, session: str) -> tuple[_Handle, UserInfo]:
        client = self._new_client(session)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                raise BackendError("auth_key_unregistered")
            me = await client.get_me()
        except BaseException as exc:
            await self._quiet_disconnect(client)
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise map_error(exc) from None
        return _Handle(client), _user_info(me)

    async def prepare_appeal(self,handle,**kwargs):
        from worker.appeal_template import prepare
        try:return await prepare(handle.client,**kwargs)
        except Exception as exc:raise map_error(exc) from None

    async def check_spam(self,handle,operation='check',**kwargs):
        from worker.spambot import interact
        return await interact(handle.client,operation,**kwargs)

    async def check_health(self, handle):
        try:
            me=await handle.client.get_me()
            if me is None:raise BackendError('auth_key_unregistered')
            if getattr(me,'deleted',False):raise BackendError('user_deactivated')
            return _user_info(me)
        except Exception as exc:
            raise map_error(exc) from None

    def is_connected(self, handle: _Handle) -> bool:
        return bool(handle.client.is_connected())

    async def disconnect(self, handle: _Handle) -> None:
        await self._quiet_disconnect(handle.client)

    async def log_out(self, handle: _Handle) -> None:
        try:
            await handle.client.log_out()  # terminates the session on Telegram's side
        except Exception as exc:
            raise map_error(exc) from None

    # ----- chats, history, live messages, forwarding -----
    async def prime(self, handle: _Handle) -> None:
        """A client restored from a StringSession knows no chats yet; loading the dialogs fills Telethon's entity cache
        (needed to address chats by id). Can be slow for accounts with thousands of chats."""
        try:
            await handle.client.get_dialogs()
        except Exception as exc:
            raise map_error(exc) from None

    async def list_telegram_groups(self, handle):
        from telethon import utils
        from telethon.tl import types
        items=[];truncated=False
        try:
            async for dialog in handle.client.iter_dialogs():
                entity=dialog.entity
                if not (isinstance(entity,types.Chat) or isinstance(entity,types.Channel) and bool(entity.megagroup)):continue
                if getattr(entity,'left',False) or getattr(entity,'kicked',False):continue
                if len(items)>=2000:truncated=True;break
                username=getattr(entity,'username',None)
                items.append({'id':str(utils.get_peer_id(entity)),'title':str(getattr(entity,'title','') or '')[:100], 'username':username[:64] if username else None})
            return {'groups':items,'truncated':truncated}
        except Exception as exc:
            raise map_error(exc) from None

    async def resolve_chats(self, handle: _Handle, chat_ids: list[int]) -> dict[int, ChatInfo]:
        out: dict[int, ChatInfo] = {}
        for cid in chat_ids:
            try:
                entity = await handle.client.get_entity(cid)
                title = getattr(entity, "title", None) or getattr(entity, "first_name", None)
                perms = await handle.client.get_permissions(entity)
                can_send = bool(perms is None or getattr(perms, "is_admin", False) or getattr(perms, "send_messages", False)
                                or getattr(perms, "post_messages", False))
                out[cid] = ChatInfo(True, can_send, (title or "")[:100] or None)
            except Exception as exc:
                err = map_error(exc)
                if err.code in ("flood_wait", "network_error"):
                    raise err from None
                out[cid] = ChatInfo(False, None, None)
        return out

    async def resolve_post_route(self,handle,post_link,targets):
        from urllib.parse import urlsplit
        from telethon import utils
        from telethon.tl import types,functions
        parts=urlsplit(post_link).path.strip('/').split('/')
        peer=-int('100'+parts[1]) if parts[0]=='c' else '@'+parts[0]
        mid=int(parts[-1]);client=handle.client
        try:
            source=await client.get_entity(peer)
            if not isinstance(source,(types.Chat,types.Channel)):raise BackendError('chat_unavailable')
            message=await client.get_messages(source,ids=mid)
            if message is None or getattr(message,'empty',False):raise BackendError('message_not_found')
            if getattr(source,'noforwards',False) or getattr(message,'noforwards',False):raise BackendError('forward_restricted')
        except Exception as exc:raise map_error(exc) from None
        checks=[]
        for index,ref in enumerate(targets):
            try:
                if ref.startswith('https://t.me/+'):
                    invite=await client(functions.messages.CheckChatInviteRequest(ref.rsplit('+',1)[1]))
                    if not isinstance(invite,types.ChatInviteAlready):
                        checks.append({'index':index,'ok':False,'can_send':False,'error_code':'not_joined'});continue
                    entity=invite.chat
                else:entity=await client.get_entity(int(ref) if ref.startswith('-') else ref)
                if not isinstance(entity,(types.Chat,types.Channel)):
                    checks.append({'index':index,'ok':False,'can_send':False,'error_code':'not_a_group'});continue
                cid=utils.get_peer_id(entity)
                if getattr(entity,'left',False) or getattr(entity,'kicked',False):
                    checks.append({'index':index,'id':cid,'ok':False,'can_send':False,'error_code':'not_joined'});continue
                perms=await client.get_permissions(entity,'me')
                can_send=can_post_message(entity,perms,message)
                checks.append({'index':index,'id':cid,'title':getattr(entity,'title','')[:100],'ok':True,'can_send':can_send,'error_code':None if can_send else 'destination_forbidden'})
            except Exception as exc:
                error=map_error(exc)
                if error.code in ('flood_wait','network_error','account_frozen','account_spam_restricted','phone_banned','auth_key_unregistered'):raise error from None
                checks.append({'index':index,'ok':False,'can_send':False,'error_code':'chat_unavailable'})
        return {'source_chat_id':utils.get_peer_id(source),'source_title':getattr(source,'title','')[:100],'message_id':mid,'targets':checks}

    async def latest_message_id(self, handle: _Handle, chat_id: int) -> int:
        try:
            msgs = await handle.client.get_messages(chat_id, limit=1)
        except Exception as exc:
            raise map_error(exc) from None
        return int(msgs[0].id) if msgs else 0

    async def history_since(self, handle: _Handle, chat_id: int, min_id: int, limit: int) -> list[MessageFacts]:
        try:
            return [_facts(m) async for m in handle.client.iter_messages(chat_id, min_id=min_id, limit=limit, reverse=True)]
        except Exception as exc:
            raise map_error(exc) from None

    def watch(self, handle: _Handle, chat_ids: set[int], callback) -> Any:
        from telethon import events

        async def _handler(event):
            try:
                callback(_facts(event.message))
            except Exception:
                pass  # a bad message must never break the update loop

        builder = events.NewMessage(chats=list(chat_ids))
        handle.client.add_event_handler(_handler, builder)
        return (_handler, builder)

    def unwatch(self, handle: _Handle, token) -> None:
        try:
            handle.client.remove_event_handler(token[0], token[1])
        except Exception:
            pass

    async def forward(self, handle: _Handle, source: int, message_id: int, dest: int, mode: str) -> int | None:
        client = handle.client
        try:
            if mode == "forward":
                sent = await client.forward_messages(dest, message_id, from_peer=source)
            else:  # copy: re-send the content without the "forwarded from" header (refused for protected chats)
                source_entity=await client.get_entity(source)
                if getattr(source_entity,'noforwards',False):raise BackendError('forward_restricted')
                msg = await client.get_messages(source, ids=message_id)
                if msg is None or getattr(msg, "empty", False):
                    raise BackendError("message_not_found")
                if getattr(msg, "noforwards", False):
                    raise BackendError("forward_restricted")
                sent = await client.send_message(dest, msg)
        except Exception as exc:
            raise map_error(exc) from None
        sent = sent[0] if isinstance(sent, list) and sent else sent
        if not sent:
            raise BackendError("message_not_found")
        return getattr(sent, "id", None)

    @staticmethod
    async def _quiet_disconnect(client) -> None:
        try:
            await asyncio.wait_for(client.disconnect(), timeout=5)
        except Exception:
            pass
