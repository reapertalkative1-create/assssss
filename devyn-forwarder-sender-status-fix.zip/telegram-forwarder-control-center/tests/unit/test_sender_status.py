import uuid
from datetime import timedelta
from sqlalchemy import select
from app.models import TelegramAccount,Worker
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_multi_senders import setup,body


def test_error_accounts_remain_selectable_and_create_drafts_but_restrictions_are_enforced(env):
    w,ids=setup(env,3);c,h=env.client,env.h
    async def change(db):
        a=await db.get(TelegramAccount,uuid.UUID(ids[0]));a.spam_status='blocked'
        b=await db.get(TelegramAccount,uuid.UUID(ids[1]));b.auth_state='invalid';b.health_status='dead'
        d=await db.get(TelegramAccount,uuid.UUID(ids[2]));d.health_status='error';d.health_error='network_error'
    run_db(env.settings,change)
    selected=c.post('/api/post-routes/senders',headers=h,json={'account_ids':ids}).json()
    assert selected['skipped_count']==0 and len(selected['items'])==3 and selected['warning_count']==3
    r=c.post('/api/post-routes/batches',headers=h,json=body(ids));assert r.status_code==201,r.text
    for route in r.json()['items']:
        assert c.post('/api/routes/'+route['id']+'/start',headers=h).status_code==409
    assert c.get('/api/jobs').json()['total']==0
    # Checks are allowed for the selected error SS; actual command results determine recovery.
    r=c.post('/api/account-bulk',headers=h,json={'action':'check','account_ids':ids})
    assert r.status_code==202 and r.json()['total']==3


def test_status_counts_and_filtering_cover_all_pages_and_same_scope_as_select_all(env):
    w=env.make_worker();c,h=env.client,env.h
    gid=c.post('/api/account-groups',headers=h,json={'name':'240 SS'}).json()['id']
    async def seed(db):
        ids=[]
        from app.models import AccountGroupMember
        for i in range(240):
            aid=uuid.uuid4();ids.append(str(aid))
            a=TelegramAccount(id=aid,name=f'Test {i:03d}',name_key=f'test {i:03d}',assigned_worker_id=uuid.UUID(w.id),
                auth_state='authorized',session_version=1,session_ciphertext='synthetic-only',health_status='live',spam_status='clear')
            if i<80:a.spam_status='blocked'
            elif i<120:a.health_status='dead';a.auth_state='invalid'
            elif i<160:a.health_status='frozen'
            elif i<200:a.health_status='error'
            db.add(a);await db.flush();db.add(AccountGroupMember(account_id=aid,group_id=uuid.UUID(gid)))
        return ids
    ids=run_db(env.settings,seed)
    r=c.get('/api/post-routes/senders',params={'group_id':gid,'page':5}).json()
    assert len(r['items'])==40 and r['total']==240
    assert r['counts']['ready']==40 and r['counts']['dead']==40 and r['counts']['blocked']==80 and r['counts']['live']==120
    ready=c.get('/api/post-routes/senders',params={'group_id':gid,'status_filter':'ready'}).json()
    assert ready['total']==40 and all(a['sender_ready'] for a in ready['items'])
    selected=c.post('/api/post-routes/senders',headers=h,json={'all_matching':True,'filters':{'group_id':gid},'status_filter':'ready','exclude_ids':[ids[-1]]}).json()
    assert len(selected['items'])==39 and ids[-1] not in [a['id'] for a in selected['items']]
    blocked=c.get('/api/post-routes/senders',params={'q':'Test 00','group_id':gid,'status_filter':'blocked'}).json()
    assert blocked['total']==10 and blocked['counts']['all']==10
    all_selected=c.post('/api/post-routes/senders',headers=h,json={'all_matching':True,'filters':{'group_id':gid}}).json()
    assert len(all_selected['items'])==240 and all_selected['skipped_count']==0


def test_ready_requires_session_worker_and_no_known_connection_or_wait_errors(env):
    w,ids=setup(env,2);c=env.client
    assert c.get('/api/post-routes/senders',params={'status_filter':'ready'}).json()['total']==2
    async def offline(db):(await db.get(Worker,uuid.UUID(w.id))).__setattr__('last_heartbeat_at',utcnow()-timedelta(days=1))
    run_db(env.settings,offline)
    assert c.get('/api/post-routes/senders',params={'status_filter':'ready'}).json()['total']==0
    assert c.get('/api/post-routes/senders',params={'status_filter':'offline'}).json()['total']==2
    w.heartbeat()
    async def errors(db):
        a=await db.get(TelegramAccount,uuid.UUID(ids[0]));a.proxy_status='dead'
        b=await db.get(TelegramAccount,uuid.UUID(ids[1]));b.flood_wait_until=utcnow()+timedelta(minutes=3)
    run_db(env.settings,errors)
    assert c.get('/api/post-routes/senders',params={'status_filter':'ready'}).json()['total']==0
    assert c.get('/api/post-routes/senders',params={'status_filter':'proxy_error'}).json()['total']==1
    assert c.get('/api/post-routes/senders',params={'status_filter':'waiting'}).json()['total']==1
    async def recover(db):
        a=await db.get(TelegramAccount,uuid.UUID(ids[0]));a.proxy_status='alive'
        b=await db.get(TelegramAccount,uuid.UUID(ids[1]));b.flood_wait_until=utcnow()-timedelta(seconds=1)
    run_db(env.settings,recover)
    assert c.get('/api/post-routes/senders',params={'status_filter':'ready'}).json()['total']==2


def test_deleted_accounts_rejected_atomically_and_invalid_status_rejected(env):
    w,ids=setup(env,2);c,h=env.client,env.h
    async def pending(db):(await db.get(TelegramAccount,uuid.UUID(ids[0]))).__setattr__('pending_deletion',True)
    run_db(env.settings,pending)
    assert c.post('/api/post-routes/batches',headers=h,json=body(ids)).status_code==409
    r=c.post('/api/post-routes/senders',headers=h,json={'account_ids':ids}).json()
    assert len(r['items'])==1 and r['skipped_count']==1
    assert c.get('/api/post-routes/senders',params={'status_filter':'invented'}).status_code==422
