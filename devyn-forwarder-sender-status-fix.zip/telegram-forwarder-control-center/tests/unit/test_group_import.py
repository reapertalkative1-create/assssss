"""Regression: selecting a folder must also apply to new and duplicate imports."""
import uuid
from tests.unit.test_accounts_api import env
from tests.unit.test_session_import import sqlite_session, archive, payload


def group(env, name):
    r=env.client.post('/api/account-groups',headers=env.h,json={'name':name})
    assert r.status_code==201,r.text
    return r.json()['id']


def test_create_in_group_and_move_both_directions(env):
    c,h=env.client,env.h
    first,second=group(env,'First'),group(env,'Second')
    r=c.post('/api/accounts',headers=h,json={'name':'New SS','group_id':first})
    assert r.status_code==201,r.text
    a=r.json();assert a['group_id']==first and a['group_name']=='First'
    for destination in (second,first,None):
        r=c.post('/api/account-groups/assign',headers=h,json={'group_id':destination,'account_ids':[a['id']]})
        assert r.json()['assigned']==1,r.text
        assert c.get('/api/accounts/'+a['id']).json()['group_id']==destination
    assert c.get('/api/accounts',params={'ungrouped':True}).json()['total']==1


def test_import_group_is_persisted_before_worker_runs_and_survives_result(env):
    c,h=env.client,env.h;w=env.make_worker();gid=group(env,'Imported')
    body=payload(w.id,archive([('a.session',sqlite_session()[0]),('bad.session',b'bad'),('b.session',sqlite_session()[0])]),'batch.zip')
    body.update(group_id=gid,require_proxy=True,proxies=['a.example:1080','bad.example:1080','b.example:1080'])
    r=c.post('/api/accounts/import-sessions',headers=h,json=body)
    assert r.status_code==202,r.text
    assert [i['status'] for i in r.json()['items']]==['queued','error','queued']
    rows=c.get('/api/accounts',params={'group_id':gid}).json()
    assert rows['total']==2 and all(a['auth_state']=='importing' and a['group_name']=='Imported' for a in rows['items'])
    assert c.get('/api/accounts',params={'ungrouped':True}).json()['total']==0
    assert c.get('/api/account-groups').json()[0]['count']==2
    commands=w.poll();assert len(commands)==2
    for cmd in commands:
        assert w.result(cmd['id'],status='failed',error_code='network_error').status_code==204
    assert c.get('/api/accounts',params={'group_id':gid}).json()['total']==2


def test_duplicate_import_moves_group_without_replacing_session_or_proxy(env):
    c,h=env.client,env.h;w=env.make_worker();raw=sqlite_session()[0]
    body=payload(w.id,raw);body.update(require_proxy=True,proxies=['old.example:1080'])
    original=c.post('/api/accounts/import-sessions',headers=h,json=body).json()['items'][0]
    commands=w.poll();assert len(commands)==1
    first,second=group(env,'First'),group(env,'Second')
    for destination in (first,second):
        body.update(group_id=destination,proxies=['unused.example:1080'])
        r=c.post('/api/accounts/import-sessions',headers=h,json=body)
        assert r.status_code==202,r.text
        item=r.json()['items'][0]
        assert item['status']=='duplicate' and item['group_assigned']
        a=c.get('/api/accounts/'+original['account_id']).json()
        assert a['group_id']==destination and a['proxy_label']=='socks5://old.example:1080'
        assert a['has_session']
    body.pop('group_id')
    r=c.post('/api/accounts/import-sessions',headers=h,json=body)
    assert not r.json()['items'][0]['group_assigned']
    assert c.get('/api/accounts/'+original['account_id']).json()['group_id']==second
    assert c.get('/api/accounts').json()['total']==1 and w.poll()==[]


def test_deleted_destination_rejects_create_and_import_without_ungrouped_accounts(env):
    c,h=env.client,env.h;w=env.make_worker();gid=group(env,'Removed')
    assert c.delete('/api/account-groups/'+gid,headers=h).status_code==200
    body=payload(w.id,sqlite_session()[0]);body['group_id']=gid
    for path,data in [('/api/accounts/import-sessions',body),('/api/accounts',{'name':'Wrong folder','group_id':gid})]:
        r=c.post(path,headers=h,json=data)
        assert r.status_code==404 and r.json()['error']['code']=='group_not_found',r.text
    assert c.get('/api/accounts').json()['total']==0 and w.poll()==[]
