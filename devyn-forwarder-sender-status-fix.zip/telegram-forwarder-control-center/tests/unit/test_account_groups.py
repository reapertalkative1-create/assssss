from tests.unit.test_accounts_api import env
from tests.unit.test_accounts_e2e import e2e

def test_group_assignment_filter_bulk_and_delete_preserve_accounts(env):
 c,h=env.client,env.h
 a=env.make_account('SS A');b=env.make_account('SS B');d=env.make_account('SS C')
 g=c.post('/api/account-groups',headers=h,json={'name':'Nhóm A'});assert g.status_code==201,g.text
 gid=g.json()['id']
 assert c.post('/api/account-groups',headers=h,json={'name':'nhóm a'}).status_code==409
 r=c.post('/api/account-groups/assign',headers=h,json={'group_id':gid,'account_ids':[a,b]});assert r.status_code==200,r.text
 assert c.get('/api/accounts',params={'group_id':gid}).json()['total']==2
 assert c.get('/api/accounts',params={'ungrouped':True}).json()['total']==1
 assert c.get('/api/accounts/'+a).json()['group_name']=='Nhóm A'
 assert c.patch('/api/account-groups/'+gid,headers=h,json={'name':'Đã đổi'}).status_code==200
 job=c.post('/api/account-bulk',headers=h,json={'action':'stop','all_matching':True,'filters':{'group_id':gid}})
 assert job.status_code==202 and job.json()['total']==2,job.text
 assert c.post('/api/account-groups/assign',headers=h,json={'group_id':None,'all_matching':True,'exclude_ids':[b],'filters':{'group_id':gid}}).json()['assigned']==1
 assert c.get('/api/accounts',params={'group_id':gid}).json()['total']==1
 deleted=c.delete('/api/account-groups/'+gid,headers=h);assert deleted.json()['accounts_kept']==1
 assert c.get('/api/accounts').json()['total']==3
 assert c.get('/api/accounts',params={'ungrouped':True}).json()['total']==3

def test_group_modifications_require_admin(env,new_client,seed_user,login):
 seed_user('operator',role='operator');client=new_client();h=login(client,'operator')
 assert client.get('/api/account-groups').status_code==200
 assert client.post('/api/account-groups',headers=h,json={'name':'No'}).status_code==403
 assert client.post('/api/account-groups/assign',headers=h,json={'account_ids':['00000000-0000-0000-0000-000000000000']}).status_code==403

def test_telegram_groups_command_and_wait_are_account_scoped(env):
 w=env.make_worker();aid=env.make_account('Groups SS',worker=w);env.authorize(w,aid)
 c,h=env.client,env.h
 r=c.post(f'/api/accounts/{aid}/telegram-groups',headers=h);assert r.status_code==202,r.text
 (cmd,)=w.poll();assert cmd['type']=='list_telegram_groups'
 payload={'groups':[{'id':'-1001234567890','title':'Test group','username':'test_group'},{'id':'invalid','title':'bad'}],'truncated':False}
 assert w.result(cmd['id'],result=payload).status_code==204
 result=c.get(f"/api/accounts/{aid}/commands/{cmd['id']}").json()['result']
 assert result['groups']==[{'id':'-1001234567890','title':'Test group','username':'test_group'}]
 r=c.post(f'/api/accounts/{aid}/telegram-groups',headers=h);(cmd,)=w.poll()
 assert w.http.post(f"/api/worker/v1/commands/{cmd['id']}/result",headers=w.h,json={'status':'failed','error_code':'flood_wait','retry_after':30}).status_code==204
 assert c.post(f'/api/accounts/{aid}/telegram-groups',headers=h).status_code==409


def test_deleted_account_is_removed_from_group_counts_in_sqlite(env):
 c,h=env.client,env.h
 aid=env.make_account('Remove session');gid=c.post('/api/account-groups',headers=h,json={'name':'Group'}).json()['id']
 c.post('/api/account-groups/assign',headers=h,json={'group_id':gid,'account_ids':[aid]})
 r=c.post(f'/api/accounts/{aid}/delete',headers=h,json={'confirm_name':'Remove session'});assert r.status_code==200,r.text
 assert c.get('/api/account-groups').json()[0]['count']==0


def test_telethon_group_list_excludes_private_chats_and_broadcasts():
 import asyncio
 from types import SimpleNamespace
 from datetime import datetime,timezone
 from telethon.tl import types
 from worker.telegram_backend import TelethonBackend
 now=datetime.now(timezone.utc)
 chat=types.Chat(id=123,title='A',photo=types.ChatPhotoEmpty(),participants_count=1,date=now,version=1)
 mega=types.Channel(id=456,title='B',photo=types.ChatPhotoEmpty(),date=now,megagroup=True,username='testgroup')
 broadcast=types.Channel(id=789,title='Channel',photo=types.ChatPhotoEmpty(),date=now,broadcast=True)
 class Client:
  async def iter_dialogs(self):
   for entity in [chat,mega,broadcast,types.User(id=12)]:yield SimpleNamespace(entity=entity)
 result=asyncio.run(TelethonBackend(123,'a'*32).list_telegram_groups(SimpleNamespace(client=Client())))
 assert [g['title'] for g in result['groups']]==['A','B']
 assert result['groups'][0]['id']=='-123' and result['groups'][1]['id']=='-1000000000456'


def test_worker_lists_groups_through_selected_account(e2e):
 import asyncio
 from tests.unit.test_forwarding_e2e import FSide
 from tests.unit.test_accounts_e2e import Admin,authorize
 from tests.fakes import FakeNetwork
 from app.main import create_app
 async def scenario():
  app=create_app(e2e);admin=Admin(app);await admin.login()
  worker=await FSide(app,admin,'groups-engine',FakeNetwork()).create()
  try:
   aid=(await admin.post('/api/accounts',{'name':'Selected SS','worker_id':worker.id})).json()['id']
   await authorize(admin,aid)
   async def groups(handle):return {'groups':[{'id':'-100123','title':'Example','username':'example_group'}],'truncated':False}
   worker.backend.list_telegram_groups=groups
   response=await admin.post('/api/accounts/'+aid+'/telegram-groups',{})
   assert response.status_code==202,response.text
   result=await admin.finished(aid,response.json()['command_id'])
   assert result['status']=='done' and result['result']['groups'][0]['title']=='Example'
  finally:
   await worker.close();await worker.client.aclose();await admin.http.aclose();await app.state.engine.dispose()
 asyncio.run(scenario())
