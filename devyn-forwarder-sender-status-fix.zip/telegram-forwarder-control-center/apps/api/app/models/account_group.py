import uuid
from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base

class AccountGroup(Base):
    __tablename__ = 'account_groups'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)

class AccountGroupMember(Base):
    __tablename__ = 'account_group_members'
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey('telegram_accounts.id', ondelete='CASCADE'), primary_key=True)
    group_id: Mapped[uuid.UUID] = mapped_column(ForeignKey('account_groups.id', ondelete='CASCADE'), index=True)
