"""Persist folder membership in the same transaction as account imports."""
from sqlalchemy import delete, select

from app.errors import ApiError
from app.models import AccountGroup, AccountGroupMember, TelegramAccount


async def require_group(db, group_id):
    if group_id is None:
        return None
    group = (await db.execute(select(AccountGroup).where(
        AccountGroup.id == group_id).with_for_update(read=True))).scalar_one_or_none()
    if group is None:
        raise ApiError(404, 'group_not_found', 'Nhóm đã bị xóa. Hãy chọn lại nhóm trước khi nhập SS.')
    return group


async def set_membership(db, account_id, group_id):
    # Serialize moves of the same account, including duplicate import requests.
    account = (await db.execute(select(TelegramAccount).where(
        TelegramAccount.id == account_id).with_for_update())).scalar_one_or_none()
    if account is None or account.pending_deletion:
        return False
    await db.execute(delete(AccountGroupMember).where(AccountGroupMember.account_id == account_id))
    if group_id is not None:
        db.add(AccountGroupMember(account_id=account_id, group_id=group_id))
    await db.flush()
    return True
