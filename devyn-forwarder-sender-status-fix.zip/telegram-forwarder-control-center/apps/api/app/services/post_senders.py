"""Account selection is independent of readiness to send on Telegram."""
import uuid
from datetime import timedelta
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import and_, case, func, or_, select
from app.errors import ApiError
from app.models import TelegramAccount as A, Worker
from app.schemas_accounts import AccountFilters
from app.services.account_health import conditions
from app.types import utcnow

MAX_SENDERS = 1000
SenderStatus = Literal['all','ready','live','dead','limited','blocked','frozen','unknown','error','login','waiting','offline','proxy_error']

class SenderSelection(BaseModel):
    model_config = ConfigDict(extra='forbid')
    account_ids: list[uuid.UUID] = Field(default_factory=list, max_length=10000)
    all_matching: bool = False
    exclude_ids: list[uuid.UUID] = Field(default_factory=list, max_length=10000)
    filters: AccountFilters = Field(default_factory=AccountFilters)
    status_filter: SenderStatus = 'all'


def status_expressions(now, timeout):
    online = select(Worker.id).where(Worker.id == A.assigned_worker_id,
        Worker.revoked_at.is_(None), Worker.last_heartbeat_at >= now-timedelta(seconds=timeout)).exists()
    frozen = or_(A.health_status == 'frozen', func.coalesce(A.health_override, '') == 'frozen')
    dead = or_(A.health_status == 'dead', A.auth_state == 'invalid')
    waiting = or_(A.flood_wait_until > now, and_(A.health_status == 'waiting', A.flood_wait_until.is_(None)))
    no_session = or_(A.session_ciphertext.is_(None), A.session_version <= 0)
    problem = or_(A.health_status == 'error', A.spam_status == 'error', A.proxy_status == 'dead', A.connection_state == 'error')
    reason = case(
        (A.pending_deletion.is_(True), 'Đang xóa'),
        (dead, 'Die / hết phiên'), (frozen, 'Đóng băng'),
        (A.spam_status == 'blocked', 'Bị chặn'), (A.spam_status == 'limited', 'Bị spam'),
        (A.auth_state != 'authorized', 'Chưa xác thực'), (no_session, 'Chưa có session'),
        (A.assigned_worker_id.is_(None), 'Chưa gán worker'), (~online, 'Worker offline'),
        (A.proxy_status == 'dead', 'Proxy die'), (waiting, 'Đang chờ Telegram'),
        (problem, 'Cần kiểm tra lại'), else_=None)
    statuses = {'all': A.pending_deletion.is_(False), 'ready': reason.is_(None),
        'live': and_(A.health_status == 'live', A.auth_state == 'authorized', ~frozen),
        'dead': dead, 'limited': A.spam_status == 'limited', 'blocked': A.spam_status == 'blocked',
        'frozen': frozen, 'unknown': A.health_status == 'unknown', 'error': problem,
        'login': A.auth_state != 'authorized', 'waiting': waiting,
        'offline': ~online, 'proxy_error': A.proxy_status == 'dead'}
    return statuses, reason


async def sender_rows(db, rows):
    # Use the same account serializer as the Telegram-account table; no secrets.
    from app.routers.accounts import _out
    data = await _out(db, [a for a, _ in rows])
    return [{**item, 'id':str(item['id']), 'sender_ready': reason is None, 'sender_reason': reason}
            for item, (_, reason) in zip(data, rows)]


async def list_senders(db, filters, status_filter='all', page=1, page_size=50, *, timeout=60):
    statuses, reason = status_expressions(utcnow(), timeout)
    base = [*conditions(**filters.model_dump()), A.pending_deletion.is_(False)]
    names = list(statuses)
    values = (await db.execute(select(*[
        func.coalesce(func.sum(case((statuses[name], 1), else_=0)), 0) for name in names
    ]).where(*base))).one()
    counts = dict(zip(names, values))
    rows = (await db.execute(select(A, reason).where(*base, statuses[status_filter])
        .order_by(A.name_key, A.id).offset((page-1)*page_size).limit(page_size))).all()
    return {'items': await sender_rows(db, rows), 'counts': counts,
            'total': counts[status_filter], 'page': page, 'page_size': page_size}


async def resolve_senders(db, selection, *, strict=False, timeout=60):
    if not selection.all_matching and not selection.account_ids:
        raise ApiError(422, 'empty_selection', 'Chọn ít nhất một tài khoản gửi.')
    statuses, reason = status_expressions(utcnow(), timeout)
    where = conditions(**selection.filters.model_dump()) if selection.all_matching else [A.id.in_(selection.account_ids)]
    if selection.all_matching:
        where.extend([statuses[selection.status_filter], A.pending_deletion.is_(False)])
        if selection.exclude_ids: where.append(A.id.not_in(selection.exclude_ids))
    count = (await db.execute(select(func.count()).select_from(A).where(*where))).scalar_one()
    if count > MAX_SENDERS:
        raise ApiError(422, 'too_many_senders', 'Chọn tối đa 1.000 SS cho một đợt, dùng nhóm/bộ lọc để thu hẹp.')
    rows = (await db.execute(select(A, reason).where(*where).order_by(A.name_key, A.id))).all()
    selected = [(a, r) for a, r in rows if not a.pending_deletion]
    skipped = [{'id':str(a.id), 'name':a.name, 'reason':'Đang xóa'} for a, _ in rows if a.pending_deletion]
    missing = len(set(selection.account_ids))-len(rows) if not selection.all_matching else 0
    if strict and (skipped or missing):
        raise ApiError(409, 'senders_changed', 'Có SS đã bị xóa hoặc đang xóa. Chọn lại tài khoản gửi; chưa tạo đợt nào.')
    return {'items': await sender_rows(db, selected), 'skipped': skipped[:100],
            'skipped_count':len(skipped)+missing, 'warning_count':sum(r is not None for _,r in selected),
            'matched_count':len(rows)+missing}
