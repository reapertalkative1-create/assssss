"""User-defined account folders. Removing a folder never deletes an account."""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import AccountGroup, AccountGroupMember, Role, TelegramAccount
from app.schemas_accounts import AccountFilters
from app.services.account_health import conditions
from app.services.account_groups import require_group

router=APIRouter(prefix='/api/account-groups',tags=['account-groups'])
admin=require_role(Role.ADMIN)

class GroupName(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name:str=Field(min_length=1,max_length=64)
    @field_validator('name')
    @classmethod
    def clean(cls,value):
        value=' '.join(value.split())
        if not value:raise ValueError('Nhập tên nhóm.')
        if len(value.casefold())>64:raise ValueError('Tên nhóm quá dài.')
        return value

class GroupAssign(BaseModel):
    model_config=ConfigDict(extra='forbid')
    group_id:uuid.UUID|None=None
    all_matching:bool=False
    account_ids:list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    exclude_ids:list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    filters:AccountFilters=Field(default_factory=AccountFilters)

async def group(db,gid):
    obj=await db.get(AccountGroup,gid)
    if not obj:raise ApiError(404,'not_found','Không tìm thấy nhóm.')
    return obj

@router.get('')
async def listing(_:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    rows=(await db.execute(select(AccountGroup.id,AccountGroup.name,func.count(AccountGroupMember.account_id)).outerjoin(AccountGroupMember,AccountGroupMember.group_id==AccountGroup.id).group_by(AccountGroup.id,AccountGroup.name,AccountGroup.name_key).order_by(AccountGroup.name_key))).all()
    return [{'id':str(gid),'name':name,'count':count} for gid,name,count in rows]

@router.post('',status_code=201)
async def create(body:GroupName,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    obj=AccountGroup(name=body.name,name_key=body.name.casefold());db.add(obj)
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'name_taken','Tên nhóm đã tồn tại.') from None
    await record_audit(db,request,'account_group.create',actor=auth.user,target_type='account_group',target_id=str(obj.id),details={'name':obj.name})
    return {'id':str(obj.id),'name':obj.name,'count':0}

@router.patch('/{gid}')
async def rename(gid:uuid.UUID,body:GroupName,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    obj=await group(db,gid);obj.name=body.name;obj.name_key=body.name.casefold()
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'name_taken','Tên nhóm đã tồn tại.') from None
    await record_audit(db,request,'account_group.rename',actor=auth.user,target_type='account_group',target_id=str(obj.id),details={'name':obj.name})
    return {'id':str(obj.id),'name':obj.name}

@router.delete('/{gid}')
async def remove(gid:uuid.UUID,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    obj=(await db.execute(select(AccountGroup).where(AccountGroup.id==gid).with_for_update())).scalar_one_or_none()
    if obj is None:raise ApiError(404,'not_found','Không tìm thấy nhóm.')
    result=await db.execute(delete(AccountGroupMember).where(AccountGroupMember.group_id==gid))
    await db.delete(obj)
    await record_audit(db,request,'account_group.delete',actor=auth.user,target_type='account_group',target_id=str(gid),details={'accounts_kept':result.rowcount or 0})
    return {'accounts_kept':result.rowcount or 0}

@router.post('/assign')
async def assign(body:GroupAssign,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    await require_group(db,body.group_id)
    if not body.all_matching and not body.account_ids:raise ApiError(422,'empty_selection','Chọn tài khoản trước.')
    filters=conditions(**body.filters.model_dump()) if body.all_matching else [TelegramAccount.id.in_(body.account_ids)]
    if body.all_matching and body.exclude_ids:filters.append(TelegramAccount.id.not_in(body.exclude_ids))
    ids=list((await db.execute(select(TelegramAccount.id).where(*filters,TelegramAccount.pending_deletion.is_(False)).order_by(TelegramAccount.id).with_for_update())).scalars())
    if not ids:raise ApiError(422,'empty_selection','Không tìm thấy tài khoản được chọn.')
    for start in range(0,len(ids),500):
        chunk=ids[start:start+500]
        await db.execute(delete(AccountGroupMember).where(AccountGroupMember.account_id.in_(chunk)))
        if body.group_id:db.add_all(AccountGroupMember(account_id=aid,group_id=body.group_id) for aid in chunk)
        await db.flush()
    await record_audit(db,request,'account_group.assign',actor=auth.user,target_type='account_group',target_id=str(body.group_id) if body.group_id else None,details={'count':len(ids)})
    return {'assigned':len(ids)}
