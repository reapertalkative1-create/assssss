import {useState} from 'react';
import {Link} from 'react-router-dom';
import {api,ApiError} from '../api/client';
import type {Account,Page} from '../api/types';
import {Alert,SelectField,TextField} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import {useAccountSelection,type AccountSelection} from '../state/accountSelection';
import type {AccountGroup} from './AccountGroups';
import {SenderChecks} from './SenderChecks';
export interface Sender extends Partial<Account> {id:string;name:string;sender_ready?:boolean;sender_reason?:string|null}
interface Resolved {items:Sender[];skipped_count:number;warning_count:number}
interface SenderPage extends Page<Sender> {counts:Record<string,number>}
const statusLabels:Record<string,string>={all:'Tất cả',ready:'Có thể chạy',live:'Live',dead:'Die / hết phiên',limited:'Bị spam',blocked:'Bị chặn',frozen:'Đóng băng',unknown:'Chưa check',error:'Cần kiểm tra lại',login:'Chưa xác thực',waiting:'Đang chờ Telegram',offline:'Worker offline',proxy_error:'Proxy die'};
const chips=['all','ready','live','dead'];
export function senderReason(a:Sender){
 if(a.sender_reason)return a.sender_reason;
 if(a.pending_deletion)return 'Đang xóa';
 if(a.health_status==='dead'||a.auth_state==='invalid')return 'Die / hết phiên';
 if(a.health_status==='frozen'||a.health_source==='manual')return 'Đóng băng';
 if(a.spam_status==='blocked')return 'Bị chặn';
 if(a.spam_status==='limited')return 'Bị spam';
 if(a.auth_state&&a.auth_state!=='authorized')return 'Chưa xác thực';
 return '';
}
function SenderBadges({a}:{a:Sender}){
 const reason=senderReason(a);
 const tone=a.sender_ready?'live':['Die / hết phiên','Bị chặn','Bị spam','Đóng băng','Proxy die'].includes(reason)?'dead':'idle';
 const label=reason||(a.sender_ready?'Có thể chạy':a.health_status==='live'?'Live':'Chưa check');
 return <span className="sender-badges"><span className={`sender-status ${tone}`}>{label}</span>{a.health_status==='live'&&!!reason&&!['Die / hết phiên','Đóng băng'].includes(reason)&&<span className="sender-status live" title="Phiên đăng nhập hoạt động; quyền gửi kiểm tra riêng">Live</span>}</span>;
}
export function SenderPicker({value,onChange,disabled=false,single=false,onBusyChange}:{value:Sender[];onChange:(value:Sender[])=>void;disabled?:boolean;single?:boolean;onBusyChange?:(busy:boolean)=>void}){
 const {saved}=useAccountSelection();
 const [search,setSearch]=useState(''),[group,setGroup]=useState(''),[status,setStatus]=useState('all'),[page,setPage]=useState(1),[busy,setBusy]=useState(false),[notice,setNotice]=useState(''),[error,setError]=useState(''),[onlySelected,setOnlySelected]=useState(false);
 const q=useDebounced(search);
 const filters={q:q||undefined,group_id:group&&group!=='ungrouped'?group:undefined,ungrouped:group==='ungrouped'?'true':undefined};
 const accounts=useQuery(signal=>api.get<SenderPage>('/api/post-routes/senders',{...filters,status_filter:status,page,page_size:50},signal),[q,group,status,page],{interval:5000});
 const groups=useQuery(signal=>api.get<AccountGroup[]>('/api/account-groups',undefined,signal),[]);
 const selectionKey=value.map(a=>a.id).join(',');
 const selectedDetails=useQuery(()=>api.post<Resolved>('/api/post-routes/senders',{account_ids:value.map(a=>a.id)}),[selectionKey],{enabled:onlySelected&&!!value.length,interval:onlySelected?5000:undefined});
 const rows=accounts.data?.items??[],ids=new Set(value.map(a=>a.id));
 const locked=disabled||busy;
 const refreshing=accounts.loading||accounts.refreshing||q!==search;
 function toggle(a:Sender){setNotice('');if(ids.has(a.id))onChange(value.filter(x=>x.id!==a.id));else onChange(single?[a]:[...value,a]);}
 function changeStatus(v:string){setStatus(v);setPage(1);setOnlySelected(false);}
 async function choose(selection:AccountSelection,statusFilter?:string){
  setBusy(true);onBusyChange?.(true);setError('');setNotice('');
  try{
   const r=await api.post<Resolved>('/api/post-routes/senders',{...selection,...(statusFilter?{status_filter:statusFilter}:{})});
   const next=new Map(value.map(a=>[a.id,a]));r.items.forEach(a=>next.set(a.id,a));
   if(next.size>1000){setError('Chọn tối đa 1.000 SS trong một đợt.');return;}
   onChange([...next.values()]);setNotice(`Đã lấy ${r.items.length} SS${r.warning_count?` · ${r.warning_count} SS cần xử lý trước khi gửi`:''}${r.skipped_count?` · ${r.skipped_count} SS đã/đang xóa`:''}.`);
  }catch(e){setError(e instanceof ApiError?e.message:'Không lấy được tài khoản.');}finally{setBusy(false);onBusyChange?.(false);}
 }
 const selectable=rows.filter(a=>!a.pending_deletion);
 const visible=onlySelected?value.map(a=>selectedDetails.data?.items.find(r=>r.id===a.id)??rows.find(r=>r.id===a.id)??a):rows;
 const counts=accounts.data?.counts??{};
 return <section className="sender-picker stack tight" aria-label="Tài khoản gửi">
  <div className="row between"><strong className="small">Tài khoản gửi <span className="hint">· Đã chọn {value.length}</span></strong><Link to="/accounts">Quản lý tài khoản</Link></div>
  <div className="sender-stats" aria-label="Lọc trạng thái tài khoản gửi">{chips.map(key=><button key={key} type="button" className={`sender-stat ${key}`} aria-pressed={status===key&&!onlySelected} disabled={locked} onClick={()=>changeStatus(key)} title={key==='live'?'Phiên đăng nhập hoạt động; không đồng nghĩa được gửi mọi nhóm':key==='ready'?'Đã xác thực, có session, worker online và không có lỗi chặn đã biết':''}><span>{key==='dead'?'Die':statusLabels[key]}</span><strong>{counts[key]??'—'}</strong></button>)}</div>
  <div className="sender-filters"><TextField label="Tìm tài khoản Telegram" value={search} disabled={locked} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Tên hoặc username…"/>
   <SelectField label="Nhóm tài khoản gửi" value={group} disabled={locked} onChange={e=>{setGroup(e.target.value);setPage(1);}}><option value="">Mọi nhóm</option><option value="ungrouped">Chưa có nhóm</option>{(Array.isArray(groups.data)?groups.data:[]).map(g=><option key={g.id} value={g.id}>{g.name} ({g.count})</option>)}</SelectField></div>
  <div className="sender-toolbar"><select className="select" aria-label="Trạng thái SS gửi" value={status} disabled={locked} onChange={e=>changeStatus(e.target.value)}>{Object.entries(statusLabels).map(([key,label])=><option key={key} value={key}>{label}{counts[key]!=null?` (${counts[key]})`:''}</option>)}</select>
   {!single&&<><button className="btn sm" disabled={locked||refreshing||!accounts.data?.total} onClick={()=>void choose({all_matching:true,account_ids:[],exclude_ids:[],filters},status)}>Chọn toàn bộ kết quả</button><button className="btn sm" disabled={locked||!saved?.count} onClick={()=>saved&&void choose(saved.selection)}>SS đã tích ({saved?.count??0})</button></>}
  </div>
  <div className="row between"><label className="small"><input type="checkbox" checked={onlySelected} onChange={e=>setOnlySelected(e.target.checked)}/> Chỉ xem đã chọn</label><button className="btn ghost sm" disabled={locked||!value.length} onClick={()=>onChange([])}>Bỏ chọn hết</button></div>
  <div className="sender-list">
   {!single&&!onlySelected&&!!rows.length&&<label className="sender-item sender-select-page"><input type="checkbox" aria-label="Chọn SS trang này" disabled={locked||refreshing||!selectable.length} checked={!!selectable.length&&selectable.every(a=>ids.has(a.id))} onChange={e=>{const checked=e.target.checked;const next=new Map(value.map(a=>[a.id,a]));selectable.forEach(a=>checked?next.set(a.id,a):next.delete(a.id));if(next.size>1000){setError('Chọn tối đa 1.000 SS trong một đợt.');return;}onChange([...next.values()]);}}/><strong>Chọn trang này</strong></label>}
   {visible.map(a=><label className={`sender-item ${ids.has(a.id)?'picked':''}`} key={a.id}><input type={single?'radio':'checkbox'} name={single?'single-sender':undefined} aria-label={`Chọn SS ${a.name}`} checked={ids.has(a.id)} disabled={locked||!!a.pending_deletion&&!ids.has(a.id)||!onlySelected&&refreshing||!ids.has(a.id)&&value.length>=1000} onChange={()=>toggle(a)}/><span className="sender-identity"><strong>{a.name}</strong><small>{a.group_name??'Chưa có nhóm'}{a.telegram_username?` · @${a.telegram_username}`:''}</small></span><SenderBadges a={a}/></label>)}
   {accounts.loading&&!onlySelected?<p className="hint">Đang tải…</p>:!visible.length&&<p className="hint">{onlySelected?'Chưa chọn SS.':status==='ready'?'Chưa có SS sẵn sàng. Chọn Tất cả để kiểm tra tài khoản lỗi.':'Không có SS phù hợp.'}</p>}
  </div>
  {!onlySelected&&<div className="row between"><span className="hint">{accounts.data?.total??0} SS · Trang {page}/{Math.max(1,Math.ceil((accounts.data?.total??0)/50))}</span><div className="row"><button className="btn ghost sm" disabled={locked||page===1||refreshing} onClick={()=>setPage(p=>p-1)}>Trước</button><button className="btn ghost sm" disabled={locked||refreshing||page*50>=(accounts.data?.total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div></div>}
  {!!value.length&&<SenderChecks ids={value.map(a=>a.id)} disabled={locked} onFinished={()=>{accounts.reload();selectedDetails.reload();}}/>}
  <p className="hint sender-help">SS lỗi vẫn chọn được. Kiểm tra phiên và quyền nhóm trước khi gửi.</p>
  {notice&&<p className="hint" role="status">{notice}</p>}{(error||accounts.error||groups.error||onlySelected&&selectedDetails.error)&&<Alert tone="bad">{error||accounts.error?.message||groups.error?.message||selectedDetails.error?.message}</Alert>}
 </section>;
}
