import {useEffect,useRef,useState} from 'react';
import {Link} from 'react-router-dom';
import {api,ApiError} from '../api/client';
import type {Job,Page,Route} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,Pill,SelectField,TextArea,TextField} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {fmtDateTime} from '../lib/format';
import {errorLabel,jobStatus} from '../lib/labels';

const pending=(r:Route)=>['pending','retry_wait','claimed','running'].reduce((n,k)=>n+(r.stats[k]??0),0);
export const deliveryDone=(r:Route)=>!!r.link_config?.queued_at&&pending(r)===0&&Object.values(r.stats).some(n=>n>0);
export function deliveryLabel(r:Route){
 if(!r.link_config)return r.status==='active'?'Theo dõi nguồn':r.status==='paused'?'Tạm dừng':'Đã dừng';
 if(deliveryDone(r))return (r.stats.failed??0)+(r.stats.dead_letter??0)>0?'Xong · có lỗi':'Hoàn tất';
 if(r.account_restriction)return 'SS đang hạn chế';
 if(r.account_wait_until&&Date.parse(r.account_wait_until)>Date.now())return 'Telegram yêu cầu chờ';
 if(r.verification_pending)return 'Đang kiểm tra';
 if(r.verification_error)return 'Kiểm tra chưa đạt';
 if(r.status==='paused')return 'Tạm dừng';
 if(r.status==='active')return r.link_config.scheduled_at&&Date.parse(r.link_config.scheduled_at)>Date.now()?'Chờ lịch':'Đang gửi';
 if(r.link_config.queued_at)return 'Đã dừng';
 return r.verified?'Sẵn sàng':'Bản nháp';
}
import {SenderPicker,type Sender} from './SenderPicker';
import {useAccountSelection} from '../state/accountSelection';


export function PostRouteForm({route,clone=false,fromAccounts=false,onClose,onSaved}:{route?:Route;clone?:boolean;fromAccounts?:boolean;onClose:()=>void;onSaved:(r:Route)=>void}){
 const config=route?.link_config;
 const [senders,setSenders]=useState<Sender[]>(route?[{id:route.account_id,name:route.account_name??route.account_id}]:[]);
 const {saved}=useAccountSelection();const initialized=useRef(false);
 const [requestId,setRequestId]=useState(()=>crypto.randomUUID());
 useEffect(()=>{if(!fromAccounts||!saved||initialized.current)return;initialized.current=true;api.post<{items:Sender[];skipped_count:number}>('/api/post-routes/senders',saved.selection).then(r=>{setSenders(r.items);if(r.skipped_count)setError(`Bỏ qua ${r.skipped_count} SS đã/đang xóa.`);}).catch(e=>setError(e instanceof ApiError?e.message:'Không lấy được SS đã tích.'));},[fromAccounts,saved]);
 const [link,setLink]=useState(config?.post_link??''),[targets,setTargets]=useState(config?.targets.join('\n')??'');
 const [delay,setDelay]=useState(String(config?.delay_seconds??60));
 const [mode,setMode]=useState<'forward'|'copy'>(route?.mode??'forward');
 const [selecting,setSelecting]=useState(false);
 const [busy,setBusy]=useState(false),[loadingFile,setLoadingFile]=useState(false),[error,setError]=useState('');
 async function file(file?:File){if(!file)return;setError('');if(file.size>500000){setError('File nhóm tối đa 500 KB.');return;}setLoadingFile(true);try{setTargets(await file.text());}catch{setError('Không đọc được file TXT.');}finally{setLoadingFile(false);}}
 async function save(){
  if(!senders.length||!link.trim()||!targets.trim()){setError('Chọn tài khoản, dán link bài viết và danh sách nhóm.');return;}
  if(!/^\d+$/.test(delay)||Number(delay)<5||Number(delay)>86400){setError('Thời gian nghỉ từ 5 đến 86.400 giây.');return;}
  setBusy(true);setError('');
  const body={name:route&&!clone?route.name:`Đợt gửi ${crypto.randomUUID().slice(0,8)}`,account_id:senders[0]?.id,post_link:link.trim(),targets_text:targets,delay_seconds:Number(delay),scheduled_at:null,mode};
  try{if(route&&!clone){onSaved(await api.patch<Route>(`/api/post-routes/${route.id}`,body));}else{const {account_id:_,name:__,scheduled_at:___,...post}=body;const result=await api.post<{items:Route[]}>('/api/post-routes/batches',{...post,account_ids:senders.map(a=>a.id),request_id:requestId});onSaved(result.items[0]);}}
  catch(e){setError(e instanceof ApiError?e.message:'Không lưu được đợt gửi.');setBusy(false);}
 }
 useEffect(()=>{setRequestId(crypto.randomUUID());},[link,targets,delay,mode]);
 const lines=targets.split(/\r?\n/).filter(s=>s.trim()&&!s.trim().startsWith('#')).length;
 return <Modal wide title={route&&!clone?'Sửa đợt gửi':'Gửi bài từ liên kết'} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button><button className="btn primary" disabled={busy||selecting||loadingFile} onClick={()=>void save()}>{busy?'Đang lưu…':'Lưu đợt gửi'}</button></>}>
  <div className="post-form-grid">
   <div className="stack tight">
    <SenderPicker onBusyChange={setSelecting} value={senders} onChange={items=>{setSenders(items);setRequestId(crypto.randomUUID());}} disabled={busy} single={!!route&&!clone}/>
    {!route||clone?<p className="hint">Chia nhóm nhận giữa {senders.length} SS đã chọn; mỗi nhóm giao cho một SS. SS dư sẽ không nhận việc. Lưu bản nháp để xem phân công trước khi gửi.</p>:null}
    <div className="sender-filters"><SelectField label="Cách gửi bài" value={mode} onChange={e=>setMode(e.target.value as 'forward'|'copy')}><option value="forward">Chuyển tiếp · giữ nguồn</option><option value="copy">Sao chép nội dung</option></SelectField>
    <TextField label="Nghỉ giữa hai nhóm (giây)" type="number" min={5} max={86400} value={delay} onChange={e=>setDelay(e.target.value)}/></div>
    <p className="hint">Gửi một lượt sau khi bạn bấm bắt đầu; SS đang tắt sẽ được bật khi bắt đầu gửi. FloodWait áp dụng cho cả SS, không tự đổi tài khoản.</p>
   </div>
   <div className="stack tight">
    <TextField label="Liên kết bài viết Telegram" value={link} onChange={e=>setLink(e.target.value)} placeholder="https://t.me/tenkenh/123" hint="Dán liên kết lấy từ Sao chép liên kết tin nhắn. Mỗi đợt một bài."/>
    <label className="field">File danh sách nhóm .txt<input type="file" accept=".txt,text/plain" disabled={busy||selecting||loadingFile} onChange={e=>void file(e.target.files?.[0])}/></label>
    <TextArea label="Nhóm nhận bài" rows={11} value={targets} maxLength={500000} disabled={loadingFile} onChange={e=>setTargets(e.target.value)} spellCheck={false} placeholder={'@nhom_cua_ban\nhttps://t.me/nhom_cua_ban_2\n-1001234567890'}/>
    <div className="row between"><span className="hint">{lines} dòng · tối đa 1.000 nhóm · tự bỏ dòng trống, # và trùng</span>{config?.checks?.some(c=>!c.can_send)&&<button className="btn sm" onClick={()=>setTargets(config.checks!.filter(c=>c.can_send).map(c=>config.targets[c.index]).join('\n'))}>Chỉ giữ nhóm hợp lệ</button>}</div>
    <p className="hint">Chỉ dùng nhóm/kênh bạn có quyền đăng. Link mời chỉ tra được nhóm SS đã tham gia; ứng dụng không tự vào nhóm. Bài nguồn bảo vệ chuyển tiếp sẽ được báo lỗi.</p>
   </div>
  </div>
  {error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}

export function PostRouteDetail({route,onClose,onVerify,onAction}:{route:Route;onClose:()=>void;onVerify:()=>Promise<void>;onAction:(action:'start'|'pause'|'resume'|'stop')=>Promise<void>}){
 const live=useQuery(signal=>api.get<Route>(`/api/routes/${route.id}`,undefined,signal),[route.id],{interval:2000});const r=live.data??route;const c=r.link_config!;
 const [tab,setTab]=useState('groups'),[filter,setFilter]=useState(''),[page,setPage]=useState(1),[busy,setBusy]=useState(false);
 const jobs=useQuery(signal=>api.get<Page<Job>>('/api/jobs',{route_id:r.id,status:filter||undefined,page,page_size:50},signal),[r.id,filter,page],{enabled:!!c.queued_at,interval:2000});
 const [groupPage,setGroupPage]=useState(1);
 async function action(a:'start'|'pause'|'resume'|'stop'){setBusy(true);try{await onAction(a);live.reload();jobs.reload();}finally{setBusy(false);}}
 const checks=new Map(c.checks?.map(x=>[x.index,x]));
 const title=(id:number)=>c.checks?.find(v=>v.id===id)?.title||String(id);
 return <Modal wide title={r.name} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{!c.queued_at&&<button className="btn" disabled={busy||r.verification_pending} onClick={async()=>{setBusy(true);try{await onVerify();live.reload();}finally{setBusy(false);}}}>{r.verification_pending?'Đang kiểm tra…':'Kiểm tra nhóm'}</button>}{r.status==='active'&&!deliveryDone(r)&&<><button className="btn" disabled={busy} onClick={()=>void action('pause')}>Tạm dừng</button><button className="btn" disabled={busy} onClick={()=>void action('stop')}>Dừng</button></>}{r.status==='paused'&&<button className="btn primary" disabled={busy} onClick={()=>void action('resume')}>Tiếp tục</button>}{r.status==='stopped'&&r.verified&&!deliveryDone(r)&&<button className="btn primary" disabled={busy} onClick={()=>void action('start')}>{c.queued_at?'Chạy tiếp':'Bắt đầu gửi'}</button>}</>}>
  <div className="post-detail-head"><div><strong>{r.account_name}</strong><span className="hint"> · {r.mode==='copy'?'Sao chép':'Giữ nguồn'} · nghỉ {c.delay_seconds}s / nhóm</span><p><a href={c.post_link} target="_blank" rel="noreferrer">{c.post_link}</a></p></div><Pill tone={deliveryDone(r)?'ok':r.verification_error?'bad':r.status==='active'?'ok':'warn'}>{deliveryLabel(r)}</Pill></div>
  <div className="proxy-list-summary"><strong>{r.destination_chat_ids.length||c.targets.length} nhóm</strong><span className="proxy-count-live">Đã gửi {r.stats.succeeded??0}</span><span>Đang chờ {pending(r)}</span><span className="proxy-count-dead">Lỗi {(r.stats.failed??0)+(r.stats.dead_letter??0)}</span>{c.scheduled_at&&<span>Lịch: {fmtDateTime(c.scheduled_at)}</span>}</div>
  {r.verification_error&&<Alert tone="bad">{errorLabel(r.verification_error)||r.verification_error} Kiểm tra bài nguồn và các nhóm bên dưới trước khi chạy.</Alert>}
  {r.account_restriction&&<Alert tone="bad">SS đang bị hạn chế/đóng băng, hàng đợi được giữ lại. <Link to="/accounts" onClick={onClose}>Kiểm tra tài khoản Telegram</Link>.</Alert>}
  {r.account_wait_until&&Date.parse(r.account_wait_until)>Date.now()&&<Alert>Telegram yêu cầu SS chờ đến {fmtDateTime(r.account_wait_until)}. Không đổi tài khoản để tiếp tục gửi.</Alert>}
  {live.error&&<Alert tone="bad">{live.error.message}</Alert>}
  <div className="seg"><button aria-pressed={tab==='groups'} onClick={()=>setTab('groups')}>Nhóm & quyền gửi</button><button aria-pressed={tab==='jobs'} onClick={()=>setTab('jobs')}>Tiến độ từng nhóm</button></div>
  {tab==='groups'?<><div className="proxy-list-table"><table className="table"><thead><tr><th>Nhóm</th><th>Tên Telegram</th><th>Quyền gửi</th></tr></thead><tbody>{c.targets.slice((groupPage-1)*50,groupPage*50).map((ref,i)=>{const check=checks.get((groupPage-1)*50+i);return <tr key={ref}><td className="mono">{ref}</td><td>{check?.title||'—'}</td><td><Pill tone={!check?'idle':check.can_send?'ok':'bad'}>{!check?'Chưa kiểm tra':check.can_send?'Gửi được':check.error_code==='not_joined'?'Chưa tham gia':check.error_code==='not_a_group'?'Không phải nhóm':'Không có quyền'}</Pill></td></tr>;})}</tbody></table></div><div className="row"><button className="btn sm" disabled={groupPage<=1} onClick={()=>setGroupPage(p=>p-1)}>Trước</button><span className="hint">Trang {groupPage}/{Math.max(1,Math.ceil(c.targets.length/50))}</span><button className="btn sm" disabled={groupPage*50>=c.targets.length} onClick={()=>setGroupPage(p=>p+1)}>Sau</button></div></>:<>
   <select className="select" aria-label="Lọc tiến độ gửi" value={filter} onChange={e=>{setFilter(e.target.value);setPage(1);}}><option value="">Mọi kết quả</option>{Object.entries(jobStatus).map(([v,s])=><option key={v} value={v}>{s.label}</option>)}</select>
   {jobs.error&&<Alert tone="bad">{jobs.error.message}</Alert>}
   <div className="proxy-list-table"><table className="table"><thead><tr><th>Nhóm</th><th>Kết quả</th><th>Sớm nhất</th></tr></thead><tbody>{jobs.data?.items.map(j=><tr key={j.id}><td>{title(j.dest_chat_id)}</td><td><Pill tone={jobStatus[j.status].tone}>{jobStatus[j.status].label}</Pill>{j.last_error_code&&<span className="hint proxy-list-reason">{errorLabel(j.last_error_code)}</span>}</td><td>{fmtDateTime(j.available_at)}</td></tr>)}</tbody></table></div>
   {!c.queued_at&&<p className="hint">Chưa tạo hàng đợi. Kiểm tra nhóm rồi bấm Bắt đầu gửi.</p>}
   <div className="row"><button className="btn sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Trước</button><span className="hint">Trang {page}/{Math.max(1,Math.ceil((jobs.data?.total??0)/50))}</span><button className="btn sm" disabled={page*50>=(jobs.data?.total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div>
  </>}
 </Modal>;
}
