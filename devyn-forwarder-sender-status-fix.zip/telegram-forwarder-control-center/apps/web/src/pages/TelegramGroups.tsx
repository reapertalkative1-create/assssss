import {useEffect,useState} from 'react';
import {api,ApiError} from '../api/client';
import type {Account,Command,CommandAccepted} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert} from '../components/ui';
import {errorLabel} from '../lib/labels';

type Group={id:string;title:string;username:string|null};
export function TelegramGroups({account,onClose}:{account:Account;onClose:()=>void}){
 const [items,setItems]=useState<Group[]>([]),[loading,setLoading]=useState(false),[error,setError]=useState(''),[search,setSearch]=useState(''),[truncated,setTruncated]=useState(false),[revision,setRevision]=useState(0);
 useEffect(()=>{const controller=new AbortController();let active=true;
  async function load(){setLoading(true);setError('');try{
   const accepted=await api.post<CommandAccepted>(`/api/accounts/${account.id}/telegram-groups`);
   for(let i=0;i<20;i++){
    const cmd=await api.get<Command>(`/api/accounts/${account.id}/commands/${accepted.command_id}`,{wait_seconds:15},controller.signal);
    if(cmd.status==='done'){if(active){setItems(Array.isArray(cmd.result?.groups)?cmd.result.groups as Group[]:[]);setTruncated(!!cmd.result?.truncated);}return;}
    if(cmd.status==='failed'||cmd.status==='expired')throw new Error(errorLabel(cmd.error_code,cmd.retry_after)||'Worker không hoàn thành kiểm tra.');
   }
   throw new Error('Worker phản hồi quá lâu. Hãy thử làm mới.');
  }catch(e){if(active)setError(e instanceof ApiError||e instanceof Error?e.message:'Không lấy được danh sách nhóm.');}finally{if(active)setLoading(false);}}
  void load();return()=>{active=false;controller.abort();};
 },[account.id,revision]);
 const filtered=items.filter(g=>`${g.title} ${g.username??''} ${g.id}`.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase()));
 function download(){const text=filtered.map(g=>g.username?`https://t.me/${g.username}`:g.id).join('\n');const url=URL.createObjectURL(new Blob([text+'\n'],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='nhom-telegram.txt';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 return <Modal wide title={`Nhóm Telegram · ${account.name}`} onClose={onClose} footer={<><button className="btn" disabled={loading} onClick={()=>setRevision(v=>v+1)}>Làm mới</button><button className="btn" disabled={loading||!filtered.length} onClick={download}>Xuất TXT ({filtered.length})</button><button className="btn primary" onClick={onClose}>Đóng</button></>}>
  <p className="hint">Các nhóm mà SS này đã tham gia. TXT gồm username hoặc ID của nhóm theo bộ lọc hiện tại.</p>
  <input className="input" aria-label="Tìm nhóm Telegram" placeholder="Tìm tên, username hoặc ID…" value={search} onChange={e=>setSearch(e.target.value)}/>
  {error&&<Alert tone="bad">{error}</Alert>}{truncated&&<Alert>Danh sách giới hạn 2.000 nhóm; có thể còn nhóm chưa hiển thị.</Alert>}
  <div className="proxy-list-table"><table className="table"><thead><tr><th>Tên nhóm</th><th>Username</th><th>ID</th></tr></thead><tbody>{filtered.slice(0,2000).map(g=><tr key={g.id}><td>{g.title||'Không có tên'}</td><td>{g.username?`@${g.username}`:'Riêng tư'}</td><td className="mono">{g.id}</td></tr>)}</tbody></table></div>
  <p className="hint">{loading?'Đang lấy danh sách…':`${filtered.length} / ${items.length} nhóm`}</p>
 </Modal>;
}
