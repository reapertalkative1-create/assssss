import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn()}};});
import {api} from '../api/client';
import {SenderChecks} from './SenderChecks';
it('checks exactly the selected SS and can check again after finishing the first job',async()=>{
 const user=userEvent.setup(),finished=vi.fn();let next=0;
 vi.mocked(api.post).mockImplementation(async()=>({id:`j${++next}`,status:'running',total:2,counts:{pending:2}}));
 vi.mocked(api.get).mockImplementation(async(path)=>({id:path.split('/').at(-1),status:'done',total:2,counts:{done:1,error:1},items:[{name:'Expired SS',status:'error',error_code:'session_revoked'}]}));
 render(<SenderChecks ids={['error1','error2']} onFinished={finished}/>);
 await user.click(screen.getByRole('button',{name:'Kiểm tra SS (2)'}));
 await waitFor(()=>expect(finished).toHaveBeenCalledTimes(1));
 expect(api.post).toHaveBeenCalledWith('/api/account-bulk',{action:'check',account_ids:['error1','error2'],all_matching:false,exclude_ids:[],filters:{}});
 expect(screen.getByRole('status')).toHaveTextContent('2/2 · 1 lỗi');
 await user.selectOptions(screen.getByLabelText('Loại kiểm tra SS'),'proxy_check');await user.click(screen.getByRole('button',{name:'Kiểm tra SS (2)'}));
 await waitFor(()=>expect(finished).toHaveBeenCalledTimes(2));expect(api.get).toHaveBeenCalledWith('/api/account-bulk/j2',undefined,expect.anything());
 expect(api.post).toHaveBeenLastCalledWith('/api/account-bulk',expect.objectContaining({action:'proxy_check',account_ids:['error1','error2']}));
});
