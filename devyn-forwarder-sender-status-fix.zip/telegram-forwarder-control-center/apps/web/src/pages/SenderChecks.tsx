import {useEffect,useRef,useState} from 'react';
import {api,ApiError} from '../api/client';
import {useQuery} from '../hooks/useQuery';
import {errorLabel} from '../lib/labels';
interface CheckJob {id:string;status:string;total:number;counts:Record<string,number>;items?:{name:string;status:string;error_code:string|null}[]}
export function SenderChecks({ids,disabled=false,onFinished}:{ids:string[];disabled?:boolean;onFinished:()=>void}){
 const [action,setAction]=useState('check'),[jobId,setJobId]=useState(''),[watch,setWatch]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const handled=useRef('');
 const result=useQuery(signal=>api.get<CheckJob>(`/api/account-bulk/${jobId}`,undefined,signal),[jobId],{enabled:!!jobId,interval:watch?2000:undefined});
 useEffect(()=>{if(result.data?.id===jobId&&['done','cancelled'].includes(result.data.status)&&handled.current!==jobId){handled.current=jobId;setWatch(false);onFinished();}},[result.data,jobId,onFinished]);
 async function run(){
  if(!ids.length)return;setBusy(true);setError('');
  try{const r=await api.post<CheckJob>('/api/account-bulk',{action,account_ids:ids,all_matching:false,exclude_ids:[],filters:{}});setJobId(r.id);setWatch(true);}
  catch(e){setError(e instanceof ApiError?e.message:'Không chạy được kiểm tra.');}finally{setBusy(false);}
 }
 const job=result.data?.id===jobId?result.data:undefined,done=job?(job.counts.done??0)+(job.counts.error??0)+(job.counts.cancelled??0):0;
 return <div className="sender-checks">
  <div className="row"><select className="select" aria-label="Loại kiểm tra SS" value={action} disabled={disabled||busy||watch} onChange={e=>setAction(e.target.value)}><option value="check">Kiểm tra phiên</option><option value="spam_check">Check spam / đóng băng</option><option value="proxy_check">Check proxy</option></select><button className="btn sm" disabled={disabled||busy||watch||!ids.length} onClick={()=>void run()}>{busy?'Đang tạo…':watch?'Đang kiểm tra…':`Kiểm tra SS (${ids.length})`}</button></div>
  {action==='spam_check'&&<span className="hint">Hỏi @SpamBot; có thể dùng lại kết quả mới trong 10 phút.</span>}
  {job&&<div className="hint" role="status">{watch?'Đang xử lý':'Đã xử lý'} {done}/{job.total} · {job.counts.error??0} lỗi</div>}
  {!!job?.counts.error&&<details className="sender-check-errors"><summary>Xem lỗi kiểm tra</summary>{job.items?.filter(i=>i.status==='error').slice(0,5).map((i,n)=><div className="hint" key={n}>{i.name}: {errorLabel(i.error_code)||'Không kiểm tra được'}</div>)}{job.counts.error>5&&<div className="hint">Xem thêm lỗi tại bảng Tài khoản Telegram.</div>}</details>}
  {(error||result.error)&&<p className="hint bad-text">{error||result.error?.message}</p>}
 </div>;
}
