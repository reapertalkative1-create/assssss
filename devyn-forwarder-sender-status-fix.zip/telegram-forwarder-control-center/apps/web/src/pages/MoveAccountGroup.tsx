import {useState} from 'react';
import {api,ApiError} from '../api/client';
import {Modal} from '../components/Modal';
import {Alert,SelectField} from '../components/ui';
import type {AccountGroup} from './AccountGroups';

export type GroupSelection={all_matching:boolean;account_ids:string[];exclude_ids:string[];filters:Record<string,string|undefined>};

export function GroupSelect({groups,value,onChange,disabled=false}:{groups:AccountGroup[];value:string;onChange:(value:string)=>void;disabled?:boolean}){
 return <SelectField label="Nhóm tài khoản" value={value} onChange={e=>onChange(e.target.value)} disabled={disabled}>
  <option value="">Chưa có nhóm</option>{groups.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}
  {value&&!groups.some(g=>g.id===value)&&<option value={value}>Nhóm không còn tồn tại — chọn lại</option>}
 </SelectField>;
}

export function MoveAccountGroup({groups,selection,count,currentGroupId,onClose,onSaved}:{groups:AccountGroup[];selection:GroupSelection;count:number;currentGroupId?:string|null;onClose:()=>void;onSaved:(count:number)=>void}){
 const [target,setTarget]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function save(){
  if(!target)return;setBusy(true);setError('');
  try{const result=await api.post<{assigned:number}>('/api/account-groups/assign',{...selection,group_id:target==='remove'?null:target});onSaved(result.assigned);}
  catch(e){setError(e instanceof ApiError?e.message:'Không đổi được nhóm.');setBusy(false);}
 }
 return <Modal title={`Đổi nhóm · ${count} SS`} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Hủy</button><button className="btn primary" disabled={busy||!target||!count} onClick={()=>void save()}>{busy?'Đang chuyển…':'Lưu nhóm'}</button></>}>
  {currentGroupId&&<p className="hint">Nhóm hiện tại: {groups.find(g=>g.id===currentGroupId)?.name??'—'}</p>}
  <SelectField label="Chuyển đến nhóm" value={target} disabled={busy} onChange={e=>setTarget(e.target.value)}><option value="">Chọn nhóm…</option>{groups.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}<option value="remove">Bỏ khỏi nhóm</option></SelectField>
  <p className="hint">Chuyển phân loại cho {count} SS, giữ nguyên session và proxy.</p>{error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}
