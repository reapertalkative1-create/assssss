import {useState} from 'react';
import {api,ApiError,request} from '../api/client';
import {Modal} from '../components/Modal';
import {Alert,TextField} from '../components/ui';
import {AccountGroupMembers} from './AccountGroupMembers';

export interface AccountGroup {id:string;name:string;count:number}
type Selection={all_matching:boolean;account_ids:string[];exclude_ids:string[];filters:Record<string,string|undefined>};
export function AccountGroups({groups,selection,count,onClose,onChanged,onImport}:{groups:AccountGroup[];selection:Selection;count:number;onClose:()=>void;onChanged:(assigned:boolean)=>void;onImport?:(groupId:string)=>void}){
 const [name,setName]=useState(''),[editing,setEditing]=useState(''),[target,setTarget]=useState(''),[opened,setOpened]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const current=groups.find(g=>g.id===opened);
 async function perform(fn:()=>Promise<unknown>,assigned=false){setBusy(true);setError('');setNotice('');try{await fn();onChanged(assigned);}catch(e){setError(e instanceof ApiError?e.message:'Không thực hiện được.');}finally{setBusy(false);}}
 async function save(){if(!name.trim()){setError('Nhập tên nhóm.');return;}await perform(async()=>{if(editing)await api.patch(`/api/account-groups/${editing}`,{name:name.trim()});else await api.post('/api/account-groups',{name:name.trim()});setEditing('');setName('');});}
 async function assign(){if(!target)return;await perform(async()=>{const result=await api.post<{assigned:number}>('/api/account-groups/assign',{...selection,group_id:target==='remove'?null:target});setNotice(target==='remove'?`Đã bỏ ${result.assigned} SS khỏi nhóm.`:`Đã thêm ${result.assigned} SS vào nhóm.`);if(target!=='remove')setOpened(target);setTarget('');},true);}
 return <Modal wide title="Nhóm tài khoản" onClose={onClose} dismissible={!busy} footer={<button className="btn primary" disabled={busy} onClick={onClose}>Đóng</button>}>
  {current?<AccountGroupMembers key={current.id} group={current} groups={groups} onImport={onImport?()=>onImport(current.id):undefined} onBack={()=>setOpened('')} onChanged={()=>onChanged(true)}/>:<>
   <p className="hint">Mỗi session thuộc tối đa một nhóm. Xóa nhóm chỉ bỏ phân loại, không xóa session.</p>
   <div className="row group-create"><TextField label={editing?'Đổi tên nhóm':'Tạo nhóm'} value={name} maxLength={64} onChange={e=>setName(e.target.value)} placeholder="Tên nhóm…"/><button className="btn sm primary" disabled={busy} onClick={()=>void save()}>{editing?'Lưu':'Tạo nhóm'}</button>{editing&&<button className="btn sm" onClick={()=>{setEditing('');setName('');}}>Hủy</button>}</div>
   <div className="account-group-list">{groups.length===0?<p className="hint">Chưa có nhóm nào.</p>:groups.map(g=><div className="account-group-item" key={g.id}><button className="group-open" onClick={()=>{setOpened(g.id);setNotice('');}}><strong>{g.name}</strong><span className="hint"> · {g.count} SS</span></button><div className="row"><button className="btn sm" disabled={busy} onClick={()=>setOpened(g.id)}>Xem SS</button>{onImport&&<button className="btn sm" disabled={busy} onClick={()=>onImport(g.id)}>Nhập SS mới</button>}<button className="btn sm" disabled={busy} onClick={()=>{setEditing(g.id);setName(g.name);}}>Đổi tên</button><button className="btn sm danger" disabled={busy} onClick={()=>void perform(()=>request('DELETE',`/api/account-groups/${g.id}`))}>Xóa nhóm</button></div></div>)}</div>
   <div className="account-group-assign"><strong>Chuyển SS đã chọn ({count})</strong><div className="row"><select className="select" aria-label="Nhóm đích" value={target} onChange={e=>setTarget(e.target.value)}><option value="">Chọn nhóm…</option>{groups.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}<option value="remove">Bỏ khỏi nhóm</option></select><button className="btn sm primary" disabled={busy||!count||!target} onClick={()=>void assign()}>Áp dụng ({count})</button></div></div>
   {error&&<Alert tone="bad">{error}</Alert>}{notice&&<Alert tone="ok">{notice}</Alert>}
  </>}
 </Modal>;
}
