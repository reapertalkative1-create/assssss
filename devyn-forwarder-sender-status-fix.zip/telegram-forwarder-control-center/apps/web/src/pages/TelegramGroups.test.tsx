import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {beforeEach,expect,it,vi} from 'vitest';
vi.mock('../api/client',()=>({api:{post:vi.fn(),get:vi.fn()},ApiError:class extends Error{}}));
import {api} from '../api/client';
import {TelegramGroups} from './TelegramGroups';
import type {Account} from '../api/types';
beforeEach(()=>{vi.clearAllMocks();vi.mocked(api.post).mockResolvedValue({command_id:'cmd1'});vi.mocked(api.get).mockResolvedValue({status:'done',result:{groups:[{id:'-100123',title:'Nhóm A',username:'group_a'},{id:'-124',title:'Riêng',username:null}],truncated:false}});});
it('loads one account’s joined groups and filters by name',async()=>{
 const user=userEvent.setup();render(<TelegramGroups account={{id:'a1',name:'SS'} as Account} onClose={()=>{}}/>);
 expect(await screen.findByText('Nhóm A')).toBeInTheDocument();expect(screen.getByText('Riêng')).toBeInTheDocument();
 await user.type(screen.getByLabelText('Tìm nhóm Telegram'),'Riêng');expect(screen.queryByText('Nhóm A')).not.toBeInTheDocument();expect(screen.getByText('1 / 2 nhóm')).toBeInTheDocument();
 expect(api.post).toHaveBeenCalledWith('/api/accounts/a1/telegram-groups');expect(screen.getByRole('button',{name:'Xuất TXT (1)'})).toBeEnabled();
});
it('shows a worker failure instead of an empty success',async()=>{
 vi.mocked(api.get).mockResolvedValue({status:'failed',error_code:'flood_wait',retry_after:30});render(<TelegramGroups account={{id:'a1',name:'SS'} as Account} onClose={()=>{}}/>);
 await waitFor(()=>expect(screen.getByRole('alert')).toBeInTheDocument());expect(screen.getByRole('button',{name:'Xuất TXT (0)'})).toBeDisabled();
});
