import { Navigate, Route, Routes } from "react-router-dom";
import {AccountSelectionProvider} from "./state/accountSelection";
import {Brand} from "./components/Brand";
import { Layout } from "./components/Layout";
import { EmptyState, Skeleton } from "./components/ui";
import { AccountsPage } from "./pages/Accounts";
import { AuditPage } from "./pages/Audit";
import { DashboardPage } from "./pages/Dashboard";
import { JobsPage } from "./pages/Jobs";
import { LoginPage } from "./pages/Login";
import { LogsPage } from "./pages/Logs";
import { RoutesPage } from "./pages/Routes";
import { SettingsPage } from "./pages/Settings";
import { UsersPage } from "./pages/Users";
import { WorkersPage } from "./pages/Workers";
import { useAuth } from "./state/auth";

export function App() {
  const { user, checking, isAdmin } = useAuth();
  if (checking) return <div className="app-loading"><Brand/><div style={{width:180}}><Skeleton/></div></div>;
  if (!user) return <LoginPage />;
  return (
    <AccountSelectionProvider key={user.id}><Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="accounts" element={<AccountsPage />} />
        <Route path="routes" element={<RoutesPage />} />
        <Route path="jobs" element={<JobsPage />} />
        <Route path="logs" element={<LogsPage />} />
        <Route path="workers" element={<WorkersPage />} />
        <Route path="users" element={isAdmin ? <UsersPage /> : <Navigate to="/" replace />} />
        <Route path="audit" element={isAdmin ? <AuditPage /> : <Navigate to="/" replace />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<EmptyState title="Không tìm thấy trang">Đường dẫn này không tồn tại.</EmptyState>} />
      </Route>
    </Routes></AccountSelectionProvider>
  );
}
