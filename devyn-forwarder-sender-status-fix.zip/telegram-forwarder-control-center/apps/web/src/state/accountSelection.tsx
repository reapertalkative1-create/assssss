import {createContext,useContext,useMemo,useState,type ReactNode} from 'react';
export interface AccountSelection {all_matching:boolean;account_ids:string[];exclude_ids:string[];filters:Record<string,string|undefined>}
export interface SelectedAccounts {selection:AccountSelection;count:number}
const Ctx=createContext<{saved:SelectedAccounts|null;setSaved:(value:SelectedAccounts|null)=>void}>({saved:null,setSaved:()=>{}});
export const useAccountSelection=()=>useContext(Ctx);
/** Memory-only selection, cleared when the authenticated app unmounts. */
export function AccountSelectionProvider({children}:{children:ReactNode}){
 const [saved,setSaved]=useState<SelectedAccounts|null>(null);
 const value=useMemo(()=>({saved,setSaved}),[saved]);
 return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
