"""Organize accounts into groups without changing Telegram sessions."""
from alembic import op
import sqlalchemy as sa
revision='0014'
down_revision='0013'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('account_groups',sa.Column('id',sa.Uuid(),primary_key=True),sa.Column('name',sa.String(64),nullable=False),sa.Column('name_key',sa.String(64),nullable=False,unique=True))
    op.create_table('account_group_members',sa.Column('account_id',sa.Uuid(),sa.ForeignKey('telegram_accounts.id',ondelete='CASCADE'),primary_key=True),sa.Column('group_id',sa.Uuid(),sa.ForeignKey('account_groups.id',ondelete='CASCADE'),nullable=False))
    op.create_index('ix_account_group_members_group_id','account_group_members',['group_id'])

def downgrade():
    op.drop_index('ix_account_group_members_group_id',table_name='account_group_members')
    op.drop_table('account_group_members')
    op.drop_table('account_groups')
