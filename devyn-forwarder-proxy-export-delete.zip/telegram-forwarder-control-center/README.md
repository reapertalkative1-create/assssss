# Nút xóa trực tiếp + lọc/xuất proxy

Nút đỏ Xóa đã chọn đã đưa ra ngoài menu. Có lọc proxy sống/die/chưa check và Xuất proxy thành proxies-live.txt hoặc proxies-die.txt. [Hướng dẫn](HUONG_DAN_XUAT_PROXY.md) · [Kiểm thử](KIEM_THU_XUAT_PROXY.md).

Giữ .env.docker/volume, giải nén đè đúng thư mục cũ rồi chạy setup.cmd một lần; sau đó dùng run.cmd. Head vẫn 0010.

# Trang tài khoản tinh gọn

Bỏ khung check/lọc trùng và giải thích dài, gom vào một thanh điều khiển. Bộ lọc phụ ở Lọc thêm; check/quản lý qua menu Thao tác session, phạm vi đổi theo các SS đã tích. [Hướng dẫn](HUONG_DAN_THANH_DIEU_KHIEN_GON.md) · [Kiểm thử](KIEM_THU_THANH_DIEU_KHIEN_GON.md).

Giữ .env.docker/volume, giải nén đè đúng thư mục cũ rồi chạy setup.cmd một lần; sau đó dùng run.cmd. Head vẫn 0010. Các ghi chú phía dưới mô tả các phiên bản trước.

# Ô thống kê gọn: Đóng băng / Bị chặn

Dãy thống kê chỉ còn 6 ô thấp: Tất cả, Chưa check, Live, Die / hết phiên, Đóng băng, Bị chặn. Bỏ ô FloodWait/Lỗi kiểm tra và dòng chú thích. Bị chặn có đếm và lọc riêng, hỗ trợ kết quả cũ. [Hướng dẫn](HUONG_DAN_O_THONG_KE_GON.md) · [Kiểm thử](KIEM_THU_O_THONG_KE_GON.md).

Giữ .env.docker/volume, giải nén đè đúng thư mục cũ rồi chạy setup.cmd một lần; sau đó dùng run.cmd. Head vẫn 0010, giữ proxy và tự chọn cổng.

# Proxy riêng cho từng SS

Nhập file .txt hoặc dán danh sách, gán vào SS đã tích hoặc tất cả SS theo bộ lọc; mỗi SS một proxy. Cột proxy xanh/đỏ/trắng và check riêng/hàng loạt. [Hướng dẫn](HUONG_DAN_PROXY.md) · [Kiểm thử](KIEM_THU_PROXY.md).

Giữ .env.docker và volume, giải nén đè đúng thư mục cũ, chạy setup.cmd một lần để nâng database 0010 và build API/web/worker; sau đó dùng run.cmd.

# Bảng SS gọn — chỉ nhãn trạng thái

Thu gọn hàng và cột trạng thái; bỏ khung lớn và giải thích dài. Chỉ hiện Bình thường/Bị spam/Đóng băng/Bị chặn… Thông tin kỹ thuật mở ngay tại dòng. [Hướng dẫn](HUONG_DAN_GIAO_DIEN_GON.md).

Giữ .env.docker/volume, giải nén đè đúng thư mục cũ rồi chạy setup.cmd một lần; sau đó dùng run.cmd.

# Nhãn xanh/đỏ và lý do lỗi tiếng Việt

Bảng SS hiển thị nhãn trạng thái và lý do ngắn; không chép nguyên chat SpamBot. [Hướng dẫn](HUONG_DAN_TRANG_THAI_MAU.md) · [Kiểm thử](KIEM_THU_TRANG_THAI_MAU.md). Giữ .env.docker/volume, giải nén đè đúng thư mục cũ, chạy setup.cmd một lần rồi dùng run.cmd. Giữ bản sửa tự chọn cổng.

# Tự xử lý cổng web bị chiếm

setup.cmd/run.cmd tự chọn cổng trống khi 8787 bận, lưu lại và mở đúng web. Giữ .env.docker và volume, giải nén đè đúng thư mục cũ rồi chạy setup.cmd lại. [Hướng dẫn](HUONG_DAN_TU_CHON_CONG.md) · [Kiểm thử](KIEM_THU_TU_CHON_CONG.md).

# Thông tin trực tiếp trên bảng SS

Đã bỏ khung Tác vụ hàng loạt phía dưới. Phản hồi SpamBot, trạng thái, tiến độ và lỗi hiển thị ngay tại dòng session; kháng nghị có nút mở lại tại dòng. Giữ chức năng thao tác nhiều SS. [Hướng dẫn mới](HUONG_DAN_BANG_SS.md) · [Kiểm thử](KIEM_THU_BANG_SS.md).

Giữ .env.docker và Docker volume, giải nén đè vào thư mục cũ rồi chạy setup.cmd một lần; sau đó dùng run.cmd. Head vẫn 0009. Các ghi chú phiên bản bên dưới mô tả lịch sử thay đổi.

# Check spam / đóng băng trực tiếp

Vào Tài khoản Telegram, bấm **Check spam / đóng băng** tại từng dòng, hoặc **Check tất cả theo bộ lọc (N)**. Có bộ lọc nhanh Bị spam/Đóng băng/Chưa check spam/Lỗi check spam. Kết quả riêng theo từng SS tự cập nhật trong bảng; tiến độ tại Tác vụ hàng loạt. [Hướng dẫn](HUONG_DAN_CHECK_HAN_CHE.md).

Giữ .env.docker và volume, giải nén đè mã nguồn rồi chạy setup.cmd một lần để build API/web/worker mới; sau đó dùng run.cmd. Không thêm migration (head 0009).

# DEVYN FORWARDER — giao diện chuyên nghiệp

Toàn bộ giao diện đã thiết kế lại: nhận diện DEVYN FORWARDER, sidebar tối, màu nhấn tím, thẻ session, bảng và biểu mẫu đồng bộ, sáng/tối và bố cục điện thoại. Giữ đầy đủ các chức năng hiện có.

Giữ `.env.docker` và Docker volume, giải nén đè vào thư mục cũ, chạy **setup.cmd một lần** để build bản mới, sau đó dùng **run.cmd**. Database head vẫn **0009**. [Hướng dẫn giao diện](HUONG_DAN_DEVYN_UI.md) · [Kiểm thử](KIEM_THU_DEVYN_UI.md).

# Kháng nghị hàng loạt theo mẫu cho từng SS

Chọn tài khoản → **Kháng nghị theo mẫu đã chọn** → nhập email chung/riêng → **Chuẩn bị bản xem trước** → kiểm tra nội dung đã điền tên/số/email → xác nhận gửi các bản sẵn sàng.

`{name}` lấy tên SS trong ứng dụng; `{phone}` đọc từ chính session; `{email}` do bạn cung cấp vì Telegram không trả đầy đủ email qua session. Mẫu chỉnh sửa được; nội dung cần đúng với từng tài khoản. Chỉ gửi khi SpamBot đang yêu cầu mô tả và ngữ cảnh vẫn khớp lúc gửi.

Giữ `.env.docker` và Docker volume, giải nén đè, chạy **setup.cmd một lần** để nâng migration **0009** và build API/web/worker, rồi dùng **run.cmd**. Đọc [HUONG_DAN_KHANG_NGHI_THEO_MAU.md](HUONG_DAN_KHANG_NGHI_THEO_MAU.md) và [KIEM_THU_KHANG_NGHI_THEO_MAU.md](KIEM_THU_KHANG_NGHI_THEO_MAU.md).

# Xóa hàng loạt tài khoản đã tích, không gõ xác nhận

Vào **Tài khoản Telegram**, lọc và tích các dòng cần xóa rồi bấm **Xóa đã chọn**. Không mở hộp xác nhận hoặc yêu cầu gõ tên. Hỗ trợ chọn toàn bộ kết quả lọc và bỏ tích một số dòng để giữ lại.

Đây là xóa khỏi ứng dụng, gồm session/tuyến/tác vụ liên quan, không xóa tài khoản Telegram. Tài khoản đang chạy được yêu cầu dừng và đợi lease kết thúc trước khi dọn. Xem [HUONG_DAN_XOA_HANG_LOAT.md](HUONG_DAN_XOA_HANG_LOAT.md).

Giữ `.env.docker` và Docker volume, giải nén đè mã nguồn, chạy **setup.cmd một lần** để cập nhật API/web, rồi dùng **run.cmd**. Không thêm migration mới (head 0008).

# Tự check sau nhập + SpamBot / kháng nghị

Bản này bổ sung tự kiểm tra phiên/API và hạn chế spam sau khi nhập, check spam hàng loạt, bộ lọc spam và cửa sổ tương tác kháng nghị theo phản hồi/nút thật của **@SpamBot**. Nội dung kháng nghị được xem trước rồi xác nhận gửi; kết quả xét duyệt do Telegram trả về.

Giữ `.env.docker` và Docker volume, giải nén đè mã nguồn, chạy **setup.cmd một lần** để nâng migration **0008** và build API/web/worker; sau đó dùng **run.cmd**. Xem [HUONG_DAN_SPAM_KHANG_NGHI.md](HUONG_DAN_SPAM_KHANG_NGHI.md) và [KIEM_THU_SPAM_KHANG_NGHI.md](KIEM_THU_SPAM_KHANG_NGHI.md).

# Quản lý nhiều session — nhập tự chia lô và thao tác hàng loạt

Không có trần tổng 100 session. ZIP được đọc từng file và tự chia lô. Trên web có chọn trang/toàn bộ kết quả lọc, bật/tắt/check hàng loạt, lọc Live/Die/lỗi/FloodWait/đóng băng, nhãn thủ công và tác vụ bền vững có lịch sử/tiến độ.

Giữ **.env.docker** và Docker volume, giải nén đè mã nguồn, chạy **setup.cmd một lần** để nâng migration 0007 và build API/web/worker, sau đó dùng **run.cmd**. Đọc [HUONG_DAN_QUAN_LY_SESSION.md](HUONG_DAN_QUAN_LY_SESSION.md) và [KIEM_THU_QUAN_LY_SESSION.md](KIEM_THU_QUAN_LY_SESSION.md). Giới hạn từng file/yêu cầu và tài nguyên thực tế vẫn áp dụng; không đảm bảo phát hiện mọi hạn chế Telegram chỉ bằng đăng nhập.

Các phần sau là ghi chú/tài liệu của những bản trước.

# Nhập session hàng loạt trên web

Có nút **Tài khoản Telegram → Nhập session hàng loạt**: tối đa 100 file Telethon `.session` hoặc ZIP, nhập API ID/hash, chọn worker, theo dõi từng kết quả. Xem [HUONG_DAN_NHAP_SESSION.md](HUONG_DAN_NHAP_SESSION.md). Giữ `.env.docker` và Docker volume, chạy setup.cmd một lần để cập nhật migration 0006 và build image mới, sau đó dùng run.cmd.

# Thêm tài khoản và đăng nhập Telegram trên web

Vào **Tài khoản Telegram → Thêm tài khoản**, chọn worker và nhập **api_id/api_hash**. Bấm **Tạo và đăng nhập**, tiếp tục bằng số điện thoại, OTP và 2FA nếu có. Tài khoản cũ có nút **API Telegram**. Không cần sửa `.env.docker` để nhập thông tin Telegram.

Cập nhật bản đang dùng: giữ `.env.docker` và Docker volume, giải nén đè mã nguồn, chạy **setup.cmd một lần** để nâng migration 0005 và build ảnh mới; sau đó dùng **run.cmd**. Xem [KIEM_THU_DANG_NHAP_WEB.md](KIEM_THU_DANG_NHAP_WEB.md) và [HUONG_DAN_WINDOWS.md](HUONG_DAN_WINDOWS.md).

# Tự kết nối máy với web

`setup.cmd` tự tạo và lưu worker; `run.cmd` tự kết nối, đợi Online và mở web. Không cần chép credential hoặc URL. Xem [HUONG_DAN_WINDOWS.md](HUONG_DAN_WINDOWS.md). Nếu đang dùng bản trước, giữ `.env.docker`/Docker volume và chạy setup lại một lần để cập nhật image.

# Chạy riêng trên Windows

Bấm `setup.cmd` một lần, sau đó dùng `run.cmd`. Cần Docker Desktop (Linux containers); không cần cài Python/Node/PostgreSQL trên Windows. Xem [HUONG_DAN_WINDOWS.md](HUONG_DAN_WINDOWS.md).

# Bản khôi phục mã nguồn đã sửa

Đọc [HUONG_DAN_CHAY.md](HUONG_DAN_CHAY.md) để chạy và [KIEM_THU_BAN_KHOI_PHUC.md](KIEM_THU_BAN_KHOI_PHUC.md) để xem xác minh hiện tại. Các mục Phase phía dưới là tài liệu của bản gốc.

# Telegram Forwarder Control Center

Web control plane + Linux/Windows Telethon workers for managing multiple independent Telegram accounts.
See `docs/architecture.md` for design decisions.

## Status

| Phase | Scope | Status |
|---|---|---|
| 1 | Skeleton, config, health endpoint, state-machine contract | **Done** — 13 unit tests pass, web builds, API and worker CLI smoke-tested |
| 2 | Database, migrations, auth, API | **Done** — see "Verified in Phase 2" |
| 3 | Worker registration, heartbeat | **Done** — see "Verified in Phase 3" |
| 4 | Telethon session management | **Done** (Telegram itself unverified) — see "Verified in Phase 4" |
| 5 | Forward engine, queue, retry | **Done** (Telegram itself unverified) — see "Verified in Phase 5" |
| 6 | Web dashboard, realtime logs | **Done** (not yet viewed in a real browser) — see "Verified in Phase 6" |
| 7 | Linux deployment | Not started |
| 8 | Windows Service deployment | Not started |
| 9 | Hardening, tests, docs | Not started |

### Verified in Phase 1 (Linux sandbox)
- 13 unit tests: settings validation (production refuses weak/missing secrets, docs disabled in production), `/health/live`, worker config parsing, credential never printed, job state machine consistency.
- `uvicorn` starts and serves `/health/live`; web app type-checks and builds.

### Verified in Phase 2 (Linux sandbox, PostgreSQL 16 + SQLite)
- 77 tests pass with PostgreSQL enabled; 48 pass without it (the 27 API tests then run on SQLite only).
  The same 27 API tests run on both backends. Mutation checks confirmed the tests fail if CSRF, lockout or RBAC are removed.
- Alembic: `upgrade head` / `downgrade base` / `alembic check` clean on PostgreSQL and SQLite.
- Real `uvicorn` on PostgreSQL: `create-admin` CLI → login (HttpOnly cookie) → `/me` → audit → CSRF rejection → logout → 401. No password or session token in logs.
- Auth: Argon2id, server-side revocable sessions (only a token hash is stored), CSRF header, RBAC (Administrator/Operator),
  per-account progressive lockout, per-IP limiter, audit trail, uniform error shape that never echoes input.

### Verified in Phase 3 (Linux sandbox, PostgreSQL 16 + SQLite)
- 134 tests pass with PostgreSQL enabled; 86 without it. Mutation checks confirmed tests fail if revocation, rotation-grace expiry or stale-heartbeat detection are removed.
- Migration `0002` upgrades/downgrades and `alembic check` is clean on both databases.
- Backend: worker CRUD (Administrator manages, Operator read-only), one-time credential (hash stored), rotation with grace, instant revocation,
  platform check, heartbeat with optional resources, computed status + background offline detector with one audit event per transition, per-IP failure limiter.
- Worker: HTTPS client, exponential backoff with full jitter, automatic re-registration, exit codes, JSON logs without credentials.
- End-to-end through the real ASGI app and database: register + heartbeat, reconnect after a dropped connection, revoked worker exits with code 2.
- **Real processes on PostgreSQL:** `uvicorn` + `tfcc-worker run`. Worker came online with CPU/RAM, survived an API outage and reconnected on its own,
  was marked offline within seconds of being stopped, and exited with code 2 right after revocation. Credential absent from both logs.

### Verified in Phase 4 (Linux sandbox, PostgreSQL 16 + SQLite, Telegram FAKED)
- 218+ tests pass with PostgreSQL enabled. Mutation checks confirmed tests fail if: a lease can be taken while held, the fencing epoch is ignored,
  the OTP payload is not wiped, sessions are stored in plaintext, `authorized` is allowed without a stored session, deletion skips the name
  confirmation, the audit sanitizer is off, the worker stops self-fencing or its deadline exceeds the server's, FloodWait time is ignored,
  lost leases are ignored, or a phone number / session string reaches the logs.
- End-to-end (real API + DB + worker client/manager, fake Telegram): login with OTP → start → renewals → stop → delete with Telegram logout;
  handover between two workers (a shared fake network proves the same session was never open twice); dead session → account `invalid`;
  full `Runner` with leases released on shutdown.
- Real processes: key file with mode 644 makes the API refuse to start, 600 starts; `verify-keys` correctly reports data encrypted with another key.

### Verified in Phase 5 (Linux sandbox, PostgreSQL 16 + SQLite, Telegram FAKED)
- Routes (1→1, 1→N, N→1, N→M) with keyword/content-type filters, priority, per-route and per-account rate limits, copy vs native forward,
  start/pause/resume/stop (idempotent), verification of read/write access before a route may start, loop protection, delete with confirmation.
- Queue in PostgreSQL following `packages/shared-schemas/job_states.json` (the API enforces exactly those transitions; a test compares them):
  atomic claim with fencing epoch, job lease + abandoned-job recovery, bounded exponential backoff with jitter, dead-letter queue with audit,
  operator retry/cancel (single and bulk), idempotent enqueue (duplicates never queued twice), per-source checkpoints and catch-up after downtime.
- FloodWait honoured to the second (account-wide block, not counted as a failed attempt, rest of the batch handed back unsent); SlowMode per job.
- Tests: 325 pass with PostgreSQL (216 of them also run without it). 25 mutation checks (removing each guard in turn) fail as they should. Two real bugs were found by the tests and fixed
  (batch kept sending after a FloodWait; two guards were redundant so the claim race was only caught on PostgreSQL, which is why integration runs matter).
- End-to-end (real API + DB + worker engine, fake Telegram): live filtered forwarding without duplicates, catch-up after an outage, pause/resume,
  retry → dead-letter → bulk retry, FloodWait, permanent failure, unwritable destination blocks the route, account stop keeps the queue, and the full
  `Runner` pipeline in real time.

### Known limits (Phase 5)
- Real Telegram behaviour is unverified (see "First real Telegram test"): entity cache priming, `forward_messages`/copy semantics, protected chats,
  update delivery after reconnects. Verification of "can send" is best effort; a rejected send is the final authority.
- Albums are forwarded per message; edits/deletes after queuing are not tracked; catch-up is bounded per round.
- At-least-once delivery: a worker crash between Telegram accepting a message and the result report can produce one duplicate.
- Per-minute caps are best-effort under simultaneous claims from the same worker (the real worker runs one claim loop).

### Verified in Phase 6 (Linux sandbox)
- Backend additions: WebSocket event stream (session cookie + Origin check, role filtering, resume cursor, periodic session re-validation),
  `/api/dashboard/summary`, `/api/events/recent`, `/api/system/info` (no secrets), `/api/auth/logout-others`.
- 10 pages (login, dashboard, accounts, routes, workers, job queue, realtime logs, settings, users, audit) — every action calls the real API.
- Backend tests (PostgreSQL + SQLite): 345 pass in total (20 new: WebSocket auth/origin/resume/role-filter/live job events/revocation, dashboard counts, system info, logout-others).
- Frontend tests (vitest, 42): API client (CSRF, 401 handling, errors), WebSocket reconnect + cursor resume + backoff, confirm dialogs, secret dialog,
  login, login wizard (secrets leave the form), route form validation, pipeline status logic, and a check that every CSS class used exists in the stylesheet.
  15 mutation checks (removing each safeguard) fail as they should; two test gaps found this way were closed.
- Real processes: uvicorn + PostgreSQL + a real WebSocket client: live event, resume from cursor, no-cookie and foreign-origin connections rejected, no cookie/password in logs.

### Known limits (Phase 6)
- **Not viewed in a real browser**: layout, contrast, dark theme and the mobile drawer were not visually checked (no browser available here). Open it once on desktop and phone.
- The realtime stream polls the database once per second per connected browser (fine for a few operators; Redis pub/sub would replace it at larger scale).
- No i18n framework: the UI is Vietnamese only. Settings are read-only (they come from the server environment).
- The 24-hour chart aggregates up to 50,000 finished jobs in memory.

### First real Telegram test (you must do this; the sandbox cannot reach Telegram)
1. Get `api_id`/`api_hash` at https://my.telegram.org. Enter them in **Telegram accounts → Add account**, select a worker, then continue with phone/OTP/2FA. Existing accounts have an **API Telegram** action. Environment credentials remain a legacy fallback.
2. Use a spare Telegram account first. Create it in the dashboard/API, assign the worker, `login/start` → enter the code (and 2FA if set).
3. Check `check_connection`, `start`, then in Telegram → Settings → Devices you should see exactly one new device. Try `stop`, reassigning to another worker, and `delete`.
4. Then try forwarding with two **test** chats you own: create a route, `verify`, `start`, post a message in the source and watch `/api/jobs`.
   Try `mode=copy`, a keyword filter, a read-only destination (the route must refuse to start) and pausing/resuming.

### Known limits (Phase 4)
- The Telethon adapter is covered offline only; real-Telegram behavior (DC migration, update streams, bans) is unverified.
- Session changes made by Telethon are saved on stop/shutdown, not continuously; after a crash the stored session may be slightly older (still valid).
- Interactive commands use pull-based long polling (≤1 s extra latency).
- Per-account login attempt throttling relies on Telegram's own FloodWait (surfaced exactly); there is no extra API-side limiter yet.

### Known limits (Phase 3)
- Worker traffic is plain HTTP request/response over TLS (no WebSocket); real-time push to workers is not needed until job dispatch (Phase 5).
- Credential rotation is manual: the new credential must be copied to the worker's config within the grace period (automatic delivery would need a trusted channel).
- The worker's `register` response does not yet carry accounts/jobs (Phases 4–5). Resource reporting needs `psutil` (installed with the worker).
- Not tested here: real TLS termination, Windows, clock skew between worker and server (the server clock is authoritative).

### Known limits (Phase 2)
- The per-IP login limiter is in-memory and per process; a Redis-backed limiter is planned before running several API processes. Nginx `limit_req` is added in Phase 7.
- Two admins demoting each other at the same instant could leave no admin; recover with `python -m app.cli create-admin`.
- No user deletion endpoint on purpose (deactivate instead, to keep the audit trail meaningful).

### NOT verified yet
Redis, Docker, Nginx/HTTPS, Windows, real Telegram, and any browser-level behavior of cookies over real HTTPS.

## Quick start (development)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -e "apps/api[dev]" -e "workers/telegram-worker[dev]"
cp .env.example .env            # fill in real values (TFCC_COOKIE_SECURE=false for local http); never commit .env
alembic upgrade head            # create / upgrade the schema
python -m app.cli create-admin <username>   # no default credentials exist (run from apps/api or set PYTHONPATH=apps/api)
uvicorn app.main:app --app-dir apps/api --reload
cd apps/web && npm install && npm run dev
./scripts/check.sh              # tests + web build
```

## Security rules
`.env`, `*.session`, and keys are git-ignored. Do not paste credentials or session strings into issues, logs or chats.
