import {useEffect,useRef,useState} from 'react';
import {api,ApiError,request} from '../api/client';
import type {Page,WorkCluster,WorkClusterSummary,WorkClusterRun,ClusterLive,Route,CommandAccepted} from '../api/types';
import {Modal} from '../components/Modal';
import {ConfirmDialog} from '../components/ConfirmDialog';
import {Pagination} from '../components/DataTable';
import {Alert,EmptyState,Pill,TextField} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import {postDraftKey,usePostDraft} from '../hooks/usePostDraft';
import {fmtDateTime} from '../lib/format';
import {useToast} from '../state/toast';
import {PostRouteForm,deliveryLabel} from './PostRoute';
import {waitForCommand} from './Accounts';
import {skipRoute} from './RouteBulkActions';
import {ClusterMessageDialog} from './ClusterMessageDialog';
import {MessageClusterForm} from './MessageClusterForm';

type Dialog={kind:'new'|'message_new'}|{kind:'edit'|'run'|'history'|'delete'|'message'|'message_edit';cluster:WorkClusterSummary};

export function WorkClusters({owner,isAdmin,onOpenBatch}:{owner:string;isAdmin:boolean;onOpenBatch:(id:string)=>void}){
 const toast=useToast();
 const [q,setQ]=useState(''),[page,setPage]=useState(1),[kind,setKind]=useState<'forward'|'message'>('forward'),[dialog,setDialog]=useState<Dialog|null>(null);
 const search=useDebounced(q);
 const list=useQuery(signal=>api.get<Page<WorkClusterSummary>>('/api/work-clusters',{q:search,kind,page,page_size:12},signal),[search,page,kind],{interval:5000});
 function saved(c:WorkCluster){setDialog(null);list.reload();toast.success(`Đã lưu cụm “${c.name}”. Bấm Chạy để dùng bài viết đã lưu.`);}
 function openBatch(id:string){setDialog(null);onOpenBatch(id);}
 return <section className="work-clusters stack tight" aria-label="Cụm làm việc">
  <div className="cluster-toolbar"><div><h2>{kind==='message'?'Cụm gửi tin nhắn':'Cụm chuyển tiếp'} <span>{list.data?.total??0}</span></h2><p>{kind==='message'?'Soạn nội dung, chọn media và lên lịch gửi theo cụm.':'Bài viết và cấu hình được lưu theo cụm.'}</p></div><div className="cluster-toolbar-actions">{isAdmin&&<button className="btn" onClick={()=>{setKind('message');setDialog({kind:'message_new'});}}>+ Cụm gửi tin nhắn</button>}{isAdmin&&<button className="btn primary" onClick={()=>{setKind('forward');setDialog({kind:'new'});}}>+ Tạo cụm làm việc</button>}</div></div>
  <div className="cluster-tabs"><button className={`btn sm ${kind==='forward'?'primary':''}`} onClick={()=>{setKind('forward');setPage(1);}}>Cụm chuyển tiếp</button><button className={`btn sm ${kind==='message'?'primary':''}`} onClick={()=>{setKind('message');setPage(1);}}>Cụm gửi tin nhắn</button></div>
  <div className="cluster-search"><input className="input" aria-label="Tìm cụm làm việc" placeholder="Tìm tên cụm…" maxLength={64} value={q} onChange={e=>{setQ(e.target.value);setPage(1);}}/><button className="btn sm" onClick={list.reload} disabled={list.refreshing}>Làm mới</button></div>
  {list.error&&<Alert tone="bad">{list.error.message}</Alert>}
  {list.loading&&<p className="hint" role="status">Đang tải cụm làm việc…</p>}
  {list.data&&!list.data.items.length&&<EmptyState title={search?'Không tìm thấy cụm':'Tạo cụm cho công việc hằng ngày'}>{search?'Thử tìm bằng tên khác.':'Đặt tên, chọn SS và lưu nhóm nhận một lần. Mỗi bài mới có tiến độ riêng.'}</EmptyState>}
  {kind==='message'?<MessageClusterGrid items={list.data?.items??[]} isAdmin={isAdmin} onEdit={c=>setDialog({kind:'message_edit',cluster:c})} onMessage={c=>setDialog({kind:'message',cluster:c})} onDelete={c=>setDialog({kind:'delete',cluster:c})} onRefresh={list.reload}/>:<div className="cluster-grid">{list.data?.items.map(c=><article className="cluster-card" key={c.id}>
   <div className="cluster-card-head"><span className="cluster-icon" aria-hidden="true">▦</span><div><h3 title={c.name}>{c.name}</h3><span className="hint">Cập nhật {fmtDateTime(c.updated_at)}</span></div>{isAdmin&&<details className="session-actions"><summary className="btn ghost sm" aria-label={`Thao tác cụm ${c.name}`}>•••</summary><div className="route-menu"><button className="btn sm" onClick={()=>setDialog({kind:'edit',cluster:c})}>Sửa cụm</button><button className="btn sm danger" onClick={()=>setDialog({kind:'delete',cluster:c})}>Xóa cụm</button></div></details>}</div>
   <div className="cluster-facts"><span><b>{c.account_count}</b> SS</span><span><b>{c.target_count}</b> nhóm nhận</span><span>{c.delay_seconds}{c.delay_max_seconds&&c.delay_max_seconds!==c.delay_seconds?`–${c.delay_max_seconds}`:''}s / nhóm</span></div>
   {c.post_link?<a className="cluster-saved-link" href={c.post_link} title={c.post_link} target="_blank" rel="noreferrer">{c.post_link}</a>:<p className="hint">Chưa lưu liên kết bài viết.</p>}
   <ClusterLivePanel cluster={c} onRefresh={list.reload}/>
   <div className="cluster-card-foot"><span className="hint">{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'}</span><div className="row"><button className="btn sm" onClick={()=>setDialog({kind:'history',cluster:c})}>Lịch sử</button><button className="btn sm" onClick={()=>setDialog({kind:'history',cluster:c})}>Kiểm tra tình trạng</button>{isAdmin&&<button className="btn sm" onClick={()=>setDialog({kind:'edit',cluster:c})}>Sửa</button>}{isAdmin&&<ClusterRunButton cluster={c} canStart={!!c.post_link} onRefresh={list.reload}/>}</div></div>
  </article>)}</div>}
  {list.data&&list.data.total>12&&<Pagination page={page} pageSize={12} total={list.data.total} onPage={setPage}/>}
  {dialog?.kind==='new'&&<PostRouteForm clusterMode draftOwner={owner} onClose={()=>setDialog(null)} onSaved={()=>{}} onClusterSaved={saved}/>}
  {dialog&&(dialog.kind==='edit'||dialog.kind==='run')&&<ClusterDialog key={`${dialog.kind}:${dialog.cluster.id}`} id={dialog.cluster.id} kind={dialog.kind} owner={owner} onClose={()=>setDialog(null)} onSaved={saved} onOpenBatch={openBatch}/>}
  {dialog?.kind==='message_new'&&<MessageClusterForm owner={owner} onClose={()=>setDialog(null)} onSaved={c=>{setDialog(null);setKind('message');list.reload();toast.success(`Đã lưu cụm gửi tin nhắn “${c.name}”.`);}}/>}
  {dialog?.kind==='message_edit'&&<MessageClusterEdit id={dialog.cluster.id} owner={owner} onClose={()=>setDialog(null)} onSaved={c=>{setDialog(null);list.reload();toast.success(`Đã cập nhật cụm “${c.name}”.`);}}/>}
  {dialog?.kind==='message'&&<ClusterMessageDialog key={dialog.cluster.id} id={dialog.cluster.id} onClose={()=>{setDialog(null);list.reload();}}/>}
  {dialog?.kind==='history'&&<ClusterHistory key={dialog.cluster.id} cluster={dialog.cluster} onClose={()=>setDialog(null)} onOpenBatch={openBatch} onNew={isAdmin?()=>setDialog({kind:'run',cluster:dialog.cluster}):undefined}/>}
  {dialog?.kind==='delete'&&<ConfirmDialog title={`Xóa cụm “${dialog.cluster.name}”?`} confirmLabel="Xóa cụm" danger onClose={()=>setDialog(null)} onConfirm={async()=>{await request('DELETE',`/api/work-clusters/${dialog.cluster.id}`);list.reload();toast.success('Đã xóa cấu hình cụm.');}}><p>Các SS và lượt gửi đã tạo vẫn được giữ trong lịch sử của cụm. Lượt đang chạy tiếp tục theo cấu hình cũ.</p></ConfirmDialog>}
 </section>;
}


function MessageClusterGrid({items,isAdmin,onEdit,onMessage,onDelete,onRefresh}:{items:WorkClusterSummary[];isAdmin:boolean;onEdit:(c:WorkClusterSummary)=>void;onMessage:(c:WorkClusterSummary)=>void;onDelete:(c:WorkClusterSummary)=>void;onRefresh:()=>void}){
 if(!items.length)return <div className="cluster-grid"><EmptyState title="Chưa có cụm gửi tin nhắn">Bấm “+ Cụm gửi tin nhắn” để tạo cấu hình riêng cho text, ảnh, video và lịch gửi.</EmptyState></div>;
 return <div className="cluster-grid">{items.map(c=><article className="cluster-card message-cluster-card" key={c.id}>
  <div className="cluster-card-head"><span className="cluster-icon message-cluster-icon" aria-hidden="true">✈</span><div><h3 title={c.name}>{c.name}</h3><span className="hint">Cập nhật {fmtDateTime(c.updated_at)}</span></div>{isAdmin&&<details className="session-actions"><summary className="btn ghost sm" aria-label={`Thao tác cụm ${c.name}`}>•••</summary><div className="route-menu"><button className="btn sm" onClick={()=>onEdit(c)}>Sửa cụm</button><button className="btn sm danger" onClick={()=>onDelete(c)}>Xóa cụm</button></div></details>}</div>
  <div className="cluster-facts"><span><b>{c.account_count}</b> SS gửi</span><span><b>{c.target_count}</b> nhóm nhận</span><span>{c.delay_seconds}–{c.delay_max_seconds??c.delay_seconds}s / nhóm</span></div>
  <div className="message-card-preview">{c.message_text?.trim()||c.message_media_id?<><strong>{c.message_media_type==='video'?'Video':c.message_media_type==='photo'?'Ảnh':'Nội dung'}</strong><span>{c.message_text?.trim()||'Đã cấu hình media'}</span></>:<span>Chưa có nội dung. Mở Sửa để soạn tin.</span>}</div>
  <div className="message-card-schedule">{c.message_schedule_enabled&&c.message_schedule_times?.length?`Lịch gửi: ${c.message_schedule_times.join(' · ')}`:'Chưa bật lịch gửi'}</div>
  {c.message_loop_enabled&&<div className="message-card-loop"><Pill tone={c.loop_active?(c.loop_block_reason?'warn':'ok'):c.loop_block_reason?'bad':'idle'}>{LOOP_STATE_LABEL(c)}</Pill>{c.loop_wait_until&&c.loop_active&&<span className="hint">Thử lại sau {fmtCountdown(c.loop_wait_until)}</span>}</div>}
  <ClusterLivePanel cluster={c} onRefresh={onRefresh}/>
  <div className="cluster-card-foot"><span className="hint">Cụm gửi tin nhắn</span><div className="row">{isAdmin&&<button className="btn sm" onClick={()=>onEdit(c)}>Sửa</button>}<button className="btn sm" onClick={()=>onMessage(c)}>Gửi ngay / Tình trạng</button>{isAdmin&&<ClusterRunButton cluster={c} canStart={!!(c.message_text?.trim()||c.message_media_id)} onRefresh={onRefresh}/>}</div></div>
 </article>)}</div>;
}
function fmtCountdown(iso:string){
 const ms=new Date(iso).getTime()-Date.now();
 if(!Number.isFinite(ms)||ms<=0)return 'ít giây';
 const mins=Math.ceil(ms/60000);
 return mins>=60?`${Math.ceil(mins/60)} giờ`:`${mins} phút`;
}

const LOOP_BLOCK_REASON:Record<string,string>={
 flood_wait:'Telegram đang bắt chờ — vòng lặp vẫn bật, sẽ tự chạy lại',
 senders_stopped:'Tất cả SS trong cụm đã dừng — bật lại SS rồi bấm Chạy',
 worker_offline:'Worker của SS đang offline — vòng lặp sẽ tự chạy lại khi worker trực tuyến',
 no_senders:'Cụm không còn SS nào — thêm SS rồi chạy lại',
 unavailable:'Không có SS sẵn sàng — kiểm tra SS rồi chạy lại',
 pass_error:'Lỗi khi tạo vòng mới — xem log máy chủ rồi bấm Chạy lại',
};

function LOOP_STATE_LABEL(c:{loop_active?:boolean;loop_block_reason?:string|null}){
 if(c.loop_active)return c.loop_block_reason?'Vòng lặp đang chờ':'Vòng lặp đang chạy';
 if(c.loop_block_reason)return LOOP_BLOCK_REASON[c.loop_block_reason]??'Vòng lặp đã dừng';
 return 'Vòng lặp đã bật · chưa chạy';
}

const OUTCOME_LABEL:Record<string,string>={done:'Đã gửi',failed:'Lỗi',pending:'Đang chờ',stopped:'Đã dừng',skipped:'Đã có lượt trước',blocked:'Không thể bắt đầu',not_started:'Chưa xếp hàng'};
const RUN_LABEL:Record<string,string>={queued:'Đang xếp hàng',running:'Đang chạy',completed:'Hoàn tất',completed_with_errors:'Xong · có lỗi',stopped:'Đã dừng',paused:'Tạm dừng',blocked:'Không thể bắt đầu',not_started:'Chưa xếp hàng',skipped:'Đã có lượt trước'};
const ERROR_LABEL:Record<string,string>={flood_wait:'Telegram yêu cầu chờ',chat_write_forbidden:'Không có quyền gửi',not_member:'Chưa tham gia',join_failed:'Không tham gia được',invite_request_sent:'Đã gửi yêu cầu tham gia',peer_not_found:'Không tìm thấy nhóm',slowmode_wait:'Nhóm đang slowmode',media_forbidden:'Nhóm cấm media',stopped:'Đã dừng',user_banned_in_channel:'SS bị cấm trong nhóm'};

/** True while the card should offer the red Stop button. A message loop stays "running" between passes. */
export function clusterIsRunning(c:Partial<ClusterLive>&{loop_active?:boolean}){return !!(c.running||c.loop_active);}

export function ClusterRunButton({cluster:c,canStart,onRefresh}:{cluster:WorkClusterSummary;canStart:boolean;onRefresh:()=>void}){
 const toast=useToast();
 const [busy,setBusy]=useState(false),[override,setOverride]=useState<boolean|null>(null);
 // Server state wins once the next poll arrives; the override only bridges the click → poll gap.
 useEffect(()=>{setOverride(null);},[c.running,c.loop_active,c.run_id,c.batch_id]);
 const running=override??clusterIsRunning(c);
 async function toggle(){
  if(busy)return;setBusy(true);
  try{
   if(running){
    await api.post(`/api/work-clusters/${c.id}/stop`);
    setOverride(false);toast.success(`Đã dừng cụm “${c.name}”. Tin đang gửi có thể hoàn tất.`);
   }else{
    const r=await api.post<{kind:'message'|'forward';cluster?:WorkClusterSummary;failures?:{account?:string|null;error?:string|null}[];}>(`/api/work-clusters/${c.id}/start`,{request_id:crypto.randomUUID(),revision:c.revision});
    setOverride(r.cluster?clusterIsRunning(r.cluster):true);
    if(r.kind==='forward'&&r.failures?.length)toast.error(`${r.failures.length} SS không bắt đầu được: ${r.failures[0].error??'xem Lịch sử'}`);
    else if(r.cluster?.run_status==='skipped')toast.success('Bài đã có trong lượt trước. Mở Hàng đợi tác vụ để xem kết quả hoặc thử lại tác vụ lỗi.');
    else if(r.kind==='forward'&&r.cluster&&!clusterIsRunning(r.cluster))toast.error('Chưa có công việc gửi đang chạy. Xem trạng thái từng nhóm trên thẻ cụm.');
    else toast.success(`Đã bắt đầu cụm “${c.name}”.`);
   }
   onRefresh();
  }catch(e){toast.error(e instanceof ApiError?e.message:'Không thực hiện được. Thử lại.');}
  finally{setBusy(false);}
 }
 return running
  ?<button className="btn sm danger solid cluster-run-toggle" aria-pressed="true" disabled={busy} onClick={()=>void toggle()} title="Dừng cụm và hủy các lượt gửi đang chờ"><span className="cluster-run-dot" aria-hidden="true"/>{busy?'Đang dừng…':'Dừng'}</button>
  :<button className="btn sm primary cluster-run-toggle" aria-pressed="false" disabled={busy||!canStart} onClick={()=>void toggle()} title={canStart?'Chạy cụm ngay':'Cụm chưa có nội dung để gửi'}>{"\u25b6"} Chạy</button>;
}

export function ClusterLivePanel({cluster:c}:{cluster:WorkClusterSummary;onRefresh?:()=>void}){
 const outcomes=c.outcomes??[];
 if(!c.run_status&&!outcomes.length&&!clusterIsRunning(c))return <div className="cluster-live idle"><span className="hint">Chưa chạy. Bấm “Chạy” để bắt đầu, kết quả từng nhóm hiện ngay tại đây.</span></div>;
 const total=c.total_count??0,done=c.done_count??0,failed=c.error_count??0,finished=Math.min(total,c.completed_count??done+failed);
 const pct=total?Math.round(finished*100/total):0;
 const running=clusterIsRunning(c);
 const status=running&&!c.running?'Chờ vòng kế tiếp':RUN_LABEL[c.run_status??'']??(running?'Đang chạy':'Đã chạy');
 const tone=running?'ok':c.run_status==='blocked'?'bad':c.run_status==='completed_with_errors'?'warn':c.run_status==='completed'?'ok':'idle';
 const recent=[...outcomes].reverse();
 return <div className={`cluster-live ${running?'running':''}`} aria-live="polite">
  <div className="cluster-live-head"><Pill tone={tone}>{running&&<span className="cluster-run-dot" aria-hidden="true"/>}{status}</Pill><span className="cluster-live-count"><b>{finished}</b>/{total} nhóm{c.loop_pass&&c.loop_pass>1?` · vòng ${c.loop_pass}`:''}</span></div>
  <div className="cluster-live-bar" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct} aria-label="Tiến độ cụm"><span style={{width:`${pct}%`}}/></div>
  <div className="cluster-live-stats"><span className="ok">✓ {done} đã gửi</span><span className="bad">✕ {failed} lỗi</span>{c.last_run_at&&<span>Bắt đầu {fmtDateTime(c.run_started_at??c.last_run_at)}</span>}</div>
  {c.run_status==='skipped'&&<p className="hint">Không tạo bản gửi trùng. Mở Hàng đợi tác vụ để xem lượt trước; tác vụ lỗi cần được thử lại tại đó.</p>}
  {recent.length?<ul className="cluster-live-results">{recent.map((o,i)=><li className={`cluster-live-row ${o.status}`} key={`${o.ref}:${i}`}><span className="cluster-live-ref" title={o.title?`${o.title} · ${o.ref}`:o.ref}>{o.title||o.ref}</span><span className="cluster-live-state" title={o.error_message??o.error_code??undefined}>{o.status==='failed'||o.status==='blocked'?o.error_message??ERROR_LABEL[o.error_code??'']??(o.error_code||'Lỗi'):OUTCOME_LABEL[o.status]??o.status}</span></li>)}</ul>:<p className="hint cluster-live-wait">{running?'Đang chuẩn bị gửi tới nhóm đầu tiên…':'Chưa có công việc gửi. Kiểm tra cấu hình cụm và trạng thái tài khoản.'}</p>}
 </div>;
}
function MessageClusterEdit({id,owner,onClose,onSaved}:{id:string;owner:string;onClose:()=>void;onSaved:(c:WorkCluster)=>void}){
 const detail=useQuery(signal=>api.get<WorkCluster>(`/api/work-clusters/${id}`,undefined,signal),[id]);
 if(!detail.data)return <Modal title="Sửa cụm gửi tin nhắn" onClose={onClose}><p className="hint">{detail.error?.message??'Đang tải cấu hình cụm…'}</p></Modal>;
 return <MessageClusterForm cluster={detail.data} owner={owner} onClose={onClose} onSaved={onSaved}/>;
}

function ClusterDialog({id,kind,owner,onClose,onSaved,onOpenBatch}:{id:string;kind:'edit'|'run';owner:string;onClose:()=>void;onSaved:(c:WorkCluster)=>void;onOpenBatch:(id:string)=>void}){
 const detail=useQuery(signal=>api.get<WorkCluster>(`/api/work-clusters/${id}`,undefined,signal),[id]);
 if(!detail.data)return <Modal title={kind==='edit'?'Sửa cụm làm việc':'Chạy cụm'} onClose={onClose}><p className="hint">{detail.error?detail.error.message:'Đang lấy cấu hình cụm…'}</p>{detail.error&&<button className="btn" onClick={detail.reload}>Thử lại</button>}</Modal>;
 return kind==='edit'?<PostRouteForm key={`${id}:${detail.data.revision}`} clusterMode cluster={detail.data} draftOwner={owner} onClose={onClose} onSaved={()=>{}} onClusterSaved={onSaved}/>:<ClusterRunForm autoRun key={`${id}:${detail.data.revision}`} cluster={detail.data} owner={owner} onClose={onClose} onCreated={onOpenBatch}/>;
}

export function ClusterRunForm({cluster:c,owner,onClose,onCreated,autoRun=false}:{autoRun?:boolean;cluster:WorkCluster;owner:string;onClose:()=>void;onCreated:(id:string)=>void}){
 const cache=usePostDraft(postDraftKey(owner,`cluster-run:${c.id}:${c.revision}`),{link:c.post_link??'',targets:'',senders:[],delay:String(c.delay_seconds),mode:c.mode,requestId:crypto.randomUUID()});
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[progress,setProgress]=useState(''),[batch,setBatch]=useState(''),[results,setResults]=useState<string[]>([]);
 const cancelled=useRef(false),running=useRef(false),mounted=useRef(true),abort=useRef<AbortController>();
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
 useEffect(()=>{if(!autoRun)return;const timer=setTimeout(()=>void create(),0);return()=>clearTimeout(timer);},[autoRun]);
 async function create(){
  if(running.current||!c.post_link||c.missing_account_ids.length)return;
  running.current=true;cancelled.current=false;setBusy(true);setError('');setResults([]);cache.saveNow();abort.current=new AbortController();
  try{
   const r=await api.post<{batch_id:string;items:Route[]}>(`/api/work-clusters/${c.id}/runs`,{request_id:cache.draft.requestId,revision:c.revision});
   if(mounted.current)setBatch(r.batch_id);
   const notes:string[]=[];
   for(const row of r.items??[]){
    if(cancelled.current)break;
    if(mounted.current)setProgress(`Kiểm tra & chạy ${notes.length+1}/${r.items.length} · ${row.account_name??row.name}`);
    try{
     let fresh=await api.get<Route>(`/api/routes/${row.id}`);
     if(cancelled.current)break;
     if(fresh.status==='active'||fresh.link_config?.queued_at){notes.push(`${row.account_name??row.name}: lượt đã có tiến độ, mở lượt để xem.`);if(mounted.current)setResults([...notes]);continue;}
     const cmd=await api.post<CommandAccepted>(`/api/routes/${row.id}/verify`);
     await waitForCommand(row.account_id,cmd.command_id,abort.current.signal,4);
     if(cancelled.current)break;
     fresh=await api.get<Route>(`/api/routes/${row.id}`);
     if(cancelled.current)break;
     const reason=skipRoute('start',fresh);
     if(reason){notes.push(`${row.account_name??row.name}: ${reason}`);}
     else{const started=await api.post<Route>(`/api/routes/${row.id}/start`);notes.push(`${row.account_name??row.name}: ${deliveryLabel(started)}.`);}
    }catch(e){if(cancelled.current)break;notes.push(`${row.account_name??row.name}: ${e instanceof ApiError?e.message:'Không chạy được; mở lượt để xem lỗi.'}`);}
    if(mounted.current)setResults([...notes]);
   }
   if(mounted.current){setProgress(cancelled.current?'Đã dừng thao tác. Những lượt đã bắt đầu tiếp tục chạy.':'Đã xử lý. Mở lượt để xem kết quả từng nhóm.');}
   cache.complete();
  }catch(e){if(mounted.current)setError(e instanceof ApiError?e.message:'Không tạo được lượt gửi.');}
  finally{running.current=false;if(mounted.current)setBusy(false);}
 }
 return <Modal title={`Chạy cụm · ${c.name}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Đóng</button>{busy&&<button className="btn" onClick={()=>{cancelled.current=true;abort.current?.abort();}}>Dừng thao tác</button>}{batch&&<button className="btn primary" onClick={()=>onCreated(batch)}>{busy?'Kiểm tra tình trạng':'Mở lượt & tiến độ'}</button>}{!busy&&!batch&&<button className="btn primary" disabled={!c.post_link||!!c.missing_account_ids.length} onClick={()=>void create()}>Chạy</button>}</>}>
  <div className="cluster-run-summary"><strong>{c.account_count} SS · {c.target_count} nhóm nhận</strong><span>{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'} · nghỉ {c.delay_seconds}–{c.delay_max_seconds??c.delay_seconds}s / nhóm</span></div>
  <TextField label="Liên kết bài viết Telegram" value={c.post_link??''} readOnly hint="Liên kết đã lưu theo cụm. Dùng Sửa cụm để đổi bài."/>
  <p className="hint">Chỉ chạy tới nhóm/kênh SS đang quản trị và có quyền đăng bài. Không tự tham gia. Thứ tự nhóm của mỗi SS được xáo trộn khi bắt đầu lượt. Gửi một lượt rồi dừng, không tự lặp. Bài đã gửi được bỏ qua; thời gian chờ Telegram luôn được giữ.</p>
  {busy&&<p className="hint">Có thể đóng bảng này, thao tác đang chạy sẽ tiếp tục. Chọn “Dừng thao tác” nếu muốn ngừng bắt đầu các SS còn lại.</p>}
  {progress&&<p role="status" className="hint">{progress}</p>}
  {!!results.length&&<div className="cluster-run-result">{results.map((text,i)=><p key={i}>{text}</p>)}</div>}
  {!!c.missing_account_ids.length&&<Alert tone="bad">{c.missing_account_ids.length} SS đã/đang bị xóa. Sửa cấu hình cụm trước khi chạy.</Alert>}
  {!c.post_link&&<Alert>Lưu liên kết bài viết trong Sửa cụm trước khi chạy.</Alert>}
  {error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}

function ClusterHistory({cluster:c,onClose,onOpenBatch,onNew}:{cluster:WorkClusterSummary;onClose:()=>void;onOpenBatch:(id:string)=>void;onNew?:()=>void}){
 const [page,setPage]=useState(1);
 const history=useQuery(signal=>api.get<Page<WorkClusterRun>>(`/api/work-clusters/${c.id}/runs`,{page,page_size:10},signal),[c.id,page],{interval:5000});
 return <Modal wide title={`Lịch sử · ${c.name}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Đóng</button>{onNew&&<button className="btn primary" onClick={onNew}>Chạy bài đã lưu</button>}</>}>
  <p className="hint">Mỗi lượt giữ bài viết, SS và nhóm nhận tại thời điểm tạo. Sửa cụm chỉ áp dụng cho lượt sau.</p>
  {history.error&&<Alert tone="bad">{history.error.message}</Alert>}{history.loading&&<p className="hint">Đang tải lịch sử…</p>}
  {history.data&&!history.data.total&&<EmptyState title="Chưa có lượt gửi">Lưu bài viết và bấm Chạy để dùng cấu hình của cụm.</EmptyState>}
  <div className="cluster-history">{history.data?.items.map(r=><div className="cluster-history-row" key={r.batch_id}><div><strong>{fmtDateTime(r.created_at)}</strong><a href={r.post_link} target="_blank" rel="noreferrer">{r.post_link}</a><span className="hint">{r.account_count} SS · {r.target_count} nhóm nhận</span></div><Pill tone={r.active_count?'ok':r.paused_count?'warn':'idle'}>{r.active_count?'Đang chạy':r.paused_count?'Tạm dừng':r.started_count?'Đã chạy':'Bản nháp'}</Pill><button className="btn sm" onClick={()=>onOpenBatch(r.batch_id)}>Mở lượt</button></div>)}</div>
  {history.data&&history.data.total>10&&<Pagination page={page} pageSize={10} total={history.data.total} onPage={setPage}/>}
 </Modal>;
}
