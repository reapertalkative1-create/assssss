"""Forward-job queue kept in PostgreSQL.

Guarantees
  * A job is handed to at most one worker at a time: claiming is one conditional UPDATE (status + fencing epoch).
  * Source-watching routes use at-least-once delivery with de-duplication: (route, source, message, destination) is unique, so the same
    message is never queued twice, but a worker crash between "sent to Telegram" and "result reported" can cause
    one duplicate send. Telegram offers no way to make that exactly-once.
  * Post-link routes reserve (source, message, destination) across all drafts, keep a fixed sender,
    and hold ambiguous sends for operator review instead of automatically retrying them.
  * Retries are bounded: transient errors back off exponentially, then the job goes to the dead-letter state.
  * Telegram FloodWait is honoured to the second and blocks the whole account, not just one job."""
import logging
import random
import uuid
from datetime import datetime, timedelta

from sqlalchemy import func, select, update
from sqlalchemy.dialects import postgresql, sqlite
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_system_audit
from app.models import ForwardJob, ForwardRoute, TelegramAccount, Worker
from app.services.accounts import lease_active
from app.services import post_delivery
from app.errors import ApiError

log = logging.getLogger("tfcc.jobs")

# Must equal packages/shared-schemas/job_states.json (a test enforces it).
TRANSITIONS: dict[str, set[str]] = {
    "pending": {"claimed", "cancelled"},
    "claimed": {"running", "pending"},
    "running": {"succeeded", "retry_wait", "failed", "dead_letter"},
    "retry_wait": {"pending", "dead_letter", "cancelled"},
    "failed": {"pending", "cancelled"},
    "dead_letter": {"pending", "cancelled"},
    "succeeded": set(),
    "cancelled": set(),
}
# Errors that say nothing about the job itself: the attempt is not counted.
NON_COUNTING = {"flood_wait", "slow_mode", "account_not_connected", "auth_key_unregistered", "user_deactivated",
                "session_revoked", "auth_key_duplicated",'account_spam_restricted','account_frozen'}
PERMANENT = {"admin_required", "not_joined", "destination_forbidden", "chat_unavailable", "message_not_found", "forward_restricted", "media_unsupported"}
ACCOUNT_BLOCKING = {"flood_wait"}  # FloodWait applies to the whole account


def _guard(old: str, new: str) -> None:
    if new not in TRANSITIONS[old]:
        raise RuntimeError(f"illegal job transition {old} -> {new}")


def idempotency_key(route_id: uuid.UUID, source: int, message_id: int, dest: int) -> str:
    return f"{route_id.hex}:{source}:{message_id}:{dest}"


def backoff_seconds(attempts: int, base: float, cap: float, rng=random.random) -> float:
    delay = min(cap, base * (2 ** max(0, attempts - 1)))
    return delay * (0.8 + 0.4 * rng())


def _insert(db: AsyncSession, model):
    return (postgresql.insert if db.get_bind().dialect.name == "postgresql" else sqlite.insert)(model)


# ------------------------------------------------------------------ enqueue
async def enqueue(db: AsyncSession, route: ForwardRoute, items: list[tuple[int, int]], now: datetime, *, spacing_seconds=0) -> tuple[int, int]:
    """items = (source_chat_id, message_id); one job is created per destination. Returns (created, duplicates)."""
    rows = []
    config = route.link_config or {}
    lower = int(config.get('delay_seconds', spacing_seconds))
    upper = int(config.get('delay_max_seconds', lower)) if config.get('managed_targets_only') else lower
    for src, mid in items:
        offset = 0
        # Shuffle a copy once at queue creation; persisted availability times
        # keep this order stable across polls, pauses and worker restarts.
        destinations = list(route.destination_chat_ids)
        if config.get("managed_targets_only"):
            random.shuffle(destinations)
        for dst in destinations:
            cooldown = random.randint(lower, max(lower, upper)) if spacing_seconds else 0
            rows.append({
                "id": uuid.uuid4(), "route_id": route.id, "account_id": route.account_id, "source_chat_id": src,
                "message_id": mid, "dest_chat_id": dst, "idempotency_key": idempotency_key(route.id, src, mid, dst),
                "status": "pending", "priority": route.priority, "attempts": 0, "max_attempts": route.max_attempts,
                "available_at": now+timedelta(seconds=offset), "cooldown_seconds": cooldown, "claim_epoch": 0, "created_at": now, "updated_at": now,
            })
            offset += cooldown
    if not rows:
        return 0, 0
    if route.link_config:
        fresh=await post_delivery.reserve(db,route,rows,now)
        accepted={r['id'] for r in fresh}
        skipped=[r['dest_chat_id'] for r in rows if r['id'] not in accepted]
        route.link_config={**route.link_config,'duplicate_targets':skipped,'duplicate_count':len(skipped),'queued_count':len(fresh)}
        for i in range(0,len(fresh),150):
            await db.execute(_insert(db,ForwardJob).values(fresh[i:i+150]))
        return len(fresh),len(skipped)
    keys = [r["idempotency_key"] for r in rows]
    existing: set[str] = set()
    for i in range(0, len(keys), 500):
        existing |= set((await db.execute(select(ForwardJob.idempotency_key).where(
            ForwardJob.idempotency_key.in_(keys[i:i + 500])))).scalars())
    fresh = [r for r in rows if r["idempotency_key"] not in existing]
    for i in range(0, len(fresh), 200):
        await db.execute(_insert(db, ForwardJob).values(fresh[i:i + 200]).on_conflict_do_nothing(index_elements=["idempotency_key"]))
    return len(fresh), len(rows) - len(fresh)


# ------------------------------------------------------------------ claim / start / result
async def claim_jobs(db: AsyncSession, worker: Worker, now: datetime, max_jobs: int, settings) -> list[dict]:
    """Only jobs of accounts this worker currently owns (valid lease) and of ACTIVE routes are handed out,
    ordered by priority, then age; per-route and per-account per-minute limits are enforced here."""
    _guard("retry_wait", "pending")
    await db.execute(update(ForwardJob).where(ForwardJob.status == "retry_wait", ForwardJob.available_at <= now)
                     .values(status="pending", updated_at=now).execution_options(synchronize_session=False))
    accounts = (await db.execute(select(TelegramAccount).where(
        TelegramAccount.lease_worker_id == worker.id, TelegramAccount.lease_expires_at > now,
        TelegramAccount.auth_state == "authorized", TelegramAccount.pending_deletion.is_(False)))).scalars().all()
    window, out = now - timedelta(seconds=60), []
    for acct in accounts:
        if acct.desired_state!='running':continue
        if acct.spam_status in ('limited','blocked') or acct.health_status in ('frozen','dead') or acct.health_override=='frozen' or acct.proxy_status=='dead':continue
        if len(out) >= max_jobs:
            break
        if acct.flood_wait_until is not None and acct.flood_wait_until > now:
            continue  # Telegram told us to wait; nothing of this account may be sent until then
        used = (await db.execute(select(func.count()).select_from(ForwardJob).where(
            ForwardJob.account_id == acct.id, ForwardJob.claimed_at > window))).scalar_one()
        budget = min(max_jobs - len(out), settings.account_rate_per_minute - used)
        if budget <= 0:
            continue
        routes = {r.id: r for r in (await db.execute(select(ForwardRoute).where(
            ForwardRoute.account_id == acct.id, ForwardRoute.status == "active"))).scalars()}
        if not routes:
            continue
        interval=max((int((r.link_config or {}).get('delay_seconds',0)) for r in routes.values()),default=0)
        if interval:
            if db.get_bind().dialect.name=='sqlite':await db.execute(update(TelegramAccount).where(TelegramAccount.id==acct.id).values(updated_at=TelegramAccount.updated_at))
            else:await db.execute(select(TelegramAccount.id).where(TelegramAccount.id==acct.id).with_for_update())
            busy=(await db.execute(select(ForwardJob.id).where(ForwardJob.account_id==acct.id,ForwardJob.status.in_(('claimed','running'))).limit(1))).first()
            sent_at = func.coalesce(ForwardJob.finished_at, ForwardJob.started_at, ForwardJob.claimed_at)
            previous = (await db.execute(select(sent_at, ForwardJob.cooldown_seconds).where(
                ForwardJob.account_id == acct.id, sent_at.is_not(None)).order_by(sent_at.desc(), ForwardJob.id.desc()).limit(1))).first()
            if busy or previous is not None and (now-previous[0]).total_seconds() < max(interval, previous[1]): continue
            budget=min(budget,1)
        route_used = dict((await db.execute(select(ForwardJob.route_id, func.count()).where(
            ForwardJob.account_id == acct.id, ForwardJob.claimed_at > window).group_by(ForwardJob.route_id))).all())
        eligible = [rid for rid, route in routes.items() if route_used.get(rid, 0) < route.rate_per_minute]
        if not eligible:
            continue
        cands = (await db.execute(select(ForwardJob).where(
            ForwardJob.account_id == acct.id, ForwardJob.status == "pending", ForwardJob.available_at <= now,
            ForwardJob.route_id.in_(eligible)).order_by(ForwardJob.priority, ForwardJob.available_at, ForwardJob.created_at)
            .limit(budget * 3 + 10))).scalars().all()
        for job in cands:
            route = routes[job.route_id]
            if route.link_config and not await post_delivery.owns_job(db,job):
                # Also fences old duplicate queues restored from a pre-0015 backup.
                job.status,job.last_error_code,job.finished_at='cancelled','duplicate_post',now
                continue
            if route_used.get(route.id, 0) >= route.rate_per_minute:
                continue
            _guard("pending", "claimed")
            res = await db.execute(
                update(ForwardJob).where(ForwardJob.id == job.id, ForwardJob.status == "pending",
                                         ForwardJob.claim_epoch == job.claim_epoch)
                .values(status="claimed", claim_epoch=job.claim_epoch + 1, lease_worker_id=worker.id,
                        lease_expires_at=now + timedelta(seconds=settings.job_lease_ttl_seconds), claimed_at=now,
                        attempts=job.attempts + 1, updated_at=now).execution_options(synchronize_session=False))
            if res.rowcount != 1:
                continue  # somebody else got it
            route_used[route.id] = route_used.get(route.id, 0) + 1
            budget -= 1
            out.append({"id": job.id, "epoch": job.claim_epoch + 1, "route_id": route.id, "account_id": acct.id,
                        "source_chat_id": job.source_chat_id, "message_id": job.message_id,
                        "dest_chat_id": job.dest_chat_id, "mode": route.mode, "attempt": job.attempts + 1,
                        "post_once": bool(route.link_config),
                        "managed_targets_only": bool((route.link_config or {}).get("managed_targets_only")),
                        "source_peer": (route.link_config or {}).get("source_peer"),
                        "dest_peer": ((route.link_config or {}).get("dest_peers") or {}).get(str(job.dest_chat_id)),
                        "max_attempts": job.max_attempts})
            if budget <= 0 or len(out) >= max_jobs:
                break
    return out


async def start_jobs(db: AsyncSession, worker: Worker, items: list, now: datetime, settings) -> tuple[list, list]:
    """claimed -> running. A job whose route was paused/stopped in the meantime goes back to the queue instead."""
    started, lost = [], []
    for it in items:
        job = await db.get(ForwardJob, it.id, populate_existing=True)
        if (job is None or job.status != "claimed" or job.lease_worker_id != worker.id or job.claim_epoch != it.epoch
                or job.lease_expires_at is None or job.lease_expires_at <= now):
            lost.append(it.id)
            continue
        route = await db.get(ForwardRoute, job.route_id)
        acct = await db.get(TelegramAccount,job.account_id,populate_existing=True)
        blocked=(acct is None or acct.auth_state!='authorized' or acct.desired_state!='running' or acct.pending_deletion
                 or not lease_active(acct,now) or acct.lease_worker_id!=worker.id or acct.assigned_worker_id!=worker.id
                 or acct.spam_status in ('limited','blocked') or acct.health_status in ('frozen','dead')
                 or acct.health_override=='frozen' or acct.proxy_status=='dead'
                 or acct.flood_wait_until is not None and acct.flood_wait_until>now)
        if route is None or route.status != "active" or blocked or (route.link_config and not await post_delivery.owns_job(db,job)):
            _guard("claimed", "pending")
            job.status, job.attempts = "pending", max(0, job.attempts - 1)
            job.lease_worker_id = job.lease_expires_at = None
            lost.append(it.id)
            continue
        _guard("claimed", "running")
        job.status, job.started_at = "running", now
        job.lease_expires_at = now + timedelta(seconds=settings.job_lease_ttl_seconds)
        started.append(it.id)
    return started, lost


async def apply_results(db: AsyncSession, worker: Worker, results: list, now: datetime, settings) -> list[dict]:
    outcomes = []
    touched=set()
    for it in results:
        job = await db.get(ForwardJob, it.id, populate_existing=True)
        if job is None:
            outcomes.append({"id": it.id, "outcome": "not_found"})
            continue
        if job.status != "running" or job.lease_worker_id != worker.id or job.claim_epoch != it.epoch:
            outcomes.append({"id": it.id, "outcome": "stale"})  # lost the claim (lease expired and recovered)
            continue
        job.lease_worker_id = job.lease_expires_at = None
        touched.add(job.route_id)
        job.finished_at = now
        route=await db.get(ForwardRoute,job.route_id)
        if route and route.link_config and (it.error_code=='delivery_uncertain' or
                it.status!='succeeded' and it.error_code in ('network_error','internal_error','telegram_error','lease_expired')):
            # The send might have reached Telegram; a new attempt could duplicate it.
            job.status,job.last_error_code='failed','delivery_uncertain'
            route.status='paused'
            route.link_config={**route.link_config,'pause_reason':'delivery_uncertain'}
            outcomes.append({'id':it.id,'outcome':'ok'})
            continue
        if it.status == "succeeded":
            _guard("running", "succeeded")
            job.status, job.result, job.last_error_code = "succeeded", {"dest_message_id": it.dest_message_id}, None
        elif it.status == "failed":
            _guard("running", "failed")
            job.status, job.last_error_code = "failed", (it.error_code or "unknown")[:64]
        else:  # retry
            code = (it.error_code or "transient_error")[:64]
            if code in ('account_spam_restricted','account_frozen'):
                acct=await db.get(TelegramAccount,job.account_id)
                if acct:
                    acct.desired_state='stopped'
                    if code=='account_frozen':acct.health_status='frozen';acct.health_error='account_frozen';acct.health_checked_at=now
                    else:acct.spam_status='limited';acct.spam_error=code;acct.spam_checked_at=now
                    await db.execute(update(ForwardRoute).where(ForwardRoute.account_id==acct.id,ForwardRoute.status=='active').values(status='paused'))
            job.last_error_code = code
            if code in NON_COUNTING:
                job.attempts = max(0, job.attempts - 1)
                delay = float((it.retry_after if it.retry_after is not None else 30) + (1 if code == "flood_wait" else 0))
                if code in ACCOUNT_BLOCKING:
                    acct = await db.get(TelegramAccount, job.account_id)
                    if acct is not None:
                        until = now + timedelta(seconds=delay)
                        acct.flood_wait_until = max(acct.flood_wait_until or until, until)
            elif job.attempts >= job.max_attempts:
                delay = None
            else:
                delay = backoff_seconds(job.attempts, settings.job_retry_base_seconds, settings.job_retry_cap_seconds)
            if delay is None:
                _guard("running", "dead_letter")
                job.status = "dead_letter"
                record_system_audit(db, "job.dead_letter", target_type="job", target_id=str(job.id),
                                    details={"route_id": str(job.route_id), "error": code, "attempts": job.attempts})
            else:
                _guard("running", "retry_wait")
                job.status, job.available_at, job.finished_at = "retry_wait", now + timedelta(seconds=delay), None
        outcomes.append({"id": it.id, "outcome": "ok"})
    await db.flush()
    for rid in touched:
        route=await db.get(ForwardRoute,rid)
        if route and route.link_config and route.status=='active':
            pending=(await db.execute(select(func.count()).select_from(ForwardJob).where(ForwardJob.route_id==rid,ForwardJob.status.in_(('pending','claimed','running','retry_wait'))))).scalar_one()
            if not pending:route.status='stopped'
    return outcomes


# ------------------------------------------------------------------ recovery (sweeper)
async def recover_abandoned(db: AsyncSession, now: datetime, settings) -> dict:
    """Jobs whose worker vanished: claimed (never started) go back to pending; running ones are retried or
    dead-lettered. Because the send may have happened, a retry can duplicate one message (at-least-once)."""
    stats = {"requeued": 0, "retried": 0, "dead_letter": 0}
    stale = (await db.execute(select(ForwardJob).where(
        ForwardJob.status.in_(("claimed", "running")), ForwardJob.lease_expires_at <= now))).scalars().all()
    for job in stale:
        old = job.status
        if old == "claimed":
            _guard("claimed", "pending")
            res = await db.execute(update(ForwardJob).where(ForwardJob.id == job.id, ForwardJob.status == "claimed",
                                   ForwardJob.claim_epoch == job.claim_epoch)
                                   .values(status="pending", attempts=max(0, job.attempts - 1), lease_worker_id=None,
                                           lease_expires_at=None, updated_at=now).execution_options(synchronize_session=False))
            stats["requeued"] += res.rowcount or 0
            continue
        route=await db.get(ForwardRoute,job.route_id)
        uncertain=bool(route and route.link_config)
        if uncertain:
            new,delay='failed',None
        elif job.attempts >= job.max_attempts:
            new, delay = "dead_letter", None
        else:
            new, delay = "retry_wait", backoff_seconds(job.attempts, settings.job_retry_base_seconds, settings.job_retry_cap_seconds)
        _guard("running", new)
        values = dict(status=new, last_error_code="delivery_uncertain" if uncertain else "lease_expired", lease_worker_id=None, lease_expires_at=None, updated_at=now)
        if new == "retry_wait":
            values["available_at"] = now + timedelta(seconds=delay)
        else:
            values["finished_at"] = now
        res = await db.execute(update(ForwardJob).where(ForwardJob.id == job.id, ForwardJob.status == "running",
                               ForwardJob.claim_epoch == job.claim_epoch).values(**values)
                               .execution_options(synchronize_session=False))
        if res.rowcount:
            stats["retried" if new == "retry_wait" else "dead_letter"] += 1
            if uncertain:
                route.status='paused'
                route.link_config={**route.link_config,'pause_reason':'delivery_uncertain'}
            if new == "dead_letter":
                record_system_audit(db, "job.dead_letter", target_type="job", target_id=str(job.id),
                                    details={"route_id": str(job.route_id), "error": "lease_expired", "attempts": job.attempts})
    if stats["requeued"] or stats["retried"] or stats["dead_letter"]:
        log.warning("jobs_recovered", extra=stats)
    return stats


# ------------------------------------------------------------------ operator actions
async def requeue(db: AsyncSession, job: ForwardJob, now: datetime, *, reviewed=False) -> None:
    if job.last_error_code=='delivery_uncertain' and not reviewed:
        raise ApiError(409,'delivery_uncertain','Chưa rõ bài đã gửi hay chưa. Đối chiếu nhóm trong chi tiết đợt gửi trước khi thử lại.')
    _guard(job.status, "pending")
    job.status, job.attempts, job.available_at, job.finished_at = "pending", 0, now, None
    job.lease_worker_id = job.lease_expires_at = None


async def cancel(db: AsyncSession, job: ForwardJob, now: datetime) -> None:
    _guard(job.status, "cancelled")
    job.status, job.finished_at = "cancelled", now
    if job.last_error_code=='delivery_uncertain':
        await db.flush()
        remaining=(await db.execute(select(ForwardJob.id).where(ForwardJob.route_id==job.route_id,
            ForwardJob.last_error_code=='delivery_uncertain',ForwardJob.status.in_(('failed','dead_letter'))).limit(1))).first()
        route=await db.get(ForwardRoute,job.route_id)
        if route and route.link_config and not remaining:
            route.link_config={**route.link_config,'pause_reason':None}


async def cancel_pending_for_route(db: AsyncSession, route_id: uuid.UUID, now: datetime) -> int:
    res = await db.execute(update(ForwardJob).where(ForwardJob.route_id == route_id, ForwardJob.status.in_(("pending", "retry_wait")))
                           .values(status="cancelled", finished_at=now, updated_at=now).execution_options(synchronize_session=False))
    return res.rowcount or 0


async def metrics(db: AsyncSession, now: datetime) -> dict:
    by_status = {s: 0 for s in TRANSITIONS}
    by_status.update(dict((await db.execute(select(ForwardJob.status, func.count()).group_by(ForwardJob.status))).all()))
    oldest = (await db.execute(select(func.min(ForwardJob.created_at)).where(ForwardJob.status == "pending"))).scalar_one()
    done = (await db.execute(select(func.count()).select_from(ForwardJob).where(
        ForwardJob.status == "succeeded", ForwardJob.finished_at >= now - timedelta(seconds=300)))).scalar_one()
    return {"by_status": by_status, "oldest_pending_age_seconds": (now - oldest).total_seconds() if oldest else None,
            "succeeded_last_5m": done, "needs_attention": by_status["failed"] + by_status["dead_letter"]}
