export type Role = "admin" | "operator";
export interface User { id: string; username: string; role: Role; is_active: boolean; locked_until: string | null; last_login_at: string | null; created_at: string }
export interface SessionInfo { user: User; csrf_token: string }
export interface Page<T> { items: T[]; total: number; page: number; page_size: number }

export type WorkerStatus = "online" | "offline" | "degraded" | "revoked";
export interface Worker {
  id: string; name: string; platform: "linux" | "windows"; version: string | null; hostname: string | null; status: WorkerStatus;
  health: string; degraded_reason: string | null; running_jobs: number; cpu_percent: number | null; memory_percent: number | null;
  resource_reporting_enabled: boolean; last_heartbeat_at: string | null; last_registered_at: string | null; last_ip: string | null;
  credential_issued_at: string; revoked_at: string | null; created_at: string;
}
export interface WorkerCreated extends Worker { credential: string }

export type AuthState = "importing" | "import_failed" | "unauthenticated" | "awaiting_code" | "awaiting_password" | "authorized" | "invalid";
export interface Account {
  id: string; name: string; phone_masked: string | null; telegram_user_id: number | null; telegram_username: string | null;
  auth_state: AuthState; desired_state: "running" | "stopped"; connection_state: string; connection_error: string | null;
  last_active_at: string | null; assigned_worker_id: string | null; assigned_worker_name: string | null; owner_worker_id: string | null;
  telegram_api_configured: boolean; session_imported: boolean; has_session: boolean; pending_deletion: boolean; created_at: string;
}
export interface CommandAccepted { command_id: string; status: string }
export interface Command { id: string; type: string; status: "pending" | "delivered" | "done" | "failed" | "expired"; error_code: string | null; retry_after: number | null; result: Record<string, unknown> | null; created_at: string; completed_at: string | null }
export interface DeleteResult { status: "deleted" | "logout_requested"; telegram_session_revoked: boolean | null; command_id: string | null }

export type ContentType = "text" | "photo" | "video" | "voice" | "audio" | "sticker" | "document" | "other";
export interface RouteFilters { keywords_include: string[]; keywords_exclude: string[]; content_types: ContentType[]; include_outgoing: boolean }
export interface Route {
  id: string; name: string; account_id: string; account_name: string | null; source_chat_ids: number[]; destination_chat_ids: number[];
  mode: "forward" | "copy"; filters: RouteFilters; priority: number; rate_per_minute: number; max_attempts: number;
  status: "stopped" | "active" | "paused"; verified: boolean; verified_at: string | null;
  verification: Record<string, { ok: boolean; can_send: boolean | null; title: string | null }> | null;
  stats: Record<string, number>; checkpoints: Record<string, number>; created_at: string; updated_at: string;
}
export interface RouteInput { name: string; account_id?: string; source_chat_ids: number[]; destination_chat_ids: number[]; mode: "forward" | "copy"; filters: RouteFilters; priority: number; rate_per_minute: number; max_attempts: number }

export type JobStatus = "pending" | "claimed" | "running" | "succeeded" | "retry_wait" | "failed" | "cancelled" | "dead_letter";
export interface Job { id: string; route_id: string; account_id: string; source_chat_id: number; message_id: number; dest_chat_id: number; status: JobStatus; priority: number; attempts: number; max_attempts: number; available_at: string; last_error_code: string | null; result: Record<string, unknown> | null; created_at: string; finished_at: string | null }
export interface QueueMetrics { by_status: Record<string, number>; oldest_pending_age_seconds: number | null; succeeded_last_5m: number; needs_attention: number }

export interface AuditEntry { id: number; occurred_at: string; actor_user_id: string | null; actor_username: string | null; action: string; target_type: string | null; target_id: string | null; ip: string | null; request_id: string | null; details: Record<string, unknown> | null }

export type Level = "info" | "warning" | "error";
export interface EventItem { key: string; ts: string; kind: "audit" | "job"; action: string; level: Level; actor: string | null; target_type: string | null; target_id: string | null; details: Record<string, unknown> | null }
export interface Cursor { audit: number; job: string }

export interface Summary {
  workers: Record<WorkerStatus, number>;
  accounts: { total: number; authorized: number; invalid: number; connected: number; running: number };
  routes: Record<string, number>;
  jobs: QueueMetrics & { last_24h: { succeeded: number; failed: number }; series: { hour: string; succeeded: number; failed: number }[] };
  resources: { id: string; name: string; platform: string; status: WorkerStatus; cpu_percent: number | null; memory_percent: number | null; running_jobs: number; last_heartbeat_at: string | null }[];
  recent_events: EventItem[]; server_time: string;
}
export interface SystemInfo { version: string; environment: string; database_ok: boolean; encryption: { configured: boolean; keys: number }; settings: Record<string, number | boolean> }
