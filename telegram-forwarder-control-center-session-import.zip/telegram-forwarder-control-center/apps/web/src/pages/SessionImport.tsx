import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import type { Page, Worker } from "../api/types";
import { Modal } from "../components/Modal";
import { Alert, SelectField, TextField } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { errorLabel } from "../lib/labels";

type Item = { index: number; filename: string; status: string; account_id?: string; command_id?: string; error_code?: string; retry_after?: number };
const terminal = (s: string) => ["done", "failed", "expired", "error", "duplicate"].includes(s);
const statuses: Record<string,string> = {queued:"Đang chờ",pending:"Đang chờ",delivered:"Đang kiểm tra",done:"Thành công",failed:"Lỗi",expired:"Hết thời gian — kiểm tra lại",error:"File không hợp lệ",duplicate:"Trùng — đã bỏ qua"};
const importErrors: Record<string,string> = {invalid_telethon_session:"Không phải session Telethon hợp lệ hoặc file chưa được đóng hoàn toàn.",session_has_no_auth_key:"Session chưa đăng nhập.",session_check_timeout:"Kiểm tra mất quá lâu. Có thể thử lại.",internal_error:"Worker chưa kiểm tra được. Có thể thử lại."};

async function encode(file: File) {
  return new Promise<string>((resolve,reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",",2)[1]);
    r.onerror = () => reject(new Error("Không đọc được file."));
    r.readAsDataURL(file);
  });
}

export function SessionImport({ onClose }: { onClose: () => void }) {
  const [files,setFiles]=useState<File[]>([]);
  const [worker,setWorker]=useState("");
  const [apiId,setApiId]=useState("");
  const [apiHash,setApiHash]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [items,setItems]=useState<Item[]>([]);
  const input=useRef<HTMLInputElement>(null);
  const workers=useQuery(signal=>api.get<Page<Worker>>("/api/workers",{page_size:100},signal),[]);
  const online=(workers.data?.items??[]).filter(w=>w.status==="online"||w.status==="degraded");
  useEffect(()=>{if(!worker&&online.length===1)setWorker(online[0].id);},[workers.data,worker]);
  const ids=items.filter(i=>i.command_id&&!terminal(i.status)).map(i=>i.command_id!);
  const key=ids.join(",");
  useEffect(()=>{
    if(!key)return;
    let cancelled=false;
    let timer:ReturnType<typeof setTimeout>;
    async function poll(){
      try{
        const r=await api.post<{items:Partial<Item>[]}>("/api/accounts/import-sessions/status",{command_ids:key.split(",")});
        if(cancelled)return;
        setItems(old=>old.map(item=>({...item,...r.items.find(x=>x.command_id===item.command_id)})));
        setError("");
      }catch(e){if(!cancelled)setError(e instanceof ApiError?e.message:"Không tải được tiến độ; sẽ thử lại.");}
      if(!cancelled)timer=setTimeout(()=>void poll(),2000);
    }
    void poll();
    return()=>{cancelled=true;clearTimeout(timer);};
  },[key]);

  async function submit(){
    if(!worker||!files.length||!(/^[1-9][0-9]*$/.test(apiId))||Number(apiId)>2147483647||!(/^[0-9a-f]{32}$/i.test(apiHash.trim()))){setError("Chọn worker online, chọn file và nhập đúng api_id/api_hash.");return;}
    if(files.length>100||files.reduce((n,f)=>n+f.size,0)>10*1024*1024){setError("Tối đa 100 file, tổng dung lượng tải lên 10 MiB. ZIP chứa tối đa 100 session.");return;}
    if(files.some(f=>!(/\.(session|zip)$/i.test(f.name)))){setError("Chỉ chọn file .session hoặc .zip.");return;}
    setBusy(true);setError("");
    const hash=apiHash.trim();setApiHash("");
    try{
      const upload=await Promise.all(files.map(async f=>({filename:f.name,content:await encode(f)})));
      const r=await api.post<{items:Item[]}>("/api/accounts/import-sessions",{worker_id:worker,api_id:Number(apiId),api_hash:hash,files:upload});
      setItems(r.items);setFiles([]);if(input.current)input.current.value="";
    }catch(e){setError(e instanceof ApiError?e.message:"Không nhập được session.");}
    finally{setBusy(false);}
  }
  async function retry(item:Item){
    if(!item.account_id)return;
    try{
      const r=await api.post<{command_id:string;status:string}>(`/api/accounts/${item.account_id}/import-session/retry`);
      setItems(old=>old.map(x=>x.index===item.index?{...x,...r,error_code:undefined,retry_after:undefined}:x));
    }catch(e){setError(e instanceof ApiError?e.message:"Không thể thử lại.");}
  }
  const active=items.some(i=>!terminal(i.status));
  return <Modal title="Nhập session hàng loạt" onClose={onClose} dismissible={!busy}
    footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{!items.length&&<button className="btn primary" disabled={busy||workers.loading} onClick={()=>void submit()}>{busy?"Đang nhập…":"Nhập và kiểm tra session"}</button>}</>}>
    {!items.length?<>
      <p>Chọn tối đa 100 file Telethon <strong>.session</strong> hoặc ZIP chứa các file đó. Tổng tải lên tối đa 10 MiB. Dừng ứng dụng đang dùng các session này trước khi nhập.</p>
      <SelectField label="Worker" value={worker} onChange={e=>setWorker(e.target.value)}><option value="">Chọn worker online</option>{online.map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</SelectField>
      {workers.error&&<Alert tone="bad">{workers.error.message}</Alert>}
      {!workers.loading&&!online.length&&<Alert>Chưa có worker online. Chạy run.cmd trước.</Alert>}
      <label className="field">File session hoặc ZIP<input ref={input} type="file" multiple accept=".session,.zip" disabled={busy} onChange={e=>setFiles(Array.from(e.target.files??[]))}/></label>
      <p className="hint">Đã chọn {files.length} file. Không hỗ trợ Pyrogram hoặc tdata. api_id/api_hash dùng cho lô này; nếu các tài khoản dùng nhiều API khác nhau, nhập thành từng lô.</p>
      <TextField label="api_id" inputMode="numeric" value={apiId} onChange={e=>setApiId(e.target.value.trim())} disabled={busy}/>
      <TextField label="api_hash" type="password" autoComplete="new-password" value={apiHash} onChange={e=>setApiHash(e.target.value)} disabled={busy}/>
    </>:<>
      <p role="status">Thành công: {items.filter(i=>i.status==="done").length} / {items.length} · Đang chờ/xử lý: {items.filter(i=>!terminal(i.status)).length} · Trùng: {items.filter(i=>i.status==="duplicate").length} · Lỗi: {items.filter(i=>["failed","expired","error"].includes(i.status)).length}</p>
      <p className="hint">Worker kiểm tra tối đa 3 session cùng lúc, không cần OTP nếu còn hiệu lực. Đóng cửa sổ này không hủy hàng đợi. Tài khoản thành công ở trạng thái Tắt, bạn có thể Bật khi cần.</p>
      <div style={{maxHeight:360,overflow:"auto"}}><table className="table"><thead><tr><th>File</th><th>Kết quả</th></tr></thead><tbody>{items.map(i=><tr key={i.index}><td>{i.filename}</td><td>{statuses[i.status]??i.status}{i.error_code&&<p className="hint">{importErrors[i.error_code]??errorLabel(i.error_code)}{i.retry_after?` — chờ ${i.retry_after} giây`:""}</p>}{["failed","expired"].includes(i.status)&&<button className="btn sm" onClick={()=>void retry(i)}>Kiểm tra lại</button>}</td></tr>)}</tbody></table></div>
      {!active&&<Alert>Đã xử lý xong lô. Tài khoản thành công xuất hiện trong danh sách. Session hết hiệu lực cần đăng nhập lại bằng OTP.</Alert>}
    </>}
    {error&&<Alert tone="bad">{error}</Alert>}
  </Modal>;
}
