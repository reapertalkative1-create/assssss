"""Per-account Telegram API credentials entered in the dashboard.

Each handle retains its own backend, so parallel account logins never share mutable API credentials.
Environment credentials remain a fallback for accounts created before the web configuration feature.
"""
from dataclasses import dataclass

from worker.client import NotFoundError
from worker.telegram_backend import BackendError, TelethonBackend


@dataclass(repr=False)
class AccountHandle:
    backend: object
    raw: object


class AccountTelegramBackend:
    def __init__(self, client, default_api_id=None, default_api_hash='', *, factory=TelethonBackend):
        self.client, self.default_api_id, self.default_api_hash, self.factory = client, default_api_id, default_api_hash, factory

    async def _for(self, account_id):
        try:
            config = await self.client.fetch_telegram_api(account_id)
        except NotFoundError as exc:
            if exc.code != 'telegram_api_not_configured':
                raise
            config = None
        if config:
            return self.factory(config.api_id, config.api_hash)
        if self.default_api_id and self.default_api_hash:
            return self.factory(self.default_api_id, self.default_api_hash)
        raise BackendError('telegram_api_not_configured')

    async def send_code_for(self, account_id, phone):
        backend = await self._for(account_id)
        return AccountHandle(backend, await backend.send_code(phone))

    async def connect_for(self, account_id, session):
        backend = await self._for(account_id)
        raw, user = await backend.connect(session)
        return AccountHandle(backend, raw), user

    async def send_code(self, phone):
        raise BackendError('telegram_api_not_configured')

    async def connect(self, session):
        raise BackendError('telegram_api_not_configured')

    async def sign_in_code(self, handle, code):
        return await handle.backend.sign_in_code(handle.raw, code)

    async def sign_in_password(self, handle, password):
        return await handle.backend.sign_in_password(handle.raw, password)

    def session_string(self, handle):
        return handle.backend.session_string(handle.raw)

    def is_connected(self, handle):
        return handle.backend.is_connected(handle.raw)

    async def disconnect(self, handle):
        await handle.backend.disconnect(handle.raw)

    async def log_out(self, handle):
        await handle.backend.log_out(handle.raw)

    async def prime(self, handle):
        await handle.backend.prime(handle.raw)

    async def resolve_chats(self, handle, chat_ids):
        return await handle.backend.resolve_chats(handle.raw, chat_ids)

    async def latest_message_id(self, handle, chat_id):
        return await handle.backend.latest_message_id(handle.raw, chat_id)

    async def history_since(self, handle, chat_id, min_id, limit):
        return await handle.backend.history_since(handle.raw, chat_id, min_id, limit)

    def watch(self, handle, chat_ids, callback):
        return handle.backend.watch(handle.raw, chat_ids, callback)

    def unwatch(self, handle, token):
        handle.backend.unwatch(handle.raw, token)

    async def forward(self, handle, source, message_id, dest, mode):
        return await handle.backend.forward(handle.raw, source, message_id, dest, mode)
