import type {Account} from '../api/types';
import {errorLabel} from './labels';
export function restrictionVerdict(a:Account):{tone:'ok'|'bad'|'warn'|'idle';title:string;reason:string}{
  if(a.health_status==='frozen'||a.spam_error==='account_frozen')return {tone:'bad',title:a.health_source==='manual'?'Đã đánh dấu đóng băng':'Tài khoản đóng băng',reason:a.health_source==='manual'?'Bạn đã đặt nhãn đóng băng cho tài khoản; đây chưa phải kết luận tự động của Telegram.':'Telegram xác nhận tài khoản bị đóng băng. Tài khoản có thể ở chế độ chỉ đọc.'};
  const text=(a.spam_response??'').toLowerCase().replace(/\s+/g,' ').trim();
  // Recognize a direct account-specific notice, never hypothetical/quoted warnings.
  if(/^(?:unfortunately[, ]+)?your account (?:was|has been|is) blocked for violations of (?:the )?telegram terms of service\b/.test(text))return {tone:'bad',title:'Tài khoản bị chặn',reason:'Telegram chặn tài khoản do vi phạm điều khoản sử dụng.'+(text.includes('based on user reports confirmed by our moderators')?' Các báo cáo đã được kiểm duyệt xác nhận.':'')};
  if(a.health_status==='dead')return {tone:'bad',title:a.health_error==='phone_banned'?'Tài khoản bị khóa':'Session hết hiệu lực',reason:errorLabel(a.health_error)||'Phiên đăng nhập không còn dùng được. Cần kiểm tra hoặc đăng nhập lại tài khoản.'};
  if(a.spam_status==='limited')return {tone:'bad',title:'Bị hạn chế spam',reason:'Telegram đang hạn chế gửi tin của tài khoản. Phạm vi và thời hạn hạn chế do Telegram quyết định.'};
  if(a.spam_status==='clear')return {tone:'ok',title:'Không bị hạn chế spam',reason:'SpamBot không ghi nhận hạn chế cấp tài khoản tại lần kiểm tra này. Quyền gửi trong từng nhóm vẫn phụ thuộc nhóm.'};
  if(a.spam_status==='error')return {tone:'warn',title:'Kiểm tra chưa thành công',reason:errorLabel(a.spam_error)||'Chưa lấy được kết quả từ Telegram. Kiểm tra worker và thử lại sau.'};
  if(a.spam_status==='unknown')return {tone:'warn',title:'Chưa xác định hạn chế',reason:'Phản hồi Telegram chưa đủ rõ để kết luận bị spam hay không. Có thể kiểm tra lại hoặc mở SpamBot trong mục Thao tác.'};
  return {tone:'idle',title:'Chưa kiểm tra spam',reason:'Bấm Check spam / đóng băng để kiểm tra tài khoản này.'};
}
