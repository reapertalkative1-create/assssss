"""Official @SpamBot only. Actions are explicit and never replayed automatically."""
import asyncio
import re
from datetime import datetime, timezone
from worker.telegram_backend import BackendError, map_error


def frozen_notice(text):
    value=' '.join(text.casefold().split())
    return bool(re.search(r'(?:^|[.!?]\s+)(?:unfortunately[, ]+)?your (?:telegram )?account (?:is(?: now| currently)?|has been) frozen\b', value)
                or re.search(r'(?:^|[.!?]\s+)ваш аккаунт заморожен\b', value))


def classify(text):
    value=' '.join(text.casefold().split())
    if frozen_notice(text):return 'error'
    if re.search(r'^(?:unfortunately[, ]+)?your account (?:was|has been|is) blocked for violations of (?:the )?telegram terms of service\b',value):return 'limited'
    if re.search(r'your account (?:is(?: now| currently)?|was|has been|will be) limited',value):return 'limited'
    if 'no limits are currently applied to your account' in value:return 'clear'
    if 'на ваш аккаунт не наложено никаких ограничений' in value:return 'clear'
    if 'ваш аккаунт ограничен' in value:return 'limited'
    return 'unknown'


def allowed_button(button):
    from telethon.tl import types as t
    if type(button) is t.KeyboardButton:
        kind=getattr(button,'type',None)
        return kind is None or type(kind) is getattr(t,'ButtonTypeDefault',None)
    legacy=getattr(t,'KeyboardButtonCallback',None)
    if legacy and type(button) is legacy:return True
    modern=getattr(t,'KeyboardInlineButton',None)
    return bool(modern and type(button) is modern and type(getattr(button,'type',None)) is getattr(t,'InlineButtonTypeCallback',None))


def describe(message):
    buttons=[]
    for i,row in enumerate(getattr(getattr(message,'reply_markup',None),'rows',[]) or []):
        for j,button in enumerate(row.buttons):
            if allowed_button(button):
                buttons.append({'id':f'{message.id}:{i}:{j}','text':str(button.text)[:200]})
    text=str(getattr(message,'raw_text','') or '')[:8000]
    # Mask full phone-like numbers before they leave the worker.
    text=re.sub(r'(?<!\w)\+?\d{8,15}(?!\w)',lambda m:m.group()[:3]+'…'+m.group()[-2:],text)
    date=getattr(message,'edit_date',None) or getattr(message,'date',None)
    return {'message_id':message.id,'text':text,'buttons':buttons[:30],
            'response_date':date.isoformat() if date else None,'status':classify(text),
            **({'error_code':'account_frozen'} if frozen_notice(text) else {})}


async def peer_for(client):
    peer=await client.get_entity('SpamBot')
    if not getattr(peer,'bot',False) or str(getattr(peer,'username','')).casefold()!='spambot':
        raise BackendError('spambot_identity_mismatch')
    return peer


async def interact(client,operation='check',*,text=None,button_id=None,expected_button_text=None,expected_reply_id=None,expected_prompt_hash=None):
    from telethon import events
    peer=await peer_for(client)
    if operation=='read':
        messages=await client.get_messages(peer,limit=10)
        incoming=[m for m in messages if not getattr(m,'out',False) and getattr(m,'sender_id',None)==peer.id]
        if not incoming:return {'status':'unknown','text':'','buttons':[],'message_id':0,'delivery':'read','error_code':'spambot_no_response'}
        return {**describe(incoming[0]),'delivery':'read'}
    button_message=None;row=col=0
    if operation=='button':
        try:message_id,row,col=map(int,button_id.split(':'))
        except (ValueError,AttributeError):raise BackendError('invalid_spambot_button') from None
        button_message=await client.get_messages(peer,ids=message_id)
        if button_message is None or getattr(button_message,'out',False) or getattr(button_message,'sender_id',None)!=peer.id:
            raise BackendError('stale_spam_report')
        try:
            if row<0 or col<0:raise IndexError
            button=button_message.reply_markup.rows[row].buttons[col]
        except (IndexError,AttributeError):raise BackendError('invalid_spambot_button') from None
        if not allowed_button(button) or str(button.text)[:200]!=expected_button_text:
            raise BackendError('invalid_spambot_button')
    elif operation=='reply':
        messages=await client.get_messages(peer,limit=5)
        latest=next((m for m in messages if not getattr(m,'out',False) and getattr(m,'sender_id',None)==peer.id),None)
        if latest is None or latest.id!=expected_reply_id:raise BackendError('stale_spam_report')
        if expected_prompt_hash:
            import hashlib
            if hashlib.sha256((latest.raw_text or '').encode()).hexdigest()!=expected_prompt_hash:raise BackendError('stale_spam_report')
    elif operation!='check':raise BackendError('invalid_spam_operation')
    queue=asyncio.Queue(maxsize=10)
    async def incoming(event):
        message=event.message
        if getattr(message,'out',False) or getattr(message,'sender_id',None)!=peer.id:return
        if queue.full():queue.get_nowait()
        queue.put_nowait(message)
    builders=[events.NewMessage(chats=peer,incoming=True),events.MessageEdited(chats=peer,incoming=True)]
    for builder in builders:client.add_event_handler(incoming,builder)
    attempted=False;sent=False
    try:
        attempted=True
        if operation=='button':await button_message.click(i=row,j=col)
        else:await client.send_message(peer,'/start' if operation=='check' else text)
        sent=True
        reply=await asyncio.wait_for(queue.get(),timeout=20)
        replies={reply.id:reply}
        # Give a multi-message response / message edit a short settling window.
        for _ in range(4):
            try:
                reply=await asyncio.wait_for(queue.get(),timeout=.5)
                replies[reply.id]=reply
            except asyncio.TimeoutError:break
        parts=[describe(m) for m in replies.values()]
        frozen=any(p.get('error_code')=='account_frozen' for p in parts)
        status=next((p['status'] for p in reversed(parts) if p['status']!='unknown'),'unknown')
        return {**describe(reply),'status':'error' if frozen else status,**({'error_code':'account_frozen'} if frozen else {}),'text':'\n\n'.join(p['text'] for p in parts)[:8000],'delivery':'sent'}
    except asyncio.TimeoutError:
        return {'status':'unknown','text':'','buttons':[],'message_id':0,'delivery':'sent' if sent else 'uncertain','error_code':'spambot_no_response'}
    except Exception as exc:
        error=map_error(exc)
        return {'status':'error','text':'','buttons':[],'message_id':0,
                'delivery':'uncertain' if attempted else 'not_sent','error_code':error.code,
                'retry_after':error.retry_after}
    finally:
        for builder in builders:client.remove_event_handler(incoming,builder)
