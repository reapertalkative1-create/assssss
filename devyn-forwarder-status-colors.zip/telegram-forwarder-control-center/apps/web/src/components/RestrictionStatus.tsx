import type {Account} from '../api/types';
import {restrictionVerdict} from '../lib/restrictionVerdict';
export function RestrictionStatus({a}:{a:Account}){
  const verdict=restrictionVerdict(a);
  return <section className={`ss-verdict ${verdict.tone}`} aria-label={`Kết luận hạn chế — ${a.name}`}>
    <strong className="ss-verdict-title"><span aria-hidden="true">{verdict.tone==='ok'?'✓':verdict.tone==='bad'?'!':'•'}</span>{verdict.title}</strong>
    <p><strong>Lý do: </strong>{verdict.reason}</p>
  </section>;
}
