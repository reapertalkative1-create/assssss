"""HTTPS client for the control plane. Outbound only; the credential never appears in logs or errors."""
from dataclasses import dataclass, field

import httpx


class ControlPlaneError(Exception):
    """Base class. Messages carry error codes only, never request/response bodies."""


class TransientError(ControlPlaneError):
    """Network failure, timeout, 429 or 5xx: retry with backoff."""


class AuthError(ControlPlaneError):
    """401/403: the credential is invalid, rotated away or revoked. Retrying cannot help."""

    def __init__(self, message: str, revoked: bool = False):
        super().__init__(message)
        self.revoked = revoked


class ConflictError(ControlPlaneError):
    """409 with a business reason (lease_held, lease_invalid, version_conflict...)."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class NotFoundError(ControlPlaneError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class FatalError(ControlPlaneError):
    """Misconfiguration the operator must fix (e.g. platform mismatch, unexpected 4xx)."""


@dataclass(frozen=True)
class Assignment:
    account_id: str
    desired_state: str  # running | stopped
    proxy_version: int = 0


@dataclass
class RouteConfig:
    route_id: str
    account_id: str
    name: str
    sources: tuple[int, ...]
    destinations: tuple[int, ...]
    mode: str
    filters: dict
    version: str
    checkpoints: dict[int, int] = field(default_factory=dict)  # source chat -> last message id handed to the queue


def _routes(items) -> tuple[RouteConfig, ...]:
    return tuple(RouteConfig(str(i["route_id"]), str(i["account_id"]), i["name"], tuple(i["source_chat_ids"]),
                             tuple(i["destination_chat_ids"]), i["mode"], dict(i.get("filters") or {}), i["version"],
                             {int(k): int(v) for k, v in (i.get("checkpoints") or {}).items()}) for i in items or ())


@dataclass(frozen=True)
class RegisterInfo:
    worker_id: str
    name: str
    heartbeat_interval_seconds: float
    heartbeat_timeout_seconds: float
    report_resources: bool
    lease_ttl_seconds: float = 60.0
    accounts: tuple[Assignment, ...] = ()
    routes: tuple[RouteConfig, ...] = ()


@dataclass(frozen=True)
class HeartbeatInfo:
    report_resources: bool
    lease_ttl_seconds: float = 60.0
    accounts: tuple[Assignment, ...] = ()
    lost_leases: tuple[str, ...] = ()
    routes: tuple[RouteConfig, ...] = ()


@dataclass(frozen=True)
class SessionData:
    session: str  # secret: held in memory only, never logged or written to disk
    version: int

    def __repr__(self) -> str:
        return f"SessionData(version={self.version})"


def _assignments(items) -> tuple[Assignment, ...]:
    return tuple(Assignment(str(i["account_id"]), i["desired_state"],int(i.get("proxy_version",0))) for i in items or ())


def _error_code(resp: httpx.Response) -> str:
    try:
        return str(resp.json()["error"]["code"])[:64]
    except Exception:
        return "unknown"


@dataclass
class TelegramApiData:
    api_id: int
    api_hash: str = field(repr=False)


class ControlPlaneClient:
    def __init__(self, base_url: str, credential: str, *, http: httpx.AsyncClient | None = None, timeout: float = 15.0):
        self._owns_http = http is None
        self._http = http or httpx.AsyncClient(base_url=base_url, timeout=timeout)
        self._headers = {"Authorization": f"Bearer {credential}"}

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    async def claim_proxy_checks(self):
        return (await self._post('/api/worker/v1/proxy-checks/claim', {}))['items']

    async def proxy_check_results(self, items):
        return await self._post('/api/worker/v1/proxy-checks/results', {'items': items})

    async def _post(self, path: str, payload: dict, *, method: str = "POST", timeout: float | None = None) -> dict:
        try:
            kwargs = {"timeout": timeout} if timeout else {}
            resp = await self._http.request(method, path, json=payload, headers=self._headers, **kwargs)
        except httpx.TransportError as exc:
            raise TransientError(type(exc).__name__) from None  # no URL/headers in the message
        code = _error_code(resp) if resp.status_code >= 400 else ""
        if resp.status_code == 401:
            raise AuthError("credential rejected (invalid or rotated)")
        if resp.status_code == 403:
            raise AuthError(f"access denied: {code}", revoked=code == "worker_revoked")
        if resp.status_code == 409 and code != "platform_mismatch":
            raise ConflictError(code)
        if resp.status_code == 404:
            raise NotFoundError(code)
        if resp.status_code == 429 or resp.status_code >= 500:
            raise TransientError(f"http {resp.status_code}")
        if resp.status_code >= 400:
            raise FatalError(f"http {resp.status_code}: {code}")
        try:
            return resp.json()
        except ValueError:
            raise TransientError("invalid json") from None

    async def register(self, platform: str, version: str, hostname: str | None) -> RegisterInfo:
        d = await self._post("/api/worker/v1/register", {"platform": platform, "version": version, "hostname": hostname})
        return RegisterInfo(
            worker_id=d["worker_id"], name=d["name"],
            heartbeat_interval_seconds=float(d["heartbeat_interval_seconds"]),
            heartbeat_timeout_seconds=float(d["heartbeat_timeout_seconds"]),
            report_resources=bool(d["report_resources"]),
            lease_ttl_seconds=float(d.get("lease_ttl_seconds", 60)), accounts=_assignments(d.get("accounts")),
            routes=_routes(d.get("routes")),
        )

    async def heartbeat(self, payload: dict) -> HeartbeatInfo:
        d = await self._post("/api/worker/v1/heartbeat", payload)
        return HeartbeatInfo(
            report_resources=bool(d.get("report_resources", True)),
            lease_ttl_seconds=float(d.get("lease_ttl_seconds", 60)), accounts=_assignments(d.get("accounts")),
            lost_leases=tuple(str(x) for x in d.get("lost_leases", ())), routes=_routes(d.get("routes")),
        )

    # ----- Telegram accounts -----
    async def poll_commands(self, wait_seconds: int) -> list[dict]:
        d = await self._post("/api/worker/v1/commands/poll", {"wait_seconds": wait_seconds}, timeout=wait_seconds + 15)
        return list(d.get("commands", []))

    async def post_command_result(self, command_id: str, status: str, result: dict | None = None,
                                  error_code: str | None = None, retry_after: int | None = None) -> None:
        await self._post(f"/api/worker/v1/commands/{command_id}/result",
                         {"status": status, "result": result, "error_code": error_code, "retry_after": retry_after})

    async def fetch_proxy(self,account_id:str) -> dict:
        return await self._post(f'/api/worker/v1/accounts/{account_id}/proxy/fetch',{})

    async def fetch_telegram_api(self, account_id: str) -> TelegramApiData:
        data = await self._post(f'/api/worker/v1/accounts/{account_id}/telegram-api/fetch', {})
        return TelegramApiData(int(data['api_id']), str(data['api_hash']))

    async def acquire_lease(self, account_id: str) -> tuple[int, float]:
        d = await self._post(f"/api/worker/v1/accounts/{account_id}/lease", {})
        return int(d["epoch"]), float(d["ttl_seconds"])

    async def release_lease(self, account_id: str, epoch: int) -> None:
        await self._post(f"/api/worker/v1/accounts/{account_id}/lease/release", {"epoch": epoch})

    async def fetch_session(self, account_id: str, epoch: int) -> SessionData:
        d = await self._post(f"/api/worker/v1/accounts/{account_id}/session/fetch", {"epoch": epoch})
        return SessionData(d["session"], int(d["version"]))

    async def upload_session(self, account_id: str, epoch: int, session: str, expected_version: int | None) -> int:
        d = await self._post(f"/api/worker/v1/accounts/{account_id}/session",
                             {"epoch": epoch, "session": session, "expected_version": expected_version}, method="PUT")
        return int(d["version"])


    # ----- forwarding queue -----
    async def enqueue(self, route_id: str, items: list[tuple[int, int]], checkpoints: dict[int, int]) -> tuple[int, int]:
        d = await self._post("/api/worker/v1/jobs/enqueue", {
            "route_id": route_id, "items": [{"source_chat_id": s, "message_id": m} for s, m in items],
            "checkpoints": {str(k): v for k, v in checkpoints.items()}})
        return int(d["created"]), int(d["duplicates"])

    async def claim_jobs(self, max_jobs: int, wait_seconds: int) -> list[dict]:
        d = await self._post("/api/worker/v1/jobs/claim", {"max_jobs": max_jobs, "wait_seconds": wait_seconds},
                             timeout=wait_seconds + 15)
        return list(d.get("jobs", []))

    async def start_jobs(self, jobs: list[dict]) -> tuple[set[str], set[str]]:
        d = await self._post("/api/worker/v1/jobs/start", {"jobs": [{"id": j["id"], "epoch": j["epoch"]} for j in jobs]})
        return {str(x) for x in d["started"]}, {str(x) for x in d["lost"]}

    async def post_job_results(self, results: list[dict]) -> list[dict]:
        d = await self._post("/api/worker/v1/jobs/results", {"results": results})
        return list(d.get("outcomes", []))
