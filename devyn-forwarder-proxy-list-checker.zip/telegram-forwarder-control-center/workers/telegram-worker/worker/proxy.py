"""Probe a fixed Telegram HTTPS endpoint through the configured proxy, without a session."""
import asyncio
import ssl
import time
from urllib.parse import quote
from worker.telegram_backend import BackendError


async def check_proxy(config):
    from python_socks.async_.asyncio import Proxy
    host=config['host'];host='['+host+']' if ':' in host else host
    auth=(quote(config['username'],safe='')+':'+quote(config.get('password') or '',safe='')+'@') if config.get('username') else ''
    url=f"{config['protocol']}://{auth}{host}:{config['port']}"
    sock=None;writer=None;start=time.monotonic()
    try:
        async with asyncio.timeout(12):
            sock=await Proxy.from_url(url).connect(dest_host='api.telegram.org',dest_port=443,timeout=8)
            _,writer=await asyncio.open_connection(sock=sock,ssl=ssl.create_default_context(),server_hostname='api.telegram.org')
            sock=None
            return {'latency_ms':min(60000,int((time.monotonic()-start)*1000))}
    except (asyncio.TimeoutError,TimeoutError):raise BackendError('proxy_timeout') from None
    except ssl.SSLError:raise BackendError('proxy_tls_failed') from None
    except Exception as exc:
        code='proxy_auth_failed' if 'auth' in type(exc).__name__.lower() else 'proxy_check_failed'
        raise BackendError(code) from None
    finally:
        if writer:
            writer.close()
            try:await asyncio.wait_for(writer.wait_closed(),timeout=1)
            except Exception:pass
        if sock:sock.close()
