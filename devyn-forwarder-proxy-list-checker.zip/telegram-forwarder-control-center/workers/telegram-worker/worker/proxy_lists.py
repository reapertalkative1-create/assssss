"""Standalone list checker. No Telegram backend, session or API credentials involved."""
import asyncio

from worker.client import AuthError, ConflictError, FatalError, NotFoundError, TransientError
from worker.proxy import check_proxy
from worker.telegram_backend import BackendError

ERRORS = {'proxy_timeout', 'proxy_tls_failed', 'proxy_auth_failed', 'proxy_check_failed'}


class ProxyListChecker:
    def __init__(self, client, *, probe=None):
        self.client, self.probe = client, probe or check_proxy

    async def _check(self, item):
        result = {'id': item['id'], 'token': item['token']}
        try:
            async with asyncio.timeout(15):
                value = await self.probe(item['proxy'])
            return {**result, 'status': 'alive', 'latency_ms': value['latency_ms']}
        except (asyncio.TimeoutError, TimeoutError):
            return {**result, 'status': 'dead', 'error_code': 'proxy_timeout'}
        except BackendError as exc:
            return {**result, 'status': 'dead', 'error_code': exc.code if exc.code in ERRORS else 'proxy_check_failed'}
        except Exception:
            return {**result, 'status': 'dead', 'error_code': 'proxy_check_failed'}

    async def once(self):
        items = await self.client.claim_proxy_checks()
        if not items: return False
        # The server leases at most ten probes per worker; each has a short timeout.
        results = await asyncio.gather(*(self._check(item) for item in items[:10]))
        # Retry only the report, never rerun a proxy because an acknowledgement was lost.
        for attempt in range(3):
            try:
                await self.client.proxy_check_results(results)
                break
            except TransientError:
                if attempt == 2: raise
                await asyncio.sleep(1)
        return True

    async def run(self, stop, *, ready=lambda: True):
        while not stop.is_set():
            delay = 1
            if ready():
                try:
                    if await self.once(): delay = .1
                except (AuthError, ConflictError, FatalError, NotFoundError, TransientError):
                    delay = 5
                except Exception:
                    # Do not log response bodies or proxy URLs/credentials.
                    delay = 5
            try: await asyncio.wait_for(stop.wait(), timeout=delay)
            except asyncio.TimeoutError: pass
