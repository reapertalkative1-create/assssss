"""Connection lifecycle: register -> heartbeat loop -> on failure back off and register again.

Re-registering after every outage is the resynchronisation step. Job and Telegram-account
assignments are added to that handshake in later phases."""
import asyncio
import logging
import time
from collections.abc import Awaitable, Callable

from worker.accounts import AccountManager
from worker.backoff import Backoff
from worker.client import AuthError, ControlPlaneClient, FatalError, TransientError
from worker.forwarding import ForwardEngine
from worker.proxy_lists import ProxyListChecker

log = logging.getLogger("tfcc.worker")

EXIT_OK, EXIT_CONFIG, EXIT_AUTH, EXIT_FATAL = 0, 1, 2, 3  # systemd/Windows service must not restart on 2 or 3

HealthProvider = Callable[[], tuple[str, str | None, int]]  # (health, degraded_reason, running_jobs)
ResourceProvider = Callable[[], dict | None]


def _default_health() -> tuple[str, str | None, int]:
    return "ok", None, 0


class Runner:
    def __init__(
        self,
        client: ControlPlaneClient,
        *,
        platform: str,
        version: str,
        hostname: str | None,
        backoff: Backoff | None = None,
        health_provider: HealthProvider = _default_health,
        resource_provider: ResourceProvider = lambda: None,
        stop_event: asyncio.Event | None = None,
        wait: Callable[[float], Awaitable[None]] | None = None,
        accounts: AccountManager | None = None,
        engine: ForwardEngine | None = None,
        clock: Callable[[], float] = time.monotonic,
    ):
        self._client, self._platform, self._version, self._hostname = client, platform, version, hostname
        self._backoff = backoff or Backoff()
        self._health, self._resources = health_provider, resource_provider
        self.stop_event = stop_event or asyncio.Event()
        self._wait = wait or self._interruptible_sleep
        self._accounts, self._clock, self._engine = accounts, clock, engine
        self.connected = False

    async def _interruptible_sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self.stop_event.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    def stop(self) -> None:
        self.stop_event.set()

    def _payload(self, report_resources: bool) -> dict:
        health, reason, running = self._health()
        payload: dict = {"health": health, "degraded_reason": reason, "running_jobs": running}
        if self._accounts is not None:
            payload["accounts"] = self._accounts.heartbeat_accounts()
        if report_resources:
            res = self._resources()
            if res:
                payload["resources"] = res
        return payload

    async def run(self) -> int:
        tasks: list[asyncio.Task] = []
        if self._accounts is not None:
            # These two keep running across outages: the fencing loop must keep enforcing lease deadlines
            # even while the control plane is unreachable.
            tasks = [asyncio.create_task(self._accounts.command_loop(self.stop_event)),
                     asyncio.create_task(self._accounts.fencing_loop(self.stop_event))]
            if self._engine is not None:
                tasks.append(asyncio.create_task(self._engine.run(self.stop_event)))
        if callable(getattr(self._client, 'claim_proxy_checks', None)):
            tasks.append(asyncio.create_task(ProxyListChecker(self._client).run(self.stop_event, ready=lambda: self.connected)))
        try:
            return await self._run_loop()
        finally:
            for t in tasks:
                t.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
            if self._engine is not None:
                await self._engine.shutdown()
            if self._accounts is not None:
                await self._accounts.shutdown()

    async def _run_loop(self) -> int:
        while not self.stop_event.is_set():
            try:
                sent_at = self._clock()
                info = await self._client.register(self._platform, self._version, self._hostname)
            except TransientError as exc:
                delay = self._backoff.next()
                log.warning("register_failed", extra={"reason": str(exc), "retry_in": round(delay, 1)})
                await self._wait(delay)
                continue
            except AuthError as exc:
                return self._auth_exit(exc)
            except FatalError as exc:
                log.error("fatal_error", extra={"reason": str(exc)})
                return EXIT_FATAL

            self._backoff.reset()
            self.connected = True
            if self._accounts is not None:
                await self._accounts.on_register(info, sent_at)
                if self._engine is not None:
                    await self._engine.on_routes(info.routes)
            interval, report = max(1.0, info.heartbeat_interval_seconds), info.report_resources
            log.info("connected", extra={"worker_id": info.worker_id, "interval": interval})

            while True:
                await self._wait(interval)
                if self.stop_event.is_set():
                    break
                try:
                    payload = self._payload(report)
                    sent_at = self._clock()
                    hb = await self._client.heartbeat(payload)
                    report = hb.report_resources
                    if self._accounts is not None:
                        await self._accounts.on_heartbeat(hb, sent_at)
                        if self._engine is not None:
                            await self._engine.on_routes(hb.routes)
                except TransientError as exc:
                    self.connected = False
                    delay = self._backoff.next()
                    log.warning("connection_lost", extra={"reason": str(exc), "retry_in": round(delay, 1)})
                    await self._wait(delay)
                    break  # back to the outer loop: register again to resynchronise
                except AuthError as exc:
                    self.connected = False
                    return self._auth_exit(exc)
                except FatalError as exc:
                    log.error("fatal_error", extra={"reason": str(exc)})
                    return EXIT_FATAL
        self.connected = False
        return EXIT_OK

    @staticmethod
    def _auth_exit(exc: AuthError) -> int:
        log.error("credential_rejected", extra={"revoked": exc.revoked, "reason": str(exc)})
        return EXIT_AUTH
