import hashlib
import json
import re
from app.crypto import CryptoError


def blocked_notice(text):
    value=' '.join(str(text or '').casefold().split())
    return bool(re.search(r'^(?:unfortunately[, ]+)?your account (?:was|has been|is) blocked for violations of (?:the )?telegram terms of service\b',value))


def clean_report(value):
    if not isinstance(value,dict):return None
    report={'status':value.get('status') if value.get('status') in ('clear','limited','blocked','unknown','error') else 'unknown',
            'text':str(value.get('text') or '')[:8000],'buttons':[]}
    if report['status'] in ('limited','unknown') and blocked_notice(report['text']):report['status']='blocked'
    mid=value.get('message_id')
    report['message_id']=mid if type(mid) is int and 0<mid<2147483648 else 0
    for b in value.get('buttons',[])[:30] if isinstance(value.get('buttons'),list) else []:
        if not isinstance(b,dict):continue
        ident=str(b.get('id',''))
        if re.fullmatch(r'[0-9]{1,10}:[0-9]{1,3}:[0-9]{1,3}',ident) and ident.startswith(str(report['message_id'])+':'):
            report['buttons'].append({'id':ident,'text':str(b.get('text',''))[:200]})
    report['delivery']=value.get('delivery') if value.get('delivery') in ('sent','not_sent','uncertain','read') else 'not_sent'
    code=value.get('error_code')
    if isinstance(code,str) and re.fullmatch('[a-z0-9_]{1,64}',code):report['error_code']=code
    seconds=value.get('retry_after')
    if type(seconds) is int and 0<seconds<=86400:report['retry_after']=seconds
    date=value.get('response_date')
    if isinstance(date,str):report['response_date']=date[:50]
    return report


def token(report):
    snapshot={key:report.get(key) for key in ('message_id','text','buttons','response_date')}
    return hashlib.sha256(json.dumps(snapshot,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def load_report(box,account):
    if not account.spam_reply_ciphertext or box is None:return None
    try:return json.loads(box.open('spam_report',str(account.id),account.spam_reply_ciphertext))
    except (CryptoError,ValueError):return None


async def restore_blocked_statuses(sessionmaker,box):
    """One-time-per-startup, bounded repair of cached pre-blocked classifications."""
    if box is None:return 0
    from sqlalchemy import select,update
    from app.models import TelegramAccount as A
    cursor=None;changed=0
    while True:
        async with sessionmaker() as db:
            query=select(A.id,A.spam_status,A.spam_reply_ciphertext).where(A.spam_status.in_(('limited','unknown')),A.spam_reply_ciphertext.is_not(None))
            if cursor is not None:query=query.where(A.id>cursor)
            rows=(await db.execute(query.order_by(A.id).limit(200))).all()
            if not rows:break
            for aid,status,ciphertext in rows:
                try:report=json.loads(box.open('spam_report',str(aid),ciphertext))
                except (CryptoError,ValueError):continue
                if isinstance(report,dict) and blocked_notice(report.get('text')):
                    result=await db.execute(update(A).where(A.id==aid,A.spam_status==status,A.spam_reply_ciphertext==ciphertext).values(spam_status='blocked').execution_options(synchronize_session=False))
                    changed+=result.rowcount
            await db.commit()
            cursor=rows[-1].id
    return changed
