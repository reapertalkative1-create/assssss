import json

from pydantic import ValidationError

from app.crypto import CryptoError
from app.errors import ApiError
from app.models import ApplicationSetting
from app.schemas_accounts import TelegramApiConfig

TELEGRAM_API_KEY = 'telegram_api'


async def saved_telegram_api(db, box, *, required=False):
    row = await db.get(ApplicationSetting, TELEGRAM_API_KEY)
    if row is None:
        if required:
            raise ApiError(409, 'telegram_api_not_configured', 'Vào Cài đặt → API Telegram để nhập api_id/api_hash một lần trước khi nhập SS.')
        return None
    if box is None:
        raise ApiError(503, 'encryption_not_configured', 'Chưa có khóa mã hóa cấu hình Telegram.')
    try:
        return TelegramApiConfig.model_validate(json.loads(box.open('app_setting', TELEGRAM_API_KEY, row.value_ciphertext)))
    except (CryptoError, ValidationError, ValueError, TypeError, KeyError):
        raise ApiError(409, 'telegram_api_unreadable', 'Không đọc được API Telegram đã lưu. Kiểm tra khóa mã hóa hoặc lưu lại trong Cài đặt.') from None


async def resolve_telegram_api(body, db, box, *, required=False):
    if body.api_id is not None:
        return TelegramApiConfig(api_id=body.api_id, api_hash=body.api_hash)
    return await saved_telegram_api(db, box, required=required)
