import uuid
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator


class ProxyListCreate(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: uuid.UUID
    worker_id: uuid.UUID
    text: SecretStr = Field(min_length=1, max_length=2000000)
    protocol: Literal['socks5', 'socks4', 'http'] = 'socks5'


class ProxyListResult(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: uuid.UUID
    token: uuid.UUID
    status: Literal['alive', 'dead']
    latency_ms: int | None = Field(default=None, ge=0, le=60000)
    error_code: Literal['proxy_timeout', 'proxy_tls_failed', 'proxy_auth_failed', 'proxy_check_failed'] | None = None

    @model_validator(mode='after')
    def valid_result(self):
        if self.status == 'alive' and (self.latency_ms is None or self.error_code is not None):
            raise ValueError('Kết quả thành công cần latency và không có lỗi.')
        if self.status == 'dead' and (self.error_code is None or self.latency_ms is not None):
            raise ValueError('Kết quả thất bại cần mã lỗi và không có latency.')
        return self


class ProxyListResults(BaseModel):
    model_config = ConfigDict(extra='forbid')
    items: list[ProxyListResult] = Field(min_length=1, max_length=10)
