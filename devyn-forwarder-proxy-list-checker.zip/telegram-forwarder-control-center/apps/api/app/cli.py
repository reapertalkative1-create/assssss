"""Operator CLI.  Usage: python -m app.cli create-admin USERNAME [--password-stdin]"""
import argparse
import asyncio
import getpass
import sys

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.config import get_settings
from app.db import make_engine, make_sessionmaker
from app.models import AuditLog, Role, User
from app.schemas import normalize_username
from app.security import hash_password, validate_password_policy


async def create_admin(database_url: str, username: str, password: str) -> None:
    username = normalize_username(username)
    problem = validate_password_policy(password, username)
    if problem:
        raise SystemExit(problem)
    engine = make_engine(database_url)
    try:
        async with make_sessionmaker(engine)() as db:
            if (await db.execute(select(User).where(User.username == username))).scalar_one_or_none():
                raise SystemExit(f"Người dùng '{username}' đã tồn tại.")
            user = User(username=username, password_hash=hash_password(password), role=Role.ADMIN)
            db.add(user)
            try:
                await db.flush()
            except IntegrityError:
                raise SystemExit(f"Người dùng '{username}' đã tồn tại.") from None
            db.add(AuditLog(actor_username="cli", action="user.create", target_type="user",
                            target_id=str(user.id), details={"username": username, "role": "admin"}))
            await db.commit()
    finally:
        await engine.dispose()


def main(argv: list[str] | None = None) -> int:
    handled = key_main(list(sys.argv[1:] if argv is None else argv))
    if handled is not None:
        return handled
    parser = argparse.ArgumentParser(prog="tfcc")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("generate-key", help="Print a new session-encryption key")
    sub.add_parser("verify-keys", help="Check all stored sessions decrypt with the configured keys")
    sub.add_parser("rotate-keys", help="Re-encrypt all sessions with the primary key")
    p = sub.add_parser("create-admin", help="Create an administrator (no default credentials exist)")
    p.add_argument("username")
    p.add_argument("--password-stdin", action="store_true", help="Read the password from stdin (for scripts)")
    args = parser.parse_args(argv)

    if args.password_stdin:
        password = sys.stdin.readline().rstrip("\r\n")
    else:
        password = getpass.getpass("Mật khẩu: ")
        if password != getpass.getpass("Nhập lại mật khẩu: "):
            raise SystemExit("Hai mật khẩu không khớp.")
    asyncio.run(create_admin(get_settings().database_url, args.username, password))
    print(f"Đã tạo quản trị viên '{normalize_username(args.username)}'.")
    return 0




# ---------------------------------------------------------------- key management (see docs/key-management.md)
async def verify_keys(database_url: str, box) -> dict:
    """Check that every stored session / pending payload decrypts with the configured keys. Prints no secrets."""
    from app.crypto import CryptoError
    from app.models import ApplicationSetting, ProxyCheckItem, TelegramAccount, WorkerCommand

    out = {"sessions_ok": 0, "sessions_failed": 0, "sessions_on_old_key": 0, "payloads_ok": 0, "payloads_failed": 0,
           'api_configs_ok': 0, 'api_configs_failed': 0, 'spam_reports_ok':0, 'spam_reports_failed':0,'appeal_drafts_ok':0,'appeal_drafts_failed':0,'proxies_ok':0,'proxies_failed':0}
    engine = make_engine(database_url)
    try:
        async with make_sessionmaker(engine)() as db:
            out['settings_ok'] = out['settings_failed'] = 0
            out['proxy_lists_ok'] = out['proxy_lists_failed'] = 0
            for item in (await db.execute(select(ProxyCheckItem))).scalars():
                try:
                    box.open('proxy_check', str(item.id), item.proxy_ciphertext)
                    out['proxy_lists_ok'] += 1
                except CryptoError:
                    out['proxy_lists_failed'] += 1
            for setting in (await db.execute(select(ApplicationSetting))).scalars():
                try:
                    box.open('app_setting', setting.key, setting.value_ciphertext)
                    out['settings_ok'] += 1
                except CryptoError:
                    out['settings_failed'] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.session_ciphertext.is_not(None)))).scalars():
                try:
                    box.open("session", str(a.id), a.session_ciphertext)
                    out["sessions_ok"] += 1
                    out["sessions_on_old_key"] += 0 if box.is_current(a.session_ciphertext) else 1
                except CryptoError:
                    out["sessions_failed"] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.telegram_api_ciphertext.is_not(None)))).scalars():
                try:
                    box.open('telegram_app', str(a.id), a.telegram_api_ciphertext)
                    out['api_configs_ok'] += 1
                except CryptoError:
                    out['api_configs_failed'] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.proxy_ciphertext.is_not(None)))).scalars():
                try:box.open('account_proxy',str(a.id),a.proxy_ciphertext);out['proxies_ok']+=1
                except CryptoError:out['proxies_failed']+=1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.spam_reply_ciphertext.is_not(None)))).scalars():
                try:
                    box.open('spam_report',str(a.id),a.spam_reply_ciphertext);out['spam_reports_ok']+=1
                except CryptoError:out['spam_reports_failed']+=1
            from app.models import AccountBulkJob,AccountBulkItem
            for model,field,purpose in [(AccountBulkJob,'settings_ciphertext','appeal_settings'),(AccountBulkItem,'payload_ciphertext','appeal_preview')]:
                for row in (await db.execute(select(model).where(getattr(model,field).is_not(None)))).scalars():
                    owner=str(row.id) if model is AccountBulkJob else f'{row.job_id}:{row.account_id}'
                    try:box.open(purpose,owner,getattr(row,field));out['appeal_drafts_ok']+=1
                    except CryptoError:out['appeal_drafts_failed']+=1
            for c in (await db.execute(select(WorkerCommand).where(WorkerCommand.payload_ciphertext.is_not(None)))).scalars():
                try:
                    box.open("command", str(c.id), c.payload_ciphertext)
                    out["payloads_ok"] += 1
                except CryptoError:
                    out["payloads_failed"] += 1
    finally:
        await engine.dispose()
    return out


async def rotate_keys(database_url: str, box) -> dict:
    """Re-encrypt everything with the primary (first) key. Run after putting a new key first in the key list."""
    from app.models import ApplicationSetting, ProxyCheckItem, TelegramAccount, WorkerCommand

    rotated = {"sessions": 0, "payloads": 0, 'api_configs': 0, 'spam_reports':0,'appeal_drafts':0,'proxies':0}
    engine = make_engine(database_url)
    try:
        async with make_sessionmaker(engine)() as db:
            rotated['settings'] = 0
            rotated['proxy_lists'] = 0
            for item in (await db.execute(select(ProxyCheckItem))).scalars():
                if not box.is_current(item.proxy_ciphertext):
                    item.proxy_ciphertext = box.rotate(item.proxy_ciphertext)
                    rotated['proxy_lists'] += 1
            for setting in (await db.execute(select(ApplicationSetting))).scalars():
                if not box.is_current(setting.value_ciphertext):
                    setting.value_ciphertext = box.rotate(setting.value_ciphertext)
                    rotated['settings'] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.session_ciphertext.is_not(None)))).scalars():
                if not box.is_current(a.session_ciphertext):
                    a.session_ciphertext = box.rotate(a.session_ciphertext)
                    rotated["sessions"] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.telegram_api_ciphertext.is_not(None)))).scalars():
                if not box.is_current(a.telegram_api_ciphertext):
                    a.telegram_api_ciphertext = box.rotate(a.telegram_api_ciphertext)
                    rotated['api_configs'] += 1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.proxy_ciphertext.is_not(None)))).scalars():
                if not box.is_current(a.proxy_ciphertext):a.proxy_ciphertext=box.rotate(a.proxy_ciphertext);rotated['proxies']+=1
            for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.spam_reply_ciphertext.is_not(None)))).scalars():
                if not box.is_current(a.spam_reply_ciphertext):
                    a.spam_reply_ciphertext=box.rotate(a.spam_reply_ciphertext);rotated['spam_reports']+=1
            from app.models import AccountBulkJob,AccountBulkItem
            for model,field in [(AccountBulkJob,'settings_ciphertext'),(AccountBulkItem,'payload_ciphertext')]:
                for row in (await db.execute(select(model).where(getattr(model,field).is_not(None)))).scalars():
                    value=getattr(row,field)
                    if not box.is_current(value):setattr(row,field,box.rotate(value));rotated['appeal_drafts']+=1
            for c in (await db.execute(select(WorkerCommand).where(WorkerCommand.payload_ciphertext.is_not(None)))).scalars():
                if not box.is_current(c.payload_ciphertext):
                    c.payload_ciphertext = box.rotate(c.payload_ciphertext)
                    rotated["payloads"] += 1
            db.add(AuditLog(actor_username="cli", action="keys.rotated", details=rotated))
            await db.commit()
    finally:
        await engine.dispose()
    return rotated


def _box_from_settings():
    from app.crypto import CryptoError, build_secret_box

    s = get_settings()
    try:
        box = build_secret_box(s.session_encryption_key.get_secret_value(), s.session_encryption_key_file)
    except CryptoError as exc:
        raise SystemExit(str(exc)) from None
    if box is None:
        raise SystemExit("Chưa cấu hình TFCC_SESSION_ENCRYPTION_KEY (hoặc _FILE).")
    return box


def key_main(argv: list[str]) -> int | None:
    """Handles generate-key / verify-keys / rotate-keys; returns None for other commands."""
    if not argv or argv[0] not in ("generate-key", "verify-keys", "rotate-keys"):
        return None
    cmd = argv[0]
    if cmd == "generate-key":
        from app.crypto import SecretBox
        print(SecretBox.generate_key())
        print("Lưu khóa này ở nơi AN TOÀN, TÁCH RIÊNG với bản sao lưu database (xem docs/key-management.md).", file=sys.stderr)
        return 0
    box = _box_from_settings()
    result = asyncio.run((verify_keys if cmd == "verify-keys" else rotate_keys)(get_settings().database_url, box))
    print(result)
    return 1 if any(value for key, value in result.items() if key.endswith('_failed')) else 0


if __name__ == "__main__":
    raise SystemExit(main())
