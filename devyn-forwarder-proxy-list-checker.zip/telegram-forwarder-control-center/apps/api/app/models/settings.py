from datetime import datetime

from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base
from app.types import UTCDateTime, utcnow


class ApplicationSetting(Base):
    __tablename__ = 'application_settings'

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value_ciphertext: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
