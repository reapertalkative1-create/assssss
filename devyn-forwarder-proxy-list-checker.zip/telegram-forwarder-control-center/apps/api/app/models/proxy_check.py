import uuid
from datetime import datetime

from sqlalchemy import ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
from app.types import UTCDateTime, utcnow


class ProxyCheckBatch(Base):
    __tablename__ = 'proxy_check_batches'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    worker_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey('workers.id', ondelete='SET NULL'), index=True)
    created_by: Mapped[uuid.UUID] = mapped_column(index=True)
    status: Mapped[str] = mapped_column(String(16), default='running')
    total: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ProxyCheckItem(Base):
    __tablename__ = 'proxy_check_items'
    __table_args__ = (UniqueConstraint('batch_id', 'position', name='uq_proxy_check_position'),
                     Index('ix_proxy_check_batch_status', 'batch_id', 'status'))
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    batch_id: Mapped[uuid.UUID] = mapped_column(ForeignKey('proxy_check_batches.id', ondelete='CASCADE'))
    position: Mapped[int] = mapped_column(Integer)
    proxy_ciphertext: Mapped[str] = mapped_column(Text)
    label: Mapped[str] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(16), default='pending')
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    error_code: Mapped[str | None] = mapped_column(String(32))
    checked_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    lease_token: Mapped[uuid.UUID | None] = mapped_column()
    lease_until: Mapped[datetime | None] = mapped_column(UTCDateTime)
