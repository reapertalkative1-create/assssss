"""Worker-facing endpoints for Telegram accounts. All of them require the worker's bearer credential."""
import asyncio
import time
import uuid
import json

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit, record_system_audit
from app.crypto import CryptoError
from app.deps import get_db
from app.deps_worker import get_worker
from app.errors import ApiError
from app.models import TelegramAccount, Worker, WorkerCommand
from app.schemas_accounts import (
    CommandResultIn, EpochIn, LeaseOut, PollRequest, PollResponse, SessionFetchOut, SessionUpload, SessionVersionOut,
)
from app.services import accounts as svc
from app.types import utcnow

router = APIRouter(prefix="/api/worker/v1", tags=["worker-accounts"])


@router.post('/accounts/{account_id}/proxy/fetch')
async def fetch_proxy(account_id:uuid.UUID,request:Request,worker:Worker=Depends(get_worker),db:AsyncSession=Depends(get_db,scope='function')):
    a=await _own_account(db,account_id,worker)
    if not a.proxy_ciphertext:return {'proxy':None,'version':a.proxy_version}
    box=request.app.state.secret_box
    if box is None:raise ApiError(503,'encryption_not_configured','Chưa có khóa mã hóa.')
    try:value=json.loads(box.open('account_proxy',str(a.id),a.proxy_ciphertext))
    except (CryptoError,ValueError):raise ApiError(500,'proxy_unreadable','Không đọc được proxy.') from None
    return {'proxy':value,'version':a.proxy_version}


@router.post('/accounts/{account_id}/telegram-api/fetch')
async def fetch_telegram_api(account_id: uuid.UUID, request: Request, worker: Worker = Depends(get_worker),
                              db: AsyncSession = Depends(get_db, scope='function')):
    a = await _own_account(db, account_id, worker)
    if a.pending_deletion:
        from sqlalchemy import select
        logout=(await db.execute(select(WorkerCommand.id).where(WorkerCommand.account_id==a.id,
            WorkerCommand.worker_id==worker.id,WorkerCommand.type=='logout',
            WorkerCommand.status=='delivered',WorkerCommand.expires_at>utcnow()))).first()
        if not logout:raise ApiError(409,'pending_deletion','Tài khoản đang chờ xóa.')
    if not a.telegram_api_ciphertext:
        raise ApiError(404, 'telegram_api_not_configured', 'Chưa cấu hình API Telegram cho tài khoản.')
    box = request.app.state.secret_box
    if box is None:
        raise ApiError(503, 'encryption_not_configured', 'Chưa cấu hình khóa mã hóa.')
    try:
        value = json.loads(box.open('telegram_app', str(a.id), a.telegram_api_ciphertext))
    except (CryptoError, ValueError):
        raise ApiError(500, 'telegram_api_unreadable', 'Không giải mã được cấu hình Telegram.') from None
    record_system_audit(db, 'account.telegram_api_fetched', target_type='account', target_id=str(a.id),
                        details={'worker_id': str(worker.id)})
    return value


def _actor(worker: Worker) -> dict:
    return {"actor_id": worker.id, "actor_username": f"worker:{worker.name}"[:32]}


async def _own_account(db: AsyncSession, account_id: uuid.UUID, worker: Worker) -> TelegramAccount:
    a = await db.get(TelegramAccount, account_id)
    if a is None or a.assigned_worker_id != worker.id:
        raise ApiError(404, "not_found", "Tài khoản không tồn tại hoặc không được gán cho worker này.")
    return a


@router.post("/commands/poll", response_model=PollResponse)
async def poll_commands(body: PollRequest, request: Request, worker: Worker = Depends(get_worker),
                        db: AsyncSession = Depends(get_db, scope="function")):
    """Long poll: returns as soon as a command is pending, or empty after `wait_seconds`."""
    box, deadline = request.app.state.secret_box, time.monotonic() + body.wait_seconds
    while True:
        cmds = await svc.claim_commands(db, box, worker.id, utcnow())
        await db.commit()  # releases the connection while we sleep
        if cmds or time.monotonic() >= deadline:
            return {"commands": cmds}
        await asyncio.sleep(1.0)


@router.post("/commands/{command_id}/result", status_code=204)
async def command_result(command_id: uuid.UUID, body: CommandResultIn, request: Request,
                         worker: Worker = Depends(get_worker), db: AsyncSession = Depends(get_db, scope="function")):
    cmd = await db.get(WorkerCommand, command_id)
    if cmd is None or cmd.worker_id != worker.id:
        raise ApiError(404, "not_found", "Không tìm thấy lệnh.")
    if cmd.status in svc.FINAL_STATUSES:
        if cmd.status == body.status:
            return Response(status_code=204)  # idempotent retry
        raise ApiError(409, "command_finished", "Lệnh đã kết thúc.")
    if cmd.status != "delivered":
        raise ApiError(409, "command_not_delivered", "Lệnh chưa được giao cho worker.")
    acct = await db.get(TelegramAccount, cmd.account_id)
    deleting = bool(acct and acct.pending_deletion and cmd.type == "logout" and body.status == "done")
    name = acct.name if acct else None
    await svc.apply_result(db, cmd, acct, body.status, body.result, body.error_code, body.retry_after, utcnow(), box=request.app.state.secret_box)
    if deleting:
        record_system_audit(db, "account.delete", target_type="account", target_id=str(cmd.account_id),
                            details={"name": name, "revoked_on_telegram": True, "forced": False})
    return Response(status_code=204)


@router.post("/accounts/{account_id}/lease", response_model=LeaseOut)
async def acquire_lease(account_id: uuid.UUID, request: Request, worker: Worker = Depends(get_worker),
                        db: AsyncSession = Depends(get_db, scope="function")):
    await _own_account(db, account_id, worker)
    ttl = request.app.state.settings.account_lease_ttl_seconds
    epoch = await svc.acquire_lease(db, account_id, worker.id, ttl, utcnow())
    if epoch is None:
        raise ApiError(409, "lease_held", "Session đang được worker khác sử dụng.")
    await record_audit(db, request, "account.lease_acquired", **_actor(worker), target_type="account",
                       target_id=str(account_id), details={"epoch": epoch})
    return {"epoch": epoch, "ttl_seconds": ttl}


@router.post("/accounts/{account_id}/lease/release", status_code=204)
async def release_lease(account_id: uuid.UUID, body: EpochIn, worker: Worker = Depends(get_worker),
                        db: AsyncSession = Depends(get_db, scope="function")):
    await svc.release_lease(db, account_id, worker.id, body.epoch)  # idempotent
    return Response(status_code=204)


@router.post("/accounts/{account_id}/session/fetch", response_model=SessionFetchOut)
async def fetch_session(account_id: uuid.UUID, body: EpochIn, request: Request, worker: Worker = Depends(get_worker),
                        db: AsyncSession = Depends(get_db, scope="function")):
    """Only the current lease holder can read the session; every read is audited."""
    a = await _own_account(db, account_id, worker)
    svc.require_lease(a, worker.id, body.epoch, utcnow())
    box = request.app.state.secret_box
    if box is None:
        raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session.")
    if not a.session_ciphertext:
        raise ApiError(404, "no_session", "Tài khoản chưa có session.")
    try:
        session = box.open("session", str(a.id), a.session_ciphertext)
    except CryptoError:
        raise ApiError(500, "session_unreadable", "Không giải mã được session (sai khóa mã hóa?).") from None
    await record_audit(db, request, "account.session_fetched", **_actor(worker), target_type="account",
                       target_id=str(a.id), details={"version": a.session_version, "epoch": body.epoch})
    return {"session": session, "version": a.session_version}


@router.put("/accounts/{account_id}/session", response_model=SessionVersionOut)
async def upload_session(account_id: uuid.UUID, body: SessionUpload, request: Request,
                         worker: Worker = Depends(get_worker), db: AsyncSession = Depends(get_db, scope="function")):
    """Stores the session encrypted. The fencing epoch stops a worker that lost its lease from overwriting it."""
    a = await _own_account(db, account_id, worker)
    now = utcnow()
    svc.require_lease(a, worker.id, body.epoch, now)
    if body.expected_version is not None and body.expected_version != a.session_version:
        raise ApiError(409, "version_conflict", "Session đã được cập nhật bởi tiến trình khác.")
    box = request.app.state.secret_box
    if box is None:
        raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session.")
    a.session_ciphertext = box.seal("session", str(a.id), body.session)
    a.session_version += 1
    a.session_updated_at = now
    await record_audit(db, request, "account.session_updated", **_actor(worker), target_type="account",
                       target_id=str(a.id), details={"version": a.session_version})
    return {"version": a.session_version}
