"""Standalone proxy lists: credentials never enter account/session tables."""
import json
import uuid
from datetime import timedelta
from typing import Literal

from fastapi import APIRouter, Depends, Query, Request, Response
from sqlalchemy import and_, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.crypto import CryptoError
from app.deps import AuthContext, get_db, require_role
from app.deps_worker import get_worker
from app.errors import ApiError
from app.models import ProxyCheckBatch as Batch, ProxyCheckItem as Item, Role, Worker
from app.schemas_proxy_checks import ProxyListCreate, ProxyListResults
from app.services.account_proxy import export_proxy_url, parse_proxies, proxy_secret
from app.services.accounts import worker_can_take_commands
from app.types import utcnow

router = APIRouter(prefix='/api/proxy-checks', tags=['proxy-checks'])
worker_router = APIRouter(prefix='/api/worker/v1/proxy-checks', tags=['worker-proxy-checks'])
admin = require_role(Role.ADMIN)


def _box(request):
    if request.app.state.secret_box is None:
        raise ApiError(503, 'encryption_not_configured', 'Chưa có khóa mã hóa proxy.')
    return request.app.state.secret_box


async def _owned(db, bid, auth):
    batch = await db.get(Batch, bid)
    if batch is None or batch.created_by != auth.user.id:
        raise ApiError(404, 'not_found', 'Không tìm thấy lô proxy.')
    return batch


async def _summary(db, batch):
    counts = dict((await db.execute(select(Item.status, func.count()).where(Item.batch_id == batch.id).group_by(Item.status))).all())
    status = 'done' if batch.status == 'running' and not (counts.get('pending', 0) + counts.get('checking', 0)) else batch.status
    worker = await db.get(Worker, batch.worker_id) if batch.worker_id else None
    return {'id': str(batch.id), 'status': status, 'total': batch.total, 'counts': counts,
            'worker_name': worker.name if worker else 'Worker đã xóa', 'created_at': batch.created_at}


@router.post('', status_code=202)
async def create(body: ProxyListCreate, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    existing = await db.get(Batch, body.request_id)
    if existing:
        return await _summary(db, await _owned(db, existing.id, auth))
    box = _box(request)
    await worker_can_take_commands(db, body.worker_id, request.app.state.settings.heartbeat_timeout_seconds, utcnow())
    entries = parse_proxies(body.text.get_secret_value(), body.protocol)
    batch = Batch(id=body.request_id, worker_id=body.worker_id, created_by=auth.user.id, total=len(entries))
    db.add(batch)
    try:
        await db.flush()
        for position, proxy in enumerate(entries, 1):
            iid = uuid.uuid4()
            db.add(Item(id=iid, batch_id=batch.id, position=position, label=proxy['label'],
                        proxy_ciphertext=box.seal('proxy_check', str(iid), proxy_secret(proxy))))
        await db.flush()
    except IntegrityError:
        raise ApiError(409, 'proxy_batch_exists', 'Lô vừa được tạo ở yêu cầu khác. Mở lại Kiểm tra list proxy để xem lô gần đây.') from None
    await record_audit(db, request, 'proxy_list.created', actor=auth.user, target_type='proxy_list', target_id=str(batch.id), details={'count': len(entries)})
    return await _summary(db, batch)


@router.get('')
async def recent(auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    batches = (await db.execute(select(Batch).where(Batch.created_by == auth.user.id).order_by(Batch.created_at.desc(), Batch.id.desc()).limit(20))).scalars().all()
    return {'items': [await _summary(db, b) for b in batches]}


@router.get('/{batch_id}')
async def details(batch_id: uuid.UUID, status: Literal['pending','checking','alive','dead','error','cancelled'] | None = None,
                  page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=100),
                  auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    batch = await _owned(db, batch_id, auth)
    conditions = [Item.batch_id == batch.id]
    if status: conditions.append(Item.status == status)
    total = (await db.execute(select(func.count()).select_from(Item).where(*conditions))).scalar_one()
    rows = (await db.execute(select(Item).where(*conditions).order_by(Item.position).offset((page - 1) * page_size).limit(page_size))).scalars()
    return {**await _summary(db, batch), 'page': page, 'page_size': page_size, 'filtered_total': total,
            'items': [{'id': str(i.id), 'position': i.position, 'label': i.label, 'status': i.status,
                       'latency_ms': i.latency_ms, 'error_code': i.error_code, 'checked_at': i.checked_at} for i in rows]}


@router.post('/{batch_id}/cancel')
async def cancel(batch_id: uuid.UUID, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    batch = await _owned(db, batch_id, auth)
    batch.status = 'cancelled'
    await db.execute(update(Item).where(Item.batch_id == batch.id, Item.status.in_(('pending','checking'))).values(status='cancelled', lease_token=None, lease_until=None))
    await record_audit(db, request, 'proxy_list.cancelled', actor=auth.user, target_type='proxy_list', target_id=str(batch.id))
    return await _summary(db, batch)


@router.get('/{batch_id}/export')
async def export(batch_id: uuid.UUID, request: Request, status: Literal['alive','dead'], auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    batch = await _owned(db, batch_id, auth); box = _box(request); lines = []
    rows = (await db.execute(select(Item).where(Item.batch_id == batch.id, Item.status == status).order_by(Item.position))).scalars()
    for item in rows:
        try: lines.append(export_proxy_url(json.loads(box.open('proxy_check', str(item.id), item.proxy_ciphertext))))
        except (CryptoError, ValueError, KeyError, TypeError):
            raise ApiError(409, 'proxy_unreadable', 'Không giải mã được proxy; chưa xuất file. Kiểm tra khóa mã hóa.') from None
    await record_audit(db, request, 'proxy_list.exported', actor=auth.user, target_type='proxy_list', target_id=str(batch.id), details={'status': status, 'count': len(lines)})
    name = 'proxy-list-live.txt' if status == 'alive' else 'proxy-list-die.txt'
    return Response('\n'.join(lines) + ('\n' if lines else ''), media_type='text/plain; charset=utf-8',
                    headers={'Content-Disposition': f'attachment; filename="{name}"', 'Cache-Control': 'no-store'})


@worker_router.post('/claim')
async def claim(request: Request, worker: Worker = Depends(get_worker), db: AsyncSession = Depends(get_db, scope='function')):
    box = _box(request); now = utcnow()
    if db.get_bind().dialect.name == 'sqlite':
        # SQLite ignores FOR UPDATE; acquire its write lock without changing worker data.
        await db.execute(update(Worker).where(Worker.id == worker.id).values(updated_at=Worker.updated_at))
    else:
        await db.execute(select(Worker.id).where(Worker.id == worker.id).with_for_update())
    owned = [Batch.worker_id == worker.id, Batch.status == 'running']
    in_flight = (await db.execute(select(func.count()).select_from(Item).join(Batch).where(*owned, Item.status == 'checking', Item.lease_until > now))).scalar_one()
    slots = max(0, 10 - in_flight)
    if not slots: return {'items': []}
    ready = or_(Item.status == 'pending', and_(Item.status == 'checking', Item.lease_until <= now))
    rows = (await db.execute(select(Item).join(Batch).where(*owned, ready).order_by(Batch.created_at, Batch.id, Item.position).limit(slots).with_for_update(skip_locked=True, of=Item))).scalars().all()
    items = []
    for item in rows:
        try: proxy = json.loads(box.open('proxy_check', str(item.id), item.proxy_ciphertext))
        except (CryptoError, ValueError, KeyError, TypeError):
            item.status = 'error'; item.error_code = 'proxy_unreadable'; item.lease_token = None; item.lease_until = None
            continue
        token = uuid.uuid4()
        result = await db.execute(update(Item).where(Item.id == item.id, ready).values(status='checking', lease_token=token, lease_until=now + timedelta(seconds=45)).execution_options(synchronize_session=False))
        if result.rowcount: items.append({'id': str(item.id), 'token': str(token), 'proxy': proxy})
    return {'items': items}


@worker_router.post('/results')
async def results(body: ProxyListResults, worker: Worker = Depends(get_worker), db: AsyncSession = Depends(get_db, scope='function')):
    now = utcnow(); accepted = []; lost = []
    for result in body.items:
        row = (await db.execute(select(Item, Batch).join(Batch).where(Item.id == result.id, Batch.worker_id == worker.id))).first()
        if row is None:
            lost.append(str(result.id)); continue
        item, batch = row
        if item.lease_token == result.token and item.status in ('alive','dead'):
            accepted.append(str(item.id)); continue
        outcome = await db.execute(update(Item).where(Item.id == result.id, Item.status == 'checking',
            Item.lease_token == result.token, Item.lease_until > now,
            Item.batch_id.in_(select(Batch.id).where(Batch.worker_id == worker.id, Batch.status == 'running'))).values(
                status=result.status, latency_ms=result.latency_ms, error_code=result.error_code, checked_at=now, lease_until=None))
        (accepted if outcome.rowcount else lost).append(str(result.id))
    return {'accepted': accepted, 'lost': lost}
