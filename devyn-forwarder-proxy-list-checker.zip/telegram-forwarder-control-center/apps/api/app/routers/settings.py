import json

from fastapi import APIRouter, Depends, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, get_db, require_role
from app.errors import ApiError
from app.models import ApplicationSetting, Role
from app.schemas_accounts import TelegramApiConfig
from app.services.telegram_api_settings import TELEGRAM_API_KEY, saved_telegram_api
from app.types import utcnow

router = APIRouter(prefix='/api/settings', tags=['settings'])
admin = require_role(Role.ADMIN)


@router.get('/telegram-api')
async def telegram_api_status(request: Request, _: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    config = await saved_telegram_api(db, request.app.state.secret_box)
    row = await db.get(ApplicationSetting, TELEGRAM_API_KEY)
    return {'configured': config is not None, 'api_id': config.api_id if config else None, 'updated_at': row.updated_at if row else None}


@router.put('/telegram-api')
async def save_telegram_api(body: TelegramApiConfig, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    box = request.app.state.secret_box
    if box is None:
        raise ApiError(503, 'encryption_not_configured', 'Chưa có khóa mã hóa cấu hình Telegram.')
    now = utcnow()
    token = box.seal('app_setting', TELEGRAM_API_KEY, json.dumps({'api_id': body.api_id, 'api_hash': body.api_hash.get_secret_value()}))
    row = await db.get(ApplicationSetting, TELEGRAM_API_KEY, with_for_update=True)
    if row is None:
        row = ApplicationSetting(key=TELEGRAM_API_KEY, value_ciphertext=token, updated_at=now)
        db.add(row)
    else:
        row.value_ciphertext, row.updated_at = token, now
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, 'settings_changed', 'Cấu hình vừa được lưu ở cửa sổ khác. Hãy thử lưu lại.') from None
    await record_audit(db, request, 'settings.telegram_api_saved', actor=auth.user, details={'configured': True})
    return {'configured': True, 'api_id': body.api_id, 'updated_at': now}
