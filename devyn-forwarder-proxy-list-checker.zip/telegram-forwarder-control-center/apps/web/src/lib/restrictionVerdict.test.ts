import {describe,it,expect} from 'vitest';
import {restrictionVerdict} from './restrictionVerdict';
import type {Account} from '../api/types';
const account={name:'SS',health_status:'live',health_source:'telegram',spam_status:'unknown'} as Account;
const blocked='Your account was blocked for violations of the Telegram Terms of Service based on user reports confirmed by our moderators.';
describe('Vietnamese account restriction verdicts',()=>{
  it('recognizes the existing blocked notice even when old records say unknown',()=>{
    const result=restrictionVerdict({...account,spam_response:blocked});
    expect(result.tone).toBe('bad');expect(result.title).toBe('Tài khoản bị chặn');expect(result.reason).toContain('vi phạm điều khoản');expect(result.reason).not.toContain(blocked);
  });
  it.each(['If your account was blocked for violations of the Telegram Terms of Service, contact support.','Your account may be blocked for violations of the Telegram Terms of Service.','Your account is not blocked.'])('does not turn hypothetical or negative statements red: %s',text=>{
    expect(restrictionVerdict({...account,spam_response:text}).tone).toBe('warn');
  });
  it('uses green only for a clear result, red for limited/frozen, and amber for unknown or errors',()=>{
    expect(restrictionVerdict({...account,spam_status:'clear'}).tone).toBe('ok');
    expect(restrictionVerdict({...account,spam_status:'limited'}).tone).toBe('bad');
    expect(restrictionVerdict({...account,health_status:'frozen',spam_status:'clear'}).title).toBe('Tài khoản đóng băng');
    expect(restrictionVerdict({...account,spam_status:'error',spam_error:'network_error'}).tone).toBe('warn');
    expect(restrictionVerdict(account).tone).toBe('warn');
  });
  it('distinguishes a manual frozen label from a Telegram confirmation',()=>{
    const result=restrictionVerdict({...account,health_status:'frozen',health_source:'manual'});expect(result.reason).toContain('chưa phải kết luận');
  });
});
