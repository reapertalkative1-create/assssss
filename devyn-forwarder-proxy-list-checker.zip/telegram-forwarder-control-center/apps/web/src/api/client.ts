export interface FieldError { field: string; message: string }

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public fields: FieldError[] = [], public requestId?: string) {
    super(message);
    this.name = "ApiError";
  }
}

let csrfToken = "";
let onUnauthorized: (() => void) | null = null;

export const setCsrfToken = (token: string) => { csrfToken = token; };
export const setUnauthorizedHandler = (fn: (() => void) | null) => { onUnauthorized = fn; };

type Query = Record<string, string | number | boolean | undefined | null>;

function withQuery(path: string, query?: Query): string {
  if (!query) return path;
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== "") qs.set(k, String(v));
  const s = qs.toString();
  return s ? `${path}?${s}` : path;
}

export async function request<T>(method: string, path: string, opts: { body?: unknown; query?: Query; signal?: AbortSignal; responseType?: "blob" } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  if (method !== "GET" && csrfToken) headers["X-CSRF-Token"] = csrfToken;
  let res: Response;
  try {
    res = await fetch(withQuery(path, opts.query), {
      method, headers, credentials: "same-origin", signal: opts.signal,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch (e) {
    if ((e as Error).name === "AbortError") throw e;
    throw new ApiError(0, "network", "Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại.");
  }
  if(res.ok && opts.responseType === "blob") return await res.blob() as T;
  if (res.status === 204) return undefined as T;
  let data: unknown = null;
  if ((res.headers.get("content-type") ?? "").includes("json")) data = await res.json().catch(() => null);
  if (!res.ok) {
    const err = (data as { error?: { code?: string; message?: string; fields?: FieldError[] }; request_id?: string } | null);
    if (res.status === 401 && !path.endsWith("/auth/login")) onUnauthorized?.();
    throw new ApiError(res.status, err?.error?.code ?? "http_error", err?.error?.message ?? `Lỗi máy chủ (${res.status}).`,
      err?.error?.fields ?? [], err?.request_id);
  }
  return data as T;
}

export const api = {
  download: (path: string, query?: Query) => request<Blob>("GET",path,{query,responseType:"blob"}),
  get: <T>(path: string, query?: Query, signal?: AbortSignal) => request<T>("GET", path, { query, signal }),
  post: <T>(path: string, body?: unknown, query?: Query) => request<T>("POST", path, { body: body ?? {}, query }),
  put: <T>(path: string, body: unknown) => request<T>("PUT", path, { body }),
  patch: <T>(path: string, body: unknown) => request<T>("PATCH", path, { body }),
};
