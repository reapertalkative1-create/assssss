import {useEffect,useRef,useState} from 'react';
import {api,ApiError} from '../api/client';
import {useToast} from '../state/toast';
export function ProxyExportMenu({filters}:{filters:Record<string,string|undefined>}){
  const ref=useRef<HTMLDetailsElement>(null);const [busy,setBusy]=useState(false);const toast=useToast();
  function place(){
    const el=ref.current,panel=el?.querySelector<HTMLElement>('.proxy-export-options');if(!el?.open||!panel)return;
    panel.style.left='0px';panel.style.right='auto';const rect=panel.getBoundingClientRect();
    panel.style.left=`${Math.min(0,window.innerWidth-12-rect.right)}px`;
  }
  useEffect(()=>{
    const outside=(e:PointerEvent)=>{if(ref.current&&!ref.current.contains(e.target as Node))ref.current.open=false;};
    const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'&&ref.current?.open){ref.current.open=false;ref.current.querySelector('summary')?.focus();}};
    const resize=()=>{if(ref.current)ref.current.open=false;};window.addEventListener('resize',resize);
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return()=>{window.removeEventListener('resize',resize);document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[]);
  async function save(status:'alive'|'dead'){
    if(busy)return;setBusy(true);
    try{
      const blob=await api.download('/api/account-proxies/export',{...filters,proxy_status:undefined,status});
      if(!blob.size){toast.error('Không có proxy thuộc nhóm này.');return;}
      const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download=status==='alive'?'proxies-live.txt':'proxies-die.txt';document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
      toast.success('Đã xuất file proxy.');
    }catch(e){toast.error(e instanceof ApiError?e.message:'Không xuất được proxy.');}
    finally{setBusy(false);if(ref.current)ref.current.open=false;}
  }
  return <details className="proxy-export-menu" ref={ref} onToggle={place}>
    <summary className="btn sm">Xuất proxy</summary>
    <div className="proxy-export-options" role="group" aria-label="Xuất proxy TXT">
      <span className="hint">Theo nhóm sống / die</span>
      <button className="btn sm" disabled={busy} onClick={()=>void save('alive')}>Đang chạy → .txt</button>
      <button className="btn sm" disabled={busy} onClick={()=>void save('dead')}>Die → .txt</button>
    </div>
  </details>;
}
