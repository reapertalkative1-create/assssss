import type {Account} from '../api/types';
import {restrictionVerdict} from '../lib/restrictionVerdict';
export function RestrictionStatus({a}:{a:Account}){
  const verdict=restrictionVerdict(a);
  const short:Record<string,string>={'Không bị hạn chế spam':'Bình thường','Tài khoản bị chặn':'Bị chặn','Bị hạn chế spam':'Bị spam','Tài khoản đóng băng':'Đóng băng','Đã đánh dấu đóng băng':'Đánh dấu đóng băng','Tài khoản bị khóa':'Bị khóa','Session hết hiệu lực':'Hết phiên','Kiểm tra chưa thành công':'Lỗi check','Chưa xác định hạn chế':'Chưa rõ','Chưa kiểm tra spam':'Chưa check'};
  return <section className={`ss-verdict ${verdict.tone}`} aria-label={`Kết luận hạn chế — ${a.name}`}>
    <strong className="ss-verdict-title"><span aria-hidden="true">{verdict.tone==='ok'?'✓':verdict.tone==='bad'?'!':'•'}</span>{short[verdict.title]??verdict.title}</strong>
  </section>;
}
