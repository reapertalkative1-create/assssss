import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {beforeEach,describe,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{
  const real=await orig<typeof import('../api/client')>();
  return {...real,api:{get:vi.fn(),post:vi.fn(),download:vi.fn()}};
});
import {api,ApiError} from '../api/client';
import {ProxyListCheck} from './ProxyListCheck';
const summary={id:'batch1',status:'done',total:2,counts:{alive:1,dead:1},worker_name:'My PC',created_at:'2026-11-12T00:00:00Z'};
const result={...summary,page:1,page_size:50,filtered_total:2,items:[
  {id:'i1',position:1,label:'socks5://live.example:1080',status:'alive',latency_ms:12,error_code:null},
  {id:'i2',position:2,label:'http://die.example:8080',status:'dead',latency_ms:null,error_code:'proxy_timeout'}
]};
beforeEach(()=>{
  vi.clearAllMocks();
  vi.mocked(api.get).mockImplementation(async(path:string)=>path==='/api/workers'?{items:[{id:'w1',name:'My PC',status:'online'}]}:path==='/api/proxy-checks'?{items:[summary]}:result);
  vi.mocked(api.post).mockResolvedValue(summary);
});
async function open(){
  const user=userEvent.setup();render(<ProxyListCheck onClose={()=>{}}/>);
  await waitFor(()=>expect(screen.getByLabelText('Worker kiểm tra proxy')).toHaveValue('w1'));
  return user;
}
describe('Independent proxy list checker',()=>{
  it('uploads TXT without account/API data and exports live and die as separate TXT downloads',async()=>{
    const user=await open();
    const file=new File(['unused'],'proxies.txt',{type:'text/plain'});
    Object.defineProperty(file,'text',{value:async()=>'live.example:1080:u:PRIVATE-PASS\nhttp://die.example:8080'});
    await user.upload(screen.getByLabelText('File list proxy .txt'),file);
    await waitFor(()=>expect(screen.getByLabelText('List proxy cần kiểm tra')).toHaveValue('live.example:1080:u:PRIVATE-PASS\nhttp://die.example:8080'));
    await user.click(screen.getByRole('button',{name:'Bắt đầu check proxy'}));
    expect(await screen.findByText('socks5://live.example:1080')).toBeVisible();
    expect(api.post).toHaveBeenCalledWith('/api/proxy-checks',expect.objectContaining({worker_id:'w1',protocol:'socks5',text:'live.example:1080:u:PRIVATE-PASS\nhttp://die.example:8080'}));
    expect(vi.mocked(api.post).mock.calls[0][1]).not.toHaveProperty('account_ids');
    expect(vi.mocked(api.post).mock.calls[0][1]).not.toHaveProperty('api_hash');
    expect(screen.queryByText(/PRIVATE-PASS/)).not.toBeInTheDocument();
    const click=vi.spyOn(HTMLAnchorElement.prototype,'click').mockImplementation(()=>{});
    Object.defineProperty(URL,'createObjectURL',{configurable:true,value:vi.fn(()=> 'blob:proxy')});
    Object.defineProperty(URL,'revokeObjectURL',{configurable:true,value:vi.fn()});
    vi.mocked(api.download).mockResolvedValue(new Blob(['proxy.example:1080\n']));
    await user.click(screen.getByRole('button',{name:'Xuất Live.txt (1)'}));
    await user.click(screen.getByRole('button',{name:'Xuất Die.txt (1)'}));
    expect(api.download).toHaveBeenCalledWith('/api/proxy-checks/batch1/export',{status:'alive'});
    expect(api.download).toHaveBeenCalledWith('/api/proxy-checks/batch1/export',{status:'dead'});
    expect(click).toHaveBeenCalledTimes(2);click.mockRestore();
    await user.selectOptions(screen.getByRole('combobox',{name:'Lọc kết quả list proxy'}),'dead');
    await waitFor(()=>expect(api.get).toHaveBeenCalledWith('/api/proxy-checks/batch1',expect.objectContaining({status:'dead',page:1}),expect.anything()));
  });
  it('restores a previous batch and cancels pending work while keeping results',async()=>{
    const user=await open();
    vi.mocked(api.get).mockImplementation(async(path:string)=>path==='/api/proxy-checks/batch1'?{...result,status:'running',counts:{alive:1,checking:1}}:{items:[summary]});
    await user.selectOptions(screen.getByLabelText('Mở lại kết quả gần đây'),'batch1');
    expect(await screen.findByRole('button',{name:'Dừng check'})).toBeEnabled();
    await user.click(screen.getByRole('button',{name:'Dừng check'}));
    expect(api.post).toHaveBeenCalledWith('/api/proxy-checks/batch1/cancel');
    expect(screen.getByRole('button',{name:'Xuất Live.txt (1)'})).toBeEnabled();
  });
  it('shows parse errors without losing the list',async()=>{
    const user=await open();
    await user.type(screen.getByLabelText('List proxy cần kiểm tra'),'invalid');
    vi.mocked(api.post).mockRejectedValue(new ApiError(422,'invalid_proxy','Proxy dòng 1 sai định dạng.'));
    await user.click(screen.getByRole('button',{name:'Bắt đầu check proxy'}));
    expect(await screen.findByText('Proxy dòng 1 sai định dạng.')).toBeVisible();
    expect(screen.getByLabelText('List proxy cần kiểm tra')).toHaveValue('invalid');
  });
  it('disables starting without an online worker',async()=>{
    const user=userEvent.setup();vi.mocked(api.get).mockResolvedValue({items:[]});
    render(<ProxyListCheck onClose={()=>{}}/>);
    expect(await screen.findByText(/Chưa có worker online/)).toBeVisible();
    await user.type(screen.getByLabelText('List proxy cần kiểm tra'),'host.example:1080');
    expect(screen.getByRole('button',{name:'Bắt đầu check proxy'})).toBeDisabled();
  });
});
