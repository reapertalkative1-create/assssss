import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import type { TelegramApiSettingsStatus } from '../api/types';
import { Alert, ErrorState, Pill, Skeleton, TextField } from '../components/ui';
import { useQuery, type QueryState } from '../hooks/useQuery';

export function useSavedTelegramApi() {
  return useQuery(signal=>api.get<TelegramApiSettingsStatus>('/api/settings/telegram-api',undefined,signal),[]);
}

export function SavedTelegramApiNotice({settings,onClose}:{settings:QueryState<TelegramApiSettingsStatus>;onClose:()=>void}) {
  if(settings.loading)return <p className="hint">Đang tải API Telegram đã lưu…</p>;
  if(settings.error)return <ErrorState error={settings.error} onRetry={settings.reload}/>;
  return settings.data?.configured
    ? <p className="hint">Dùng API Telegram đã lưu · ID {settings.data.api_id}. <Link to="/settings" onClick={onClose}>Cài đặt</Link></p>
    : <Alert>Chưa lưu API Telegram. <Link to="/settings" onClick={onClose}>Vào Cài đặt để nhập một lần</Link>.</Alert>;
}

export function TelegramApiSettings() {
  const query=useSavedTelegramApi();
  const [saved,setSaved]=useState<TelegramApiSettingsStatus>();
  const [apiId,setApiId]=useState(''),[apiHash,setApiHash]=useState('');
  const [busy,setBusy]=useState(false),[error,setError]=useState('');
  const [waiting,setWaiting]=useState(false);
  const initialized=useRef(false),saving=useRef(false),attempted=useRef('');
  const validId=/^[1-9][0-9]*$/.test(apiId)&&Number(apiId)<=2147483647;
  const valid=validId&&/^[0-9a-f]{32}$/i.test(apiHash.trim());
  const changed=!!apiHash||!!saved?.configured&&apiId!==String(saved.api_id);
  useEffect(()=>{
    if(query.data&&!initialized.current){
      initialized.current=true;setSaved(query.data);setApiId(query.data.api_id?String(query.data.api_id):'');
    }
  },[query.data]);
  async function save(){
    if(!valid||saving.current)return;
    saving.current=true;attempted.current=apiId+':'+apiHash;setBusy(true);setWaiting(false);setError('');
    try{
      const result=await api.put<TelegramApiSettingsStatus>('/api/settings/telegram-api',{api_id:Number(apiId),api_hash:apiHash.trim()});
      setSaved(result);setApiHash('');attempted.current='';
    }catch(e){setError(e instanceof ApiError?e.message:'Chưa lưu được API Telegram. Hãy thử lại.');}
    finally{saving.current=false;setBusy(false);}
  }
  useEffect(()=>{
    if(!initialized.current||!valid||attempted.current===apiId+':'+apiHash){setWaiting(false);return;}
    setWaiting(true);setError('');
    const timer=setTimeout(()=>void save(),800);
    return()=>clearTimeout(timer);
  },[apiId,apiHash,valid]);
  return <section className="panel">
    <div className="panel-head row between"><h2>API Telegram</h2><span role="status"><Pill tone={error?'bad':busy||waiting||changed?'warn':saved?.configured?'ok':'idle'}>{busy?'Đang lưu…':waiting?'Chờ tự lưu…':error?'Chưa lưu được':changed?'Chưa lưu thay đổi':saved?.configured?'Đã lưu':'Chưa cấu hình'}</Pill></span></div>
    <div className="panel-body stack tight" style={{maxWidth:620}}>
      {query.error&&!saved?<ErrorState error={query.error} onRetry={query.reload}/>:query.loading&&!saved?<Skeleton/>:<>
        <p className="hint">Nhập một lần tại <a href="https://my.telegram.org" target="_blank" rel="noreferrer">my.telegram.org → API development tools</a>. Thông tin hợp lệ sẽ tự lưu và dùng cho tài khoản / SS mới.</p>
        <div className="form-grid">
          <TextField label="api_id" inputMode="numeric" value={apiId} disabled={busy} onChange={e=>setApiId(e.target.value.trim())} autoComplete="off"/>
          <TextField label="api_hash" type="password" value={apiHash} disabled={busy} onChange={e=>setApiHash(e.target.value)} maxLength={32} autoComplete="new-password" placeholder={saved?.configured?'Đã lưu — nhập mới nếu muốn đổi':'32 ký tự hexadecimal'}/>
        </div>
        <p className="hint">{saved?.configured?'API đã lưu được giữ lại khi đóng web hoặc khởi động lại. Muốn đổi, nhập đủ cặp api_id/api_hash mới.':'Nhập đủ api_id và api_hash để tự lưu.'} api_hash được mã hóa và không hiển thị lại.</p>
        {error&&<Alert tone="bad">{error} <button className="btn sm" disabled={busy||!valid} onClick={()=>void save()}>Thử lưu lại</button></Alert>}
      </>}
    </div>
  </section>;
}
