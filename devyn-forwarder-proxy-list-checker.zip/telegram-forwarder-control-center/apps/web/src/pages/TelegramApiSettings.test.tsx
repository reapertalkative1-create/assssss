import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter} from 'react-router-dom';
import {beforeEach,describe,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{
  const real=await orig<typeof import('../api/client')>();
  return {...real,api:{get:vi.fn(),put:vi.fn()}};
});
import {api,ApiError} from '../api/client';
import {TelegramApiSettings} from './TelegramApiSettings';
const saved={configured:true,api_id:12345,updated_at:null};
beforeEach(()=>{vi.clearAllMocks();});
const open=()=>render(<MemoryRouter><TelegramApiSettings/></MemoryRouter>);

describe('Telegram API in Settings',()=>{
  it('automatically saves a complete valid pair, clears the hash and restores saved status after remount',async()=>{
    const user=userEvent.setup();
    vi.mocked(api.get).mockResolvedValue({configured:false,api_id:null,updated_at:null});
    vi.mocked(api.put).mockResolvedValue(saved);
    const view=open();
    await user.type(await screen.findByLabelText('api_hash'),'a'.repeat(32));
    expect(api.put).not.toHaveBeenCalled();
    await user.type(screen.getByLabelText('api_id'),'12345');
    await waitFor(()=>expect(api.put).toHaveBeenCalledWith('/api/settings/telegram-api',{api_id:12345,api_hash:'a'.repeat(32)}),{timeout:2500});
    expect(await screen.findByText('Đã lưu',{exact:true})).toBeInTheDocument();
    expect(screen.getByLabelText('api_hash')).toHaveValue('');
    expect(api.put).toHaveBeenCalledTimes(1);
    view.unmount();vi.mocked(api.get).mockResolvedValue(saved);open();
    expect(await screen.findByLabelText('api_id')).toHaveValue('12345');
    expect(screen.getByLabelText('api_hash')).toHaveValue('');
    expect(screen.getByText('Đã lưu',{exact:true})).toBeInTheDocument();
    expect(api.put).toHaveBeenCalledTimes(1);
  });
  it('does not mark an edited API ID as saved until a new complete pair is entered',async()=>{
    const user=userEvent.setup();vi.mocked(api.get).mockResolvedValue(saved);open();
    await user.clear(await screen.findByLabelText('api_id'));await user.type(screen.getByLabelText('api_id'),'999');
    expect(screen.getByText('Chưa lưu thay đổi',{exact:true})).toBeInTheDocument();
    expect(api.put).not.toHaveBeenCalled();
  });
  it('shows save failures and allows retry without retyping the pair',async()=>{
    const user=userEvent.setup();vi.mocked(api.get).mockResolvedValue(saved);
    vi.mocked(api.put).mockRejectedValueOnce(new ApiError(503,'unavailable','Chưa lưu được.')).mockResolvedValue(saved);
    open();await user.type(await screen.findByLabelText('api_hash'),'b'.repeat(32));
    expect(await screen.findByRole('button',{name:'Thử lưu lại'},{timeout:2500})).toBeEnabled();
    expect(screen.getByText('Chưa lưu được',{exact:true})).toBeInTheDocument();
    await user.click(screen.getByRole('button',{name:'Thử lưu lại'}));
    expect(await screen.findByText('Đã lưu',{exact:true})).toBeInTheDocument();
    expect(api.put).toHaveBeenCalledTimes(2);
    expect(screen.getByLabelText('api_hash')).toHaveValue('');
  });
});
