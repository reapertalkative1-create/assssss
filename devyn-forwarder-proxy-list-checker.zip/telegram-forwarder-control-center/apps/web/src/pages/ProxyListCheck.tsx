import {useEffect,useRef,useState} from 'react';
import {api,ApiError} from '../api/client';
import type {Page,Worker} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,Pill,SelectField,TextArea} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {fmtDateTime} from '../lib/format';
import type {Tone} from '../lib/labels';

type Batch={id:string;status:string;total:number;counts:Record<string,number>;worker_name:string;created_at:string};
type Result=Batch&{page:number;page_size:number;filtered_total:number;items:{id:string;position:number;label:string;status:string;latency_ms:number|null;error_code:string|null}[]};
const labels:Record<string,string>={alive:'Live',dead:'Die',pending:'Chưa check',checking:'Đang check',error:'Lỗi đọc proxy',cancelled:'Đã dừng'};
const tones:Record<string,Tone>={alive:'ok',dead:'bad',pending:'idle',checking:'warn',error:'warn',cancelled:'idle'};
const reasons:Record<string,string>={proxy_timeout:'Hết thời gian',proxy_auth_failed:'Sai user/mật khẩu',proxy_tls_failed:'Lỗi TLS',proxy_check_failed:'Không kết nối được',proxy_unreadable:'Không đọc được cấu hình'};

export function ProxyListCheck({onClose}:{onClose:()=>void}){
  const [text,setText]=useState(''),[protocol,setProtocol]=useState('socks5'),[worker,setWorker]=useState('');
  const [batchId,setBatchId]=useState(''),[filter,setFilter]=useState(''),[page,setPage]=useState(1);
  const [busy,setBusy]=useState(false),[loadingFile,setLoadingFile]=useState(false),[error,setError]=useState('');
  const [downloading,setDownloading]=useState(false);
  const [following,setFollowing]=useState(true);
  const requestId=useRef('');
  const workers=useQuery(signal=>api.get<Page<Worker>>('/api/workers',{page_size:100},signal),[]);
  const recent=useQuery(signal=>api.get<{items:Batch[]}>('/api/proxy-checks',undefined,signal),[]);
  const progress=useQuery(signal=>api.get<Result>(`/api/proxy-checks/${batchId}`,{status:filter||undefined,page,page_size:50},signal),[batchId,filter,page],{enabled:!!batchId,interval:following?1500:undefined});
  const online=(workers.data?.items??[]).filter(w=>w.status==='online'||w.status==='degraded');
  useEffect(()=>{if(!worker&&online.length===1)setWorker(online[0].id);},[workers.data,worker]);
  useEffect(()=>{requestId.current='';},[text,protocol,worker]);
  const data=progress.data?.id===batchId?progress.data:undefined;
  const counts=data?.counts??{};
  const active=data?.status==='running';
  useEffect(()=>{if(data&&data.status!=='running')setFollowing(false);},[data?.id,data?.status]);
  function openBatch(id:string){setBatchId(id);setFilter('');setPage(1);setError('');setFollowing(true);}
  function newList(){setBatchId('');setFilter('');setPage(1);setError('');recent.reload();}
  async function load(file?:File){
    if(!file)return;setError('');
    if(file.size>2000000){setError('File tối đa 2 MB, tối đa 10.000 proxy mỗi lô.');return;}
    setLoadingFile(true);
    try{setText(await file.text());}
    catch{setError('Không đọc được file. Hãy dùng TXT UTF-8 hoặc dán list.');}
    finally{setLoadingFile(false);}
  }
  async function start(){
    if(!worker||!text.trim()){setError('Chọn worker online và nhập list proxy.');return;}
    setBusy(true);setError('');
    if(!requestId.current)requestId.current=crypto.randomUUID();
    try{
      const result=await api.post<Batch>('/api/proxy-checks',{request_id:requestId.current,worker_id:worker,text,protocol});
      setText('');openBatch(result.id);recent.reload();
    }catch(e){setError(e instanceof ApiError?e.message:'Không tạo được lô check proxy.');}
    finally{setBusy(false);}
  }
  async function stop(){
    setBusy(true);setError('');
    try{await api.post(`/api/proxy-checks/${batchId}/cancel`);progress.reload();}
    catch(e){setError(e instanceof ApiError?e.message:'Không dừng được.');}
    finally{setBusy(false);}
  }
  async function download(status:'alive'|'dead'){
    setDownloading(true);setError('');
    try{
      const blob=await api.download(`/api/proxy-checks/${batchId}/export`,{status});
      if(!blob.size){setError('Chưa có proxy thuộc nhóm này.');return;}
      const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;
      a.download=status==='alive'?'proxy-list-live.txt':'proxy-list-die.txt';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }catch(e){setError(e instanceof ApiError?e.message:'Không xuất được file.');}
    finally{setDownloading(false);}
  }
  return <Modal title="Kiểm tra list proxy" onClose={onClose} dismissible={!busy} wide={!!batchId}
    footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{batchId?<><button className="btn" disabled={busy} onClick={newList}>Nhập list mới</button>{active&&<button className="btn danger" disabled={busy} onClick={()=>void stop()}>Dừng check</button>}</>:<button className="btn primary" disabled={busy||loadingFile||!worker||!text.trim()} onClick={()=>void start()}>{busy?'Đang tạo…':'Bắt đầu check proxy'}</button>}</>}>
    {!batchId?<>
      <p className="hint">Dán list hoặc tải TXT để check và xuất riêng. Không cần SS hay API Telegram; không gán proxy vào tài khoản.</p>
      <div className="import-proxy-grid">
        <SelectField label="Worker kiểm tra proxy" value={worker} onChange={e=>setWorker(e.target.value)} disabled={busy}><option value="">Chọn worker online</option>{online.map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</SelectField>
        <SelectField label="Loại proxy của list" value={protocol} onChange={e=>setProtocol(e.target.value)} disabled={busy}><option value="socks5">SOCKS5</option><option value="http">HTTP CONNECT</option><option value="socks4">SOCKS4</option></SelectField>
      </div>
      {workers.error&&<Alert tone="bad">{workers.error.message}</Alert>}
      {!workers.loading&&!online.length&&<Alert>Chưa có worker online. Mở Docker Desktop và chạy run.cmd trước.</Alert>}
      <label className="field">File list proxy .txt<input type="file" accept=".txt,text/plain" disabled={busy||loadingFile} onChange={e=>void load(e.target.files?.[0])}/></label>
      <TextArea label="List proxy cần kiểm tra" value={text} rows={7} maxLength={2000000} disabled={busy||loadingFile} onChange={e=>setText(e.target.value)} spellCheck={false} autoComplete="off" placeholder={'host:port\nhost:port:user:password\nsocks5://user:password@host:port'}/>
      <p className="hint">Mỗi dòng một proxy · Tối đa 10.000 proxy / 2 MB mỗi lô · Bỏ dòng trống, # và proxy trùng. Dòng có scheme dùng đúng scheme đó.</p>
      {!!recent.data?.items.length&&<SelectField label="Mở lại kết quả gần đây" value="" onChange={e=>{if(e.target.value)openBatch(e.target.value);}}><option value="">Chọn lô đã nhập…</option>{recent.data.items.map(b=><option key={b.id} value={b.id}>{fmtDateTime(b.created_at)} · {b.total} proxy · {b.worker_name}</option>)}</SelectField>}
    </>:<>
      <div className="proxy-list-summary" role="status">
        <strong>{data?.id===batchId?`${data.total} proxy`:'Đang tải…'}</strong>
        <span className="proxy-count-live">Live {counts.alive??0}</span><span className="proxy-count-dead">Die {counts.dead??0}</span>
        <span>Đang check {counts.checking??0}</span><span>Chưa check {counts.pending??0}</span>
        {!!counts.error&&<span>Lỗi đọc {counts.error}</span>}{!!counts.cancelled&&<span>Đã dừng {counts.cancelled}</span>}
      </div>
      <div className="row between">
        <select className="select" aria-label="Lọc kết quả list proxy" value={filter} onChange={e=>{setFilter(e.target.value);setPage(1);}}><option value="">Mọi kết quả</option>{Object.entries(labels).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select>
        <div className="row"><button className="btn sm" disabled={downloading||!counts.alive} onClick={()=>void download('alive')}>Xuất Live.txt ({counts.alive??0})</button><button className="btn sm" disabled={downloading||!counts.dead} onClick={()=>void download('dead')}>Xuất Die.txt ({counts.dead??0})</button></div>
      </div>
      <p className="hint">{data?.worker_name}{!data?'Đang tải kết quả…':active?' · Đang kiểm tra… Đóng cửa sổ vẫn tiếp tục, mở lại trong Lô gần đây.':data.status==='cancelled'?' · Đã dừng.':' · Đã kiểm tra xong.'} Xanh = kết nối thành công, đỏ = check thất bại. TXT xuất toàn bộ nhóm trong lô, kể cả trang khác.</p>
      {progress.error&&<Alert tone="bad">{progress.error.message} <button className="btn sm" onClick={progress.reload}>Tải lại</button></Alert>}
      <div className="proxy-list-table"><table className="table"><thead><tr><th>#</th><th>Proxy</th><th>Kết quả</th><th>ms</th></tr></thead><tbody>{data?.id===batchId&&data.items.map(i=><tr key={i.id}><td>{i.position}</td><td className="mono">{i.label}</td><td><Pill tone={tones[i.status]??'idle'}>{labels[i.status]??i.status}</Pill>{i.error_code&&<span className="hint proxy-list-reason">{reasons[i.error_code]??'Check thất bại'}</span>}</td><td>{i.latency_ms??'—'}</td></tr>)}</tbody></table></div>
      <div className="row"><button className="btn sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Trước</button><span className="hint">Trang {page}/{Math.max(1,Math.ceil((data?.filtered_total??0)/50))}</span><button className="btn sm" disabled={page*50>=(data?.filtered_total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div>
    </>}
    {error&&<Alert tone="bad">{error}</Alert>}
  </Modal>;
}
