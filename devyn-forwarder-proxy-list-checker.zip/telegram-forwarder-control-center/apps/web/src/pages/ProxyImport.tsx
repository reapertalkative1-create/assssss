import {useState} from 'react';
import {api,ApiError} from '../api/client';
import {Modal} from '../components/Modal';
import {Alert,TextArea} from '../components/ui';
import type {AppealSelection} from './BulkAppeal';
export function ProxyImport({selection,count,total,filters,onClose,onSaved}:{selection:AppealSelection;count:number;total:number;filters:Record<string,string|undefined>;onClose:()=>void;onSaved:(message:string)=>void}){
  const [text,setText]=useState(''),[protocol,setProtocol]=useState('socks5'),[scope,setScope]=useState(count?'selected':'all');
  const [busy,setBusy]=useState(false),[error,setError]=useState('');
  async function load(file?:File){if(!file)return;setError('');if(file.size>2000000){setError('File tối đa 2 MB.');return;}setText(await file.text());}
  async function save(){
    setBusy(true);setError('');
    try{
      const target=scope==='selected'?selection:{all_matching:true,account_ids:[],exclude_ids:[],filters};
      const r=await api.post<{assigned:number;unused:number}>('/api/account-proxies/assign',{text,protocol,selection:{action:'proxy_check',...target}});
      setText('');onSaved(`Đã gán ${r.assigned} proxy riêng cho ${r.assigned} SS${r.unused?`; dư ${r.unused} proxy chưa dùng`:''}.`);
    }catch(e){setError(e instanceof ApiError?e.message:'Không gán được proxy.');}finally{setBusy(false);}
  }
  return <Modal title="Nhập proxy" onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button><button className="btn primary" disabled={busy||!text.trim()||(scope==='selected'&&!count)||!total} onClick={()=>void save()}>{busy?'Đang gán…':'Gán proxy'}</button></>}>
    <div className="row"><label>Gán cho <select className="select" aria-label="Phạm vi gán proxy" value={scope} onChange={e=>setScope(e.target.value)}><option value="selected" disabled={!count}>SS đã tích ({count})</option><option value="all">Tất cả SS theo bộ lọc ({total})</option></select></label><label>Loại mặc định <select className="select" aria-label="Loại proxy mặc định" value={protocol} onChange={e=>setProtocol(e.target.value)}><option value="socks5">SOCKS5</option><option value="http">HTTP CONNECT</option><option value="socks4">SOCKS4</option></select></label></div>
    <label className="field">File .txt<input type="file" accept=".txt,text/plain" disabled={busy} onChange={e=>void load(e.target.files?.[0])}/></label>
    <TextArea label="Danh sách proxy" rows={10} value={text} onChange={e=>setText(e.target.value)} placeholder={'host:port\nhost:port:user:pass\nsocks5://user:pass@host:port'}/>
    <p className="hint">Mỗi dòng một proxy, mỗi SS một proxy riêng. Thiếu proxy sẽ báo lỗi, không gán dở. Hỗ trợ SOCKS5/SOCKS4/HTTP; proxy có scheme riêng dùng đúng scheme đó. SS đang chạy tự kết nối lại qua proxy mới.</p>
    {error&&<Alert tone="bad">{error}</Alert>}
  </Modal>;
}
