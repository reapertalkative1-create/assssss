import {useEffect,useRef,useState} from "react";
import {api,ApiError} from "../api/client";
import type {Account,Command} from "../api/types";
import {useQuery} from "../hooks/useQuery";
import {Modal} from "../components/Modal";
import {Alert,TextArea} from "../components/ui";
import {errorLabel} from "../lib/labels";
export const spamLabels:Record<string,string>={not_checked:"Chưa check spam",clear:"SpamBot: không hạn chế",limited:"SpamBot: bị hạn chế",blocked:"Bị chặn",unknown:"Cần đọc phản hồi",error:"Lỗi check spam"};
type Report={status:string;message_id:number;text:string;buttons:{id:string;text:string}[];delivery:string;response_date?:string;error_code?:string};
type Data={status:string;checked_at:string|null;error_code:string|null;action_status:string;report:Report|null;report_token:string|null;pending_command_id:string|null};
export function SpamPanel({a,onClose}:{a:Account;onClose:()=>void}){
  const info=useQuery(s=>api.get<Data>(`/api/accounts/${a.id}/spam`,undefined,s),[a.id],{interval:3000});
  const [text,setText]=useState("");
  const [busy,setBusy]=useState(false),[error,setError]=useState(""),[message,setMessage]=useState("");
  const [confirmation,setConfirmation]=useState<{operation:'reply'|'button';text:string;button_id?:string;request_id:string;report_token:string}>();
  const mounted=useRef(true);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  async function follow(cid:string){
    for(let i=0;i<40&&mounted.current;i++){
      const cmd=await api.get<Command>(`/api/accounts/${a.id}/commands/${cid}`,{wait_seconds:15});
      if(['done','failed','expired'].includes(cmd.status)){
        info.reload();
        if(cmd.status!=='done')setError(errorLabel(cmd.error_code)||'Lệnh hết hạn; kiểm tra kết quả trước khi gửi lại.');
        else if(cmd.result?.action_delivery==='uncertain')setMessage('Chưa xác nhận được tin đã gửi. Dùng Lấy phản hồi mới để kiểm tra.');
        else if(cmd.result?.action_delivery==='sent')setMessage('Đã gửi tương tác tới @SpamBot. Xem phản hồi bên dưới.');
        else if(cmd.result?.action_delivery==='not_sent')setError('Chưa gửi được tương tác. Hãy lấy phản hồi mới.');
        return;
      }
    }
    setMessage('Lệnh vẫn đang xử lý. Có thể đóng và mở lại cửa sổ này để xem kết quả.');
  }
  async function run(operation:'check'|'read'){
    setBusy(true);setError("");setMessage("");
    try{const r=await api.post<{command_id:string}>(`/api/accounts/${a.id}/spam/${operation}`);await follow(r.command_id);}
    catch(e){setError(e instanceof ApiError?e.message:'Không thực hiện được.');}finally{if(mounted.current)setBusy(false);}
  }
  function prepare(operation:'reply'|'button',button?:{id:string;text:string}){
    const token=info.data?.report_token;if(!token)return;
    if(operation==='reply'&&!text.trim()){setError('Nhập nội dung cần gửi theo câu hỏi SpamBot.');return;}
    setConfirmation({operation,text:operation==='reply'?text.trim():button!.text,button_id:button?.id,request_id:crypto.randomUUID(),report_token:token});
  }
  async function send(){
    if(!confirmation)return;setBusy(true);setError("");setMessage("");
    try{
      const {text:content,...rest}=confirmation;
      const payload=rest.operation==='reply'?{...rest,text:content}:rest;
      const r=await api.post<{command_id:string}>(`/api/accounts/${a.id}/spam/action`,payload);
      setConfirmation(undefined);setText("");await follow(r.command_id);
    }catch(e){setError(e instanceof ApiError?e.message:'Mất kết nối. Thử lại cùng yêu cầu hoặc lấy phản hồi mới để kiểm tra.');}
    finally{if(mounted.current)setBusy(false);}
  }
  const blocked=busy||!!info.data?.pending_command_id||a.auth_state!=='authorized';
  return <Modal title={`SpamBot / kháng nghị — ${a.name}`} onClose={onClose} dismissible={!busy}
    footer={<button className="btn" disabled={busy} onClick={onClose}>Đóng</button>}>
    <p><strong>{spamLabels[info.data?.status??'not_checked']}</strong>{info.data?.checked_at&&` · ${new Date(info.data.checked_at).toLocaleString()}`}</p>
    <p className="hint">Check gửi /start tới @SpamBot chính thức. Để tiếp tục kháng nghị, dùng nút thật của bot hoặc nhập câu trả lời của bạn. Nếu có CAPTCHA/liên kết cần thao tác, hoàn tất trong Telegram.</p>
    {a.auth_state!=='authorized'&&<Alert>Cần xác thực phiên trước khi tương tác với SpamBot.</Alert>}
    <div className="row"><button className="btn" disabled={blocked} onClick={()=>void run('check')}>Check spam (/start)</button><button className="btn" disabled={blocked} onClick={()=>void run('read')}>Lấy phản hồi mới</button></div>
    {info.data?.pending_command_id&&<Alert>Đang có lệnh xử lý. Kết quả sẽ tự cập nhật khi worker hoàn tất.</Alert>}
    {info.data?.action_status&&info.data.action_status!=='none'&&<p className="hint">Tương tác gần nhất: {({queued:'đang chờ worker',sent:'đã gửi tới bot',uncertain:'chưa xác nhận — kiểm tra phản hồi trước khi gửi tiếp',failed:'chưa gửi được'} as Record<string,string>)[info.data.action_status]??info.data.action_status}.</p>}
    {info.data?.report?.text&&<div className="card"><strong>Phản hồi từ @SpamBot</strong><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{info.data.report.text}</p><div className="row" style={{flexWrap:'wrap'}}>{info.data.report.buttons.map(b=><button className="btn" key={b.id} disabled={blocked} onClick={()=>prepare('button',b)}>{b.text}</button>)}</div></div>}
    {info.data?.report?.error_code&&<Alert tone="warn">{errorLabel(info.data.report.error_code)}</Alert>}
    <TextArea label="Nội dung kháng nghị / trả lời SpamBot" value={text} onChange={e=>setText(e.target.value)} maxLength={4000} rows={5} disabled={blocked} hint="Nhập thông tin thực tế theo câu hỏi hiện tại của SpamBot. Tin sẽ được gửi bằng tài khoản đang chọn."/>
    <button className="btn primary" disabled={blocked||!text.trim()||!info.data?.report?.message_id} onClick={()=>prepare('reply')}>Xem trước và gửi kháng nghị</button>
    {confirmation&&<div className="card stack"><strong>Xác nhận gửi bằng {a.name} tới @SpamBot</strong><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{confirmation.text}</p><div className="row"><button className="btn" disabled={busy} onClick={()=>setConfirmation(undefined)}>Hủy gửi</button><button className="btn primary" disabled={busy} onClick={()=>void send()}>{busy?'Đang xử lý…':confirmation.operation==='button'?'Xác nhận bấm nút':'Xác nhận gửi nội dung'}</button></div></div>}
    {message&&<Alert>{message}</Alert>}
    {(error||info.error)&&<Alert tone="bad">{error||info.error?.message}</Alert>}
    <p className="hint">Trạng thái gửi tin là kết quả tương tác, không phải kết quả xét duyệt. Telegram phản hồi quyết định trong cuộc hội thoại. Ứng dụng không tự gửi lại kháng nghị khi mất phản hồi.</p>
  </Modal>;
}
