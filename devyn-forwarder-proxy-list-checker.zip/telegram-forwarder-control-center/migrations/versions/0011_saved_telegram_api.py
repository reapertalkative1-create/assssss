"""Encrypted application settings for reusable Telegram API credentials."""
from alembic import op
import sqlalchemy as sa

revision = '0011'
down_revision = '0010'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('application_settings',
        sa.Column('key', sa.String(64), primary_key=True),
        sa.Column('value_ciphertext', sa.Text(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False))


def downgrade():
    op.drop_table('application_settings')
