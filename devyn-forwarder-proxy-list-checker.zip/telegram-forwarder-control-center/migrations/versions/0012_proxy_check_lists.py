"""Standalone proxy list checks, independent of Telegram accounts."""
from alembic import op
import sqlalchemy as sa
revision = '0012'
down_revision = '0011'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('proxy_check_batches',
        sa.Column('id', sa.Uuid(), primary_key=True),
        sa.Column('worker_id', sa.Uuid(), sa.ForeignKey('workers.id', ondelete='SET NULL'), nullable=True),
        sa.Column('created_by', sa.Uuid(), nullable=False),
        sa.Column('status', sa.String(16), nullable=False),
        sa.Column('total', sa.Integer(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_index('ix_proxy_check_batches_worker_id', 'proxy_check_batches', ['worker_id'])
    op.create_index('ix_proxy_check_batches_created_by', 'proxy_check_batches', ['created_by'])
    op.create_table('proxy_check_items',
        sa.Column('id', sa.Uuid(), primary_key=True),
        sa.Column('batch_id', sa.Uuid(), sa.ForeignKey('proxy_check_batches.id', ondelete='CASCADE'), nullable=False),
        sa.Column('position', sa.Integer(), nullable=False),
        sa.Column('proxy_ciphertext', sa.Text(), nullable=False),
        sa.Column('label', sa.String(300), nullable=False),
        sa.Column('status', sa.String(16), nullable=False),
        sa.Column('latency_ms', sa.Integer(), nullable=True),
        sa.Column('error_code', sa.String(32), nullable=True),
        sa.Column('checked_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('lease_token', sa.Uuid(), nullable=True),
        sa.Column('lease_until', sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint('batch_id', 'position', name='uq_proxy_check_position'))
    op.create_index('ix_proxy_check_batch_status', 'proxy_check_items', ['batch_id', 'status'])


def downgrade():
    op.drop_table('proxy_check_items')
    op.drop_table('proxy_check_batches')
