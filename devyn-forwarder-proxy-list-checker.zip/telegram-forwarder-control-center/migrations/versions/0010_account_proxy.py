"""Encrypted per-account proxies and independent proxy checks."""
from alembic import op
import sqlalchemy as sa
revision='0010'
down_revision='0009'
branch_labels=None
depends_on=None

def upgrade():
    for column in [sa.Column('proxy_ciphertext',sa.Text(),nullable=True),sa.Column('proxy_label',sa.String(300),nullable=True),sa.Column('proxy_fingerprint',sa.String(64),nullable=True),sa.Column('proxy_version',sa.Integer(),nullable=False,server_default='0'),sa.Column('proxy_status',sa.String(16),nullable=False,server_default='unknown'),sa.Column('proxy_checked_at',sa.DateTime(timezone=True),nullable=True),sa.Column('proxy_error',sa.String(64),nullable=True),sa.Column('proxy_latency_ms',sa.Integer(),nullable=True),sa.Column('proxy_check_command_id',sa.Uuid(),nullable=True)]:
        op.add_column('telegram_accounts',column)
    op.create_index('ix_telegram_accounts_proxy_fingerprint','telegram_accounts',['proxy_fingerprint'],unique=True)

def downgrade():
    op.drop_index('ix_telegram_accounts_proxy_fingerprint',table_name='telegram_accounts')
    for name in ['proxy_check_command_id','proxy_latency_ms','proxy_error','proxy_checked_at','proxy_status','proxy_version','proxy_fingerprint','proxy_label','proxy_ciphertext']:
        op.drop_column('telegram_accounts',name)
