import asyncio
import uuid
from datetime import timedelta

import pytest
from sqlalchemy import select
from app.crypto import SecretBox
from app.models import ProxyCheckItem, Role
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from worker.proxy_lists import ProxyListChecker
from worker.telegram_backend import BackendError

BASE = '/api/proxy-checks'
WB = '/api/worker/v1/proxy-checks'


def create(env, w, text='host1.example:1080:user:PRIVATE-PROXY-PASS\nhttp://host2.example:8080', **extra):
    body = {'request_id': str(uuid.uuid4()), 'worker_id': w.id, 'text': text, **extra}
    return env.client.post(BASE, headers=env.h, json=body)


def claim(w):
    r = w.http.post(WB + '/claim', headers=w.h, json={})
    assert r.status_code == 200, r.text
    return r.json()['items']


def report(w, items):
    r = w.http.post(WB + '/results', headers=w.h, json={'items': items})
    assert r.status_code == 200, r.text
    return r.json()


def outcome(item, status='alive'):
    return {'id': item['id'], 'token': item['token'], 'status': status,
            **({'latency_ms': 42} if status == 'alive' else {'error_code': 'proxy_timeout'})}


def test_standalone_create_dedup_claim_results_and_exports_without_ss_or_api(env):
    w = env.make_worker(); other = env.make_worker('other')
    text = '\ufeff# list\nhost1.example:1080:user:PRIVATE-PROXY-PASS\nhttp://host2.example:8080\n\nsocks5://user:PRIVATE-PROXY-PASS@host1.example:1080'
    r = create(env, w, text); assert r.status_code == 202, r.text
    bid = r.json()['id']; assert r.json()['total'] == 2
    assert env.client.get('/api/accounts').json()['total'] == 0 and w.poll() == []
    path = BASE + '/' + bid
    assert 'PRIVATE-PROXY-PASS' not in r.text + env.client.get(path).text + env.client.get('/api/audit').text
    async def tokens(db): return (await db.execute(select(ProxyCheckItem.proxy_ciphertext))).scalars().all()
    assert all('PRIVATE-PROXY-PASS' not in token for token in run_db(env.settings, tokens))
    assert claim(other) == []
    a, b = claim(w)
    assert a['proxy']['password'] == 'PRIVATE-PROXY-PASS'
    assert report(other, [outcome(a)])['lost'] == [a['id']]
    assert report(w, [outcome(a), outcome(b, 'dead')])['accepted'] == [a['id'], b['id']]
    data = env.client.get(path).json()
    assert data['status'] == 'done' and data['counts'] == {'alive': 1, 'dead': 1}
    assert env.client.get(path + '?status=alive').json()['filtered_total'] == 1
    live = env.client.get(path + '/export?status=alive')
    dead = env.client.get(path + '/export?status=dead')
    assert live.text == 'socks5://user:PRIVATE-PROXY-PASS@host1.example:1080\n'
    assert dead.text == 'http://host2.example:8080\n'
    assert 'proxy-list-live.txt' in live.headers['content-disposition'] and live.headers['cache-control'] == 'no-store'
    assert env.client.get('/api/accounts').json()['total'] == 0


def test_claims_bounded_expired_lease_recovery_and_late_result_fencing(env):
    w = env.make_worker(); bid = create(env, w, '\n'.join(f'host{i}.example:1080' for i in range(12))).json()['id']
    first = claim(w); assert len(first) == 10 and claim(w) == []
    async def expire(db):
        (await db.get(ProxyCheckItem, uuid.UUID(first[0]['id']))).lease_until = utcnow() - timedelta(seconds=1)
    run_db(env.settings, expire)
    (again,) = claim(w)
    assert again['id'] == first[0]['id'] and again['token'] != first[0]['token']
    assert report(w, [outcome(first[0])])['lost'] == [first[0]['id']]
    assert report(w, [outcome(again)])['accepted'] == [again['id']]
    assert report(w, [outcome(again)])['accepted'] == [again['id']]
    assert env.client.get(BASE + '/' + bid).json()['counts']['alive'] == 1
    r = env.client.post(BASE + '/' + bid + '/cancel', headers=env.h)
    assert r.json()['status'] == 'cancelled' and r.json()['counts']['cancelled'] == 11
    assert report(w, [outcome(first[1])])['lost'] == [first[1]['id']]
    assert claim(w) == []


def test_concurrent_claims_keep_one_worker_within_ten_active_probes(env):
    from concurrent.futures import ThreadPoolExecutor
    w = env.make_worker()
    create(env, w, '\n'.join(f'proxy{i}.example:1080' for i in range(25)))
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(claim, w) for _ in range(2)]
        batches = [future.result() for future in futures]
    assert sum(len(b) for b in batches) == 10
    assert len({i['id'] for b in batches for i in b}) == 10


def test_export_includes_all_pages_but_never_pending_items(env):
    w = env.make_worker(); bid = create(env, w, '\n'.join(f'host{i}.example:1080' for i in range(61))).json()['id']
    async def seed(db):
        rows = (await db.execute(select(ProxyCheckItem).order_by(ProxyCheckItem.position))).scalars().all()
        for i, row in enumerate(rows): row.status = 'alive' if i < 55 else 'dead' if i < 60 else 'pending'
    run_db(env.settings, seed)
    path = BASE + '/' + bid
    data = env.client.get(path + '?page_size=20').json()
    assert len(data['items']) == 20 and data['filtered_total'] == 61
    assert len(env.client.get(path + '/export?status=alive').text.splitlines()) == 55
    assert len(env.client.get(path + '/export?status=dead').text.splitlines()) == 5


def test_bad_proxy_and_missing_worker_do_not_create_partial_batches(env):
    w = env.make_worker()
    assert create(env, w, 'good.example:1080\nhttp://u:SECRET-INVALID@bad host:80').status_code == 422
    assert env.client.get(BASE).json()['items'] == []
    offline = env.make_worker('offline', register=False)
    assert create(env, offline).status_code == 409
    assert env.client.get(BASE).json()['items'] == []


def test_create_retry_is_idempotent_and_access_is_scoped(env, new_client, seed_user, login):
    w = env.make_worker(); rid = str(uuid.uuid4())
    a = create(env, w, request_id=rid); b = create(env, w, request_id=rid)
    assert a.status_code == b.status_code == 202 and len(env.client.get(BASE).json()['items']) == 1
    path = BASE + '/' + rid
    assert env.client.post(BASE, json={'request_id': str(uuid.uuid4()), 'worker_id': w.id, 'text': 'host:80'}).status_code == 403
    seed_user('proxy-op', role=Role.OPERATOR); op = new_client(); h = login(op, 'proxy-op')
    assert op.get(BASE).status_code == 403 and op.post(path + '/cancel', headers=h).status_code == 403
    seed_user('other-admin'); other = new_client(); login(other, 'other-admin')
    assert other.get(BASE).json()['items'] == [] and other.get(path).status_code == 404
    assert other.get(path + '/export?status=alive').status_code == 404
    assert new_client().get(path).status_code == 401


def test_unreadable_proxy_is_not_mislabelled_dead_and_exports_fail_before_returning_data(env):
    w = env.make_worker(); bid = create(env, w).json()['id']
    async def corrupt(db):
        row = (await db.execute(select(ProxyCheckItem).order_by(ProxyCheckItem.position))).scalars().first()
        row.proxy_ciphertext = 'broken'
    run_db(env.settings, corrupt)
    (good,) = claim(w); report(w, [outcome(good)])
    data = env.client.get(BASE + '/' + bid).json()
    assert data['counts'] == {'alive': 1, 'error': 1}
    async def corrupt_good(db):
        (await db.get(ProxyCheckItem, uuid.UUID(good['id']))).proxy_ciphertext = 'broken'
    run_db(env.settings, corrupt_good)
    r = env.client.get(BASE + '/' + bid + '/export?status=alive')
    assert r.status_code == 409 and 'host2.example' not in r.text


def test_proxy_list_key_verification_and_rotation(env):
    from app.cli import rotate_keys, verify_keys
    w = env.make_worker(); create(env, w)
    old = env.settings.session_encryption_key.get_secret_value(); new = SecretBox.generate_key()
    assert asyncio.run(verify_keys(env.settings.database_url, SecretBox([old])))['proxy_lists_ok'] == 2
    assert asyncio.run(rotate_keys(env.settings.database_url, SecretBox([new, old])))['proxy_lists'] == 2
    assert asyncio.run(verify_keys(env.settings.database_url, SecretBox([new])))['proxy_lists_ok'] == 2


def test_checker_bounds_concurrency_sanitizes_errors_and_retries_reports_without_reprobing():
    from worker.client import TransientError
    active = peak = calls = 0
    class Client:
        reports = 0
        async def claim_proxy_checks(self):return [{'id': str(i), 'token': str(i), 'proxy': {'host': str(i)}} for i in range(10)]
        async def proxy_check_results(self, items):
            self.reports += 1
            if self.reports == 1: raise TransientError('temporary')
            assert len(items) == 10 and items[1]['error_code'] == 'proxy_auth_failed' and items[2]['error_code'] == 'proxy_check_failed'
            assert 'SECRET' not in repr(items)
    async def probe(proxy):
        nonlocal active, peak, calls
        calls += 1; active += 1; peak = max(peak, active)
        await asyncio.sleep(.005); active -= 1
        if proxy['host'] == '1': raise BackendError('proxy_auth_failed')
        if proxy['host'] == '2': raise ValueError('SECRET')
        return {'latency_ms': 7}
    client = Client()
    asyncio.run(ProxyListChecker(client, probe=probe).once())
    assert calls == peak == 10 and client.reports == 2


def test_runner_automatically_checks_lists_with_no_account_manager(env, monkeypatch):
    import httpx
    from app.main import create_app
    from worker.client import ControlPlaneClient
    from worker.runner import Runner, EXIT_OK
    w = env.make_worker()
    bid = create(env, w, 'live.example:1080\ndie.example:1080').json()['id']
    probes = []
    async def probe(proxy):
        probes.append(proxy['host'])
        if proxy['host'] == 'die.example': raise BackendError('proxy_auth_failed')
        return {'latency_ms': 9}
    monkeypatch.setattr('worker.proxy_lists.check_proxy', probe)
    async def scenario():
        app = create_app(env.settings)
        http = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://testserver')
        client = ControlPlaneClient('http://testserver', w.h['Authorization'].removeprefix('Bearer '), http=http)
        runner = Runner(client, platform='linux', version='0.6.0', hostname='proxy-only')
        task = asyncio.create_task(runner.run())
        try:
            for _ in range(100):
                async with app.state.sessionmaker() as db:
                    statuses = (await db.execute(select(ProxyCheckItem.status).where(ProxyCheckItem.batch_id == uuid.UUID(bid)))).scalars().all()
                if sorted(statuses) == ['alive', 'dead']: break
                await asyncio.sleep(.05)
            else: raise AssertionError('Runner did not process proxy-only job')
        finally:
            runner.stop(); assert await task == EXIT_OK
            await http.aclose(); await app.state.engine.dispose()
    asyncio.run(scenario())
    assert sorted(probes) == ['die.example', 'live.example']
    assert env.client.get('/api/accounts').json()['total'] == 0
