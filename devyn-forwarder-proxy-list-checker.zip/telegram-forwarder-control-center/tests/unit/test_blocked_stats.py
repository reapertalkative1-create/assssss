import asyncio,json,uuid
from sqlalchemy import select
from app.crypto import SecretBox
from app.models import TelegramAccount as A
from app.db import make_engine,make_sessionmaker
from app.services.spam import clean_report,restore_blocked_statuses
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
BLOCKED='Your account was blocked for violations of the Telegram Terms of Service based on user reports confirmed by our moderators.'


def repair(env):
    async def run():
        engine=make_engine(env.settings.database_url)
        try:return await restore_blocked_statuses(make_sessionmaker(engine),SecretBox([env.settings.session_encryption_key.get_secret_value()]))
        finally:await engine.dispose()
    return asyncio.run(run())


def test_blocked_report_is_distinct_from_generic_spam():
    assert clean_report({'status':'limited','text':BLOCKED})['status']=='blocked'
    assert clean_report({'status':'blocked','text':BLOCKED})['status']=='blocked'
    assert clean_report({'status':'limited','text':'Your account is now limited.'})['status']=='limited'
    assert clean_report({'status':'unknown','text':'If your account was blocked for violations of the Telegram Terms of Service, contact support.'})['status']=='unknown'


def test_cached_blocked_results_count_filter_and_bulk_scope(env):
    ids=[env.make_account('SS '+str(i)) for i in range(5)]
    box=SecretBox([env.settings.session_encryption_key.get_secret_value()])
    async def seed(db):
        for i,aid in enumerate(ids):
            a=await db.get(A,uuid.UUID(aid));a.health_status='frozen' if i==3 else 'live';a.spam_status='unknown' if i==0 else 'limited'
            text=BLOCKED if i<2 else 'Your account is now limited.'
            a.spam_reply_ciphertext=box.seal('spam_report',aid,json.dumps({'text':text,'status':a.spam_status}))
    run_db(env.settings,seed)
    assert repair(env)==2
    assert repair(env)==0
    summary=env.client.get('/api/accounts/summary').json()
    assert summary['spam']['blocked']==2 and summary['spam']['limited']==3 and summary['health']['frozen']==1
    pages=[env.client.get(f'/api/accounts?spam_status=blocked&page={p}&page_size=1').json() for p in (1,2)]
    assert all(p['total']==2 for p in pages)
    assert {p['items'][0]['id'] for p in pages}==set(ids[:2])
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True,'exclude_ids':[ids[0]],'filters':{'spam_status':'blocked'}})
    assert r.status_code==202,r.text
    assert r.json()['total']==1
    assert env.client.get('/api/accounts?spam_status=limited').json()['total']==3


def test_unreadable_cached_report_is_not_guessed(env):
    aid=env.make_account()
    async def seed(db):
        a=await db.get(A,uuid.UUID(aid));a.spam_status='unknown';a.spam_reply_ciphertext='unreadable'
    run_db(env.settings,seed)
    assert repair(env)==0
    assert env.client.get('/api/accounts/'+aid).json()['spam_status']=='unknown'
