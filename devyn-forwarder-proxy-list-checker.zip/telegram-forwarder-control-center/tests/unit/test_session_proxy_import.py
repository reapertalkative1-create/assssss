"""Synthetic sessions only: proxy is persisted before the worker's first connect."""
import asyncio

import pytest

from app.main import create_app
from tests.fakes import FakeBackend, FakeNetwork
from tests.unit.test_accounts_api import env, db_dump
from tests.unit.test_accounts_e2e import e2e, Admin, WorkerSide
from tests.unit.test_session_import import sqlite_session, archive, payload
from worker.account_backend import AccountTelegramBackend
from worker.telegram_backend import BackendError


def upload(env, worker, files, proxies=None, **extra):
    body = payload(worker.id, archive(files), 'batch.zip')
    body.update(require_proxy=True, **extra)
    if proxies is not None:
        body['proxies'] = proxies
    return env.client.post('/api/accounts/import-sessions', headers=env.h, json=body)


@pytest.mark.parametrize('proxies', [None, [], ['proxy.example:1080'],
    ['proxy.example:1080', 'socks5://proxy.example:1080'],
    ['proxy.example:1080', 'http://u:PRIVATE-PROXY-SECRET@bad host:80'],
    ['proxy.example:1080', 'proxy2.example:1080\nproxy3.example:1080']])
def test_missing_bad_or_duplicate_proxy_rejects_entire_batch(env, proxies):
    w = env.make_worker()
    r = upload(env, w, [('a.session', sqlite_session()[0]), ('b.session', sqlite_session()[0])], proxies)
    assert r.status_code == 422, r.text
    assert 'PRIVATE-PROXY-SECRET' not in r.text
    assert env.client.get('/api/accounts').json()['total'] == 0
    assert w.poll() == []


def test_encrypted_proxies_available_to_worker_before_import_command(env):
    w = env.make_worker()
    r = upload(env, w, [('a.session', sqlite_session()[0]), ('b.session', sqlite_session()[0])],
        ['proxy1.example:8080:u:PRIVATE-PROXY-SECRET', 'socks5://proxy2.example:1080'], proxy_protocol='http')
    assert r.status_code == 202, r.text
    items = r.json()['items']
    assert [i['proxy_label'] for i in items] == ['http://proxy1.example:8080', 'socks5://proxy2.example:1080']
    assert 'PRIVATE-PROXY-SECRET' not in r.text + db_dump(env.settings) + env.client.get('/api/audit').text
    commands = w.poll()
    assert len(commands) == 2 and all(c['type'] == 'import_session' for c in commands)
    for item, host in zip(items, ['proxy1.example', 'proxy2.example']):
        data = w.http.post(f"/api/worker/v1/accounts/{item['account_id']}/proxy/fetch", headers=w.h).json()
        assert data['version'] == 1 and data['proxy']['host'] == host
        a = env.client.get('/api/accounts/' + item['account_id']).json()
        assert a['proxy_status'] == 'unknown' and a['auth_state'] == 'importing'


def test_used_proxy_rejects_batch_before_any_import(env):
    w = env.make_worker()
    assert upload(env, w, [('old.session', sqlite_session()[0])], ['old.example:1080']).status_code == 202
    w.poll()
    r = upload(env, w, [('new1.session', sqlite_session()[0]), ('new2.session', sqlite_session()[0])],
        ['free.example:1080', 'old.example:1080'])
    assert r.status_code == 409 and r.json()['error']['code'] == 'proxy_in_use'
    assert env.client.get('/api/accounts').json()['total'] == 1
    assert w.poll() == []


def test_duplicate_and_invalid_sessions_keep_positions_and_old_proxy(env):
    w = env.make_worker(); raw = sqlite_session()[0]
    old = upload(env, w, [('old.session', raw)], ['old.example:1080']).json()['items'][0]
    r = upload(env, w, [('duplicate.session', raw), ('bad.session', b'bad'), ('new.session', sqlite_session()[0])],
        ['ignored.example:1080', 'unused.example:1080', 'new.example:1080'])
    assert r.status_code == 202, r.text
    rows = r.json()['items']
    assert [i['status'] for i in rows] == ['duplicate', 'error', 'queued']
    assert rows[0]['account_id'] == old['account_id'] and rows[0]['proxy_label'] == 'socks5://old.example:1080'
    assert rows[2]['proxy_label'] == 'socks5://new.example:1080'
    # Retrying the same upload after a lost response keeps both SS/proxy assignments.
    r = upload(env, w, [('duplicate.session', raw)], ['old.example:1080'])
    assert r.status_code == 202 and r.json()['items'][0]['status'] == 'duplicate'


def test_worker_first_connection_and_retry_always_use_imported_proxy(e2e):
    async def scenario():
        app = create_app(e2e); admin = Admin(app); await admin.login()
        net = FakeNetwork(); w = await WorkerSide(app, admin, 'proxy-import', net).create()
        attempts = []; broken = True
        class ProxyBackend(FakeBackend):
            proxy = None
            def set_proxy(self, proxy): self.proxy = proxy
            async def send_code(self, phone): raise AssertionError('Import must not request OTP')
            async def connect(self, session):
                assert self.proxy is not None, 'First connection must already have its proxy'
                attempts.append(dict(self.proxy))
                if broken: raise BackendError('network_error')
                return await super().connect(session)
        w.manager._backend = AccountTelegramBackend(w.client, factory=lambda api_id, api_hash: ProxyBackend(net))
        try:
            body = payload(w.id, sqlite_session()[0])
            body.update(require_proxy=True, proxies=['proxy.example:1080:u:PRIVATE-PROXY-SECRET'])
            r = await admin.post('/api/accounts/import-sessions', body)
            assert r.status_code == 202, r.text
            item = r.json()['items'][0]; aid = item['account_id']
            cmd = await admin.finished(aid, item['command_id'])
            assert cmd['status'] == 'failed' and cmd['error_code'] == 'network_error'
            assert len(attempts) == 1  # No direct-connection retry on proxy failure.
            assert (await admin.account(aid))['auth_state'] == 'import_failed'
            broken = False
            retry = await admin.post(f'/api/accounts/{aid}/import-session/retry')
            assert (await admin.finished(aid, retry.json()['command_id']))['status'] == 'done'
            assert len(attempts) == 2 and attempts[0] == attempts[1]
            assert attempts[0]['host'] == 'proxy.example' and attempts[0]['password'] == 'PRIVATE-PROXY-SECRET'
            assert (await admin.account(aid))['auth_state'] == 'authorized'
        finally:
            await w.close(); await w.client.aclose(); await admin.http.aclose(); await app.state.engine.dispose()
    asyncio.run(scenario())
