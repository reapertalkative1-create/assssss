import asyncio

import pytest

from app.cli import rotate_keys, verify_keys
from app.crypto import SecretBox
from app.models import ApplicationSetting, Role
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_session_import import payload, sqlite_session

PATH = '/api/settings/telegram-api'
CONFIG = {'api_id': 12345, 'api_hash': 'abcdef0123456789abcdef0123456789'}


def save(env, config=CONFIG):
    return env.client.put(PATH, headers=env.h, json=config)


def import_without_api(env, w):
    body = payload(w.id, sqlite_session()[0])
    del body['api_id']; del body['api_hash']
    return env.client.post('/api/accounts/import-sessions', headers=env.h, json=body)


def fetch(w, aid):
    return w.http.post(f'/api/worker/v1/accounts/{aid}/telegram-api/fetch', headers=w.h)


def test_save_once_persists_across_api_instances_and_never_returns_hash(env, new_client, login):
    assert env.client.get(PATH).json() == {'configured': False, 'api_id': None, 'updated_at': None}
    r = save(env); assert r.status_code == 200, r.text
    assert r.json()['configured'] and r.json()['api_id'] == 12345
    assert CONFIG['api_hash'] not in r.text + env.client.get(PATH).text + env.client.get('/api/audit').text
    assert r.headers['cache-control'] == 'no-store'
    async def stored(db):
        return (await db.get(ApplicationSetting, 'telegram_api')).value_ciphertext
    token = run_db(env.settings, stored)
    assert CONFIG['api_hash'] not in token
    client = new_client(); login(client, 'admin1')
    assert client.get(PATH).json()['api_id'] == 12345


def test_missing_or_unreadable_default_stops_import_without_creating_accounts(env):
    w = env.make_worker()
    r = import_without_api(env, w)
    assert r.status_code == 409 and r.json()['error']['code'] == 'telegram_api_not_configured'
    save(env)
    async def corrupt(db):
        (await db.get(ApplicationSetting, 'telegram_api')).value_ciphertext = 'broken'
    run_db(env.settings, corrupt)
    assert env.client.get(PATH).json()['error']['code'] == 'telegram_api_unreadable'
    assert import_without_api(env, w).status_code == 409
    assert env.client.get('/api/accounts').json()['total'] == 0 and w.poll() == []


def test_import_and_account_create_use_saved_pair_but_old_accounts_keep_theirs(env):
    w = env.make_worker(); assert save(env).status_code == 200
    r = import_without_api(env, w); assert r.status_code == 202, r.text
    imported = r.json()['items'][0]['account_id']
    assert fetch(w, imported).json() == CONFIG
    r = env.client.post('/api/accounts', headers=env.h, json={'name': 'Uses settings', 'worker_id': w.id})
    assert r.status_code == 201 and r.json()['telegram_api_configured']
    created = r.json()['id']; assert fetch(w, created).json() == CONFIG
    new = {'api_id': 98765, 'api_hash': 'b' * 32}
    assert save(env, new).status_code == 200
    assert fetch(w, imported).json() == CONFIG and fetch(w, created).json() == CONFIG
    next_id = import_without_api(env, w).json()['items'][0]['account_id']
    assert fetch(w, next_id).json() == new
    r = env.client.put(f'/api/accounts/{created}/telegram-api', headers=env.h, json={})
    assert r.status_code == 200 and fetch(w, created).json() == new
    # Older clients that explicitly send a pair remain compatible.
    body = payload(w.id, sqlite_session()[0])
    body.update(CONFIG)
    aid = env.client.post('/api/accounts/import-sessions', headers=env.h, json=body).json()['items'][0]['account_id']
    assert fetch(w, aid).json() == CONFIG


def test_settings_require_admin_csrf_and_valid_complete_pair(env, seed_user, new_client, login):
    seed_user('settings-op', role=Role.OPERATOR); op = new_client(); h = login(op, 'settings-op')
    assert op.get(PATH).status_code == 403
    assert op.put(PATH, headers=h, json=CONFIG).status_code == 403
    assert new_client().get(PATH).status_code == 401
    assert env.client.put(PATH, json=CONFIG).status_code == 403
    assert save(env).status_code == 200
    for body in [{'api_id': 2}, {'api_hash': CONFIG['api_hash']}, {'api_id': 0, 'api_hash': 'SECRET-BAD-HASH'}, {'api_id': 3, 'api_hash': None}]:
        r = save(env, body)
        assert r.status_code == 422 and 'SECRET-BAD-HASH' not in r.text
    assert env.client.get(PATH).json()['api_id'] == CONFIG['api_id']


def test_saved_api_is_included_in_key_verification_and_rotation(env):
    save(env)
    old = env.settings.session_encryption_key.get_secret_value(); new = SecretBox.generate_key()
    assert asyncio.run(verify_keys(env.settings.database_url, SecretBox([old])))['settings_ok'] == 1
    assert asyncio.run(verify_keys(env.settings.database_url, SecretBox([new])))['settings_failed'] == 1
    assert asyncio.run(rotate_keys(env.settings.database_url, SecretBox([new, old])))['settings'] == 1
    assert asyncio.run(verify_keys(env.settings.database_url, SecretBox([new])))['settings_ok'] == 1
