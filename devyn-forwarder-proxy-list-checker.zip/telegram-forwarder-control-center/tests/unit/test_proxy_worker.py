import asyncio
import datetime
import ssl
from types import SimpleNamespace
import pytest
from worker.telegram_backend import BackendError,TelethonBackend
from worker.account_backend import AccountTelegramBackend
from worker.accounts import AccountManager
from worker.client import TelegramApiData


def test_backend_attaches_proxy_and_never_falls_back_when_proxy_fetch_fails():
    async def run():
        class Client:
            async def fetch_telegram_api(self,aid):return TelegramApiData(123,'a'*32)
            async def fetch_proxy(self,aid):return {'proxy':{'protocol':'socks5','host':'127.0.0.1','port':1080,'username':'test','password':'secret'}}
        backend=await AccountTelegramBackend(Client())._for('a')
        assert backend._proxy['proxy_type']=='socks5' and backend._proxy['password']=='secret'
        class Broken(Client):
            async def fetch_proxy(self,aid):raise BackendError('proxy_unreadable')
        with pytest.raises(BackendError):await AccountTelegramBackend(Broken())._for('a')
    asyncio.run(run())


def test_proxy_check_runs_without_telegram_api_and_checks_config_version(monkeypatch):
    async def run():
        async def fetch(aid):return {'proxy':{'host':'127.0.0.1'},'version':2}
        async def probe(value):return {'latency_ms':12}
        monkeypatch.setattr('worker.proxy.check_proxy',probe)
        manager=AccountManager(SimpleNamespace(fetch_proxy=fetch),None)
        assert await manager._execute('proxy_check','a',{'proxy_version':2})=={'latency_ms':12}
        with pytest.raises(BackendError,match='proxy_changed'):await manager._execute('proxy_check','a',{'proxy_version':1})
    asyncio.run(run())


def make_tls(tmp_path):
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization,hashes
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'api.telegram.org')]);now=datetime.datetime.now(datetime.timezone.utc)
    cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1)).not_valid_after(now+datetime.timedelta(days=1)).add_extension(x509.SubjectAlternativeName([x509.DNSName('api.telegram.org')]),critical=False).sign(key,hashes.SHA256())
    cert_path=tmp_path/'test-cert.pem';key_path=tmp_path/'test-key.pem'
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM));key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
    server=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);server.load_cert_chain(str(cert_path),str(key_path))
    client=ssl.create_default_context(cafile=str(cert_path))
    return server,client


@pytest.mark.parametrize('protocol',['http','socks5'])
def test_real_local_proxy_tunnel_and_tls_handshake(tmp_path,monkeypatch,protocol):
    server_ctx,client_ctx=make_tls(tmp_path)
    async def run():
        requests=[];tasks=set()
        async def tls_peer(reader,writer):
            try:await reader.read()
            finally:writer.close();await writer.wait_closed()
        target=await asyncio.start_server(tls_peer,'127.0.0.1',0,ssl=server_ctx)
        target_port=target.sockets[0].getsockname()[1]
        async def forward(reader,writer):
            try:
                while data:=await reader.read(65536):writer.write(data);await writer.drain()
            finally:writer.close()
        async def tunnel(reader,writer):
            upstream=None
            try:
                if protocol=='http':
                    headers=await reader.readuntil(b'\r\n\r\n');requests.append(headers.split(b'\r\n')[0])
                    import base64
                    assert b'Proxy-Authorization: Basic '+base64.b64encode(b'tester:p@ss') in headers
                    writer.write(b'HTTP/1.1 200 Connection established\r\n\r\n');await writer.drain()
                else:
                    version,n=await reader.readexactly(2);methods=await reader.readexactly(n);assert version==5
                    assert 2 in methods
                    writer.write(b'\x05\x02');await writer.drain()
                    auth_version,user_length=await reader.readexactly(2);user=await reader.readexactly(user_length)
                    pass_length=(await reader.readexactly(1))[0];password=await reader.readexactly(pass_length)
                    assert auth_version==1 and user==b'tester' and password==b'p@ss'
                    writer.write(b'\x01\x00');await writer.drain()
                    head=await reader.readexactly(4);assert head[:3]==b'\x05\x01\x00' and head[3]==3
                    length=(await reader.readexactly(1))[0];host=await reader.readexactly(length);port=int.from_bytes(await reader.readexactly(2),'big');requests.append((host,port))
                    writer.write(b'\x05\x00\x00\x01\x7f\x00\x00\x01\x01\xbb');await writer.drain()
                remote,upstream=await asyncio.open_connection('127.0.0.1',target_port)
                await asyncio.gather(forward(reader,upstream),forward(remote,writer))
            finally:
                writer.close()
                if upstream:upstream.close()
        def accept(r,w):
            task=asyncio.create_task(tunnel(r,w));tasks.add(task);task.add_done_callback(tasks.discard)
        proxy=await asyncio.start_server(accept,'127.0.0.1',0)
        monkeypatch.setattr('worker.proxy.ssl.create_default_context',lambda:client_ctx)
        try:
            from worker.proxy import check_proxy
            result=await check_proxy({'protocol':protocol,'host':'127.0.0.1','port':proxy.sockets[0].getsockname()[1],'username':'tester','password':'p@ss'})
            assert 0<=result['latency_ms']<=60000
            assert requests==([b'CONNECT api.telegram.org:443 HTTP/1.1'] if protocol=='http' else [(b'api.telegram.org',443)])
        finally:
            proxy.close();target.close();await proxy.wait_closed();await target.wait_closed()
            if tasks:await asyncio.gather(*list(tasks),return_exceptions=True)
    asyncio.run(run())


from tests.unit.test_accounts_e2e import e2e

def test_running_account_reconnects_with_new_proxy_without_duplicate_session(e2e):
    from app.main import create_app
    from tests.unit.test_accounts_e2e import Admin,WorkerSide,authorize
    from tests.fakes import FakeBackend,FakeNetwork
    async def run():
        app=create_app(e2e);admin=Admin(app);await admin.login();net=FakeNetwork()
        w=await WorkerSide(app,admin,'proxy-reconnect',net).create()
        class ProxyBackend(FakeBackend):
            proxy=None
            def set_proxy(self,value):self.proxy=value
        try:
            a=(await admin.post('/api/accounts',{'name':'Proxy SS','worker_id':w.id,'api_id':12345,'api_hash':'a'*32})).json();aid=a['id']
            await authorize(admin,aid)
            w.manager._backend=AccountTelegramBackend(w.client,factory=lambda api_id,api_hash:ProxyBackend(net))
            await admin.post(f'/api/accounts/{aid}/start');await w.beat()
            old=w.manager._active[aid].handle
            r=await admin.post('/api/account-proxies/assign',{'text':'127.0.0.1:1080','selection':{'action':'proxy_check','account_ids':[aid]}})
            assert r.status_code==200,r.text
            await w.beat()
            current=w.manager._active[aid].handle
            assert current is not old and current.backend.proxy['host']=='127.0.0.1'
            assert old.raw in old.backend.disconnects
            assert net.max_simultaneous==1
            assert (await admin.account(aid))['desired_state']=='running'
        finally:
            await w.close();await w.client.aclose();await admin.http.aclose();await app.state.engine.dispose()
    asyncio.run(run())
