import uuid
from app.models import TelegramAccount as A,Role
from app.services.account_proxy import parse_proxies
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_account_proxy import assign,process


def seed_proxies(env):
    w=env.make_worker();ids=[env.make_account('Export '+str(i),worker=w) for i in range(4)]
    text='socks5://export-user:EXPORT-PROXY-PASSWORD@127.0.0.1:1080\nhttp://127.0.0.2:8080\nsocks5://127.0.0.3:1080\nsocks5://127.0.0.4:1080'
    assert assign(env,ids,text).status_code==200
    env.client.post('/api/account-bulk',headers=env.h,json={'action':'proxy_check','account_ids':ids[:3]});process(env)
    for cmd in w.poll():
        w.result(cmd['id'],status='failed' if cmd['account_id']==ids[2] else 'done',error_code='proxy_check_failed' if cmd['account_id']==ids[2] else None,result={'latency_ms':24} if cmd['account_id']!=ids[2] else None)
    return ids


def test_proxy_filter_and_separate_exports_include_every_matching_page(env):
    ids=seed_proxies(env)
    assert env.client.get('/api/accounts?proxy_status=alive&page_size=1').json()['total']==2
    assert env.client.get('/api/accounts?proxy_status=dead').json()['items'][0]['id']==ids[2]
    assert env.client.get('/api/accounts?proxy_status=unknown').json()['items'][0]['id']==ids[3]
    alive=env.client.get('/api/account-proxies/export?status=alive&proxy_status=dead')
    assert alive.status_code==200,alive.text
    assert len(alive.text.splitlines())==2 and len(parse_proxies(alive.text))==2
    assert 'EXPORT-PROXY-PASSWORD' in alive.text and '127.0.0.3' not in alive.text and '127.0.0.4' not in alive.text
    assert 'proxies-live.txt' in alive.headers['content-disposition'] and alive.headers['cache-control']=='no-store'
    dead=env.client.get('/api/account-proxies/export?status=dead')
    assert dead.status_code==200 and dead.text=='socks5://127.0.0.3:1080\n'
    assert 'proxies-die.txt' in dead.headers['content-disposition']
    assert env.client.get('/api/account-proxies/export?status=alive&q=Export+0').text==alive.text.splitlines()[0]+'\n'
    assert 'EXPORT-PROXY-PASSWORD' not in env.client.get('/api/accounts').text
    assert 'EXPORT-PROXY-PASSWORD' not in env.client.get('/api/audit').text
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True,'filters':{'proxy_status':'alive'}})
    assert r.status_code==202 and r.json()['total']==2


def test_export_is_admin_only_and_does_not_return_partial_files(env,new_client,seed_user,login):
    ids=seed_proxies(env)
    seed_user('export-operator',role=Role.OPERATOR);op=new_client();login(op,'export-operator')
    assert op.get('/api/account-proxies/export?status=alive').status_code==403
    assert new_client().get('/api/account-proxies/export?status=alive').status_code==401
    assert env.client.get('/api/account-proxies/export?status=unknown').status_code==422
    async def corrupt(db):
        a=await db.get(A,uuid.UUID(ids[1]));a.proxy_ciphertext='unreadable'
    run_db(env.settings,corrupt)
    r=env.client.get('/api/account-proxies/export?status=alive')
    assert r.status_code==409 and 'content-disposition' not in r.headers
    assert 'EXPORT-PROXY-PASSWORD' not in r.text
