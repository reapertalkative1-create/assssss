import asyncio,json,uuid
from datetime import timedelta
import pytest
from sqlalchemy import select
from app.errors import ApiError
from app.crypto import SecretBox
from app.models import TelegramAccount as A,WorkerCommand,Role
from app.services.account_proxy import parse_proxies
from app.services.account_bulk import tick
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env,db_dump


def assign(env,ids,text,**extra):
    return env.client.post('/api/account-proxies/assign',headers=env.h,json={'text':text,'selection':{'action':'proxy_check','account_ids':ids,**extra}})

def process(env):
    async def run(db):await tick(db,env.settings,SecretBox([env.settings.session_encryption_key.get_secret_value()]))
    run_db(env.settings,run)


def test_parse_formats_ipv6_passwords_and_dedup():
    values=parse_proxies('\ufeff# comment\nhost.example:1080:user:p:a:ss\nsocks5://user:p%3Aa%3Ass@host.example:1080\nhttp://u:p%40ss@127.0.0.1:8080\nsocks5://[::1]:1080')
    assert len(values)==3 and values[0]['password']=='p:a:ss'
    assert values[1]['password']=='p@ss' and values[2]['host']=='::1'
    assert all('user' not in v['label'] and 'p@ss' not in v['label'] for v in values)

@pytest.mark.parametrize('value',['','host:70000','ftp://host:80','http://host:80/path','http://host:80?x=y','bad host:80','socks5://u:p%0Ainject@host:80'])
def test_invalid_proxy_does_not_echo_secret(value):
    with pytest.raises(ApiError):parse_proxies(value)


def test_assign_distinct_encrypted_proxies_and_insufficient_atomic(env):
    a=env.make_account('SS A');b=env.make_account('SS B')
    r=assign(env,[a,b],'127.0.0.1:1080:user:PRIVATE-PROXY-PASSWORD\n127.0.0.2:1080')
    assert r.status_code==200,r.text
    assert r.json()['assigned']==2
    rows=env.client.get('/api/accounts').json()['items']
    assert len({x['proxy_label'] for x in rows})==2 and all(x['proxy_status']=='unknown' for x in rows)
    assert 'PRIVATE-PROXY-PASSWORD' not in json.dumps(rows)
    assert 'PRIVATE-PROXY-PASSWORD' not in db_dump(env.settings)
    before={x['id']:x['proxy_label'] for x in rows}
    r=assign(env,[a,b],'127.0.0.3:1080');assert r.status_code==422
    assert {x['id']:x['proxy_label'] for x in env.client.get('/api/accounts').json()['items']}==before
    # A proxy already assigned outside the selection cannot be reused.
    assert assign(env,[b],'127.0.0.1:1080:user:PRIVATE-PROXY-PASSWORD').status_code==409


def test_filtered_selection_exclusions_and_worker_secret_scope(env):
    w=env.make_worker();other=env.make_worker('other')
    a=env.make_account('Keep',worker=w);b=env.make_account('Skip',worker=w)
    r=assign(env,[],'http://usr:PRIVATE-PROXY@127.0.0.1:8080',all_matching=True,exclude_ids=[b])
    assert r.status_code==200,r.text
    url=f'/api/worker/v1/accounts/{a}/proxy/fetch'
    r=w.http.post(url,headers=w.h);assert r.status_code==200 and r.json()['proxy']['password']=='PRIVATE-PROXY'
    assert other.http.post(url,headers=other.h).status_code==404
    assert env.client.get('/api/accounts/'+b).json()['proxy_label'] is None
    assert 'PRIVATE-PROXY' not in env.client.get('/api/audit').text


def test_proxy_check_does_not_need_telegram_session_and_result_is_independent(env):
    w=env.make_worker();aid=env.make_account(worker=w)
    assert assign(env,[aid],'127.0.0.1:1080').status_code==200
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'proxy_check','account_ids':[aid]});assert r.status_code==202
    process(env);(cmd,)=w.poll();assert cmd['type']=='proxy_check'
    assert env.client.get('/api/accounts/'+aid).json()['proxy_status']=='checking'
    assert w.result(cmd['id'],result={'latency_ms':35}).status_code==204
    a=env.client.get('/api/accounts/'+aid).json()
    assert a['proxy_status']=='alive' and a['proxy_latency_ms']==35
    assert a['health_status']=='unknown' and a['auth_state']=='unauthenticated'
    process(env)
    env.client.post('/api/account-bulk',headers=env.h,json={'action':'proxy_check','account_ids':[aid]});process(env)
    (cmd,)=w.poll();w.result(cmd['id'],status='failed',error_code='proxy_check_failed')
    assert env.client.get('/api/accounts/'+aid).json()['proxy_status']=='dead'


def test_reassignment_fences_old_probe_result(env):
    w=env.make_worker();aid=env.make_account(worker=w)
    assign(env,[aid],'127.0.0.1:1080')
    env.client.post('/api/account-bulk',headers=env.h,json={'action':'proxy_check','account_ids':[aid]});process(env);(cmd,)=w.poll()
    assert assign(env,[aid],'127.0.0.2:1080').status_code==200
    assert w.result(cmd['id'],result={'latency_ms':1}).status_code==409
    a=env.client.get('/api/accounts/'+aid).json();assert a['proxy_status']=='unknown' and '127.0.0.2' in a['proxy_label']


def test_proxy_assign_csrf_and_role(env,new_client,seed_user,login):
    aid=env.make_account();body={'text':'127.0.0.1:1080','selection':{'action':'proxy_check','account_ids':[aid]}}
    assert env.client.post('/api/account-proxies/assign',json=body).status_code==403
    seed_user('proxy-op',role=Role.OPERATOR);op=new_client();h=login(op,'proxy-op')
    assert op.post('/api/account-proxies/assign',headers=h,json=body).status_code==403


def test_proxy_key_rotation(env):
    from app.cli import rotate_keys,verify_keys
    aid=env.make_account();assign(env,[aid],'127.0.0.1:1080:secret-user:secret-password')
    old=env.settings.session_encryption_key.get_secret_value();new=SecretBox.generate_key();box=SecretBox([new,old])
    assert asyncio.run(rotate_keys(env.settings.database_url,box))['proxies']==1
    assert asyncio.run(verify_keys(env.settings.database_url,SecretBox([new])))['proxies_ok']==1
