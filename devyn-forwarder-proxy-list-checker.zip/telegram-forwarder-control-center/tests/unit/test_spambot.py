import asyncio
import uuid
from datetime import timedelta
from types import SimpleNamespace
import pytest
from sqlalchemy import select
from app.models import TelegramAccount,Role,WorkerCommand
from app.main import create_app
from app.services import accounts as svc
from app.types import utcnow
from app.crypto import SecretBox
from tests.conftest import run_db
from tests.unit.test_accounts_api import env,db_dump
from tests.unit.test_accounts_e2e import e2e,Admin,WorkerSide
from tests.unit.test_session_import import sqlite_session,payload
from tests.fakes import FakeBackend,FakeNetwork
from worker.account_backend import AccountTelegramBackend
from worker.spambot import classify,describe,interact
from worker.telegram_backend import BackendError


@pytest.mark.parametrize('text,status',[
 ('Good news, no limits are currently applied to your account.','clear'),
 ('Unfortunately your account is now limited until tomorrow.','limited'),
 ('Your account may be limited if you send unsolicited messages.','unknown'),
 ('The bot changed its wording completely','unknown'),
 ('На Ваш аккаунт не наложено никаких ограничений.','clear')])
def test_spam_classification_is_conservative(text,status):assert classify(text)==status


def bot_message(text='Your account is now limited',buttons=None):
    return SimpleNamespace(id=101,raw_text=text,reply_markup=SimpleNamespace(rows=[SimpleNamespace(buttons=buttons or [])]),
        date=utcnow(),edit_date=None,out=False,sender_id=178220800)


class BotClient:
    def __init__(self):
        from telethon.tl.types import KeyboardButton
        self.peer=SimpleNamespace(id=178220800,bot=True,username='SpamBot')
        self.message=bot_message(buttons=[KeyboardButton('This is a mistake',__import__('telethon.tl.types',fromlist=['ButtonTypeDefault']).ButtonTypeDefault())]);self.handlers=[];self.sent=[];self.clicked=[]
    async def get_entity(self,name):assert name=='SpamBot';return self.peer
    async def get_messages(self,peer,**kw):return self.message if 'ids' in kw else [self.message]
    def add_event_handler(self,fn,builder):self.handlers.append(fn)
    def remove_event_handler(self,fn,builder):self.handlers.remove(fn)
    async def send_message(self,peer,text):
        assert peer is self.peer;self.sent.append(text)
        for fn in self.handlers[:]:await fn(SimpleNamespace(message=self.message))


def test_official_bot_check_and_explicit_reply_only():
    async def scenario():
        c=BotClient();r=await interact(c)
        assert c.sent==['/start'] and r['status']=='limited' and not c.handlers
        r=await interact(c,'reply',text='My truthful appeal',expected_reply_id=101)
        assert c.sent==['/start','My truthful appeal'] and r['delivery']=='sent'
        await interact(c,'read');assert len(c.sent)==2
        with pytest.raises(BackendError):await interact(c,'reply',text='Do not send',expected_reply_id=999)
        assert len(c.sent)==2
        c.peer.username='FakeBot'
        with pytest.raises(BackendError):await interact(c)
        assert len(c.sent)==2
    asyncio.run(scenario())


def test_dangerous_buttons_are_not_exposed_or_clicked():
    from telethon.tl.types import KeyboardInlineButton,InlineButtonTypeUrl,KeyboardButton,ButtonTypeRequestPhone
    msg=bot_message(buttons=[KeyboardInlineButton('Open',InlineButtonTypeUrl('https://example.com')),KeyboardButton('Share phone',ButtonTypeRequestPhone())])
    assert describe(msg)['buttons']==[]
    async def scenario():
        c=BotClient();c.message=msg
        with pytest.raises(BackendError):await interact(c,'button',button_id='101:0:0',expected_button_text='Open')
        assert not c.sent
    asyncio.run(scenario())


def seeded_report(env):
    w=env.make_worker();aid=env.make_account(worker=w);env.authorize(w,aid)
    r=env.client.post(f'/api/accounts/{aid}/spam/check',headers=env.h)
    assert r.status_code==202,r.text
    (cmd,)=w.poll();assert cmd['type']=='spam_check'
    w.result(cmd['id'],result={'connection_state':'connected','spam_report':{'status':'limited','message_id':101,
        'text':'PRIVATE-BOT-REPLY: your account is now limited','buttons':[{'id':'101:0:0','text':'This is a mistake'}],'delivery':'sent'}})
    return w,aid,env.client.get(f'/api/accounts/{aid}/spam').json()


def test_bot_report_encryption_and_appeal_idempotency(env):
    w,aid,report=seeded_report(env)
    assert report['status']=='limited' and 'PRIVATE-BOT-REPLY' in report['report']['text']
    assert 'PRIVATE-BOT-REPLY' not in db_dump(env.settings)
    request_id=str(uuid.uuid4());body={'request_id':request_id,'report_token':report['report_token'],
        'operation':'reply','text':'PRIVATE-APPEAL-CONTENT'}
    r=env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body)
    assert r.status_code==202,r.text
    again=env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body)
    assert again.json()['command_id']==request_id==r.json()['command_id']
    assert 'PRIVATE-APPEAL-CONTENT' not in db_dump(env.settings)
    (cmd,)=w.poll();assert cmd['type']=='spam_reply' and cmd['payload']['text']=='PRIVATE-APPEAL-CONTENT'
    assert 'PRIVATE-APPEAL-CONTENT' not in db_dump(env.settings)
    w.result(cmd['id'],result={'connection_state':'connected','spam_report':{'status':'unknown','message_id':0,'text':'','buttons':[],'delivery':'uncertain','error_code':'network_error'}})
    final=env.client.get(f'/api/accounts/{aid}/spam').json()
    assert final['action_status']=='uncertain'
    assert env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body).json()['command_id']==request_id
    assert not w.poll()  # No automatic resubmission after an uncertain send.
    assert 'PRIVATE-APPEAL-CONTENT' not in env.client.get('/api/audit').text


def test_spam_rbac_stale_buttons_and_no_arbitrary_recipient(env,new_client,seed_user,login):
    w,aid,report=seeded_report(env)
    body={'request_id':str(uuid.uuid4()),'report_token':'0'*64,'operation':'button','button_id':'101:0:0'}
    assert env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body).status_code==409
    body['report_token']=report['report_token'];body['button_id']='101:0:99'
    assert env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body).status_code==422
    body['recipient']='SomeoneElse'
    assert env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body).status_code==422
    seed_user('op',role=Role.OPERATOR);op=new_client();h=login(op,'op')
    assert op.get(f'/api/accounts/{aid}/spam').status_code==403
    assert op.post(f'/api/accounts/{aid}/spam/check',headers=h).status_code==403
    assert env.client.post(f'/api/accounts/{aid}/spam/read').status_code==403
    assert env.client.get('/api/accounts?spam_status=limited').json()['total']==1


def test_spam_report_key_rotation(env):
    from app.cli import rotate_keys,verify_keys
    w,aid,_=seeded_report(env)
    old=env.settings.session_encryption_key.get_secret_value();new=SecretBox.generate_key()
    both=SecretBox([new,old])
    assert asyncio.run(verify_keys(env.settings.database_url,both))['spam_reports_ok']==1
    assert asyncio.run(rotate_keys(env.settings.database_url,both))['spam_reports']==1
    assert asyncio.run(verify_keys(env.settings.database_url,SecretBox([new])))['spam_reports_ok']==1


@pytest.mark.parametrize('spam_state',['limited','error','frozen'])
def test_auto_import_checks_spam_without_losing_valid_session(e2e,spam_state):
    async def scenario():
        app=create_app(e2e);admin=Admin(app);await admin.login()
        net=FakeNetwork();w=await WorkerSide(app,admin,'spam-worker',net).create();calls=[]
        class Backend(FakeBackend):
            async def send_code(self,phone):raise AssertionError('No OTP for imported session')
            async def check_spam(self,handle,operation='check',**kw):
                calls.append(operation)
                return {'status':'error' if spam_state=='frozen' else spam_state,'message_id':101,'text':'Synthetic SpamBot reply','buttons':[],
                    'delivery':'sent' if spam_state=='limited' else 'not_sent','error_code':'account_frozen' if spam_state=='frozen' else 'network_error' if spam_state=='error' else None}
        w.manager._backend=AccountTelegramBackend(w.client,factory=lambda api_id,api_hash:Backend(net))
        try:
            raw,_=sqlite_session();body=payload(w.id,raw);body['auto_check_spam']=True
            r=await admin.post('/api/accounts/import-sessions',body);assert r.status_code==202,r.text
            item=r.json()['items'][0];cmd=await admin.finished(item['account_id'],item['command_id'])
            assert cmd['status']=='done',cmd
            a=await admin.account(item['account_id'])
            assert a['auth_state']=='authorized'
            assert a['health_status']==('frozen' if spam_state=='frozen' else 'live')
            assert a['spam_status']==('error' if spam_state=='frozen' else spam_state)
            assert calls==['check']
        finally:await w.close();await w.client.aclose();await admin.http.aclose();await app.state.engine.dispose()
    asyncio.run(scenario())


def test_real_callback_button_is_supported_but_not_clicked_implicitly():
    from telethon.tl.types import KeyboardInlineButton,InlineButtonTypeCallback
    async def scenario():
        c=BotClient();c.message=bot_message(buttons=[KeyboardInlineButton('Appeal',InlineButtonTypeCallback(b'appeal'))])
        async def click(*,i,j):
            assert (i,j)==(0,0);c.clicked.append((i,j))
            c.message=bot_message('Please describe the issue')
            c.message.id=102
            for fn in c.handlers[:]:await fn(SimpleNamespace(message=c.message))
        c.message.click=click
        assert describe(c.message)['buttons']==[{'id':'101:0:0','text':'Appeal'}] and not c.clicked
        result=await interact(c,'button',button_id='101:0:0',expected_button_text='Appeal')
        assert c.clicked==[(0,0)] and result['delivery']=='sent' and result['message_id']==102
    asyncio.run(scenario())


def test_read_does_not_change_semantic_snapshot_token():
    from app.services.spam import token
    report={'message_id':1,'text':'Example','buttons':[],'delivery':'sent','status':'unknown'}
    assert token(report)==token({**report,'delivery':'read'})


def test_bulk_spam_check_uses_fresh_result_without_resetting_bot(env):
    from app.services.account_bulk import tick
    w,aid,_=seeded_report(env)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'spam_check','account_ids':[aid]})
    assert r.status_code==202,r.text
    async def run(db):await tick(db,env.settings,SecretBox([env.settings.session_encryption_key.get_secret_value()]))
    run_db(env.settings,run)
    j=env.client.get('/api/account-bulk/'+r.json()['id']).json()
    assert j['status']=='done' and j['counts']['done']==1 and not w.poll()


def test_expired_unsent_appeal_does_not_stay_queued(env):
    w,aid,report=seeded_report(env)
    body={'request_id':str(uuid.uuid4()),'report_token':report['report_token'],'operation':'reply','text':'Test appeal.'}
    r=env.client.post(f'/api/accounts/{aid}/spam/action',headers=env.h,json=body);assert r.status_code==202
    async def run(db):
        cmd=await db.get(WorkerCommand,uuid.UUID(body['request_id']));a=await db.get(TelegramAccount,uuid.UUID(aid))
        old=utcnow()-timedelta(minutes=20);cmd.created_at=old;a.spam_last_action_at=old
        cmd.expires_at=utcnow()-timedelta(seconds=1)
        await db.flush();await svc.expire_commands(db,utcnow())
    run_db(env.settings,run)
    report=env.client.get(f'/api/accounts/{aid}/spam').json()
    assert report['action_status']=='failed' and not report['pending_command_id']


def test_bulk_spam_bot_error_is_visible_as_item_error(env):
    from app.services.account_bulk import tick
    w=env.make_worker();aid=env.make_account(worker=w);env.authorize(w,aid)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'spam_check','account_ids':[aid]})
    async def run(db):await tick(db,env.settings,SecretBox([env.settings.session_encryption_key.get_secret_value()]))
    run_db(env.settings,run)
    (cmd,)=w.poll();assert cmd['type']=='spam_check'
    w.result(cmd['id'],result={'connection_state':'connected','spam_report':{'status':'error','error_code':'network_error','delivery':'not_sent'}})
    run_db(env.settings,run)
    job=env.client.get('/api/account-bulk/'+r.json()['id']+'?status=error').json()
    assert job['counts']['error']==1 and job['items'][0]['error_code']=='network_error'
    assert env.client.get('/api/accounts/'+aid).json()['auth_state']=='authorized'


@pytest.mark.parametrize('text,expected',[
    ('Your account is frozen. Telegram is in read-only mode.',True),
    ('Your Telegram account has been frozen.',True),
    ('Ваш аккаунт заморожен.',True),
    ('Your account may be frozen if you violate the rules.',False),
    ('If your account is frozen, contact support.',False),
    ('Your account is not frozen.',False),
])
def test_frozen_notice_requires_explicit_statement(text,expected):
    from worker.spambot import frozen_notice
    assert frozen_notice(text)==expected
    report=describe(bot_message(text))
    assert (report.get('error_code')=='account_frozen')==expected
    if expected:assert report['status']=='error'


def test_spambot_frozen_error_overrides_successful_get_me(env):
    from app.services.account_bulk import tick
    w=env.make_worker();aid=env.make_account(worker=w);env.authorize(w,aid)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'spam_check','account_ids':[aid]})
    async def run(db):await tick(db,env.settings,SecretBox([env.settings.session_encryption_key.get_secret_value()]))
    run_db(env.settings,run)
    (cmd,)=w.poll()
    w.result(cmd['id'],result={'connection_state':'connected','spam_report':{'status':'error','error_code':'account_frozen','delivery':'not_sent'}})
    run_db(env.settings,run)
    a=env.client.get('/api/accounts/'+aid).json()
    assert a['health_status']=='frozen' and a['health_error']=='account_frozen'
    assert a['desired_state']=='stopped' and a['spam_error']=='account_frozen'
    summary=env.client.get('/api/accounts/summary').json()
    assert summary['health']['frozen']==1 and summary['spam']['error']==1
    job=env.client.get('/api/account-bulk/'+r.json()['id']).json()
    assert job['counts']['error']==1 and job['items'][0]['error_code']=='account_frozen'


def test_multimessage_frozen_notice_survives_followup_instructions():
    async def scenario():
        client=BotClient()
        async def send(peer,text):
            for mid,body in [(101,'Your account is frozen.'),(102,'Please contact support for more information.')]:
                message=bot_message(body);message.id=mid
                for fn in client.handlers[:]:await fn(SimpleNamespace(message=message))
        client.send_message=send
        report=await interact(client,'check')
        assert report['error_code']=='account_frozen' and report['status']=='error'
        assert report['message_id']==102
    asyncio.run(scenario())


@pytest.mark.parametrize('text,status',[
    ('Your account was blocked for violations of the Telegram Terms of Service based on user reports confirmed by our moderators.','blocked'),
    ('If your account was blocked for violations of the Telegram Terms of Service, contact support.','unknown'),
    ('Your account may be blocked for violations of the Telegram Terms of Service.','unknown'),
    ('Your account is not blocked.','unknown'),
])
def test_blocked_account_notice_classification(text,status):
    assert classify(text)==status
