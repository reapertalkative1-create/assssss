"""Named configurations and explicit, immutable snapshots for each new post."""
import uuid
from typing import Literal
from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import case, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import ForwardRoute, Role, TelegramAccount, WorkCluster
from app.routers.post_routes import PostBatchInput, batch_routes, save_batch
from app.routers.routes import _out
from app.services.post_links import parse_post_link, parse_targets

router = APIRouter(prefix='/api/work-clusters', tags=['work-clusters'])
admin = require_role(Role.ADMIN)


class ClusterInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=64)
    account_ids: list[uuid.UUID] = Field(min_length=1, max_length=1000)
    targets_text: str = Field(min_length=1, max_length=500000)
    delay_seconds: int = Field(default=150, ge=5, le=86400)
    delay_max_seconds: int | None = Field(default=None, ge=5, le=86400)
    post_link: str | None = Field(default=None, max_length=500)

    @model_validator(mode='after')
    def valid_interval(self):
        if self.delay_max_seconds is None:
            self.delay_max_seconds = self.delay_seconds if 'delay_seconds' in self.model_fields_set else 180
        if self.delay_max_seconds < self.delay_seconds:
            raise ValueError('Mốc nghỉ đến phải lớn hơn hoặc bằng mốc từ.')
        return self
    mode: Literal['forward', 'copy'] = 'forward'

    @field_validator('name')
    @classmethod
    def clean_name(cls, value):
        value = ' '.join(value.split())
        if not value or len(value.casefold()) > 64:
            raise ValueError('Nhập tên cụm từ 1 đến 64 ký tự.')
        return value


class ClusterCreate(ClusterInput):
    request_id: uuid.UUID


class ClusterUpdate(ClusterInput):
    revision: int = Field(ge=1)


class ClusterRun(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: uuid.UUID
    revision: int = Field(ge=1)
    post_link: str | None = Field(default=None, max_length=500)


class RoutesPreview(BaseModel):
    model_config = ConfigDict(extra='forbid')
    route_ids: list[uuid.UUID] = Field(min_length=1, max_length=10000)


@router.post('/from-routes/preview')
async def preview_routes(body: RoutesPreview, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    import hashlib
    ids = set(body.route_ids)
    rows = list((await db.execute(select(ForwardRoute).where(ForwardRoute.id.in_(ids)).order_by(ForwardRoute.id))).scalars())
    if len(rows) != len(ids):
        raise ApiError(409, 'routes_changed', 'Có dòng đã bị xóa. Chọn lại danh sách trước khi lưu thành cụm.')
    if any(not row.link_config for row in rows):
        raise ApiError(422, 'post_routes_only', 'Chỉ chọn các lượt gửi bài từ liên kết để tạo cụm. Bỏ chọn tuyến theo dõi nguồn.')
    account_ids = list(dict.fromkeys(str(row.account_id) for row in rows))
    if len(account_ids) > 1000:
        raise ApiError(422, 'too_many_senders', 'Một cụm tối đa 1.000 SS. Chọn ít SS hơn để tạo cụm.')
    refs = []
    seen = set()
    for row in rows:
        for ref in row.link_config.get('targets', []):
            if ref not in seen:
                seen.add(ref); refs.append(ref)
                if len(refs) > 1000:
                    raise ApiError(422, 'too_many_targets', 'Một cụm tối đa 1.000 nhóm nhận. Thu hẹp lựa chọn trước khi tạo cụm.')
    targets = parse_targets('\n'.join(refs))
    accounts = dict((await db.execute(select(TelegramAccount.id, TelegramAccount.name).where(
        TelegramAccount.id.in_([uuid.UUID(a) for a in account_ids]), TelegramAccount.pending_deletion.is_(False)))).all())
    if len(accounts) != len(account_ids):
        raise ApiError(409, 'senders_changed', 'Có SS đã/đang bị xóa. Bỏ chọn dòng của SS đó trước khi tạo cụm.')
    modes = {row.mode for row in rows}
    delays = {row.link_config.get('delay_seconds', 60) for row in rows}
    key = hashlib.sha256('|'.join(f'{r.id}:{r.updated_at.isoformat()}' for r in rows).encode()).hexdigest()[:24]
    return {'seed_key': key, 'name': '', 'senders': [{'id': aid, 'name': accounts[uuid.UUID(aid)]} for aid in account_ids],
            'targets': targets, 'mode': next(iter(modes)) if len(modes) == 1 else 'forward',
            'delay_seconds': max(delays), 'mixed_settings': len(modes) > 1 or len(delays) > 1}


async def require_cluster(db, cid, *, lock=False):
    stmt = select(WorkCluster).where(WorkCluster.id == cid)
    if lock: stmt = stmt.with_for_update()
    obj = (await db.execute(stmt)).scalar_one_or_none()
    if obj is None:
        raise ApiError(404, 'not_found', 'Không tìm thấy cụm làm việc.')
    return obj


def summary(obj):
    return {'id': str(obj.id), 'name': obj.name, 'account_count': len(obj.account_ids),
            'target_count': len(obj.targets), 'mode': obj.mode, 'delay_seconds': obj.delay_seconds,
            'delay_max_seconds': obj.delay_max_seconds, 'post_link': obj.post_link,
            'revision': obj.revision, 'created_at': obj.created_at, 'updated_at': obj.updated_at}


async def detail(db, obj):
    rows = (await db.execute(select(TelegramAccount.id, TelegramAccount.name).where(
        TelegramAccount.id.in_([uuid.UUID(v) for v in obj.account_ids]),
        TelegramAccount.pending_deletion.is_(False)))).all()
    names = {str(aid): name for aid, name in rows}
    missing = [aid for aid in obj.account_ids if aid not in names]
    return {**summary(obj), 'account_ids': obj.account_ids, 'targets': obj.targets,
            'senders': [{'id': aid, 'name': names.get(aid, 'SS đã xóa · ' + aid[:8])} for aid in obj.account_ids],
            'missing_account_ids': missing}


async def values(db, body):
    targets = parse_targets(body.targets_text)
    ids = list(dict.fromkeys(body.account_ids))
    count = (await db.execute(select(func.count()).select_from(TelegramAccount).where(
        TelegramAccount.id.in_(ids), TelegramAccount.pending_deletion.is_(False)))).scalar_one()
    if count != len(ids):
        raise ApiError(409, 'senders_changed', 'Có SS đã bị xóa hoặc đang xóa. Bỏ SS đó khỏi cụm rồi lưu lại.')
    data = {'name': body.name, 'name_key': body.name.casefold(), 'account_ids': [str(v) for v in ids],
            'targets': targets, 'mode': body.mode, 'delay_seconds': body.delay_seconds,
            'delay_max_seconds': body.delay_max_seconds}
    if 'post_link' in body.model_fields_set:
        try: data['post_link'] = parse_post_link(body.post_link)['url'] if body.post_link and body.post_link.strip() else None
        except ValueError as exc: raise ApiError(422, 'invalid_post_link', str(exc)) from None
    return data


async def flush(db):
    try: await db.flush()
    except IntegrityError:
        raise ApiError(409, 'name_taken', 'Tên cụm đã tồn tại hoặc yêu cầu đang được lưu. Đổi tên hoặc thử lại.') from None


@router.get('')
async def listing(q: str = Query('', max_length=64), page: int = Query(1, ge=1), page_size: int = Query(12, ge=1, le=50),
                  auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    stmt = select(WorkCluster)
    if q.strip(): stmt = stmt.where(WorkCluster.name_key.contains(q.strip().casefold(), autoescape=True))
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(WorkCluster.updated_at.desc(), WorkCluster.id)
                            .offset((page-1)*page_size).limit(page_size))).scalars()
    return {'items': [summary(row) for row in rows], 'total': total, 'page': page, 'page_size': page_size}


@router.get('/{cid}')
async def get(cid: uuid.UUID, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    return await detail(db, await require_cluster(db, cid))


@router.post('', status_code=201)
async def create(body: ClusterCreate, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    data = await values(db, body)
    existing = await db.get(WorkCluster, body.request_id)
    if existing:
        if existing.created_by != auth.user.id or any(getattr(existing, k) != v for k, v in data.items()):
            raise ApiError(409, 'request_conflict', 'Yêu cầu này đã lưu với nội dung khác. Mở lại biểu mẫu để tiếp tục.')
        return await detail(db, existing)
    obj = WorkCluster(id=body.request_id, created_by=auth.user.id, **data)
    db.add(obj)
    await flush(db)
    await record_audit(db, request, 'work_cluster.create', actor=auth.user, target_type='work_cluster', target_id=str(obj.id),
                       details={'accounts': len(obj.account_ids), 'targets': len(obj.targets)})
    return await detail(db, obj)


@router.patch('/{cid}')
async def update(cid: uuid.UUID, body: ClusterUpdate, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    if obj.revision != body.revision:
        raise ApiError(409, 'cluster_changed', 'Cụm đã được sửa ở cửa sổ khác. Đóng và mở lại để lấy cấu hình mới.')
    for key, value in (await values(db, body)).items(): setattr(obj, key, value)
    obj.revision += 1
    await flush(db)
    await record_audit(db, request, 'work_cluster.update', actor=auth.user, target_type='work_cluster', target_id=str(cid), details={'revision': obj.revision})
    return await detail(db, obj)


@router.delete('/{cid}')
async def remove(cid: uuid.UUID, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    await db.delete(obj)
    await record_audit(db, request, 'work_cluster.delete', actor=auth.user, target_type='work_cluster', target_id=str(cid))
    return {'deleted': True}


@router.post('/{cid}/runs', status_code=201)
async def new_run(cid: uuid.UUID, body: ClusterRun, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    try: post = parse_post_link(body.post_link) if body.post_link is not None else None
    except ValueError as exc: raise ApiError(422, 'invalid_post_link', str(exc)) from None
    # Recover a lost successful response even if the cluster was edited/deleted meanwhile.
    existing = await batch_routes(db, body.request_id)
    if existing:
        if any(r.created_by != auth.user.id or r.link_config.get('work_cluster_id') != str(cid)
               or r.link_config.get('work_cluster_revision') != body.revision
               or (post is not None and r.link_config.get('post_link') != post['url']) for r in existing):
            raise ApiError(409, 'request_conflict', 'Yêu cầu đã được dùng cho bài khác. Mở Bài mới để tạo lượt khác.')
        return {'batch_id': str(body.request_id), 'items': await _out(db, existing), 'unused_senders': existing[0].link_config.get('unused_senders', 0)}
    obj = await require_cluster(db, cid, lock=True)
    if obj.revision != body.revision:
        raise ApiError(409, 'cluster_changed', 'Cụm đã thay đổi. Đóng và mở Bài mới để xem cấu hình mới trước khi tạo lượt.')
    if post is None:
        if not obj.post_link: raise ApiError(422, 'post_link_required', 'Sửa cụm và lưu liên kết bài viết trước khi chạy.')
        post = parse_post_link(obj.post_link)
    batch = PostBatchInput(request_id=body.request_id, account_ids=obj.account_ids, post_link=post['url'],
                           targets_text='\n'.join(obj.targets), delay_seconds=obj.delay_seconds, mode=obj.mode)
    result = await save_batch(batch, request, auth, db, cluster_context={
        'work_cluster_id': str(cid), 'work_cluster_name': obj.name, 'work_cluster_revision': obj.revision,
        'work_cluster_target_count': len(obj.targets), 'delay_max_seconds': obj.delay_max_seconds,
        'managed_targets_only': True})
    await record_audit(db, request, 'work_cluster.run_created', actor=auth.user, target_type='work_cluster', target_id=str(cid),
                       details={'batch_id': str(body.request_id), 'revision': obj.revision})
    return result


@router.get('/{cid}/runs')
async def history(cid: uuid.UUID, page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50),
                  auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    await require_cluster(db, cid)
    config = ForwardRoute.link_config
    batch_id = config['batch_id'].as_string()
    stmt = select(batch_id.label('batch_id'), func.min(ForwardRoute.created_at).label('created_at'),
                  func.max(config['post_link'].as_string()).label('post_link'),
                  func.count().label('account_count'),
                  func.max(config['work_cluster_target_count'].as_integer()).label('target_count'),
                  func.sum(case((ForwardRoute.status == 'active', 1), else_=0)).label('active_count'),
                  func.sum(case((ForwardRoute.status == 'paused', 1), else_=0)).label('paused_count'),
                  func.sum(case((config['queued_at'].as_string().is_not(None), 1), else_=0)).label('started_count'))
    stmt = stmt.where(config['work_cluster_id'].as_string() == str(cid)).group_by(batch_id)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(func.min(ForwardRoute.created_at).desc(), batch_id)
                            .offset((page-1)*page_size).limit(page_size))).mappings().all()
    return {'items': [dict(row) for row in rows], 'total': total, 'page': page, 'page_size': page_size}
