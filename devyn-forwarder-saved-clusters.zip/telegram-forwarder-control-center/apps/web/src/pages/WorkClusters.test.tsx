import {render,screen,waitFor,within} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter} from 'react-router-dom';
import {beforeEach,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn(),patch:vi.fn()},request:vi.fn()};});
vi.mock('../state/toast',()=>({useToast:()=>({success:vi.fn(),error:vi.fn()})}));
import {api,ApiError} from '../api/client';
import type {WorkCluster} from '../api/types';
import {PostRouteForm} from './PostRoute';
import {ClusterRunForm,WorkClusters} from './WorkClusters';

const cluster:WorkCluster={id:'cluster-1',name:'Khách hàng',post_link:'https://t.me/source_group/456',delay_max_seconds:120,account_count:1,target_count:2,mode:'copy',delay_seconds:90,revision:3,created_at:'2026-11-14T10:00:00Z',updated_at:'2026-11-14T10:00:00Z',account_ids:['a1'],senders:[{id:'a1',name:'SS Một'}],targets:['@group_one','@group_two'],missing_account_ids:[]};
const accounts={items:[{id:'a1',name:'SS Một',auth_state:'authorized',desired_state:'stopped',health_status:'live',spam_status:'clear',pending_deletion:false}],total:1};
const wrap=(node:React.ReactNode)=>render(<MemoryRouter>{node}</MemoryRouter>);
beforeEach(()=>{localStorage.clear();vi.clearAllMocks();vi.mocked(api.get).mockImplementation(async path=>path==='/api/post-routes/senders'?accounts:path==='/api/work-clusters'?{items:[cluster],total:1}:path==='/api/account-groups'?[]:cluster);});

it('preserves the cluster name and configuration on close, then saves without needing a post link',async()=>{
 const user=userEvent.setup(),saved=vi.fn();
 let view=wrap(<PostRouteForm clusterMode draftOwner="cluster-owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={saved}/>);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('');
 expect(screen.getByLabelText('Từ')).toHaveValue(150);expect(screen.getByLabelText('Đến')).toHaveValue(180);
 await user.type(screen.getByLabelText('Tên cụm làm việc'),'Khách hàng hôm nay');
 await user.click(await screen.findByLabelText('Chọn SS SS Một'));
 await user.type(screen.getByLabelText('Nhóm nhận bài'),'@group_one\n@group_two');
 view.unmount();
 view=wrap(<PostRouteForm clusterMode draftOwner="cluster-owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={saved}/>);
 expect(screen.getByLabelText('Tên cụm làm việc')).toHaveValue('Khách hàng hôm nay');
 expect(screen.getByLabelText('Nhóm nhận bài')).toHaveValue('@group_one\n@group_two');
 expect(await screen.findByLabelText('Chọn SS SS Một')).toBeChecked();
 vi.mocked(api.post).mockResolvedValue(cluster);
 await user.click(screen.getByRole('button',{name:/^Tạo cụm$/}));
 expect(api.post).toHaveBeenCalledWith('/api/work-clusters',{request_id:expect.any(String),name:'Khách hàng hôm nay',account_ids:['a1'],targets_text:'@group_one\n@group_two',delay_seconds:150,delay_max_seconds:180,post_link:'',mode:'forward'});
 expect(saved).toHaveBeenCalledWith(cluster);view.unmount();
 expect(Object.keys(localStorage).filter(k=>k.includes('cluster-owner'))).toEqual([]);
});

it('reuses the saved cluster and retries a failed new-post request with the same ID',async()=>{
 const user=userEvent.setup(),created=vi.fn();
 let view=wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={created}/>);
 expect(screen.getByText('1 SS · 2 nhóm nhận')).toBeVisible();
 expect(screen.queryByLabelText('Nhóm nhận bài')).not.toBeInTheDocument();
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('https://t.me/source_group/456');
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveAttribute('readonly');
 vi.mocked(api.post).mockRejectedValue(new ApiError(0,'network','Mất kết nối'));
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 expect(await screen.findByText('Mất kết nối')).toBeVisible();
 const first=vi.mocked(api.post).mock.calls[0];view.unmount();
 view=wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={created}/>);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('https://t.me/source_group/456');
 vi.mocked(api.post).mockResolvedValue({batch_id:'batch-new'});
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 expect(vi.mocked(api.post).mock.calls[1]).toEqual(first);
 expect(first).toEqual(['/api/work-clusters/cluster-1/runs',{request_id:expect.any(String),revision:3}]);
 await user.click(await screen.findByRole('button',{name:'Mở lượt & tiến độ'}));
 expect(created).toHaveBeenCalledWith('batch-new');view.unmount();
 expect(Object.keys(localStorage).filter(k=>k.includes('cluster-run'))).toEqual([]);
});

it('blocks creating a new run with deleted accounts and edits require the current revision',async()=>{
 const user=userEvent.setup(),c={...cluster,missing_account_ids:['a1']};
 const view=wrap(<ClusterRunForm cluster={c} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 expect(screen.getByRole('button',{name:'Chạy'})).toBeDisabled();expect(screen.getByText(/Sửa cấu hình cụm trước/)).toBeVisible();view.unmount();
 wrap(<PostRouteForm clusterMode cluster={cluster} draftOwner="owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={()=>{}}/>);
 await user.clear(screen.getByLabelText('Tên cụm làm việc'));await user.type(screen.getByLabelText('Tên cụm làm việc'),'Cụm đổi tên');
 vi.mocked(api.patch).mockResolvedValue({...cluster,name:'Cụm đổi tên',revision:4});
 await user.click(screen.getByRole('button',{name:'Lưu cụm'}));
 expect(api.patch).toHaveBeenCalledWith('/api/work-clusters/cluster-1',{name:'Cụm đổi tên',account_ids:['a1'],targets_text:'@group_one\n@group_two',delay_seconds:90,delay_max_seconds:120,post_link:'https://t.me/source_group/456',mode:'copy',revision:3});
});

it('opens the correct historical run and keeps each post separate',async()=>{
 const user=userEvent.setup(),open=vi.fn();
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'?{items:[cluster],total:1}:path.endsWith('/runs')?{items:[{batch_id:'yesterday',post_link:'https://t.me/source_group/123',created_at:'2026-11-13T10:00:00Z',account_count:1,target_count:2,active_count:0,paused_count:0,started_count:1},{batch_id:'today',post_link:'https://t.me/source_group/124',created_at:'2026-11-14T10:00:00Z',account_count:1,target_count:2,active_count:0,paused_count:0,started_count:0}],total:2}:cluster);
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={open}/>);
 await user.click(await screen.findByRole('button',{name:'Lịch sử'}));
 const post=await screen.findByRole('link',{name:'https://t.me/source_group/123'});
 await user.click(within(post.closest('.cluster-history-row') as HTMLElement).getByRole('button',{name:'Mở lượt'}));
 expect(open).toHaveBeenCalledWith('yesterday');expect(api.post).not.toHaveBeenCalled();
});

it('hides configuration and new-post actions from operators',async()=>{
 wrap(<WorkClusters owner="operator" isAdmin={false} onOpenBatch={()=>{}}/>);
 await waitFor(()=>expect(screen.getByRole('heading',{name:'Khách hàng'})).toBeVisible());
 expect(screen.queryByRole('button',{name:/Tạo cụm|^Chạy$/})).not.toBeInTheDocument();
 expect(screen.queryByLabelText('Thao tác cụm Khách hàng')).not.toBeInTheDocument();
 expect(screen.getByRole('button',{name:'Lịch sử'})).toBeVisible();
});

it('checks management permissions before starting a saved run and only starts once',async()=>{
 const user=userEvent.setup();let reads=0;
 const row={id:'r1',account_id:'a1',account_name:'SS Một',name:'Run',status:'stopped',verified:false,stats:{},link_config:{post_link:cluster.post_link,targets:['@group_one'],delay_seconds:150}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?{...row,verified:++reads>1}:path.includes('/commands/')?{status:'done'}:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'saved-run',items:[row]}:path.endsWith('/verify')?{command_id:'verify-1'}:{});
 wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 await user.dblClick(screen.getByRole('button',{name:'Chạy'}));
 await screen.findByRole('button',{name:'Mở lượt & tiến độ'});
 const calls=vi.mocked(api.post).mock.calls.map(c=>c[0]);
 expect(calls).toEqual(['/api/work-clusters/cluster-1/runs','/api/routes/r1/verify','/api/routes/r1/start']);
 expect(vi.mocked(api.post).mock.calls[0][1]).toEqual({revision:3,request_id:expect.any(String)});
});

it('does not start an unverified destination and keeps its saved configuration',async()=>{
 const user=userEvent.setup();
 const row={id:'r1',account_id:'a1',account_name:'SS Một',name:'Run',status:'stopped',verified:false,stats:{},link_config:{post_link:cluster.post_link,targets:['@group_one'],delay_seconds:150}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?row:path.includes('/commands/')?{status:'done'}:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'saved-run',items:[row]}:{command_id:'verify-1'});
 wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 await screen.findByRole('button',{name:'Mở lượt & tiến độ'});
 expect(vi.mocked(api.post).mock.calls.some(c=>c[0].endsWith('/start'))).toBe(false);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue(cluster.post_link);
});

it('rejects a reversed interval without saving and keeps both ends editable',async()=>{
 const user=userEvent.setup();
 wrap(<PostRouteForm clusterMode cluster={cluster} draftOwner="owner" onClose={()=>{}} onSaved={()=>{}}/>);
 await user.clear(screen.getByLabelText('Đến'));await user.type(screen.getByLabelText('Đến'),'80');
 await user.click(screen.getByRole('button',{name:'Lưu cụm'}));
 expect(await screen.findByText(/Mốc nghỉ đến phải/)).toBeVisible();
 expect(api.patch).not.toHaveBeenCalled();
});

it('starts the saved post from the cluster card without entering a link',async()=>{
 const user=userEvent.setup();
 vi.mocked(api.post).mockResolvedValue({batch_id:'run-from-card',items:[]});
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(await screen.findByRole('button',{name:'Chạy'}));
 await screen.findByRole('button',{name:'Mở lượt & tiến độ'});
 expect(api.post).toHaveBeenCalledWith('/api/work-clusters/cluster-1/runs',{revision:3,request_id:expect.any(String)});
});
