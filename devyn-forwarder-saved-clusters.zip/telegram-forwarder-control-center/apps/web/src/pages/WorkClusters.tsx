import {useEffect,useRef,useState} from 'react';
import {api,ApiError,request} from '../api/client';
import type {Page,WorkCluster,WorkClusterSummary,WorkClusterRun,Route,CommandAccepted} from '../api/types';
import {Modal} from '../components/Modal';
import {ConfirmDialog} from '../components/ConfirmDialog';
import {Pagination} from '../components/DataTable';
import {Alert,EmptyState,Pill,TextField} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import {postDraftKey,usePostDraft} from '../hooks/usePostDraft';
import {fmtDateTime} from '../lib/format';
import {useToast} from '../state/toast';
import {PostRouteForm,deliveryLabel} from './PostRoute';
import {waitForCommand} from './Accounts';
import {skipRoute} from './RouteBulkActions';

type Dialog={kind:'new'}|{kind:'edit'|'run'|'history'|'delete';cluster:WorkClusterSummary};

export function WorkClusters({owner,isAdmin,onOpenBatch}:{owner:string;isAdmin:boolean;onOpenBatch:(id:string)=>void}){
 const toast=useToast();
 const [q,setQ]=useState(''),[page,setPage]=useState(1),[dialog,setDialog]=useState<Dialog|null>(null);
 const search=useDebounced(q);
 const list=useQuery(signal=>api.get<Page<WorkClusterSummary>>('/api/work-clusters',{q:search,page,page_size:12},signal),[search,page]);
 function saved(c:WorkCluster){setDialog(null);list.reload();toast.success(`Đã lưu cụm “${c.name}”. Bấm Chạy để dùng bài viết đã lưu.`);}
 function openBatch(id:string){setDialog(null);onOpenBatch(id);}
 return <section className="work-clusters stack tight" aria-label="Cụm làm việc">
  <div className="cluster-toolbar"><div><h2>Cụm của bạn <span>{list.data?.total??0}</span></h2><p>Bài viết và cấu hình được lưu theo cụm.</p></div>{isAdmin&&<button className="btn primary" onClick={()=>setDialog({kind:'new'})}>+ Tạo cụm làm việc</button>}</div>
  <div className="cluster-search"><input className="input" aria-label="Tìm cụm làm việc" placeholder="Tìm tên cụm…" maxLength={64} value={q} onChange={e=>{setQ(e.target.value);setPage(1);}}/><button className="btn sm" onClick={list.reload} disabled={list.refreshing}>Làm mới</button></div>
  {list.error&&<Alert tone="bad">{list.error.message}</Alert>}
  {list.loading&&<p className="hint" role="status">Đang tải cụm làm việc…</p>}
  {list.data&&!list.data.items.length&&<EmptyState title={search?'Không tìm thấy cụm':'Tạo cụm cho công việc hằng ngày'}>{search?'Thử tìm bằng tên khác.':'Đặt tên, chọn SS và lưu nhóm nhận một lần. Mỗi bài mới có tiến độ riêng.'}</EmptyState>}
  <div className="cluster-grid">{list.data?.items.map(c=><article className="cluster-card" key={c.id}>
   <div className="cluster-card-head"><span className="cluster-icon" aria-hidden="true">▦</span><div><h3 title={c.name}>{c.name}</h3><span className="hint">Cập nhật {fmtDateTime(c.updated_at)}</span></div>{isAdmin&&<details className="session-actions"><summary className="btn ghost sm" aria-label={`Thao tác cụm ${c.name}`}>•••</summary><div className="route-menu"><button className="btn sm" onClick={()=>setDialog({kind:'edit',cluster:c})}>Sửa cụm</button><button className="btn sm danger" onClick={()=>setDialog({kind:'delete',cluster:c})}>Xóa cụm</button></div></details>}</div>
   <div className="cluster-facts"><span><b>{c.account_count}</b> SS</span><span><b>{c.target_count}</b> nhóm nhận</span><span>{c.delay_seconds}{c.delay_max_seconds&&c.delay_max_seconds!==c.delay_seconds?`–${c.delay_max_seconds}`:''}s / nhóm</span></div>
   {c.post_link?<a className="cluster-saved-link" href={c.post_link} title={c.post_link} target="_blank" rel="noreferrer">{c.post_link}</a>:<p className="hint">Chưa lưu liên kết bài viết.</p>}
   <div className="cluster-card-foot"><span className="hint">{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'}</span><div className="row"><button className="btn sm" onClick={()=>setDialog({kind:'history',cluster:c})}>Lịch sử</button>{isAdmin&&<button className="btn sm" onClick={()=>setDialog({kind:'edit',cluster:c})}>Sửa</button>}{isAdmin&&<button className="btn sm primary" disabled={!c.post_link} onClick={()=>setDialog({kind:'run',cluster:c})}>Chạy</button>}</div></div>
  </article>)}</div>
  {list.data&&list.data.total>12&&<Pagination page={page} pageSize={12} total={list.data.total} onPage={setPage}/>}
  {dialog?.kind==='new'&&<PostRouteForm clusterMode draftOwner={owner} onClose={()=>setDialog(null)} onSaved={()=>{}} onClusterSaved={saved}/>}
  {dialog&&(dialog.kind==='edit'||dialog.kind==='run')&&<ClusterDialog key={`${dialog.kind}:${dialog.cluster.id}`} id={dialog.cluster.id} kind={dialog.kind} owner={owner} onClose={()=>setDialog(null)} onSaved={saved} onOpenBatch={openBatch}/>}
  {dialog?.kind==='history'&&<ClusterHistory key={dialog.cluster.id} cluster={dialog.cluster} onClose={()=>setDialog(null)} onOpenBatch={openBatch} onNew={isAdmin?()=>setDialog({kind:'run',cluster:dialog.cluster}):undefined}/>}
  {dialog?.kind==='delete'&&<ConfirmDialog title={`Xóa cụm “${dialog.cluster.name}”?`} confirmLabel="Xóa cụm" danger onClose={()=>setDialog(null)} onConfirm={async()=>{await request('DELETE',`/api/work-clusters/${dialog.cluster.id}`);list.reload();toast.success('Đã xóa cấu hình cụm.');}}><p>Các SS và lượt gửi đã tạo vẫn được giữ trong lịch sử của cụm. Lượt đang chạy tiếp tục theo cấu hình cũ.</p></ConfirmDialog>}
 </section>;
}

function ClusterDialog({id,kind,owner,onClose,onSaved,onOpenBatch}:{id:string;kind:'edit'|'run';owner:string;onClose:()=>void;onSaved:(c:WorkCluster)=>void;onOpenBatch:(id:string)=>void}){
 const detail=useQuery(signal=>api.get<WorkCluster>(`/api/work-clusters/${id}`,undefined,signal),[id]);
 if(!detail.data)return <Modal title={kind==='edit'?'Sửa cụm làm việc':'Chạy cụm'} onClose={onClose}><p className="hint">{detail.error?detail.error.message:'Đang lấy cấu hình cụm…'}</p>{detail.error&&<button className="btn" onClick={detail.reload}>Thử lại</button>}</Modal>;
 return kind==='edit'?<PostRouteForm key={`${id}:${detail.data.revision}`} clusterMode cluster={detail.data} draftOwner={owner} onClose={onClose} onSaved={()=>{}} onClusterSaved={onSaved}/>:<ClusterRunForm autoRun key={`${id}:${detail.data.revision}`} cluster={detail.data} owner={owner} onClose={onClose} onCreated={onOpenBatch}/>;
}

export function ClusterRunForm({cluster:c,owner,onClose,onCreated,autoRun=false}:{autoRun?:boolean;cluster:WorkCluster;owner:string;onClose:()=>void;onCreated:(id:string)=>void}){
 const cache=usePostDraft(postDraftKey(owner,`cluster-run:${c.id}:${c.revision}`),{link:c.post_link??'',targets:'',senders:[],delay:String(c.delay_seconds),mode:c.mode,requestId:crypto.randomUUID()});
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[progress,setProgress]=useState(''),[batch,setBatch]=useState(''),[results,setResults]=useState<string[]>([]);
 const cancelled=useRef(false),running=useRef(false),mounted=useRef(true),abort=useRef<AbortController>();
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;cancelled.current=true;abort.current?.abort();};},[]);
 useEffect(()=>{if(!autoRun)return;const timer=setTimeout(()=>void create(),0);return()=>clearTimeout(timer);},[autoRun]);
 async function create(){
  if(running.current||!c.post_link||c.missing_account_ids.length)return;
  running.current=true;cancelled.current=false;setBusy(true);setError('');setResults([]);cache.saveNow();abort.current=new AbortController();
  try{
   const r=await api.post<{batch_id:string;items:Route[]}>(`/api/work-clusters/${c.id}/runs`,{request_id:cache.draft.requestId,revision:c.revision});
   if(!mounted.current)return;
   setBatch(r.batch_id);const notes:string[]=[];
   for(const row of r.items??[]){
    if(cancelled.current)break;
    setProgress(`Kiểm tra & chạy ${notes.length+1}/${r.items.length} · ${row.account_name??row.name}`);
    try{
     let fresh=await api.get<Route>(`/api/routes/${row.id}`);
     if(cancelled.current)break;
     if(fresh.status==='active'||fresh.link_config?.queued_at){notes.push(`${row.account_name??row.name}: lượt đã có tiến độ, mở lượt để xem.`);setResults([...notes]);continue;}
     const cmd=await api.post<CommandAccepted>(`/api/routes/${row.id}/verify`);
     await waitForCommand(row.account_id,cmd.command_id,abort.current.signal,4);
     if(cancelled.current)break;
     fresh=await api.get<Route>(`/api/routes/${row.id}`);
     if(cancelled.current)break;
     const reason=skipRoute('start',fresh);
     if(reason){notes.push(`${row.account_name??row.name}: ${reason}`);}
     else{const started=await api.post<Route>(`/api/routes/${row.id}/start`);notes.push(`${row.account_name??row.name}: ${deliveryLabel(started)}.`);}
    }catch(e){if(cancelled.current)break;notes.push(`${row.account_name??row.name}: ${e instanceof ApiError?e.message:'Không chạy được; mở lượt để xem lỗi.'}`);}
    if(mounted.current)setResults([...notes]);
   }
   if(mounted.current){setProgress(cancelled.current?'Đã dừng thao tác. Những lượt đã bắt đầu tiếp tục chạy.':'Đã xử lý. Mở lượt để xem kết quả từng nhóm.');cache.complete();}
  }catch(e){if(mounted.current)setError(e instanceof ApiError?e.message:'Không tạo được lượt gửi.');}
  finally{running.current=false;if(mounted.current)setBusy(false);}
 }
 return <Modal title={`Chạy cụm · ${c.name}`} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{busy?<button className="btn" onClick={()=>{cancelled.current=true;abort.current?.abort();}}>Dừng thao tác</button>:batch?<button className="btn primary" onClick={()=>onCreated(batch)}>Mở lượt & tiến độ</button>:<button className="btn primary" disabled={!c.post_link||!!c.missing_account_ids.length} onClick={()=>void create()}>Chạy</button>}</>}>
  <div className="cluster-run-summary"><strong>{c.account_count} SS · {c.target_count} nhóm nhận</strong><span>{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'} · nghỉ {c.delay_seconds}–{c.delay_max_seconds??c.delay_seconds}s / nhóm</span></div>
  <TextField label="Liên kết bài viết Telegram" value={c.post_link??''} readOnly hint="Liên kết đã lưu theo cụm. Dùng Sửa cụm để đổi bài."/>
  <p className="hint">Chỉ chạy tới nhóm/kênh SS đang quản trị và có quyền đăng bài. Không tự tham gia. Bài đã gửi được bỏ qua; thời gian chờ Telegram luôn được giữ.</p>
  {progress&&<p role="status" className="hint">{progress}</p>}
  {!!results.length&&<div className="cluster-run-result">{results.map((text,i)=><p key={i}>{text}</p>)}</div>}
  {!!c.missing_account_ids.length&&<Alert tone="bad">{c.missing_account_ids.length} SS đã/đang bị xóa. Sửa cấu hình cụm trước khi chạy.</Alert>}
  {!c.post_link&&<Alert>Lưu liên kết bài viết trong Sửa cụm trước khi chạy.</Alert>}
  {error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}

function ClusterHistory({cluster:c,onClose,onOpenBatch,onNew}:{cluster:WorkClusterSummary;onClose:()=>void;onOpenBatch:(id:string)=>void;onNew?:()=>void}){
 const [page,setPage]=useState(1);
 const history=useQuery(signal=>api.get<Page<WorkClusterRun>>(`/api/work-clusters/${c.id}/runs`,{page,page_size:10},signal),[c.id,page],{interval:5000});
 return <Modal wide title={`Lịch sử · ${c.name}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Đóng</button>{onNew&&<button className="btn primary" onClick={onNew}>Chạy bài đã lưu</button>}</>}>
  <p className="hint">Mỗi lượt giữ bài viết, SS và nhóm nhận tại thời điểm tạo. Sửa cụm chỉ áp dụng cho lượt sau.</p>
  {history.error&&<Alert tone="bad">{history.error.message}</Alert>}{history.loading&&<p className="hint">Đang tải lịch sử…</p>}
  {history.data&&!history.data.total&&<EmptyState title="Chưa có lượt gửi">Lưu bài viết và bấm Chạy để dùng cấu hình của cụm.</EmptyState>}
  <div className="cluster-history">{history.data?.items.map(r=><div className="cluster-history-row" key={r.batch_id}><div><strong>{fmtDateTime(r.created_at)}</strong><a href={r.post_link} target="_blank" rel="noreferrer">{r.post_link}</a><span className="hint">{r.account_count} SS · {r.target_count} nhóm nhận</span></div><Pill tone={r.active_count?'ok':r.paused_count?'warn':'idle'}>{r.active_count?'Đang chạy':r.paused_count?'Tạm dừng':r.started_count?'Đã chạy':'Bản nháp'}</Pill><button className="btn sm" onClick={()=>onOpenBatch(r.batch_id)}>Mở lượt</button></div>)}</div>
  {history.data&&history.data.total>10&&<Pagination page={page} pageSize={10} total={history.data.total} onPage={setPage}/>}
 </Modal>;
}
