import asyncio
from worker.telegram_backend import BackendError

async def guarded_lease_operation(client,aid,epoch,ttl,operation):
    """Renew a temporary read lease; cancel all RPCs if renewal is lost."""
    async def keep():
        duration=ttl
        while True:
            await asyncio.sleep(max(.01,duration/4))
            try:duration=await asyncio.wait_for(client.renew_lease(aid,epoch),timeout=max(.01,duration/4))
            except Exception:raise BackendError('lease_expired') from None
    op=asyncio.create_task(operation());keeper=asyncio.create_task(keep())
    try:
        async with asyncio.timeout(1700):
            done,_=await asyncio.wait((op,keeper),return_when=asyncio.FIRST_COMPLETED)
            if keeper in done:await keeper
            return await op
    except TimeoutError:raise BackendError('verification_timeout') from None
    finally:
        op.cancel();keeper.cancel();await asyncio.gather(op,keeper,return_exceptions=True)
