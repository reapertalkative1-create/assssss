"""Per-account Telegram API credentials entered in the dashboard.

Each handle retains its own backend, so parallel account logins never share mutable API credentials.
Environment credentials remain a fallback for accounts created before the web configuration feature.
"""
from dataclasses import dataclass

from worker.client import NotFoundError
from worker.telegram_backend import BackendError, TelethonBackend


@dataclass(repr=False)
class AccountHandle:
    backend: object
    raw: object


class AccountTelegramBackend:
    def __init__(self, client, default_api_id=None, default_api_hash='', *, factory=TelethonBackend):
        self.client, self.default_api_id, self.default_api_hash, self.factory = client, default_api_id, default_api_hash, factory

    async def _for(self, account_id):
        try:
            config = await self.client.fetch_telegram_api(account_id)
        except NotFoundError as exc:
            if exc.code != 'telegram_api_not_configured':
                raise
            config = None
        if config:backend=self.factory(config.api_id, config.api_hash)
        elif self.default_api_id and self.default_api_hash:backend=self.factory(self.default_api_id,self.default_api_hash)
        else:raise BackendError('telegram_api_not_configured')
        fetch=getattr(self.client,'fetch_proxy',None)
        value=await fetch(account_id) if fetch else None
        proxy=(value or {}).get('proxy')
        if proxy:
            setter=getattr(backend,'set_proxy',None)
            if setter is None:raise BackendError('proxy_not_supported')
            setter(proxy)
        return backend

    async def send_code_for(self, account_id, phone):
        backend = await self._for(account_id)
        return AccountHandle(backend, await backend.send_code(phone))

    async def connect_for(self, account_id, session):
        backend = await self._for(account_id)
        raw, user = await backend.connect(session)
        return AccountHandle(backend, raw), user

    async def send_code(self, phone):
        raise BackendError('telegram_api_not_configured')

    async def connect(self, session):
        raise BackendError('telegram_api_not_configured')

    async def sign_in_code(self, handle, code):
        return await handle.backend.sign_in_code(handle.raw, code)

    async def sign_in_password(self, handle, password):
        return await handle.backend.sign_in_password(handle.raw, password)

    def session_string(self, handle):
        return handle.backend.session_string(handle.raw)

    async def prepare_appeal(self,handle,**kwargs):
        method=getattr(handle.backend,'prepare_appeal',None)
        if method is None:raise BackendError('appeal_worker_outdated')
        return await method(handle.raw,**kwargs)

    async def check_spam(self,handle,operation='check',**kwargs):
        check=getattr(handle.backend,'check_spam',None)
        if check is None:raise BackendError('spam_check_not_supported')
        return await check(handle.raw,operation,**kwargs)

    async def check_health(self,handle):
        check=getattr(handle.backend,'check_health',None)
        return await check(handle.raw) if check else None

    def is_connected(self, handle):
        return handle.backend.is_connected(handle.raw)

    async def disconnect(self, handle):
        await handle.backend.disconnect(handle.raw)

    async def log_out(self, handle):
        await handle.backend.log_out(handle.raw)

    async def prime(self, handle):
        await handle.backend.prime(handle.raw)

    async def resolve_chats(self, handle, chat_ids):
        return await handle.backend.resolve_chats(handle.raw, chat_ids)

    async def resolve_post_route(self,handle,post_link,targets):
        return await handle.backend.resolve_post_route(handle.raw,post_link,targets)

    async def latest_message_id(self, handle, chat_id):
        return await handle.backend.latest_message_id(handle.raw, chat_id)

    async def history_since(self, handle, chat_id, min_id, limit):
        return await handle.backend.history_since(handle.raw, chat_id, min_id, limit)

    def watch(self, handle, chat_ids, callback):
        return handle.backend.watch(handle.raw, chat_ids, callback)

    def unwatch(self, handle, token):
        handle.backend.unwatch(handle.raw, token)

    async def forward(self, handle, source, message_id, dest, mode):
        return await handle.backend.forward(handle.raw, source, message_id, dest, mode)
