from datetime import datetime, timezone
from types import SimpleNamespace
import uuid
import pytest

from app.models import Role, TelegramAccount
from app.services.restriction_duration import parse_duration, account_duration
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from worker.spambot import classify


@pytest.mark.parametrize('text,until', [
    ('Your account will be automatically released on 18 Nov 2026, 12:34 UTC.', '2026-11-18T12:34:00+00:00'),
    ('Unfortunately, your account is now limited until 18 November 2026, 12:34 UTC.', '2026-11-18T12:34:00+00:00'),
    ('Your account is blocked until 2026-11-18T19:34:00+07:00.', '2026-11-18T12:34:00+00:00'),
    ('Your account is limited until 18.11.2026 12:34 GMT.', '2026-11-18T12:34:00+00:00'),
    ('Tài khoản của bạn bị khóa đến 18/11/2026 19:34 UTC+7.', '2026-11-18T12:34:00+00:00'),
    ('The restrictions on your account will be lifted on 18 Nov 2026, 12:34 UTC.', '2026-11-18T12:34:00+00:00'),
    ('Your account will be automatically released in 2 days and 3 hours.', '2026-11-14T13:00:00+00:00'),
    ('Your account will be released in 24 hours.', '2026-11-13T10:00:00+00:00'),
    ("I'm afraid that, unfortunately, your account is now limited until 18 Nov 2026, 12:34 UTC.", '2026-11-18T12:34:00+00:00'),
    ('Your account will be released on 18 May 2027, 12:34 UTC.', '2027-05-18T12:34:00+00:00'),
])
def test_explicit_deadlines_and_relative_anchor(text, until):
    result = parse_duration(text, '2026-11-12T10:00:00Z')
    assert result['restriction_term'] == 'temporary'
    assert result['restriction_until'].isoformat() == until


@pytest.mark.parametrize('text', [
    'Your account has been permanently limited.',
    'Your account will remain limited forever.',
    'Your account is permanently blocked.',
    'Your Telegram account is permanently frozen.',
    'The restrictions on your account are permanent.',
    'Tài khoản của bạn bị khóa vĩnh viễn.',
    "I'm afraid your account will remain limited forever.",
])
def test_permanent_requires_explicit_statement(text):
    assert parse_duration(text) == {'restriction_term': 'permanent', 'restriction_until': None}


@pytest.mark.parametrize('text', [
    'Your account was blocked for violations of the Telegram Terms of Service based on user reports confirmed by our moderators.',
    'Your account may be permanently blocked.',
    'If your account is permanently limited, contact support.',
    'Your account is permanently blocked if you violate the rules.',
    'Your account is not permanently blocked.',
    'Your account is limited. Future violations may lead to permanent restrictions.',
    'Your account is frozen. Your account will be deleted on 18 Nov 2026, 12:34 UTC.',
    'Your account is frozen. You can submit an appeal until 18 Nov 2026, 12:34 UTC.',
    'Your account is limited until tomorrow.',
    'Your account is limited until 18 Nov 2026, 12:34.',
    'Your account is limited until 11/12/2026 12:34 UTC.',
    'Your account is limited until 31 Nov 2026, 12:34 UTC.',
    'Your account is permanently limited. Your account will be released on 18 Nov 2026, 12:34 UTC.',
    'Your account is limited until 18 Nov 2026, 12:34 UTC. Your account will be released on 19 Nov 2026, 12:34 UTC.',
])
def test_ambiguous_hypothetical_missing_or_conflicting_terms_stay_unknown(text):
    assert parse_duration(text)['restriction_term'] == 'unknown'


@pytest.mark.parametrize('reference', [None, '', 'bad', '2026-11-12T10:00:00', '9999-12-31T23:59:59Z'])
def test_relative_terms_never_restart_at_page_load_without_message_date(reference):
    assert parse_duration('Your account will be released in 3 days.', reference)['restriction_term'] == 'unknown'


def test_explicit_permanent_notices_are_classified_without_matching_conditional_warnings():
    assert classify('Your account has been permanently limited.') == 'limited'
    assert classify('Your account is permanently blocked.') == 'blocked'
    assert classify('Your account is permanently frozen. If you disagree, appeal.') == 'error'
    assert classify('Your account will remain limited forever.') == 'limited'
    assert classify('Your account is permanently blocked if you violate the rules.') == 'unknown'


def test_expired_sessions_manual_freezes_and_rpc_bans_do_not_inherit_old_spam_expiry():
    a = SimpleNamespace(spam_status='limited', health_status='live', health_override=None, spam_error=None, health_error=None)
    report = {'status': 'limited', 'text': 'Your account is limited until 18 Nov 2026, 12:34 UTC.'}
    assert account_duration(a, report)['restriction_term'] == 'temporary'
    a.health_status = 'frozen'
    assert account_duration(a, report)['restriction_term'] == 'unknown'
    a.health_override = 'frozen'; report['error_code'] = 'account_frozen'
    assert account_duration(a, report)['restriction_term'] == 'unknown'
    a.health_override = None; a.health_status = 'dead'; a.health_error = 'phone_banned'
    assert account_duration(a, report)['restriction_term'] == 'unknown'


def test_account_api_exposes_duration_without_chat_for_operators_and_clears_after_clear_result(env, seed_user, new_client, login):
    w = env.make_worker(); aid = env.make_account(worker=w); env.authorize(w, aid)
    r = env.client.post(f'/api/accounts/{aid}/spam/check', headers=env.h); assert r.status_code == 202
    (cmd,) = w.poll()
    text = 'Your account will be automatically released on 18 Nov 2026, 12:34 UTC. PRIVATE-BOT-REPLY'
    w.result(cmd['id'], result={'connection_state': 'connected', 'spam_report': {'status': 'limited', 'text': text, 'message_id': 101, 'delivery': 'sent'}})
    a = env.client.get('/api/accounts/' + aid).json()
    assert a['restriction_term'] == 'temporary'
    assert datetime.fromisoformat(a['restriction_until'].replace('Z', '+00:00')) == datetime(2026, 11, 18, 12, 34, tzinfo=timezone.utc)
    seed_user('duration-op', role=Role.OPERATOR); op = new_client(); login(op, 'duration-op')
    listing = op.get('/api/accounts').json()['items']
    assert listing[0]['restriction_term'] == 'temporary' and listing[0]['spam_response'] is None
    assert 'PRIVATE-BOT-REPLY' not in op.get('/api/accounts').text
    env.client.post(f'/api/accounts/{aid}/spam/read', headers=env.h)
    (cmd,) = w.poll()
    w.result(cmd['id'], result={'connection_state': 'connected', 'spam_report': {'status': 'clear', 'text': 'No limits are currently applied to your account.', 'message_id': 102, 'delivery': 'read'}})
    a = env.client.get('/api/accounts/' + aid).json()
    assert a['restriction_term'] == 'none' and a['restriction_until'] is None


def test_old_cached_reports_render_duration_without_migration_and_manual_override_is_unknown(env):
    import json
    from app.crypto import SecretBox
    aid = env.make_account()
    box = SecretBox([env.settings.session_encryption_key.get_secret_value()])
    async def seed(db):
        a = await db.get(TelegramAccount, uuid.UUID(aid))
        a.spam_status = 'blocked'; a.health_status = 'live'
        a.spam_reply_ciphertext = box.seal('spam_report', aid, json.dumps({'status': 'blocked', 'text': 'Your account is permanently blocked.'}))
    run_db(env.settings, seed)
    assert env.client.get('/api/accounts/' + aid).json()['restriction_term'] == 'permanent'
    async def freeze(db):
        (await db.get(TelegramAccount, uuid.UUID(aid))).health_override = 'frozen'
    run_db(env.settings, freeze)
    assert env.client.get('/api/accounts/' + aid).json()['restriction_term'] == 'unknown'
