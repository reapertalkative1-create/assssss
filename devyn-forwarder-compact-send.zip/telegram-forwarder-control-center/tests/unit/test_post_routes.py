import asyncio,uuid
from datetime import timedelta
from types import SimpleNamespace
import pytest
from sqlalchemy import select,update
from app.models import ForwardJob,ForwardRoute,TelegramAccount
from app.services.post_links import parse_post_link,parse_targets
from app.services.routes import routes_for_worker
from app.types import utcnow
from app.errors import ApiError
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_accounts_e2e import e2e
from tests.unit.test_routes_jobs_api import jw,WJ,SRC,DST,DST2
from worker.lease_operation import guarded_lease_operation
from worker.telegram_backend import BackendError


def create(env,st,**extra):
 body={'name':'Post '+uuid.uuid4().hex[:6],'account_id':st.aid,'post_link':'https://t.me/source_group/123','targets_text':'@target_one\nhttps://t.me/target_two','delay_seconds':60,**extra}
 r=env.client.post('/api/post-routes',headers=env.h,json=body)
 assert r.status_code==201,r.text
 return r.json(),body


def verify(env,st,rid,allowed=True):
 r=env.client.post(f'/api/routes/{rid}/verify',headers=env.h);assert r.status_code==202,r.text
 (cmd,)=st.worker.poll();assert cmd['type']=='verify_post'
 result={'post':{'source_chat_id':SRC,'message_id':123,'source_title':'Source','targets':[
  {'index':0,'id':DST,'ok':True,'can_send':True,'title':'One'},
  {'index':1,'id':DST2,'ok':True,'can_send':allowed,'title':'Two'}]}}
 assert st.worker.result(cmd['id'],result=result).status_code==204
 return cmd


def test_link_and_group_parsers_do_not_accept_arbitrary_urls():
 assert parse_post_link('https://t.me/source_group/123?single')['message_id']==123
 assert parse_post_link('https://t.me/c/123456789/7/123')['peer']==-100123456789
 assert parse_post_link('https://telegram.me/s/source_group/123')['url']=='https://t.me/source_group/123'
 assert parse_targets('\ufeff#groups\n@Target_one\nhttps://t.me/target_one\n-100123\nhttps://t.me/joinchat/AbCdEf123\nhttps://t.me/+AbCdEf123')==['@target_one','-100123','https://t.me/+AbCdEf123']
 for value in ['https://evil.example/source/123','https://t.me/source_group/0','https://t.me/+AbCdEf123','https://t.me/source_group/123?comment=5']:
  with pytest.raises(ValueError):parse_post_link(value)
 with pytest.raises(ApiError):parse_targets('@valid_group\nhttps://evil.example/group')


def test_draft_verify_and_one_pass_queue_no_watch_or_duplicate_on_resume(env,jw):
 st=jw();r,body=create(env,st);rid=r['id']
 assert not r['verified'] and env.client.get('/api/jobs',params={'route_id':rid}).json()['total']==0
 assert env.client.post(f'/api/routes/{rid}/start',headers=env.h).status_code==409
 verify(env,st,rid)
 r=env.client.get('/api/routes/'+rid).json();assert r['verified'] and len(r['link_config']['checks'])==2
 assert env.client.post(f'/api/routes/{rid}/start',headers=env.h).status_code==200
 rows=env.client.get('/api/jobs',params={'route_id':rid}).json()['items'];assert len(rows)==2
 times=sorted(x['available_at'] for x in rows)
 from datetime import datetime
 assert (datetime.fromisoformat(times[1].replace('Z','+00:00'))-datetime.fromisoformat(times[0].replace('Z','+00:00'))).total_seconds()==60
 for action in ['start','pause','resume','stop','start']:
  assert env.client.post(f'/api/routes/{rid}/{action}',headers=env.h).status_code==200
 assert env.client.get('/api/jobs',params={'route_id':rid}).json()['total']==2
 assert run_db(env.settings,lambda db:routes_for_worker(db,uuid.UUID(st.worker.id)))==[]
 assert st.worker.enqueue(rid,[(SRC,999)]).status_code==409
 assert env.client.patch(f'/api/post-routes/{rid}',headers=env.h,json=body).status_code==409


def test_invalid_target_blocks_start_and_old_verification_cannot_overwrite_edit(env,jw):
 st=jw();r,body=create(env,st);rid=r['id'];verify(env,st,rid,allowed=False)
 assert not env.client.get('/api/routes/'+rid).json()['verified']
 assert env.client.post(f'/api/routes/{rid}/start',headers=env.h).status_code==409
 accepted=env.client.post(f'/api/routes/{rid}/verify',headers=env.h);(old,)=st.worker.poll()
 assert accepted.status_code==202
 body['targets_text']='@new_target';assert env.client.patch('/api/post-routes/'+rid,headers=env.h,json=body).status_code==200
 st.worker.result(old['id'],result={'post':{'source_chat_id':SRC,'message_id':123,'targets':[{'index':0,'id':DST,'ok':True,'can_send':True}]}})
 current=env.client.get('/api/routes/'+rid).json()
 assert not current['verified'] and current['link_config']['targets']==['@new_target']
 assert current['destination_chat_ids']==[]


def test_schedule_and_pacing_survive_overdue_jobs_after_pause(env,jw):
 st=jw();r,_=create(env,st);rid=r['id'];verify(env,st,rid)
 env.client.post(f'/api/routes/{rid}/start',headers=env.h)
 (one,)=st.worker.claim();st.worker.start([one]);st.worker.results([st.worker.ok(one)])
 async def overdue(db):await db.execute(update(ForwardJob).where(ForwardJob.route_id==uuid.UUID(rid),ForwardJob.status=='pending').values(available_at=utcnow()-timedelta(hours=1)))
 run_db(env.settings,overdue)
 env.client.post(f'/api/routes/{rid}/pause',headers=env.h);env.client.post(f'/api/routes/{rid}/resume',headers=env.h)
 assert st.worker.claim()==[]
 async def elapsed(db):
  await db.execute(update(ForwardJob).where(ForwardJob.id==uuid.UUID(one['id'])).values(claimed_at=utcnow()-timedelta(seconds=61),started_at=utcnow()-timedelta(seconds=61),finished_at=utcnow()-timedelta(seconds=61)))
 run_db(env.settings,elapsed)
 (two,)=st.worker.claim();assert two['id']!=one['id']
 st.worker.start([two]);st.worker.results([st.worker.ok(two)])
 assert env.client.get('/api/routes/'+rid).json()['status']=='stopped'
 assert env.client.get('/api/jobs',params={'route_id':rid}).json()['total']==2
 r,_=create(env,st,scheduled_at=(utcnow()+timedelta(days=1)).isoformat());verify(env,st,r['id'])
 env.client.post('/api/routes/'+r['id']+'/start',headers=env.h)
 assert st.worker.claim()==[]


def test_post_start_can_enable_stopped_ss_but_never_bypasses_restriction(env,jw):
 st=jw();r,_=create(env,st);verify(env,st,r['id'])
 env.client.post('/api/accounts/'+st.aid+'/stop',headers=env.h)
 assert env.client.post('/api/routes/'+r['id']+'/start',headers=env.h).status_code==200
 assert env.client.get('/api/accounts/'+st.aid).json()['desired_state']=='running'
 env.client.post('/api/routes/'+r['id']+'/stop',headers=env.h)
 async def restrict(db):(await db.get(TelegramAccount,uuid.UUID(st.aid))).__setattr__('spam_status','limited')
 run_db(env.settings,restrict)
 assert env.client.post('/api/routes/'+r['id']+'/start',headers=env.h).status_code==409


def test_peer_flood_pauses_account_and_all_active_routes(env,jw):
 st=jw();r,_=create(env,st);verify(env,st,r['id']);env.client.post('/api/routes/'+r['id']+'/start',headers=env.h)
 (job,)=st.worker.claim();st.worker.start([job]);st.worker.results([st.worker.retry(job,'account_spam_restricted')])
 a=env.client.get('/api/accounts/'+st.aid).json()
 assert a['desired_state']=='stopped' and a['spam_status']=='limited'
 assert env.client.get('/api/routes/'+r['id']).json()['status']=='paused'
 assert st.worker.claim()==[]


def test_temporary_lease_renews_same_epoch_and_rejects_wrong_owner(env):
 w=env.make_worker();other=env.make_worker('other');aid=env.make_account(worker=w);env.authorize(w,aid)
 epoch=w.lease(aid).json()['epoch'];path=f'/api/worker/v1/accounts/{aid}/lease/renew'
 assert w.http.post(path,headers=w.h,json={'epoch':epoch}).json()['epoch']==epoch
 assert other.http.post(path,headers=other.h,json={'epoch':epoch}).status_code==404
 assert w.http.post(path,headers=w.h,json={'epoch':epoch-1}).status_code==409


def test_guarded_reads_stop_on_lost_lease_and_do_not_leave_background_tasks():
 async def scenario():
  calls=0;cancelled=False
  class Client:
   async def renew_lease(self,aid,epoch):
    nonlocal calls
    calls+=1
    if calls==2:raise RuntimeError('network')
    return .08
  async def op():
   nonlocal cancelled
   try:await asyncio.sleep(10)
   finally:cancelled=True
  with pytest.raises(BackendError,match='lease_expired'):
   await guarded_lease_operation(Client(),'a',2,.08,op)
  assert calls==2 and cancelled
 asyncio.run(scenario())


def test_actual_telethon_permissions_and_protected_posts_are_checked_without_joining():
 from telethon.tl import types,functions
 from telethon.tl.custom.participantpermissions import ParticipantPermissions
 from worker.telegram_backend import TelethonBackend,can_post_message
 def channel(cid,title,**kwargs):return types.Channel(cid,title,types.ChatPhotoEmpty(),utcnow(),megagroup=True,**kwargs)
 source=channel(1000000001,'Source');dest=channel(2000000001,'Allowed')
 perms=ParticipantPermissions(types.ChannelParticipant(user_id=1,date=utcnow()),chat=False)
 msg=SimpleNamespace(id=123,noforwards=False,empty=False,photo=None,video=None,sticker=None,document=None,poll=None)
 assert can_post_message(dest,perms,msg)
 dest.default_banned_rights=types.ChatBannedRights(until_date=None,send_messages=True)
 assert not can_post_message(dest,perms,msg)
 dest.default_banned_rights=None
 class Client:
  requests=[]
  async def get_entity(self,ref):return source if ref in ('@source_group',SRC) else dest
  async def get_messages(self,entity,ids):return msg
  async def get_permissions(self,entity,user):assert user=='me';return perms
  async def __call__(self,request):self.requests.append(type(request));return None
 async def scenario():
  client=Client();backend=TelethonBackend(123,'a'*32)
  result=await backend.resolve_post_route(SimpleNamespace(client=client),'https://t.me/source_group/123',['@target_one','https://t.me/+AbCdEf123'])
  assert result['targets'][0]['can_send'] is True and result['targets'][1]['error_code']=='not_joined'
  assert client.requests==[functions.messages.CheckChatInviteRequest]
  source.noforwards=True
  with pytest.raises(BackendError,match='forward_restricted'):
   await backend.resolve_post_route(SimpleNamespace(client=client),'https://t.me/source_group/123',['@target_one'])
  with pytest.raises(BackendError,match='forward_restricted'):
   await backend.forward(SimpleNamespace(client=client),SRC,123,DST,'copy')
 asyncio.run(scenario())


def test_api_manager_and_forward_engine_send_only_the_linked_post_once(e2e):
 from tests.unit.test_forwarding_e2e import FSide,finish,job_rows
 from tests.unit.test_accounts_e2e import Admin,authorize
 from tests.fakes import FakeNetwork
 from app.main import create_app
 async def scenario():
  app=create_app(e2e);admin=Admin(app);await admin.login()
  w=await FSide(app,admin,'post-engine',FakeNetwork()).create()
  try:
   aid=(await admin.post('/api/accounts',{'name':'Post SS','worker_id':w.id})).json()['id']
   await authorize(admin,aid)
   async def resolve(handle,link,targets):
    assert link.endswith('/123') and targets==['@target_one','@target_two']
    return {'source_chat_id':SRC,'message_id':123,'targets':[{'index':i,'id':dst,'ok':True,'can_send':True,'title':str(dst)} for i,dst in enumerate([DST,DST2])]}
   w.backend.resolve_post_route=resolve
   r=await admin.post('/api/post-routes',{'name':'Post link','account_id':aid,'post_link':'https://t.me/source_group/123','targets_text':'@target_one\n@target_two','delay_seconds':5})
   assert r.status_code==201,r.text
   rid=r.json()['id'];cid=(await admin.post('/api/routes/'+rid+'/verify')).json()['command_id']
   assert (await admin.finished(aid,cid))['status']=='done'
   assert (await admin.get('/api/routes/'+rid)).json()['verified']
   assert (await admin.post('/api/routes/'+rid+'/start')).status_code==200
   await w.beat();await w.beat()
   assert w.engine.routes=={} and not w.backend.watchers
   assert await w.engine.execute_once()==1
   async with app.state.sessionmaker() as db:
    await db.execute(update(ForwardJob).where(ForwardJob.route_id==uuid.UUID(rid)).values(available_at=utcnow()-timedelta(seconds=10),claimed_at=utcnow()-timedelta(seconds=10),started_at=utcnow()-timedelta(seconds=10),finished_at=utcnow()-timedelta(seconds=10)))
    await db.commit()
   assert await w.engine.execute_once()==1
   assert len(w.backend.forwarded)==2 and all(item[1]==123 for item in w.backend.forwarded)
   assert all(row[2]=='succeeded' for row in await job_rows(app))
  finally:
   await w.close();await w.client.aclose();await admin.http.aclose();await app.state.engine.dispose()
 asyncio.run(scenario())


def test_limit_report_during_verification_stops_the_ss_before_any_queue_is_created(env,jw):
 st=jw();r,_=create(env,st)
 env.client.post('/api/routes/'+r['id']+'/verify',headers=env.h)
 (cmd,)=st.worker.poll()
 response=st.worker.result(cmd['id'],status='failed',error_code='account_spam_restricted')
 assert response.status_code==204,response.text
 account=env.client.get('/api/accounts/'+st.aid).json()
 assert account['spam_status']=='limited' and account['desired_state']=='stopped'
 assert env.client.get('/api/routes/'+r['id']).json()['verification_error']=='account_spam_restricted'
 assert env.client.get('/api/jobs',params={'route_id':r['id']}).json()['total']==0
