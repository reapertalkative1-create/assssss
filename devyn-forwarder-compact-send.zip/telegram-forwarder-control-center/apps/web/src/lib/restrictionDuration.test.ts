import {describe,expect,it} from 'vitest';
import type {Account} from '../api/types';
import {restrictionDuration} from './restrictionDuration';
const now=Date.parse('2026-11-12T10:00:00Z');
const account={restriction_term:'temporary',restriction_until:'2026-11-14T13:00:00Z'} as Account;
describe('Restriction duration on account rows',()=>{
  it('shows days and hours from the absolute UTC deadline',()=>{
    expect(restrictionDuration(account,now)?.text).toBe('Còn 2 ngày 3 giờ');
  });
  it('shows hours/minutes and handles under-one-hour periods',()=>{
    expect(restrictionDuration({...account,restriction_until:'2026-11-12T12:30:00Z'},now)?.text).toBe('Còn 2 giờ 30 phút');
    expect(restrictionDuration({...account,restriction_until:'2026-11-12T10:25:00Z'},now)?.text).toBe('Còn 25 phút');
    expect(restrictionDuration({...account,restriction_until:'2026-11-12T10:00:01Z'},now)?.text).toBe('Còn 1 phút');
  });
  it('keeps expired restrictions until checked again',()=>{
    expect(restrictionDuration({...account,restriction_until:'2026-11-12T09:00:00Z'},now)).toMatchObject({text:'Đã đến hạn · check lại',expired:true});
  });
  it('does not infer permanence from missing dates or an invalid deadline',()=>{
    expect(restrictionDuration({...account,restriction_until:'invalid'},now)?.text).toBe('Chưa rõ thời hạn');
    expect(restrictionDuration({...account,restriction_term:'unknown'},now)?.text).toBe('Chưa rõ thời hạn');
    expect(restrictionDuration({...account,restriction_term:'permanent'},now)?.text).toBe('Vĩnh viễn');
    expect(restrictionDuration({...account,restriction_term:'none'},now)).toBeNull();
  });
});
