import type {Account} from '../api/types';

/** Absolute deadline supplied by the server; do not turn a missing date into "forever". */
export function restrictionDuration(a:Account,now=Date.now()):{text:string;until?:string;expired?:boolean}|null{
  if(a.restriction_term==='permanent')return {text:'Vĩnh viễn'};
  if(a.restriction_term==='temporary'&&a.restriction_until){
    const end=Date.parse(a.restriction_until);
    if(!Number.isFinite(end))return {text:'Chưa rõ thời hạn'};
    const remaining=end-now;
    if(remaining<=0)return {text:'Đã đến hạn · check lại',until:a.restriction_until,expired:true};
    const minutes=Math.ceil(remaining/60000);
    const days=Math.floor(minutes/1440),hours=Math.floor((minutes%1440)/60),mins=minutes%60;
    return {text:days?`Còn ${days} ngày ${hours} giờ`:hours?`Còn ${hours} giờ${mins?` ${mins} phút`:''}`:`Còn ${mins} phút`,until:a.restriction_until};
  }
  if(a.restriction_term==='unknown'||a.restriction_term==='temporary')return {text:'Chưa rõ thời hạn'};
  return null;
}
