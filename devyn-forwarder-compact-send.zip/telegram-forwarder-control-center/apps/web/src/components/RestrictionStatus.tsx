import {useEffect,useState} from 'react';
import type {Account} from '../api/types';
import {restrictionVerdict} from '../lib/restrictionVerdict';
import {restrictionDuration} from '../lib/restrictionDuration';
export function RestrictionStatus({a}:{a:Account}){
  const verdict=restrictionVerdict(a);
  const [now,setNow]=useState(Date.now());
  useEffect(()=>{
    setNow(Date.now());
    if(a.restriction_term!=='temporary')return;
    const timer=setInterval(()=>setNow(Date.now()),60000);
    return()=>clearInterval(timer);
  },[a.restriction_term,a.restriction_until]);
  const restricted=['Tài khoản bị chặn','Bị hạn chế spam','Tài khoản đóng băng','Đã đánh dấu đóng băng','Tài khoản bị khóa'].includes(verdict.title);
  const duration=restricted?(restrictionDuration(a,now)??{text:'Chưa rõ thời hạn'}):null;
  const deadline=duration?.until?`Hết hạn theo Telegram: ${new Date(duration.until).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})} (giờ Việt Nam)`:undefined;
  const short:Record<string,string>={'Không bị hạn chế spam':'Bình thường','Tài khoản bị chặn':'Bị chặn','Bị hạn chế spam':'Bị spam','Tài khoản đóng băng':'Đóng băng','Đã đánh dấu đóng băng':'Đánh dấu đóng băng','Tài khoản bị khóa':'Bị khóa','Session hết hiệu lực':'Hết phiên','Kiểm tra chưa thành công':'Lỗi check','Chưa xác định hạn chế':'Chưa rõ','Chưa kiểm tra spam':'Chưa check'};
  return <section className={`ss-verdict ${verdict.tone}`} aria-label={`Kết luận hạn chế — ${a.name}`}>
    <strong className="ss-verdict-title"><span aria-hidden="true">{verdict.tone==='ok'?'✓':verdict.tone==='bad'?'!':'•'}</span>{short[verdict.title]??verdict.title}</strong>
    {duration&&<span className={`ss-restriction-term${duration.expired?' expired':''}`} title={deadline}>{duration.text}</span>}
  </section>;
}
