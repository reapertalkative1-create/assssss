import {act,render,screen} from '@testing-library/react';
import {describe,expect,it,vi} from 'vitest';
import type {Account} from '../api/types';
import {RestrictionStatus} from './RestrictionStatus';
const base={name:'SS demo',health_status:'live',health_source:'telegram',spam_status:'blocked',restriction_term:'unknown'} as Account;
describe('Compact account restriction details',()=>{
  it('shows an explicit permanent flag but never the original bot conversation',()=>{
    render(<RestrictionStatus a={{...base,restriction_term:'permanent',spam_response:'Your account is permanently blocked. PRIVATE-CHAT'}}/>);
    expect(screen.getByText('Vĩnh viễn')).toBeVisible();
    expect(screen.queryByText(/PRIVATE-CHAT/)).not.toBeInTheDocument();
  });
  it('shows unknown duration for a blocked notice without explicit expiry',()=>{
    render(<RestrictionStatus a={base}/>);
    expect(screen.getByText('Bị chặn')).toBeVisible();
    expect(screen.getByText('Chưa rõ thời hạn')).toBeVisible();
    expect(screen.queryByText('Vĩnh viễn')).not.toBeInTheDocument();
  });
  it('updates the countdown locally and asks to check again when the deadline is reached',()=>{
    vi.useFakeTimers();vi.setSystemTime(new Date('2026-11-12T10:00:00Z'));
    const view=render(<RestrictionStatus a={{...base,restriction_term:'temporary',restriction_until:'2026-11-12T10:02:00Z'}}/>);
    expect(screen.getByText('Còn 2 phút')).toBeVisible();
    act(()=>{vi.advanceTimersByTime(60000);});expect(screen.getByText('Còn 1 phút')).toBeVisible();
    act(()=>{vi.advanceTimersByTime(60000);});expect(screen.getByText('Đã đến hạn · check lại')).toBeVisible();
    expect(screen.getByText('Bị chặn')).toBeVisible();
    view.unmount();vi.useRealTimers();
  });
  it('does not show a stale expiry after a clear result',()=>{
    render(<RestrictionStatus a={{...base,spam_status:'clear',restriction_term:'none',restriction_until:null}}/>);
    expect(screen.getByText('Bình thường')).toBeVisible();
    expect(screen.queryByText(/thời hạn|ngày|Vĩnh viễn/)).not.toBeInTheDocument();
  });
});
