"""Read explicit account restriction terms; never infer permanence from an RPC error."""
import re
from datetime import datetime, timedelta, timezone

UNKNOWN = {'restriction_term': 'unknown', 'restriction_until': None}
CONDITIONAL = re.compile(r'\b(?:if|might|could|would|unless|nếu|có thể)\b|\bmay\b(?!\s+\d{4}\b)', re.I)
SUBJECT = r"(?:(?:unfortunately|sorry)[, ]+|i(?:'m| am) afraid(?: that)?[, ]+|please note that )*your (?:telegram )?account"
STATE = r'(?:limited|restricted|blocked|banned|frozen)'
VERB = r'(?:is(?: now| currently)?|has been|was|will be|will remain|remains)'
PERMANENT = [
    rf'^{SUBJECT} {VERB} (?:permanently {STATE}|{STATE} (?:permanently|forever|for life))\b',
    r'^(?:the )?(?:restrictions?|limits?) on your account (?:is|are|will remain) permanent\b',
    r'^tài khoản (?:telegram )?của bạn (?:đã |hiện |sẽ )?(?:bị )?(?:khóa|chặn|hạn chế|đóng băng) vĩnh viễn\b',
]
RELEASE = [
    rf'^{SUBJECT} {VERB} {STATE} (?:until|till) (?P<value>.+)',
    rf'^{SUBJECT} (?:will be|is scheduled to be) (?:automatically )?(?:released|unblocked|unbanned|unfrozen|restored|unrestricted) (?:on|at|in) (?P<value>.+)',
    r'^(?:the )?(?:restrictions?|limits?) on your account will be (?:automatically )?(?:lifted|removed) (?:on|at|in) (?P<value>.+)',
    r'^tài khoản (?:telegram )?của bạn (?:hiện |đang |đã )?(?:bị )?(?:khóa|chặn|giới hạn|hạn chế|đóng băng) (?:cho )?đến (?:lúc |ngày )?(?P<value>.+)',
    r'^tài khoản (?:telegram )?của bạn sẽ được (?:tự động )?(?:mở khóa|gỡ hạn chế|khôi phục) (?:vào|sau) (?P<value>.+)',
]
MONTHS = {v: i for i, names in enumerate([
    ('jan', 'january'), ('feb', 'february'), ('mar', 'march'), ('apr', 'april'), ('may',), ('jun', 'june'),
    ('jul', 'july'), ('aug', 'august'), ('sep', 'sept', 'september'), ('oct', 'october'), ('nov', 'november'), ('dec', 'december')], 1) for v in names}
DATE = r'(?P<date>\d{4}-\d{2}-\d{2}|\d{1,2}[./]\d{1,2}[./]\d{4}|\d{1,2} [a-z]+ \d{4})'
TIME = r'(?:,?\s+|t)(?:at\s+)?(?P<hour>\d{1,2}):(?P<minute>\d{2})(?::(?P<second>\d{2}))?'
ZONE = r'\s*\(?(?P<zone>z|utc(?:\s*[+-]\d{1,2}(?::?\d{2})?)?|gmt(?:\s*[+-]\d{1,2}(?::?\d{2})?)?|[+-]\d{2}:\d{2})\)?'
STAMP = re.compile(r'^' + DATE + TIME + ZONE + r'(?=$|[\s.,!;])', re.I)


def _reference(value):
    if not isinstance(value, str): return None
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return dt.astimezone(timezone.utc) if dt.tzinfo is not None and 2000 <= dt.year <= 2100 else None
    except ValueError: return None


def _deadline(value, reference):
    stamp = STAMP.match(value)
    if stamp:
        try:
            date = stamp['date']
            if '-' in date: year, month, day = map(int, date.split('-'))
            elif re.search(r'[./]', date):
                day, month, year = map(int, re.split(r'[./]', date))
                # Slash dates that could be either DD/MM or MM/DD are not guessed.
                if '/' in date and day <= 12 and month <= 12: return None
            else:
                day, month, year = date.split(' '); day, month, year = int(day), MONTHS[month], int(year)
            zone = stamp['zone'].replace(' ', '').replace('utc', '').replace('gmt', '')
            if zone in ('', 'z'): tz = timezone.utc
            else:
                sign = 1 if zone[0] == '+' else -1; offset = zone[1:]
                if ':' in offset: hours, minutes = map(int, offset.split(':'))
                elif len(offset) > 2: hours, minutes = int(offset[:-2]), int(offset[-2:])
                else: hours, minutes = int(offset), 0
                if hours > 14 or minutes > 59 or hours == 14 and minutes: return None
                tz = timezone(sign * timedelta(hours=hours, minutes=minutes))
            if not 2000 <= year <= 2100: return None
            return datetime(year, month, day, int(stamp['hour']), int(stamp['minute']), int(stamp['second'] or 0), tzinfo=tz).astimezone(timezone.utc)
        except (ValueError, KeyError, OverflowError): return None
    # Relative terms need the bot message's timestamp, never the page-render time.
    if reference is None: return None
    relative = re.fullmatch(r'(?:(\d{1,4}) (?:days?|ngày)(?:,? (?:and |và )?)?)?(?:(\d{1,3}) (?:hours?|giờ)(?:,? (?:and |và )?)?)?(?:(\d{1,3}) (?:minutes?|phút))?[.!]?', value.strip())
    if not relative or not any(relative.groups()): return None
    days, hours, minutes = (int(v or 0) for v in relative.groups())
    duration = timedelta(days=days, hours=hours, minutes=minutes)
    if not timedelta(0) < duration <= timedelta(days=3660): return None
    return reference + duration


def parse_duration(text, response_date=None):
    value = re.sub(r'[\u200b-\u200f\ufeff]', '', str(text or '')[:8000]).casefold().replace('’', "'")
    statements = [re.sub(r'\s+', ' ', s).strip() for s in re.split(r'\n+|(?<=[.!?])\s+', value)]
    permanent = False; deadlines = set(); uncertain = False
    for statement in statements:
        if CONDITIONAL.search(statement): continue
        if any(re.search(pattern, statement) for pattern in PERMANENT): permanent = True
        for pattern in RELEASE:
            match = re.search(pattern, statement)
            if match:
                deadline = _deadline(match['value'], _reference(response_date))
                if deadline: deadlines.add(deadline)
                else: uncertain = True
    if permanent and not deadlines and not uncertain: return {'restriction_term': 'permanent', 'restriction_until': None}
    if len(deadlines) == 1 and not permanent and not uncertain: return {'restriction_term': 'temporary', 'restriction_until': deadlines.pop()}
    return dict(UNKNOWN)


def account_duration(account, report):
    status = account.spam_status
    frozen = account.health_override == 'frozen' or account.health_status == 'frozen' or account.spam_error == 'account_frozen'
    blocked = status in ('limited', 'blocked')
    banned = account.health_status == 'dead' and account.health_error == 'phone_banned'
    if not (frozen or blocked or banned): return {'restriction_term': 'none', 'restriction_until': None}
    if account.health_override == 'frozen' or not isinstance(report, dict): return dict(UNKNOWN)
    # Do not reuse an old spam deadline for a newer freeze or login ban.
    if frozen and report.get('error_code') != 'account_frozen': return dict(UNKNOWN)
    if banned: return dict(UNKNOWN)
    if not frozen and report.get('status') not in ('limited', 'blocked'): return dict(UNKNOWN)
    return parse_duration(report.get('text'), report.get('response_date'))
