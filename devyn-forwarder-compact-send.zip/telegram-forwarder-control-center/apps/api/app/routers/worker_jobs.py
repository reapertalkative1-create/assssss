"""Worker-facing queue endpoints: enqueue observed messages, claim, start, report results."""
import asyncio
import time

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import get_db
from app.deps_worker import get_worker
from app.errors import ApiError
from app.models import ForwardRoute, TelegramAccount, Worker
from app.schemas_forwarding import (
    ClaimRequest, ClaimResponse, EnqueueRequest, EnqueueResponse, ResultsRequest, ResultsResponse, StartRequest,
    StartResponse,
)
from app.services import jobs as svc
from app.services import routes as route_svc
from app.services.accounts import lease_active
from app.types import utcnow

router = APIRouter(prefix="/api/worker/v1/jobs", tags=["worker-jobs"])


@router.post("/enqueue", response_model=EnqueueResponse)
async def enqueue(body: EnqueueRequest, worker: Worker = Depends(get_worker), db: AsyncSession = Depends(get_db, scope="function")):
    route = await db.get(ForwardRoute, body.route_id)
    acct = await db.get(TelegramAccount, route.account_id) if route else None
    if route is None or acct is None or acct.assigned_worker_id != worker.id:
        raise ApiError(404, "not_found", "Tuyến không tồn tại hoặc không thuộc worker này.")
    now = utcnow()
    if route.status != "active":
        raise ApiError(409, "route_not_active", "Tuyến không ở trạng thái hoạt động.")
    if route.link_config is not None:raise ApiError(409,'post_route_manual','Đợt gửi theo link chỉ tạo hàng đợi khi người dùng bấm bắt đầu.')
    if not (acct.lease_worker_id == worker.id and lease_active(acct, now)):
        raise ApiError(409, "lease_invalid", "Worker không còn sở hữu session của tài khoản này.")
    sources = set(route.source_chat_ids)
    if any(i.source_chat_id not in sources for i in body.items) or any(c not in sources for c in body.checkpoints):
        raise ApiError(422, "invalid_source", "Có chat không phải nguồn của tuyến này.")
    if len(body.items) * len(route.destination_chat_ids) > 1000:
        raise ApiError(422, "too_many_jobs", "Quá nhiều tác vụ trong một lần gửi.")
    created, duplicates = await svc.enqueue(db, route, [(i.source_chat_id, i.message_id) for i in body.items], now)
    highest = dict(body.checkpoints)
    for i in body.items:
        highest[i.source_chat_id] = max(highest.get(i.source_chat_id, 0), i.message_id)
    for src, mid in highest.items():
        await route_svc.upsert_checkpoint(db, route.id, src, mid, now)
    return {"created": created, "duplicates": duplicates}


@router.post("/claim", response_model=ClaimResponse)
async def claim(body: ClaimRequest, request: Request, worker: Worker = Depends(get_worker),
                db: AsyncSession = Depends(get_db, scope="function")):
    """Long poll. Returns at most `max_jobs`, highest priority first, within per-route/per-account rate limits."""
    settings, deadline = request.app.state.settings, time.monotonic() + body.wait_seconds
    while True:
        jobs = await svc.claim_jobs(db, worker, utcnow(), body.max_jobs, settings)
        await db.commit()
        if jobs or time.monotonic() >= deadline:
            return {"jobs": jobs}
        await asyncio.sleep(1.0)


@router.post("/start", response_model=StartResponse)
async def start(body: StartRequest, request: Request, worker: Worker = Depends(get_worker),
                db: AsyncSession = Depends(get_db, scope="function")):
    started, lost = await svc.start_jobs(db, worker, body.jobs, utcnow(), request.app.state.settings)
    return {"started": started, "lost": lost}


@router.post("/results", response_model=ResultsResponse)
async def results(body: ResultsRequest, request: Request, worker: Worker = Depends(get_worker),
                  db: AsyncSession = Depends(get_db, scope="function")):
    return {"outcomes": await svc.apply_results(db, worker, body.results, utcnow(), request.app.state.settings)}
