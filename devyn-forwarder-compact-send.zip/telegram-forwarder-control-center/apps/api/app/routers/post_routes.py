import uuid
from datetime import datetime
from fastapi import APIRouter,Depends,Request
from pydantic import BaseModel,ConfigDict,Field,field_validator
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext,get_db,require_role
from app.errors import ApiError
from app.models import ForwardRoute,TelegramAccount,Role
from app.schemas_forwarding import RouteOut
from app.services.post_links import parse_post_link,parse_targets
from app.routers.routes import _out

router=APIRouter(prefix='/api/post-routes',tags=['post-routes'])
admin=require_role(Role.ADMIN)
class PostRouteInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name:str=Field(min_length=1,max_length=64)
    account_id:uuid.UUID
    post_link:str=Field(min_length=1,max_length=500)
    targets_text:str=Field(min_length=1,max_length=500000)
    delay_seconds:int=Field(default=60,ge=5,le=86400)
    scheduled_at:datetime|None=None
    mode:str='forward'
    @field_validator('name')
    @classmethod
    def name_ok(cls,v):
        v=' '.join(v.split())
        if not v:raise ValueError('Nhập tên đợt gửi.')
        return v
    @field_validator('mode')
    @classmethod
    def mode_ok(cls,v):
        if v not in ('forward','copy'):raise ValueError('Chọn forward hoặc copy.')
        return v
    @field_validator('scheduled_at')
    @classmethod
    def aware(cls,v):
        if v is not None and v.tzinfo is None:raise ValueError('Lịch gửi cần múi giờ.')
        return v

async def save(body,request,auth,db,route=None):
    acct=await db.get(TelegramAccount,body.account_id)
    if acct is None or acct.pending_deletion:raise ApiError(404,'account_not_found','Không tìm thấy tài khoản Telegram.')
    if request.app.state.secret_box is None:raise ApiError(503,'encryption_not_configured','Chưa có khóa mã hóa.')
    try:post=parse_post_link(body.post_link)
    except ValueError as exc:raise ApiError(422,'invalid_post_link',str(exc)) from None
    refs=parse_targets(body.targets_text)
    if route is not None and (route.link_config is None or route.status!='stopped' or route.link_config.get('queued_at')):
        raise ApiError(409,'post_route_locked','Chỉ sửa đợt chưa gửi và đang dừng. Tạo bản mới nếu đã gửi.')
    if route is None:
        route=ForwardRoute(id=uuid.uuid4(),created_by=auth.user.id,source_chat_ids=[],destination_chat_ids=[],filters={},priority=5,max_attempts=3)
        db.add(route)
    route.name=body.name;route.name_key=body.name.lower();route.account_id=body.account_id;route.mode=body.mode
    route.source_chat_ids=[];route.destination_chat_ids=[];route.verified_at=None;route.verification=None
    route.rate_per_minute=max(1,60//body.delay_seconds)
    route.link_config={'post_link':post['url'],'targets':refs,'delay_seconds':body.delay_seconds,'scheduled_at':body.scheduled_at.isoformat() if body.scheduled_at else None}
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'name_taken','Tên tuyến đã tồn tại.') from None
    await record_audit(db,request,'route.post_saved',actor=auth.user,target_type='route',target_id=str(route.id),details={'groups':len(refs)})
    return (await _out(db,[route]))[0]

@router.post('',response_model=RouteOut,status_code=201)
async def create(body:PostRouteInput,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    return await save(body,request,auth,db)

@router.patch('/{rid}',response_model=RouteOut)
async def edit(rid:uuid.UUID,body:PostRouteInput,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    r=await db.get(ForwardRoute,rid)
    if r is None:raise ApiError(404,'not_found','Không tìm thấy tuyến.')
    return await save(body,request,auth,db,r)
