import asyncio
import time
import uuid
import json
import base64
import binascii

from fastapi.concurrency import run_in_threadpool

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import Role, TelegramAccount, Worker, WorkerCommand
from app.schemas import Page
from app.schemas_accounts import (
    AccountCreate, AccountOut, AccountRename, AssignRequest, CommandAccepted, CommandOut, DeleteAccount, DeleteOut,
    LoginCode, LoginPassword, LoginStart, TelegramApiSelection, SessionImportRequest, ImportStatusRequest,
)
from app.services import accounts as svc
from app.services.account_health import health, conditions
from app.services.telegram_api_settings import resolve_telegram_api
from app.types import utcnow

router = APIRouter(prefix="/api/accounts", tags=["accounts"])
admin_only = require_role(Role.ADMIN)


def _box(request: Request):
    if request.app.state.secret_box is None:
        raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session (TFCC_SESSION_ENCRYPTION_KEY).")
    return request.app.state.secret_box


async def _out(db: AsyncSession, accounts: list[TelegramAccount], *, box=None, private=False) -> list[dict]:
    from app.services.account_rows import row_activity
    from app.services.spam import load_report
    from app.services.restriction_duration import account_duration
    activity = await row_activity(db, [a.id for a in accounts])
    reports = {a.id: load_report(box, a) for a in accounts} if box is not None else {}
    now = utcnow()
    ids = {a.assigned_worker_id for a in accounts if a.assigned_worker_id}
    names = dict((await db.execute(select(Worker.id, Worker.name).where(Worker.id.in_(ids)))).all()) if ids else {}
    return [{
        "id": a.id, "name": a.name, "phone_masked": a.phone_masked, "telegram_user_id": a.telegram_user_id,
        "telegram_username": a.telegram_username, "auth_state": a.auth_state, "desired_state": a.desired_state,
        "connection_state": svc.effective_connection_state(a, now),
        "connection_error": a.connection_error, "last_active_at": a.last_active_at,
        "assigned_worker_id": a.assigned_worker_id, "assigned_worker_name": names.get(a.assigned_worker_id),
        "owner_worker_id": a.lease_worker_id if svc.lease_active(a, now) else None,
        "has_session": a.session_version > 0 and a.session_ciphertext is not None,
        "telegram_api_configured": bool(a.telegram_api_ciphertext),
        "session_imported": bool(a.import_fingerprint),
        "spam_status": a.spam_status, "spam_checked_at": a.spam_checked_at,
        "proxy_label": a.proxy_label, "proxy_status": a.proxy_status,
        "proxy_checked_at": a.proxy_checked_at, "proxy_error": a.proxy_error, "proxy_latency_ms": a.proxy_latency_ms,
        "spam_response": (reports.get(a.id) or {}).get("text") if private else None,
        **account_duration(a, reports.get(a.id)),
        "row_operations": activity.get(a.id, []),
        "spam_error": a.spam_error, "spam_action_status": a.spam_action_status,
        "health_status": health(a), "health_source": "manual" if a.health_override else "telegram",
        "health_checked_at": a.health_checked_at, "health_error": a.health_error, "flood_wait_until": a.flood_wait_until,
        "pending_deletion": a.pending_deletion, "created_at": a.created_at,
    } for a in accounts]


async def _get(db: AsyncSession, account_id: uuid.UUID) -> TelegramAccount:
    a = await db.get(TelegramAccount, account_id)
    if a is None:
        raise ApiError(404, "not_found", "Không tìm thấy tài khoản Telegram.")
    return a


def _no_pending_deletion(a: TelegramAccount) -> None:
    if a.pending_deletion:
        raise ApiError(409, "pending_deletion", "Tài khoản đang chờ xóa.")


@router.get("", response_model=Page[AccountOut])
async def list_accounts(
    request: Request,
    q: str | None = Query(default=None, max_length=64),
    auth_state: str | None = Query(default=None, max_length=24),
    worker_id: uuid.UUID | None = None,
    health_status: str | None = Query(default=None,max_length=16),
    desired_state: str | None = Query(default=None,max_length=16),
    spam_status: str | None = Query(default=None,max_length=16),
    proxy_status: str | None = Query(default=None,pattern='^(alive|dead|unknown|checking)$'),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    auth: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(TelegramAccount).where(*conditions(q,auth_state,worker_id,health_status,desired_state,spam_status,proxy_status))
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(TelegramAccount.created_at.desc(), TelegramAccount.name_key)
                             .offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[AccountOut](items=await _out(db, list(rows), box=request.app.state.secret_box, private=auth.user.role==Role.ADMIN), total=total, page=page, page_size=page_size)


@router.post("", response_model=AccountOut, status_code=201)
async def create_account(body: AccountCreate, request: Request, auth: AuthContext = Depends(admin_only),
                         db: AsyncSession = Depends(get_db, scope="function")):
    config = await resolve_telegram_api(body, db, request.app.state.secret_box)
    a = TelegramAccount(name=body.name, name_key=body.name.lower(), created_by=auth.user.id)
    if body.worker_id is not None:
        worker = await db.get(Worker, body.worker_id)
        if worker is None or worker.revoked_at is not None:
            raise ApiError(409, 'worker_unavailable', 'Worker không tồn tại hoặc đã bị thu hồi.')
        a.assigned_worker_id = worker.id
    db.add(a)
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên tài khoản đã tồn tại.") from None
    if config is not None:
        _save_api(request, a, config.api_id, config.api_hash.get_secret_value())
    await record_audit(db, request, "account.create", actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"name": a.name})
    return (await _out(db, [a]))[0]


def _save_api(request: Request, account: TelegramAccount, api_id: int, api_hash: str) -> None:
    account.telegram_api_ciphertext = _box(request).seal(
        'telegram_app', str(account.id), json.dumps({'api_id': api_id, 'api_hash': api_hash}))


@router.put('/{account_id}/telegram-api', response_model=AccountOut)
async def configure_telegram_api(account_id: uuid.UUID, body: TelegramApiSelection, request: Request,
                                 auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope='function')):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.desired_state == 'running' or svc.lease_active(a, utcnow()) or a.auth_state in ('awaiting_code', 'awaiting_password'):
        raise ApiError(409, 'account_busy', 'Hãy tắt tài khoản và hoàn tất đăng nhập đang dở trước khi đổi API Telegram.')
    config = await resolve_telegram_api(body, db, request.app.state.secret_box, required=True)
    _save_api(request, a, config.api_id, config.api_hash.get_secret_value())
    await record_audit(db, request, 'account.telegram_api_updated', actor=auth.user,
                       target_type='account', target_id=str(a.id), details={'configured': True})
    return (await _out(db, [a]))[0]


@router.get('/summary')
async def account_summary(_:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    from sqlalchemy import case
    effective=case((TelegramAccount.health_override=='frozen','frozen'),else_=TelegramAccount.health_status)
    counts=dict((await db.execute(select(effective,func.count()).group_by(effective))).all())
    running=(await db.execute(select(func.count()).select_from(TelegramAccount).where(TelegramAccount.desired_state=='running'))).scalar_one()
    spam=dict((await db.execute(select(TelegramAccount.spam_status,func.count()).group_by(TelegramAccount.spam_status))).all())
    return {'total':sum(counts.values()),'health':counts,'running':running,'spam':spam}


@router.post('/import-sessions', status_code=202)
async def import_sessions(body: SessionImportRequest, request: Request, auth: AuthContext = Depends(admin_only),
                          db: AsyncSession = Depends(get_db, scope='function')):
    from app.services.session_import import MAX_UPLOAD, ImportFormatError, parse_uploads
    from app.services.account_proxy import parse_proxies, proxy_secret
    box = _box(request)
    config = await resolve_telegram_api(body, db, box, required=True)
    await svc.worker_can_take_commands(db, body.worker_id, request.app.state.settings.heartbeat_timeout_seconds, utcnow())
    if sum(len(f.content.get_secret_value()) for f in body.files) > (MAX_UPLOAD + 2) // 3 * 4 + 400:
        raise ApiError(413, 'upload_too_large', 'Tổng dung lượng tải lên tối đa 10 MiB.')
    try:
        files = [(f.filename, base64.b64decode(f.content.get_secret_value(), validate=True)) for f in body.files]
        parsed = await run_in_threadpool(parse_uploads, files)
    except (ImportFormatError, binascii.Error, ValueError) as exc:
        code = str(exc) if isinstance(exc, ImportFormatError) else 'invalid_upload'
        raise ApiError(422, code, 'File không hợp lệ. Dùng tối đa 100 file Telethon .session, tổng tải lên 10 MiB; ZIP không đặt mật khẩu.') from None
    proxies = None
    if body.require_proxy or body.proxies is not None:
        if body.proxies is None or len(body.proxies) != len(parsed):
            raise ApiError(422, 'proxy_count_mismatch', 'Cần đúng một proxy cho mỗi file session trong lô. Chưa nhập session nào của lô này.')
        proxies = []
        seen = set()
        for index, value in enumerate(body.proxies):
            raw = value.get_secret_value().strip()
            if '\n' in raw or '\r' in raw:
                raise ApiError(422, 'invalid_proxy', f'Proxy thứ {index + 1} phải nằm trên một dòng.')
            try:
                proxy = parse_proxies(raw, body.proxy_protocol)[0]
            except ApiError:
                raise ApiError(422, 'invalid_proxy', f'Proxy thứ {index + 1} sai định dạng. Chưa nhập session nào của lô này.') from None
            if proxy['fingerprint'] in seen:
                raise ApiError(422, 'duplicate_proxy', 'Danh sách có proxy trùng. Mỗi SS cần một proxy riêng; chưa nhập lô này.')
            seen.add(proxy['fingerprint'])
            proxies.append(proxy)
        existing_fingerprints = set((await db.execute(select(TelegramAccount.import_fingerprint).where(
            TelegramAccount.import_fingerprint.in_([e.fingerprint for e in parsed if not e.error])))).scalars())
        chosen = [p['fingerprint'] for e, p in zip(parsed, proxies) if not e.error and e.fingerprint not in existing_fingerprints]
        if chosen and (await db.execute(select(TelegramAccount.id).where(TelegramAccount.proxy_fingerprint.in_(chosen)))).first():
            raise ApiError(409, 'proxy_in_use', 'Có proxy đã gán cho SS khác. Chưa nhập lô này; hãy dùng proxy riêng.')
    items=[]
    for index, entry in enumerate(parsed):
        item = {'index':index, 'filename':entry.filename}
        if entry.error:
            items.append({**item, 'status':'error', 'error_code':entry.error})
            continue
        existing = (await db.execute(select(TelegramAccount).where(TelegramAccount.import_fingerprint == entry.fingerprint))).scalar_one_or_none()
        if existing:
            items.append({**item,'status':'duplicate','account_id':str(existing.id),'proxy_label':existing.proxy_label})
            continue
        aid=uuid.uuid4()
        account=TelegramAccount(id=aid,name=f'Session {aid.hex[:12]}',name_key=f'session {aid.hex[:12]}',
            created_by=auth.user.id,assigned_worker_id=body.worker_id,auth_state='importing',
            import_fingerprint=entry.fingerprint,session_ciphertext=box.seal('session',str(aid),entry.session),
            session_version=1,session_updated_at=utcnow())
        _save_api(request,account,config.api_id,config.api_hash.get_secret_value())
        if proxies is not None:
            proxy = proxies[index]
            account.proxy_ciphertext = box.seal('account_proxy', str(aid), proxy_secret(proxy))
            account.proxy_fingerprint = proxy['fingerprint']
            account.proxy_label = proxy['label']
            account.proxy_version = 1
        try:
            async with db.begin_nested():
                db.add(account)
                await db.flush()
                cmd=svc.create_command(db,box,worker_id=body.worker_id,account_id=aid,type='import_session',
                    payload={'check_spam':True} if body.auto_check_spam else None,ttl=604800,created_by=auth.user.id,now=utcnow())
                await db.flush()
        except IntegrityError:
            existing=(await db.execute(select(TelegramAccount).where(TelegramAccount.import_fingerprint == entry.fingerprint))).scalar_one_or_none()
            if existing is None:
                if proxies is not None:
                    raise ApiError(409, 'proxy_in_use', 'Proxy vừa được gán cho SS khác. Tải lại và nhập lại lô này.') from None
                raise
            items.append({**item,'status':'duplicate','account_id':str(existing.id),'proxy_label':existing.proxy_label})
            continue
        items.append({**item,'status':'queued','account_id':str(aid),'command_id':str(cmd.id),'proxy_label':account.proxy_label})
    await record_audit(db,request,'account.sessions_imported',actor=auth.user,details={
        'queued':sum(i['status']=='queued' for i in items),'duplicates':sum(i['status']=='duplicate' for i in items),
        'rejected':sum(i['status']=='error' for i in items)})
    return {'items':items}


@router.post('/import-sessions/status')
async def import_status(body: ImportStatusRequest, _: AuthContext = Depends(admin_only),
                        db: AsyncSession = Depends(get_db, scope='function')):
    rows=(await db.execute(select(WorkerCommand).where(WorkerCommand.id.in_(body.command_ids),
                                                      WorkerCommand.type=='import_session'))).scalars().all()
    return {'items':[{'command_id':str(c.id),'account_id':str(c.account_id),'status':c.status,
                      'error_code':c.error_code,'retry_after':c.retry_after,'spam_status':(c.result or {}).get('spam_status'),'spam_error':(c.result or {}).get('spam_error')} for c in rows]}


@router.post('/{account_id}/import-session/retry', response_model=CommandAccepted, status_code=202)
async def retry_import(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(admin_only),
                       db: AsyncSession = Depends(get_db, scope='function')):
    a=await _get(db,account_id)
    _no_pending_deletion(a)
    if not a.import_fingerprint or not a.session_ciphertext or a.auth_state not in ('importing','import_failed','invalid') or svc.lease_active(a,utcnow()):
        raise ApiError(409,'invalid_state','Không thể kiểm tra lại session ở trạng thái hiện tại.')
    await svc.worker_can_take_commands(db,a.assigned_worker_id,request.app.state.settings.heartbeat_timeout_seconds,utcnow())
    pending=(await db.execute(select(WorkerCommand).where(WorkerCommand.account_id==a.id,
        WorkerCommand.type=='import_session',WorkerCommand.status.in_(('pending','delivered')),
        WorkerCommand.expires_at>utcnow()))).scalars().first()
    if pending:
        return {'command_id':pending.id,'status':pending.status}
    previous=(await db.execute(select(WorkerCommand).where(WorkerCommand.account_id==a.id,
        WorkerCommand.type=='import_session',WorkerCommand.status=='failed').order_by(WorkerCommand.completed_at.desc()))).scalars().first()
    if previous and previous.retry_after and previous.completed_at:
        from datetime import timedelta
        if previous.completed_at + timedelta(seconds=previous.retry_after) > utcnow():
            raise ApiError(429,'flood_wait','Telegram yêu cầu chờ. Hãy thử lại sau thời gian đã báo.')
    a.auth_state='importing'
    cmd=svc.create_command(db,_box(request),worker_id=a.assigned_worker_id,account_id=a.id,type='import_session',
        payload=None,ttl=3600,created_by=auth.user.id,now=utcnow())
    await record_audit(db,request,'account.session_import_retried',actor=auth.user,target_type='account',target_id=str(a.id))
    return {'command_id':cmd.id,'status':cmd.status}


@router.get("/{account_id}", response_model=AccountOut)
async def get_account(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return (await _out(db, [await _get(db, account_id)], box=request.app.state.secret_box, private=auth.user.role==Role.ADMIN))[0]


@router.patch("/{account_id}", response_model=AccountOut)
async def rename_account(account_id: uuid.UUID, body: AccountRename, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if body.name != a.name:
        old, a.name, a.name_key = a.name, body.name, body.name.lower()
        try:
            await db.flush()
        except IntegrityError:
            raise ApiError(409, "name_taken", "Tên tài khoản đã tồn tại.") from None
        await record_audit(db, request, "account.update", actor=auth.user, target_type="account", target_id=str(a.id),
                           details={"changed": ["name"], "from": old, "to": a.name})
    return (await _out(db, [a]))[0]


@router.put("/{account_id}/assignment", response_model=AccountOut)
async def assign_worker(account_id: uuid.UUID, body: AssignRequest, request: Request,
                        auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    """Changing the worker never lets two workers share a session: the previous owner loses its right to renew
    immediately and the new worker can only acquire the lease after the old one is released or expires."""
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.auth_state == 'importing':
        pending = (await db.execute(select(WorkerCommand).where(WorkerCommand.account_id==a.id,
            WorkerCommand.type=='import_session',WorkerCommand.status.in_(('pending','delivered')),
            WorkerCommand.expires_at>utcnow()))).scalars().first()
        if pending or svc.lease_active(a,utcnow()):
            raise ApiError(409,'account_busy','Đợi kiểm tra session xong trước khi đổi worker.')
    if body.worker_id is not None:
        w = await db.get(Worker, body.worker_id)
        if w is None:
            raise ApiError(404, "worker_not_found", "Không tìm thấy worker.")
        if w.revoked_at is not None:
            raise ApiError(409, "worker_revoked", "Worker đã bị thu hồi.")
    if a.assigned_worker_id != body.worker_id:
        before, a.assigned_worker_id = a.assigned_worker_id, body.worker_id
        if a.auth_state in ("awaiting_code", "awaiting_password"):
            a.auth_state = "unauthenticated"  # the half-finished login lived in the old worker's memory
        await svc.supersede_login_commands(db, a.id, utcnow())
        await record_audit(db, request, "account.assign", actor=auth.user, target_type="account", target_id=str(a.id),
                           details={"from": str(before) if before else None, "to": str(body.worker_id) if body.worker_id else None})
    return (await _out(db, [a]))[0]


# ----------------------------------------------------------------- login flow (admin only; OTP never stored/audited)
async def _dispatch(request: Request, db: AsyncSession, auth: AuthContext, a: TelegramAccount, type: str,
                    payload: dict | None, audit_action: str, audit_details: dict | None = None) -> dict:
    settings = request.app.state.settings
    now = utcnow()
    worker = await svc.worker_can_take_commands(db, a.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
    if type in svc.LOGIN_COMMANDS and type == "send_code":
        await svc.supersede_login_commands(db, a.id, now)
    cmd = svc.create_command(db, _box(request) if payload else None, worker_id=worker.id, account_id=a.id, type=type,
                             payload=payload, ttl=settings.command_ttl_seconds, created_by=auth.user.id, now=now)
    await record_audit(db, request, audit_action, actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"command_id": str(cmd.id), **(audit_details or {})})
    return {"command_id": cmd.id, "status": "pending"}


@router.post("/{account_id}/login/start", response_model=CommandAccepted, status_code=202)
async def login_start(account_id: uuid.UUID, body: LoginStart, request: Request, auth: AuthContext = Depends(admin_only),
                      db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.auth_state not in svc.LOGIN_ALLOWED_STATES:
        raise ApiError(409, "invalid_state", "Tài khoản đã được xác thực. Hãy đăng xuất hoặc xóa trước khi đăng nhập lại.")
    _box(request)
    a.phone_masked = svc.mask_phone(body.phone)
    return await _dispatch(request, db, auth, a, "send_code", {"phone": body.phone}, "account.login_start",
                           {"phone": a.phone_masked})


@router.post("/{account_id}/login/code", response_model=CommandAccepted, status_code=202)
async def login_code(account_id: uuid.UUID, body: LoginCode, request: Request, auth: AuthContext = Depends(admin_only),
                     db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if a.auth_state != "awaiting_code":
        raise ApiError(409, "invalid_state", "Tài khoản không ở bước chờ mã xác nhận.")
    return await _dispatch(request, db, auth, a, "sign_in_code", {"code": body.code}, "account.login_code_submitted")


@router.post("/{account_id}/login/password", response_model=CommandAccepted, status_code=202)
async def login_password(account_id: uuid.UUID, body: LoginPassword, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if a.auth_state != "awaiting_password":
        raise ApiError(409, "invalid_state", "Tài khoản không ở bước chờ mật khẩu hai lớp.")
    return await _dispatch(request, db, auth, a, "sign_in_password", {"password": body.password},
                           "account.login_password_submitted")


# ----------------------------------------------------------------- operation (operators allowed)
@router.post("/{account_id}/check", response_model=CommandAccepted, status_code=202)
async def check_connection(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                           db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.auth_state != "authorized":
        raise ApiError(409, "invalid_state", "Tài khoản chưa được xác thực.")
    return await _dispatch(request, db, auth, a, "check_connection", None, "account.check")


async def _set_desired(account_id, desired, request, auth, db):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if desired == "running":
        if a.auth_state != "authorized":
            raise ApiError(409, "invalid_state", "Tài khoản chưa được xác thực.")
        if a.assigned_worker_id is None:
            raise ApiError(409, "no_worker_assigned", "Tài khoản chưa được gán cho worker nào.")
    if a.desired_state != desired:  # idempotent: repeating the call changes nothing and writes no audit
        a.desired_state = desired
        await record_audit(db, request, f"account.{'start' if desired == 'running' else 'stop'}", actor=auth.user,
                           target_type="account", target_id=str(a.id))
    return (await _out(db, [a]))[0]


@router.post("/{account_id}/start", response_model=AccountOut)
async def start_account(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                        db: AsyncSession = Depends(get_db, scope="function")):
    return await _set_desired(account_id, "running", request, auth, db)


@router.post("/{account_id}/stop", response_model=AccountOut)
async def stop_account(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                       db: AsyncSession = Depends(get_db, scope="function")):
    return await _set_desired(account_id, "stopped", request, auth, db)


@router.get("/{account_id}/commands/{command_id}", response_model=CommandOut)
async def get_command(account_id: uuid.UUID, command_id: uuid.UUID, wait_seconds: int = Query(default=0, ge=0, le=25),
                      _: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    """Optionally waits (short polling on the server side) until the command finishes."""
    deadline = time.monotonic() + wait_seconds
    while True:
        cmd = await db.get(WorkerCommand, command_id, populate_existing=True)
        if cmd is None or cmd.account_id != account_id:  # also true once a deleted account's commands are purged
            raise ApiError(404, "not_found", "Không tìm thấy lệnh.")
        if cmd.status in svc.FINAL_STATUSES or time.monotonic() >= deadline:
            return cmd
        await db.commit()  # do not sit in an open transaction while waiting
        await asyncio.sleep(0.5)


# ----------------------------------------------------------------- deletion with explicit confirmation
@router.post("/{account_id}/delete", response_model=DeleteOut)
async def delete_account(account_id: uuid.UUID, body: DeleteAccount, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    """The caller must retype the account name. By default the Telegram session is terminated on Telegram's side
    (by the owning worker) before the record is purged; `force` skips that and leaves the session active there."""
    a = await _get(db, account_id)
    if body.confirm_name != a.name:
        raise ApiError(422, "confirmation_mismatch", "Tên xác nhận không khớp với tên tài khoản.")
    settings, now = request.app.state.settings, utcnow()
    has_session = a.session_version > 0 and a.session_ciphertext is not None

    if has_session and body.telegram_logout and not body.force:
        worker = await svc.worker_can_take_commands(db, a.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
        a.pending_deletion, a.desired_state = True, "stopped"
        cmd = svc.create_command(db, None, worker_id=worker.id, account_id=a.id, type="logout", payload=None,
                                 ttl=settings.command_ttl_seconds, created_by=auth.user.id, now=now)
        await record_audit(db, request, "account.delete_requested", actor=auth.user, target_type="account",
                           target_id=str(a.id), details={"name": a.name, "command_id": str(cmd.id)})
        return {"status": "logout_requested", "command_id": cmd.id}

    await record_audit(db, request, "account.delete", actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"name": a.name, "had_stored_login": has_session, "forced": body.force,
                                "revoked_on_telegram": False if has_session else None})
    await svc.purge_account(db, a)
    return {"status": "deleted", "telegram_session_revoked": False if has_session else None}
