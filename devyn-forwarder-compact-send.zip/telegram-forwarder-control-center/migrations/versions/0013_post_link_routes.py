"""One-pass post-link deliveries and group lists."""
from alembic import op
import sqlalchemy as sa
revision='0013'
down_revision='0012'
branch_labels=None
depends_on=None

def upgrade():op.add_column('forward_routes',sa.Column('link_config',sa.JSON(),nullable=True))
def downgrade():op.drop_column('forward_routes','link_config')
