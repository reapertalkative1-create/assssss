import importlib.util
import json
from pathlib import Path

import pytest
from sqlalchemy import select, func

from app.models import Worker, AuditLog
from app.services.workers import create_worker, credential_matches, revoke
from app.types import utcnow
from tests.conftest import run_db

spec = importlib.util.spec_from_file_location('local_worker_bootstrap', Path(__file__).parents[2]/'docker/provision_worker.py')
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)


def test_auto_worker_create_reuse_and_recover_without_duplicates(settings):
    async def go(db):
        first = await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC')
        again = await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC', first['credential'])
        assert again == first
        recovered = await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC')
        assert recovered['id'] == first['id']
        assert recovered['credential'] != first['credential']
        worker = (await db.execute(select(Worker))).scalar_one()
        assert worker.platform == 'linux'
        assert 'MY-PC' in worker.name
        assert credential_matches(worker, recovered['credential'], utcnow())
        assert not credential_matches(worker, first['credential'], utcnow())
        audit = (await db.execute(select(AuditLog))).scalars().all()
        serialized = json.dumps([row.details for row in audit])
        assert first['credential'] not in serialized and recovered['credential'] not in serialized
    run_db(settings, go)


def test_auto_worker_does_not_reactivate_revoked_worker(settings):
    async def go(db):
        first = await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC')
        worker = (await db.execute(select(Worker))).scalar_one()
        revoke(worker)
        for credential in ['', first['credential']]:
            with pytest.raises(ValueError, match='revoked'):
                await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC', credential)
        assert (await db.execute(select(func.count()).select_from(Worker))).scalar_one() == 1
    run_db(settings, go)


@pytest.mark.parametrize('platform', ['linux', 'windows'])
def test_existing_worker_configuration_is_preserved(settings, platform):
    async def go(db):
        previous, credential = create_worker(db, 'Existing worker', platform, None)
        await db.flush()
        out = await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC', credential)
        assert credential_matches(previous, credential, utcnow())
        if platform == 'linux':
            assert out['id'] == str(previous.id) and out['credential'] == credential
        else:
            assert out['id'] != str(previous.id)
            assert (await db.execute(select(func.count()).select_from(Worker))).scalar_one() == 2
    run_db(settings, go)


def test_invalid_existing_credential_is_rejected_without_creating_worker(settings):
    async def go(db):
        with pytest.raises(ValueError, match='invalid'):
            await bootstrap.provision(db, 'tfcc-install-a', 'MY-PC', 'not-a-credential')
        assert (await db.execute(select(func.count()).select_from(Worker))).scalar_one() == 0
    run_db(settings, go)
