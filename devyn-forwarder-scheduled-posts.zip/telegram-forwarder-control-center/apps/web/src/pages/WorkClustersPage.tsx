import {useEffect,useState} from 'react';
import {useLocation,useNavigate} from 'react-router-dom';
import type {CommandAccepted,Route} from '../api/types';
import {api,ApiError} from '../api/client';
import {PageHead} from '../components/ui';
import {useAuth} from '../state/auth';
import {useToast} from '../state/toast';
import {WorkClusters} from './WorkClusters';
import {PostBatch} from './PostBatch';
import {PostRouteDetail,PostRouteForm} from './PostRoute';
import {waitForCommand} from './Accounts';

export function WorkClustersPage(){
 const {user,isAdmin}=useAuth(),toast=useToast(),location=useLocation(),navigate=useNavigate();
 const [tick,setTick]=useState(0),[fromAccounts,setFromAccounts]=useState(false);
 const [batch,setBatch]=useState<string|null>(null),[detail,setDetail]=useState<Route|null>(null);
 useEffect(()=>{if(isAdmin&&(location.state?.clusterFromAccounts||location.state?.composeFromAccounts)){setFromAccounts(true);navigate(location.pathname,{replace:true,state:null});}},[location.key,isAdmin]);
 if(!user)return null;
 async function act(action:'start'|'pause'|'resume'|'stop'){
  if(!detail)return;
  try{await api.post(`/api/routes/${detail.id}/${action}`);}catch(e){toast.error(e instanceof ApiError?e.message:'Không cập nhật được lượt gửi.');}
 }
 async function verify(){
  if(!detail)return;
  try{const c=await api.post<CommandAccepted>(`/api/routes/${detail.id}/verify`);await waitForCommand(detail.account_id,c.command_id);}catch(e){toast.error(e instanceof ApiError?e.message:'Không kiểm tra được nhóm.');}
 }
 return <div className="stack">
  <PageHead title="Cụm làm việc">Lưu bài viết, tài khoản, nhóm nhận và khoảng nghỉ. Chạy ngay hoặc lên lịch một lượt theo giờ đã chọn.</PageHead>
  <WorkClusters key={`${user.id}:${tick}`} owner={user.id} isAdmin={isAdmin} onOpenBatch={setBatch}/>
  {fromAccounts&&<PostRouteForm clusterMode fromAccounts draftOwner={user.id} onClose={()=>setFromAccounts(false)} onSaved={()=>{}} onClusterSaved={()=>{setFromAccounts(false);setTick(v=>v+1);toast.success('Đã lưu cụm làm việc.');}}/>}
  {batch&&<PostBatch batchId={batch} isAdmin={isAdmin} onClose={()=>setBatch(null)} onDetail={r=>{setBatch(null);setDetail(r);}}/>}
  {detail&&<PostRouteDetail route={detail} onClose={()=>{setBatch(detail.link_config?.batch_id??null);setDetail(null);}} onVerify={verify} onAction={act}/>}
 </div>;
}
