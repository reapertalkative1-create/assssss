import type { AuthState, JobStatus, Level, WorkerStatus } from "../api/types";

export type Tone = "ok" | "warn" | "bad" | "idle";

export const workerStatus: Record<WorkerStatus, { label: string; tone: Tone }> = {
  online: { label: "Online", tone: "ok" }, degraded: { label: "Suy giảm", tone: "warn" },
  offline: { label: "Mất kết nối", tone: "bad" }, revoked: { label: "Đã thu hồi", tone: "idle" },
};
export const authState: Record<AuthState, { label: string; tone: Tone }> = {
  importing: {label: "Đang nhập session", tone:"warn"}, import_failed: {label:"Lỗi nhập session",tone:"bad"},
  unauthenticated: { label: "Chưa đăng nhập", tone: "idle" }, awaiting_code: { label: "Chờ mã xác nhận", tone: "warn" },
  awaiting_password: { label: "Chờ mật khẩu 2 lớp", tone: "warn" }, authorized: { label: "Đã xác thực", tone: "ok" },
  invalid: { label: "Phiên hết hiệu lực", tone: "bad" },
};
export const connectionState: Record<string, { label: string; tone: Tone }> = {
  connected: { label: "Đang kết nối", tone: "ok" }, connecting: { label: "Đang kết nối…", tone: "warn" },
  error: { label: "Lỗi kết nối", tone: "bad" }, disconnected: { label: "Ngắt kết nối", tone: "idle" },
};
export const routeStatus: Record<string, { label: string; tone: Tone }> = {
  active: { label: "Đang chạy", tone: "ok" }, paused: { label: "Tạm dừng", tone: "warn" }, stopped: { label: "Đã dừng", tone: "idle" },
};
export const jobStatus: Record<JobStatus, { label: string; tone: Tone }> = {
  pending: { label: "Chờ xử lý", tone: "idle" }, claimed: { label: "Đã nhận", tone: "idle" }, running: { label: "Đang chạy", tone: "warn" },
  succeeded: { label: "Thành công", tone: "ok" }, retry_wait: { label: "Chờ thử lại", tone: "warn" },
  failed: { label: "Thất bại", tone: "bad" }, cancelled: { label: "Đã hủy", tone: "idle" }, dead_letter: { label: "Hàng chờ lỗi", tone: "bad" },
};
export const levelTone: Record<Level, Tone> = { info: "idle", warning: "warn", error: "bad" };
export const levelLabel: Record<Level, string> = { info: "Thông tin", warning: "Cảnh báo", error: "Lỗi" };

export const contentTypes: Record<string, string> = {
  text: "Văn bản", photo: "Ảnh", video: "Video", voice: "Ghi âm", audio: "Âm thanh", sticker: "Sticker", document: "Tệp", other: "Khác",
};

/** Plain-language text for audit/event action codes. Unknown codes fall back to the code itself. */
const actions: Record<string, string> = {
  "auth.login": "Đăng nhập", "auth.logout": "Đăng xuất", "auth.login_failed": "Đăng nhập thất bại", "auth.login_blocked": "Đăng nhập bị chặn",
  "auth.account_locked": "Tài khoản bị khóa tạm thời", "auth.password_changed": "Đổi mật khẩu", "auth.password_change_failed": "Đổi mật khẩu thất bại",
  "auth.logout_others": "Đăng xuất các phiên khác", "user.create": "Tạo người dùng", "user.update": "Cập nhật người dùng",
  "worker.create": "Tạo worker", "worker.update": "Cập nhật worker", "worker.rotate_credential": "Xoay credential worker", "worker.revoke": "Thu hồi worker",
  "worker.register": "Worker kết nối", "worker.online": "Worker online", "worker.offline": "Worker mất kết nối", "worker.degraded": "Worker suy giảm",
  "account.create": "Tạo tài khoản Telegram", "account.update": "Đổi tên tài khoản", "account.assign": "Gán worker cho tài khoản",
  "account.login_start": "Bắt đầu đăng nhập Telegram", "account.login_code_submitted": "Gửi mã xác nhận", "account.login_password_submitted": "Gửi mật khẩu 2 lớp",
  "account.authorized": "Tài khoản đã xác thực", "account.invalidated": "Phiên Telegram hết hiệu lực", "account.start": "Bật tài khoản", "account.stop": "Tắt tài khoản",
  "account.check": "Kiểm tra kết nối", "account.lease_acquired": "Worker nhận quyền dùng session", "account.session_fetched": "Worker đọc session",
  "account.session_updated": "Lưu session", "account.delete_requested": "Yêu cầu xóa tài khoản", "account.delete": "Xóa tài khoản",
  "route.create": "Tạo tuyến", "route.update": "Sửa tuyến", "route.verify": "Xác minh quyền truy cập", "route.start": "Bật tuyến", "route.pause": "Tạm dừng tuyến",
  "route.resume": "Tiếp tục tuyến", "route.stop": "Dừng tuyến", "route.delete": "Xóa tuyến", "route.cancel_pending": "Hủy tác vụ đang chờ",
  "job.succeeded": "Chuyển tiếp thành công", "job.failed": "Chuyển tiếp thất bại", "job.retry_wait": "Sẽ thử lại", "job.dead_letter": "Tác vụ vào hàng chờ lỗi",
  "job.retry": "Thử lại tác vụ", "job.cancel": "Hủy tác vụ", "job.bulk_retry": "Thử lại hàng loạt", "job.bulk_cancel": "Hủy hàng loạt", "keys.rotated": "Xoay khóa mã hóa",
};
export const actionLabel = (a: string) => actions[a] ?? a;
export const actionCodes = Object.keys(actions);

/** Telegram / worker error codes shown to people. */
const errors: Record<string, string> = {
  account_not_authorized: "SS chưa xác thực / hết phiên",
  delivery_uncertain: "Chưa rõ đã gửi · cần đối chiếu", duplicate_post: "Bài đã có trong đợt trước", proxy_dead: "Proxy lỗi · tạm dừng gửi", target_owner_mismatch: "Nhóm đã có SS phụ trách", account_restricted: "SS bị hạn chế / đóng băng",
  code_invalid: "Mã xác nhận không đúng.", code_expired: "Mã xác nhận đã hết hạn. Hãy bắt đầu lại từ số điện thoại.",
  password_invalid: "Mật khẩu hai lớp không đúng.", phone_invalid: "Số điện thoại không hợp lệ.", phone_banned: "Số điện thoại này bị Telegram chặn.",
  phone_flood: "Số điện thoại này đã yêu cầu quá nhiều mã. Hãy thử lại sau.", flood_wait: "Telegram yêu cầu chờ trước khi thử lại.",
  slow_mode: "Nhóm đích đang bật chế độ chậm.", login_session_lost: "Worker đã khởi động lại giữa chừng. Hãy bắt đầu lại từ số điện thoại.",
  auth_key_duplicated: "Telegram từ chối vì phiên được sử dụng từ nhiều nơi. Cần tạo phiên mới.",
  spambot_no_response: "Chưa có phản hồi mới từ SpamBot. Dùng Lấy phản hồi mới để kiểm tra.",
  spambot_timeout: "SpamBot chưa phản hồi kịp; kiểm tra lại cuộc hội thoại trước khi gửi tiếp.",
  spam_check_not_supported: "Worker chưa hỗ trợ check spam. Cập nhật bằng setup.cmd.",
  spambot_identity_mismatch: "Không xác minh được bot chính thức @SpamBot.",
  stale_spam_report: "Phản hồi đã thay đổi. Lấy phản hồi mới trước khi thao tác.",
  invalid_spambot_button: "Nút này không còn hợp lệ hoặc cần thao tác trong Telegram.",
  spam_action_pending: "Đang có tương tác SpamBot chờ xử lý.",
  spam_action_duplicate: "Tương tác này đã được gửi. Hãy lấy phản hồi mới.",
  appeal_in_progress: "Vừa tương tác kháng nghị; dùng Lấy phản hồi mới để tiếp tục.",
  appeal_not_ready: "SpamBot chưa ở bước yêu cầu mô tả. Mở hội thoại và thực hiện các bước phù hợp trước.",
  appeal_email_missing: "Chưa có email thực tế cho tài khoản này. Nhập email chung hoặc riêng, hoặc bỏ dòng email trong mẫu.",
  appeal_phone_missing: "Không đọc được số điện thoại. Khai báo số riêng cho tài khoản rồi tạo lại bản xem trước.",
  appeal_worker_outdated: "Worker chưa hỗ trợ mẫu kháng nghị. Cập nhật bằng setup.cmd.",
  appeal_text_too_long: "Nội dung sau khi điền biến quá dài (tối đa 4.000 ký tự).",
  appeal_prepare_failed: "Chưa chuẩn bị được nội dung. Xem tình trạng phiên và worker.",
  appeal_delivery_uncertain: "Chưa xác nhận được việc gửi. Đọc hội thoại SpamBot trước khi quyết định gửi tiếp.",
  appeal_review_required: "Cần tạo và kiểm tra bản xem trước mới trước khi gửi lại.",
  no_proxy: "Chưa có proxy.", proxy_changed: "Proxy đã đổi, hãy check lại.", proxy_check_expired: "Check proxy hết hạn; kiểm tra worker rồi thử lại.",
  proxy_timeout: "Proxy quá thời gian kết nối.", proxy_check_failed: "Không kết nối được Telegram qua proxy.", proxy_auth_failed: "Xác thực proxy thất bại.", proxy_tls_failed: "Proxy không thiết lập được kết nối bảo mật tới Telegram.", proxy_unreadable: "Không đọc được cấu hình proxy.",
  account_frozen: "Telegram xác nhận tài khoản bị đóng băng.",
  account_spam_restricted: "Telegram hạn chế gửi tin. SS và các tuyến đã tạm dừng để kiểm tra.",
  verification_timeout: "Kiểm tra nhóm mất quá lâu. Hãy chia danh sách nhỏ hơn rồi kiểm tra lại.",
  invalid_verification: "Chưa lấy được kết quả kiểm tra hợp lệ. Hãy kiểm tra lại nhóm.",
  admin_required: "Tài khoản cần quyền quản trị nhóm/kênh để chạy cụm.",
  not_joined: "Tài khoản chưa tham gia nhóm.", not_a_group: "Đích không phải nhóm hoặc kênh.",
  account_not_ready: "Chưa đăng nhập, chưa gán worker hoặc tài khoản đang bị đánh dấu đóng băng/Die.",
  worker_unavailable: "Worker đang offline hoặc đã bị thu hồi.",
  no_session: "Tài khoản chưa có session.",
  command_expired: "Lệnh đã hết thời gian chờ; có thể kiểm tra lại.",
  session_check_timeout: "Kiểm tra session mất quá lâu; có thể thử lại.",
  login_in_progress: "Đang đăng nhập OTP/2FA; hãy hoàn tất trước khi check.",
  account_missing: "Tài khoản đã bị xóa hoặc đang chờ xóa.",
  lease_held: "Session đang được worker khác sử dụng. Thử lại sau ít giây.", telegram_api_not_configured: "Chưa có api_id/api_hash cho tài khoản này. Bấm API Telegram để cấu hình trên web.",
  telegram_api_id_invalid: "api_id/api_hash của worker không hợp lệ.", auth_key_unregistered: "Telegram đã thu hồi phiên này. Cần đăng nhập lại.",
  user_deactivated: "Tài khoản Telegram đã bị vô hiệu hóa.", session_revoked: "Phiên đã bị đăng xuất từ thiết bị khác. Cần đăng nhập lại.",
  network_error: "Lỗi mạng khi nói chuyện với Telegram.", telegram_error: "Telegram trả về lỗi không xác định.", internal_error: "Lỗi nội bộ của worker.",
  destination_forbidden: "Tài khoản không có quyền gửi vào chat đích.", chat_unavailable: "Không truy cập được chat (riêng tư hoặc đã rời).",
  message_not_found: "Tin nhắn đã bị xóa.", forward_restricted: "Chat bật bảo vệ nội dung, không thể chuyển tiếp.", media_unsupported: "Loại media không được hỗ trợ.",
  account_not_connected: "Tài khoản đang không kết nối.", lease_expired: "Worker ngừng phản hồi khi đang xử lý.", connection_lost: "Mất kết nối tới Telegram.",
  control_plane_error: "Không lấy được session từ máy chủ.", session_not_uploaded: "Worker chưa lưu được session.", payload_unreadable: "Không đọc được dữ liệu lệnh.",
};
export const errorLabel = (code?: string | null, retryAfter?: number | null) => {
  if (!code) return "";
  const base = errors[code] ?? `Lỗi: ${code}`;
  return retryAfter ? `${base} (chờ ${retryAfter} giây)` : base;
};
