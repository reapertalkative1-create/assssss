import json
from fastapi import APIRouter,Depends,Request
from pydantic import BaseModel,Field,SecretStr
from typing import Literal
from sqlalchemy import select,update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import TelegramAccount as A,Role,WorkerCommand
from app.deps import AuthContext,get_db,require_role
from app.schemas_accounts import AccountBulkRequest
from app.services.account_health import conditions
from app.services.account_proxy import parse_proxies,proxy_secret
from app.audit import record_audit
from app.errors import ApiError
from app.types import utcnow
router=APIRouter(prefix='/api/account-proxies',tags=['account-proxies'])
admin=require_role(Role.ADMIN)
class AssignProxies(BaseModel):
    text:SecretStr=Field(max_length=2000000)
    protocol:Literal['socks5','socks4','http']='socks5'
    selection:AccountBulkRequest

@router.post('/assign')
async def assign(body:AssignProxies,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    box=request.app.state.secret_box
    if box is None:raise ApiError(503,'encryption_not_configured','Chưa có khóa mã hóa.')
    entries=parse_proxies(body.text.get_secret_value(),body.protocol)
    s=body.selection
    filters=conditions(**s.filters.model_dump()) if s.all_matching else [A.id.in_(s.account_ids)]
    if s.all_matching and s.exclude_ids:filters.append(A.id.not_in(s.exclude_ids))
    accounts=(await db.execute(select(A).where(*filters,A.pending_deletion.is_(False)).order_by(A.created_at,A.id).with_for_update())).scalars().all()
    if not accounts:raise ApiError(422,'empty_selection','Chưa chọn session.')
    if len(entries)<len(accounts):raise ApiError(422,'not_enough_proxies',f'Cần {len(accounts)} proxy riêng; danh sách chỉ có {len(entries)} proxy không trùng.')
    if any(a.auth_state in ('awaiting_code','awaiting_password','importing') for a in accounts):raise ApiError(409,'login_in_progress','Đợi SS đang nhập hoặc đăng nhập hoàn tất rồi gán proxy.')
    ids=[a.id for a in accounts];chosen=entries[:len(accounts)]
    busy=(await db.execute(select(A.id).where(A.proxy_fingerprint.in_([p['fingerprint'] for p in chosen]),A.id.not_in(ids)))).first()
    if busy:raise ApiError(409,'proxy_in_use','Một proxy đã được gán cho SS ngoài lựa chọn. Hãy dùng danh sách proxy khác.')
    for a in accounts:a.proxy_fingerprint=None
    await db.flush()
    await db.execute(update(WorkerCommand).where(WorkerCommand.account_id.in_(ids),WorkerCommand.type=='proxy_check',WorkerCommand.status.in_(('pending','delivered'))).values(status='expired',payload_ciphertext=None,completed_at=utcnow()))
    for a,p in zip(accounts,chosen):
        a.proxy_ciphertext=box.seal('account_proxy',str(a.id),proxy_secret(p));a.proxy_fingerprint=p['fingerprint'];a.proxy_label=p['label'];a.proxy_version+=1
        a.proxy_status='unknown';a.proxy_checked_at=None;a.proxy_error=None;a.proxy_latency_ms=None;a.proxy_check_command_id=None
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'proxy_in_use','Proxy vừa được gán cho SS khác. Tải lại và thử lại.') from None
    await record_audit(db,request,'account.proxies_assigned',actor=auth.user,details={'count':len(accounts)})
    return {'assigned':len(accounts),'unused':len(entries)-len(accounts)}
