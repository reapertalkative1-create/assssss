import hashlib
import ipaddress
import json
import re
from urllib.parse import urlsplit,unquote,quote
from app.errors import ApiError


def parse_proxies(text, default_protocol='socks5'):
    if default_protocol not in ('socks5','socks4','http'):raise ApiError(422,'invalid_proxy','Loại proxy không hợp lệ.')
    values=[];seen=set()
    for number,line in enumerate(text.lstrip('\ufeff').splitlines(),1):
        line=line.strip()
        if not line or line.startswith('#'):continue
        try:
            if '://' not in line:
                parts=line.split(':',3)
                if len(parts) not in (2,4):raise ValueError
                line=default_protocol+'://'+(quote(parts[2],safe='')+':'+quote(parts[3],safe='')+'@' if len(parts)==4 else '')+parts[0]+':'+parts[1]
            u=urlsplit(line)
            if u.scheme not in ('socks5','socks4','http') or u.path not in ('','/') or u.query or u.fragment or not u.hostname or not u.port:raise ValueError
            host=u.hostname.encode('idna').decode().lower()
            try:ipaddress.ip_address(host)
            except ValueError:
                if len(host)>253 or not all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',p) for p in host.rstrip('.').split('.')):raise ValueError
            user=unquote(u.username) if u.username is not None else None
            password=unquote(u.password) if u.password is not None else None
            if any(c in (user or '')+(password or '') for c in '\r\n\x00') or bool(user)!=(password is not None) or len(user or '')>255 or len(password or '')>255:raise ValueError
            address=('['+host+']') if ':' in host else host
            label=f'{u.scheme}://{address}:{u.port}'
            canonical=u.scheme+'://'+(quote(user,safe='')+':'+quote(password,safe='')+'@' if user else '')+address+':'+str(u.port)
            fingerprint=hashlib.sha256(canonical.encode()).hexdigest()
            if fingerprint in seen:continue
            seen.add(fingerprint);values.append({'protocol':u.scheme,'host':host,'port':u.port,'username':user,'password':password,'label':label,'fingerprint':fingerprint})
        except (ValueError,UnicodeError):raise ApiError(422,'invalid_proxy',f'Proxy dòng {number} sai định dạng.') from None
        if len(values)>10000:raise ApiError(422,'too_many_proxies','Tối đa 10.000 proxy mỗi lần nhập.')
    if not values:raise ApiError(422,'empty_proxies','Nhập ít nhất một proxy.')
    return values


def proxy_secret(value):
    return json.dumps({k:value[k] for k in ('protocol','host','port','username','password')})
