import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Account, Summary } from "../api/types";

vi.mock("../api/client", async (orig) => {
  const real = await orig<typeof import("../api/client")>();
  return { ...real, api: { get: vi.fn(), post: vi.fn(), put: vi.fn(), patch: vi.fn(), download: vi.fn() } };
});
import { ApiError, api } from "../api/client";
import { ToastProvider } from "../state/toast";
import { AuthProvider } from "../state/auth";
import { LoginWizard } from "./Accounts";
import { pipelineTones } from "./Dashboard";
import { LoginPage } from "./Login";
import { RouteForm } from "./Routes";

const mocked = { get: vi.mocked(api.get), post: vi.mocked(api.post) };
const savedApiStatus={configured:true,api_id:12345,updated_at:null};
function mockWorkersAndApi(workers:unknown){mocked.get.mockImplementation(async(path:string)=>path==='/api/settings/telegram-api'?savedApiStatus:workers);}
beforeEach(() => { vi.clearAllMocks(); });
const wrap = (ui: React.ReactElement) => render(<MemoryRouter><ToastProvider>{ui}</ToastProvider></MemoryRouter>);

describe("LoginPage", () => {
  it("validates before calling the API, shows the server message and clears the password after a failure", async () => {
    const user = userEvent.setup();
    mocked.get.mockRejectedValue(new ApiError(401, "unauthenticated", "x"));            // /auth/me on mount
    mocked.post.mockRejectedValueOnce(new ApiError(401, "invalid_credentials", "Sai tên đăng nhập hoặc mật khẩu."));
    wrap(<AuthProvider><LoginPage /></AuthProvider>);
    await user.click(screen.getByRole("button", { name: "Đăng nhập" }));
    expect(screen.getByText("Nhập tên đăng nhập.")).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();

    await user.type(screen.getByLabelText("Tên đăng nhập"), "admin1");
    await user.type(screen.getByLabelText("Mật khẩu"), "wrong-password");
    await user.click(screen.getByRole("button", { name: "Đăng nhập" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Sai tên đăng nhập hoặc mật khẩu.");
    expect(mocked.post).toHaveBeenCalledWith("/api/auth/login", { username: "admin1", password: "wrong-password" });
    expect(screen.getByLabelText("Mật khẩu")).toHaveValue("");
    expect(screen.getByLabelText("Tên đăng nhập")).toHaveValue("admin1");
  });
});

const account = { id: "acc1", name: "Sale 1", auth_state: "unauthenticated" } as Account;

describe("LoginWizard", () => {
  it("moves phone → code → done and drops each secret from the form as soon as it is sent", async () => {
    const user = userEvent.setup();
    mocked.post.mockImplementation(async (path: string) => ({ command_id: path.includes("start") ? "c1" : "c2", status: "pending" }));
    mocked.get.mockImplementation(async (path: string) => ({
      id: path.includes("c1") ? "c1" : "c2", type: "x", status: "done", error_code: null, retry_after: null, created_at: "", completed_at: "",
      result: path.includes("c2") ? { state: "authorized" } : { state: "awaiting_code" },
    }));
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    const code = await screen.findByLabelText("Mã xác nhận");
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/acc1/login/start", { phone: "+84901234567" });
    expect(screen.queryByDisplayValue("+84901234567")).toBeNull();

    await user.type(code, "48213");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByText(/Đã đăng nhập thành công/)).toBeInTheDocument();
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/acc1/login/code", { code: "48213" });
    expect(document.body.innerHTML).not.toContain("48213");
    expect(document.body.innerHTML).not.toContain("901234567");
  });

  it("asks for the 2FA password when Telegram requires it and explains a wrong code in plain Vietnamese", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    const results = [
      { status: "failed", error_code: "code_invalid", result: null },
      { status: "done", error_code: null, result: { state: "awaiting_password" } },
    ];
    mocked.get.mockImplementation(async () => ({ id: "c", type: "x", retry_after: null, created_at: "", completed_at: "", ...results.shift()! }));
    wrap(<LoginWizard a={{ ...account, auth_state: "awaiting_code" }} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Mã xác nhận"), "11111");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Mã xác nhận không đúng.");
    expect(screen.getByLabelText("Mã xác nhận")).toHaveValue("");               // the rejected code is not kept in the form
    await user.type(screen.getByLabelText("Mã xác nhận"), "22222");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    const pw = await screen.findByLabelText("Mật khẩu hai lớp");
    expect(pw).toHaveAttribute("type", "password");
  });

  it("starts over with an empty phone field after the code expired (no secret is kept between steps)", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    const results = [{ status: "done", error_code: null, result: { state: "awaiting_code" } }, { status: "failed", error_code: "code_expired", result: null }];
    mocked.get.mockImplementation(async () => ({ id: "c", type: "x", retry_after: null, created_at: "", completed_at: "", ...results.shift()! }));
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    await user.type(await screen.findByLabelText("Mã xác nhận"), "99999");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("hết hạn");
    expect(await screen.findByLabelText("Số điện thoại")).toHaveValue("");
  });

  it("says so when the worker does not answer in time", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    mocked.get.mockResolvedValue({ id: "c", type: "x", status: "expired", error_code: null, retry_after: null, created_at: "", completed_at: "", result: null });
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Worker không phản hồi kịp");
  });
});

describe("RouteForm", () => {
  beforeEach(() => { mocked.get.mockResolvedValue({ items: [{ id: "acc1", name: "Sale 1", auth_state: "authorized" }], total: 1, page: 1, page_size: 100 }); });

  it("explains invalid chat ids, duplicates and overlaps instead of sending bad data", async () => {
    const user = userEvent.setup();
    wrap(<RouteForm onClose={() => {}} onSaved={() => {}} />);
    await user.type(screen.getByLabelText("Tên tuyến"), "Tin sale");
    await user.selectOptions(await screen.findByLabelText("Tài khoản Telegram"), "acc1");
    await user.type(screen.getByLabelText("Chat nguồn"), "-1001\nabc");
    await user.type(screen.getByLabelText("Chat đích"), "-1001");
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    expect(await screen.findByText(/Chat id không hợp lệ: abc/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();

    const src = screen.getByLabelText("Chat nguồn");
    await user.clear(src);
    await user.type(src, "-1001");
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    expect(await screen.findByText(/vừa là nguồn vừa là đích/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();
  });

  it("sends a clean payload: normalised ids, keyword lists and numeric settings", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({});
    const onSaved = vi.fn();
    wrap(<RouteForm onClose={() => {}} onSaved={onSaved} />);
    await user.type(screen.getByLabelText("Tên tuyến"), "  Tin sale ");
    await user.selectOptions(await screen.findByLabelText("Tài khoản Telegram"), "acc1");
    await user.type(screen.getByLabelText("Chat nguồn"), "-1001, -1002");
    await user.type(screen.getByLabelText("Chat đích"), "-2001");
    await user.type(screen.getByLabelText("Phải chứa một trong các từ khóa"), "giá rẻ\n\nsale");
    await user.click(screen.getByLabelText("Ảnh"));
    await user.click(screen.getByRole("button", { name: "Sao chép nội dung" }));
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    await waitFor(() => expect(onSaved).toHaveBeenCalled());
    expect(mocked.post).toHaveBeenCalledWith("/api/routes", {
      name: "Tin sale", account_id: "acc1", source_chat_ids: [-1001, -1002], destination_chat_ids: [-2001], mode: "copy",
      filters: { keywords_include: ["giá rẻ", "sale"], keywords_exclude: [], content_types: ["photo"], include_outgoing: false },
      priority: 5, rate_per_minute: 20, max_attempts: 5,
    });
  });
});

describe("dashboard pipeline", () => {
  const base = (): Summary => ({
    workers: { online: 2, offline: 0, degraded: 0, revoked: 0 }, accounts: { total: 3, authorized: 3, invalid: 0, connected: 3, running: 3 },
    routes: { active: 2, paused: 0, stopped: 1 },
    jobs: { by_status: {}, oldest_pending_age_seconds: null, succeeded_last_5m: 0, needs_attention: 0, last_24h: { succeeded: 0, failed: 0 }, series: [] },
    resources: [], recent_events: [], server_time: "",
  });
  it("is green when everything works", () => expect(pipelineTones(base())).toEqual({ workers: "ok", accounts: "ok", routes: "ok", queue: "ok" }));
  it("turns each stage amber or red for the right reason", () => {
    const s = base();
    s.workers = { online: 1, offline: 1, degraded: 0, revoked: 0 }; s.accounts.invalid = 1; s.routes.paused = 1; s.jobs.needs_attention = 4;
    expect(pipelineTones(s)).toEqual({ workers: "warn", accounts: "bad", routes: "warn", queue: "bad" });
    const none = base(); none.workers = { online: 0, offline: 2, degraded: 0, revoked: 0 };
    expect(pipelineTones(none).workers).toBe("bad");
    const idle = base(); idle.workers = { online: 0, offline: 0, degraded: 0, revoked: 0 }; idle.accounts.running = 0; idle.routes.active = 0;
    expect(pipelineTones(idle)).toMatchObject({ workers: "idle", accounts: "idle", routes: "idle" });
    const slow = base(); slow.jobs.oldest_pending_age_seconds = 300;
    expect(pipelineTones(slow).queue).toBe("warn");
  });
});

describe("Telegram API web form", () => {
  it("creates an assigned account using saved settings without API inputs", async () => {
    const { TelegramAccountForm } = await import("./Accounts");
    const user = userEvent.setup();
    mockWorkersAndApi({items:[{id:'worker1',name:'My PC',status:'online'}],total:1});
    mocked.post.mockResolvedValue({ ...account, telegram_api_configured: true });
    const saved = vi.fn();
    wrap(<TelegramAccountForm onClose={() => {}} onSaved={saved} />);
    await waitFor(() => expect(screen.getByLabelText("Worker")).toHaveValue("worker1"));
    await user.click(screen.getByRole("button", { name: "Tạo và đăng nhập" }));
    expect(mocked.post).not.toHaveBeenCalled();
    await user.type(screen.getByLabelText("Tên hiển thị"), "Sale 1");
    expect(screen.queryByLabelText('api_id')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('api_hash')).not.toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "Tạo và đăng nhập" }));
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts", { name: "Sale 1", worker_id: "worker1" });
    expect(saved).toHaveBeenCalledWith(expect.objectContaining({ telegram_api_configured: true }));
  });
  it("applies saved credentials to an existing account without asking for the hash", async () => {
    const { TelegramAccountForm } = await import("./Accounts");
    const user = userEvent.setup();
    mockWorkersAndApi({items:[]});
    vi.mocked(api.put).mockResolvedValue({ ...account, telegram_api_configured: true });
    wrap(<TelegramAccountForm a={{ ...account, telegram_api_configured: true }} onClose={() => {}} onSaved={() => {}} />);
    await waitFor(()=>expect(screen.getByRole('button',{name:'Dùng API đã lưu'})).toBeEnabled());
    expect(screen.queryByLabelText('api_hash')).not.toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "Dùng API đã lưu" }));
    expect(api.put).toHaveBeenCalledWith("/api/accounts/acc1/telegram-api", {});
  });
});

describe("Session import", () => {
  it("uses saved API settings for session import and shows worker progress", async () => {
    const { SessionImport } = await import("./SessionImport");
    const user = userEvent.setup();
    mockWorkersAndApi({items:[{id:"w1",name:"My PC",status:"online"}]});
    mocked.post.mockImplementation(async (path: string) => path.endsWith("/status")
      ? {items:[{command_id:"c1",account_id:"a1",status:"done"}]}
      : {items:[{index:0,filename:"sample.session",account_id:"a1",command_id:"c1",status:"queued"}]});
    wrap(<SessionImport onClose={()=>{}} />);
    await waitFor(()=>expect(screen.getByLabelText("Worker")).toHaveValue("w1"));
    await user.click(screen.getByRole("button",{name:"Nhập và kiểm tra session"}));
    expect(mocked.post).not.toHaveBeenCalled();
    await user.upload(screen.getByLabelText("File session hoặc ZIP"),new File(["fake session"],"sample.session"));
    expect(screen.getByLabelText('Nhập SS kèm proxy')).toBeChecked();
    await user.type(screen.getByLabelText('Proxy cho session mới'),'proxy.example:1080:u:private-pass');
    await user.click(screen.getByRole("button",{name:"Nhập và kiểm tra session"}));
    await waitFor(()=>expect(screen.getByText(/Thành công: 1 \/ 1/)).toBeInTheDocument());
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/import-sessions",expect.objectContaining({worker_id:"w1",files:[{filename:"sample.session",content:btoa("fake session")}],require_proxy:true,proxy_protocol:'socks5',proxies:['proxy.example:1080:u:private-pass']}));
    expect(screen.queryByLabelText("api_hash")).not.toBeInTheDocument();
    expect(mocked.post.mock.calls.find(([path])=>path==='/api/accounts/import-sessions')![1]).not.toHaveProperty('api_hash');
  });
  it('links to settings and blocks import until an API has been saved',async()=>{
    const {SessionImport}=await import('./SessionImport');
    mocked.get.mockImplementation(async(path:string)=>path==='/api/settings/telegram-api'?{configured:false,api_id:null,updated_at:null}:{items:[{id:'w1',name:'My PC',status:'online'}]});
    wrap(<SessionImport onClose={()=>{}}/>);
    expect(await screen.findByRole('link',{name:'Vào Cài đặt để nhập một lần'})).toHaveAttribute('href','/settings');
    expect(screen.getByRole('button',{name:'Nhập và kiểm tra session'})).toBeDisabled();
    expect(mocked.post).not.toHaveBeenCalled();
  });
});

describe("Unlimited session upload",()=>{
  it("automatically splits 101 selected files into requests of 100 and 1",async()=>{
    const {SessionImport}=await import("./SessionImport");
    const user=userEvent.setup();
    mockWorkersAndApi({items:[{id:"w1",name:"My PC",status:"online"}]});
    let number=0;
    mocked.post.mockImplementation(async(path:string,body?:unknown)=>{
      if(path.endsWith('/status'))return {items:(body as {command_ids:string[]}).command_ids.map(id=>({command_id:id,status:'done'}))};
      const files=(body as {files:{filename:string}[]}).files;
      return {items:files.map((f,index)=>({index,filename:f.filename,command_id:`cmd-${number++}`,status:'queued'}))};
    });
    wrap(<SessionImport onClose={()=>{}}/>);
    await waitFor(()=>expect(screen.getByLabelText('Worker')).toHaveValue('w1'));
    await user.upload(screen.getByLabelText('File session hoặc ZIP'),Array.from({length:101},(_,i)=>new File(['x'],`${i}.session`)));
    const text=Array.from({length:101},(_,i)=>`proxy-${i}.example:1080`).join('\n');
    await user.click(screen.getByLabelText('Proxy cho session mới'));await user.paste(text);
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    await waitFor(()=>expect(mocked.post.mock.calls.filter(([p])=>p==='/api/accounts/import-sessions')).toHaveLength(2),{timeout:10000});
    const calls=mocked.post.mock.calls.filter(([p])=>p==='/api/accounts/import-sessions');
    expect((calls[0][1] as {files:unknown[]}).files).toHaveLength(100);
    expect((calls[1][1] as {files:unknown[]}).files).toHaveLength(1);
    expect((calls[0][1] as {proxies:string[]}).proxies).toEqual(text.split('\n').slice(0,100));
    expect((calls[1][1] as {proxies:string[]}).proxies).toEqual(['proxy-100.example:1080']);
    expect(await screen.findByText(/Đã gửi 101 session/)).toBeInTheDocument();
  },15000);
});

describe('Session import with proxies',()=>{
  async function form(count=2){
    const {SessionImport}=await import('./SessionImport');const user=userEvent.setup();
    mockWorkersAndApi({items:[{id:'w1',name:'My PC',status:'online'}]});
    wrap(<SessionImport onClose={()=>{}}/>);
    await waitFor(()=>expect(screen.getByLabelText('Worker')).toHaveValue('w1'));
    await user.upload(screen.getByLabelText('File session hoặc ZIP'),Array.from({length:count},(_,i)=>new File(['x'],`${i}.session`)));
    return user;
  }
  it('does not upload any SS when there are too few proxies',async()=>{
    const user=await form();await user.type(screen.getByLabelText('Proxy cho session mới'),'proxy.example:1080');
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    expect(await screen.findByText(/Có 2 SS nhưng chỉ có 1 proxy/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();
  });
  it('reads TXT, skips comments, and preserves proxy order without exposing passwords in results',async()=>{
    const user=await form();
    const file=new File(['unused'],'proxies.txt',{type:'text/plain'});
    Object.defineProperty(file,'text',{value:async()=>'\ufeff# demo\nproxy1.example:1080:u:secret1\n\nhttp://u:secret2@proxy2.example:8080\nunused.example:1080'});
    await user.upload(screen.getByLabelText('File proxy .txt'),file);
    await screen.findByText(/3 dòng proxy/);
    mocked.post.mockResolvedValue({items:[{index:0,filename:'0.session',status:'done',proxy_label:'socks5://proxy1.example:1080'}]});
    await user.selectOptions(screen.getByLabelText('Loại proxy mặc định'),'socks5');
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    expect(await screen.findByText('socks5://proxy1.example:1080')).toBeInTheDocument();
    expect(mocked.post).toHaveBeenCalledWith('/api/accounts/import-sessions',expect.objectContaining({proxies:['proxy1.example:1080:u:secret1','http://u:secret2@proxy2.example:8080']}));
    expect(screen.queryByText(/secret1/)).not.toBeInTheDocument();
  });
  it('allows explicit import without proxy',async()=>{
    const user=await form(1);await user.click(screen.getByLabelText('Nhập SS kèm proxy'));
    mocked.post.mockResolvedValue({items:[{index:0,filename:'0.session',status:'done'}]});
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalled());
    expect(mocked.post.mock.calls[0][1]).not.toHaveProperty('proxies');
    expect(mocked.post.mock.calls[0][1]).not.toHaveProperty('require_proxy');
  });
  it('rejects duplicate proxy lines before uploading',async()=>{
    const user=await form();await user.click(screen.getByLabelText('Proxy cho session mới'));await user.paste('proxy.example:1080\nproxy.example:1080');
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    expect(await screen.findByText(/Danh sách có proxy trùng/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();
  });
  it('keeps an upload error visible while earlier commands keep polling',async()=>{
    const user=await form(101);await user.click(screen.getByLabelText('Proxy cho session mới'));await user.paste(Array.from({length:101},(_,i)=>`proxy-${i}.example:1080`).join('\n'));
    let batches=0;
    mocked.post.mockImplementation(async(path:string)=>{
      if(path.endsWith('/status'))return {items:[{command_id:'c1',status:'done'}]};
      if(++batches===2)throw new ApiError(409,'proxy_in_use','Proxy đã được gán cho SS khác.');
      return {items:[{index:0,filename:'0.session',status:'queued',command_id:'c1'}]};
    });
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    expect(await screen.findByText('Proxy đã được gán cho SS khác.')).toBeInTheDocument();
    await waitFor(()=>expect(screen.getByText(/Thành công: 1 \/ 1/)).toBeInTheDocument());
    expect(screen.getByText('Proxy đã được gán cho SS khác.')).toBeInTheDocument();
  },15000);
});

describe("SpamBot appeal panel",()=>{
  it("requires an explicit preview confirmation before sending to SpamBot",async()=>{
    const {SpamPanel}=await import('./SpamPanel');
    const user=userEvent.setup();
    mocked.get.mockImplementation(async(path:string)=>path.endsWith('/spam')?{
      status:'limited',checked_at:null,error_code:null,action_status:'none',pending_command_id:null,report_token:'a'.repeat(64),
      report:{status:'limited',message_id:101,text:'Your account is now limited',buttons:[{id:'101:0:0',text:'This is a mistake'}],delivery:'sent'}
    }:{status:'done',result:{action_delivery:'sent'}});
    mocked.post.mockResolvedValue({command_id:'c1'});
    wrap(<SpamPanel a={{...account,auth_state:'authorized'}} onClose={()=>{}}/>);
    await screen.findByText('Your account is now limited');
    await user.type(screen.getByLabelText('Nội dung kháng nghị / trả lời SpamBot'),'Please review my restriction.');
    await user.click(screen.getByRole('button',{name:'Xem trước và gửi kháng nghị'}));
    expect(mocked.post).not.toHaveBeenCalled();
    expect(screen.getByText('Xác nhận gửi bằng Sale 1 tới @SpamBot')).toBeInTheDocument();
    await user.click(screen.getByRole('button',{name:'Xác nhận gửi nội dung'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalledWith('/api/accounts/acc1/spam/action',expect.objectContaining({operation:'reply',report_token:'a'.repeat(64),text:'Please review my restriction.'})));
    await waitFor(()=>expect(screen.getByLabelText('Nội dung kháng nghị / trả lời SpamBot')).toHaveValue(''));
    expect(mocked.post.mock.calls[0][1]).not.toHaveProperty('recipient');
  });
  it("reads new replies without sending a /start check",async()=>{
    const {SpamPanel}=await import('./SpamPanel');
    const user=userEvent.setup();
    mocked.get.mockImplementation(async(path:string)=>path.endsWith('/spam')?{status:'unknown',action_status:'sent',report:null,report_token:null,pending_command_id:null}:{status:'done',result:{}});
    mocked.post.mockResolvedValue({command_id:'c2'});
    wrap(<SpamPanel a={{...account,auth_state:'authorized'}} onClose={()=>{}}/>);
    await user.click(screen.getByRole('button',{name:'Lấy phản hồi mới'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/accounts/acc1/spam/read');
    expect(mocked.post).not.toHaveBeenCalledWith('/api/accounts/acc1/spam/check');
  });
});

describe('Bulk delete selected accounts',()=>{
  it('deletes selected rows immediately without a dialog or typed confirmation',async()=>{
    const {AccountsPage}=await import('./Accounts');
    const user=userEvent.setup();
    const row={...account,id:'selected-account',name:'Delete selected',health_status:'unknown',spam_status:'not_checked',assigned_worker_id:null,created_at:'2026-11-11T00:00:00Z'};
    mocked.get.mockImplementation(async(path:string)=>{
      if(path==='/api/auth/me')return {user:{id:'admin-id',username:'admin',role:'admin'},csrf_token:'test'};
      if(path==='/api/accounts')return {items:[row],total:1,page:1,page_size:50};
      if(path==='/api/accounts/summary')return {total:1,health:{unknown:1},running:0};
      return {items:[],total:0};
    });
    mocked.post.mockResolvedValue({id:'delete-job',total:1,status:'running'});
    wrap(<AuthProvider><AccountsPage/></AuthProvider>);
    await user.click(await screen.findByRole('checkbox',{name:'Chọn Delete selected'}));
    await user.click(screen.getByRole('button',{name:'Xóa đã chọn'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk',expect.objectContaining({action:'delete',all_matching:false,account_ids:['selected-account']})));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(screen.queryByRole('button',{name:'Xác nhận'})).not.toBeInTheDocument();
  });
});

describe('Bulk appeal templates',()=>{
  it('creates an encrypted draft with provided email and no sending confirmation yet',async()=>{
    const {BulkAppeal}=await import('./BulkAppeal');const user=userEvent.setup();
    mocked.get.mockResolvedValue({id:'draft1',status:'preparing',total:1,counts:{pending:1},review_token:null,items:[],items_total:0});
    mocked.post.mockResolvedValue({id:'draft1'});
    wrap(<BulkAppeal selection={{all_matching:false,account_ids:['a1'],exclude_ids:[],filters:{}}} onClose={()=>{}}/>);
    await user.type(screen.getByLabelText('Email liên hệ chung'),'owner@example.com');
    await user.click(screen.getByRole('button',{name:'Chuẩn bị bản xem trước'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-appeals',expect.objectContaining({account_ids:['a1'],email:'owner@example.com',template:expect.stringContaining('{phone}')}));
    expect(mocked.post.mock.calls).toHaveLength(1);
  });
  it('requires fact confirmation before sending the reviewed personalized bodies',async()=>{
    const {BulkAppeal}=await import('./BulkAppeal');const user=userEvent.setup();
    mocked.get.mockResolvedValue({id:'draft1',status:'preview',total:1,counts:{prepared:1},review_token:'a'.repeat(64),items:[{account_id:'a1',name:'SS-A',status:'prepared',text:'Hello SS-A. Phone: +15551234567 Email: a@example.com'}],items_total:1});
    mocked.post.mockResolvedValue({id:'draft1',status:'running'});
    wrap(<BulkAppeal jobId='draft1' onClose={()=>{}}/>);
    await screen.findByText('Hello SS-A. Phone: +15551234567 Email: a@example.com');
    const send=screen.getByRole('button',{name:'Xác nhận gửi 1 kháng nghị'});expect(send).toBeDisabled();
    await user.click(screen.getByRole('checkbox',{name:'Tôi đã kiểm tra mẫu, thông tin và xác nhận nội dung đúng với tất cả tài khoản sẵn sàng gửi'}));
    await user.click(send);
    expect(mocked.post).toHaveBeenCalledWith('/api/account-appeals/draft1/confirm',{review_token:'a'.repeat(64),facts_confirmed:true});
  });
});

describe('Visible Telegram restriction checks',()=>{
  async function openAccounts(){
    const {AccountsPage}=await import('./Accounts');
    const row={...account,id:'check-account',name:'Check me',health_status:'live',spam_status:'limited',auth_state:'authorized',assigned_worker_id:'worker1',created_at:'2026-11-11T00:00:00Z'};
    mocked.get.mockImplementation(async(path:string)=>{
      if(path==='/api/auth/me')return {user:{id:'admin-id',username:'admin',role:'admin'},csrf_token:'test'};
      if(path==='/api/accounts')return {items:[row],total:3,page:1,page_size:50};
      if(path==='/api/accounts/summary')return {total:3,health:{live:2,frozen:1},spam:{limited:2,not_checked:1},running:0};
      return {items:[],total:0};
    });
    mocked.post.mockResolvedValue({id:'restriction-job',total:1,status:'running'});
    wrap(<AuthProvider><AccountsPage/></AuthProvider>);
    await screen.findByRole('checkbox',{name:'Chọn Check me'});
    return userEvent.setup();
  }
  it('queues a combined check from a visible row button without opening a menu',async()=>{
    const user=await openAccounts();
    await user.click(screen.getByRole('button',{name:'Check spam / đóng băng — Check me'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk',expect.objectContaining({action:'spam_check',all_matching:false,account_ids:['check-account']}));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });
  it('checks every filtered result and forwards spam filters to the server',async()=>{
    const user=await openAccounts();
    await user.selectOptions(screen.getByRole('combobox',{name:'Lọc hạn chế spam'}),'limited');
    await waitFor(()=>expect(mocked.get).toHaveBeenCalledWith('/api/accounts',expect.objectContaining({spam_status:'limited'}),expect.anything()));
    await user.click(screen.getByRole('button',{name:'Check tất cả theo bộ lọc (3)'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk',expect.objectContaining({action:'spam_check',all_matching:true,account_ids:[],filters:expect.objectContaining({spam_status:'limited'})}));
    await user.click(screen.getByRole('button',{name:'Đóng băng: 1'}));
    await waitFor(()=>expect(mocked.get).toHaveBeenCalledWith('/api/accounts',expect.objectContaining({health_status:'frozen',spam_status:undefined}),expect.anything()));
  });
  it('reports queue errors without a success toast',async()=>{
    const user=await openAccounts();mocked.post.mockRejectedValue(new ApiError(503,'unavailable','Máy chủ chưa sẵn sàng.'));
    await user.click(screen.getByRole('button',{name:'Check spam / đóng băng — Check me'}));
    expect(await screen.findByText('Máy chủ chưa sẵn sàng.')).toBeVisible();
    expect(screen.queryByText(/Đã xếp hàng check Check me/)).not.toBeInTheDocument();
  });
});

describe('Session information stays on the row',()=>{
  it('shows bot reply, progress and error inline without the bulk task panel or its polling',async()=>{
    const {AccountsPage}=await import('./Accounts');
    mocked.get.mockImplementation(async(path:string)=>{
      if(path==='/api/auth/me')return {user:{id:'admin-id',username:'admin',role:'admin'},csrf_token:'test'};
      if(path==='/api/accounts')return {items:[{...account,id:'inline-ss',name:'Inline SS',auth_state:'authorized',health_status:'live',spam_status:'unknown',spam_response:'Synthetic response: please read this instruction.',row_operations:[{id:'op1',kind:'bulk',action:'spam_check',status:'error',job_status:'done',error_code:'worker_offline',updated_at:'2026-11-11T00:00:00Z'}]}],total:1};
      if(path==='/api/accounts/summary')return {total:1,health:{live:1},spam:{unknown:1}};
      return {items:[],total:0};
    });
    wrap(<AuthProvider><AccountsPage/></AuthProvider>);
    expect(await screen.findByText('Chưa rõ')).toBeVisible();
    expect(screen.queryByText('Synthetic response: please read this instruction.')).not.toBeInTheDocument();
    expect(screen.getByText('Thất bại')).toBeVisible();
    expect(screen.getAllByText('Đã xác thực')[0]).toBeVisible();
    expect(screen.queryByRole('heading',{name:'Tác vụ hàng loạt'})).not.toBeInTheDocument();
    expect(mocked.get.mock.calls.some(([path])=>path==='/api/account-bulk')).toBe(false);
  });
  it('opens a saved appeal from the row and cancels a whole batch only through its explicit button',async()=>{
    const {SessionActivity}=await import('./SessionActivity');const user=userEvent.setup();const onAppeal=vi.fn(),onReload=vi.fn();
    mocked.post.mockResolvedValue({});
    wrap(<SessionActivity a={{...account,row_operations:[{id:'saved-draft',kind:'bulk',action:'bulk_appeal',status:'prepared',job_status:'preview',error_code:null,updated_at:'2026-11-11T00:00:00Z'}]}} isAdmin onReload={onReload} onAppeal={onAppeal}/>);
    await user.click(screen.getByRole('button',{name:'Xem / duyệt kháng nghị'}));expect(onAppeal).toHaveBeenCalledWith('saved-draft');
    expect(mocked.post).not.toHaveBeenCalled();
    await user.click(screen.getByRole('button',{name:'Dừng cả đợt'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk/saved-draft/cancel');
    await waitFor(()=>expect(onReload).toHaveBeenCalled());
  });
});

describe('Proxy import and assignment',()=>{
  it('pastes proxies and assigns each selected SS without changing selection scope',async()=>{
    const {ProxyImport}=await import('./ProxyImport');const user=userEvent.setup();const saved=vi.fn();mocked.post.mockResolvedValue({assigned:2,unused:0});
    wrap(<ProxyImport selection={{all_matching:false,account_ids:['ss1','ss2'],exclude_ids:[],filters:{}}} count={2} total={9} filters={{}} onClose={()=>{}} onSaved={saved}/>);
    await user.type(screen.getByLabelText('Danh sách proxy'),'127.0.0.1:1080\n127.0.0.2:1080');await user.click(screen.getByRole('button',{name:'Gán proxy'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-proxies/assign',expect.objectContaining({protocol:'socks5',selection:expect.objectContaining({account_ids:['ss1','ss2'],all_matching:false})}));
    await waitFor(()=>expect(saved).toHaveBeenCalled());
  });
  it('reads txt and assigns all filtered SS with the chosen protocol',async()=>{
    const {ProxyImport}=await import('./ProxyImport');const user=userEvent.setup();mocked.post.mockResolvedValue({assigned:1,unused:0});
    wrap(<ProxyImport selection={{all_matching:false,account_ids:[],exclude_ids:[],filters:{}}} count={0} total={1} filters={{health_status:'live'}} onClose={()=>{}} onSaved={()=>{}}/>);
    const file=new File(['127.0.0.1:8080'],'proxies.txt',{type:'text/plain'});Object.defineProperty(file,'text',{value:async()=>'127.0.0.1:8080'});
    await user.upload(screen.getByLabelText('File .txt'),file);expect(await screen.findByDisplayValue('127.0.0.1:8080')).toBeVisible();
    await user.selectOptions(screen.getByRole('combobox',{name:'Loại proxy mặc định'}),'http');await user.click(screen.getByRole('button',{name:'Gán proxy'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/account-proxies/assign',expect.objectContaining({protocol:'http',selection:expect.objectContaining({all_matching:true,filters:{health_status:'live'}})}));
  });
  it('shows insufficient-proxy errors without reporting success',async()=>{
    const {ProxyImport}=await import('./ProxyImport');const user=userEvent.setup();const saved=vi.fn();mocked.post.mockRejectedValue(new ApiError(422,'not_enough_proxies','Cần 2 proxy riêng.'));
    wrap(<ProxyImport selection={{all_matching:false,account_ids:['s1','s2'],exclude_ids:[],filters:{}}} count={2} total={2} filters={{}} onClose={()=>{}} onSaved={saved}/>);
    await user.type(screen.getByLabelText('Danh sách proxy'),'127.0.0.1:8080');await user.click(screen.getByRole('button',{name:'Gán proxy'}));
    expect(await screen.findByText('Cần 2 proxy riêng.')).toBeVisible();expect(saved).not.toHaveBeenCalled();
  });
});

describe('Compact account counters',()=>{
  it('removes FloodWait/error cards and filters blocked, frozen and all consistently',async()=>{
    const {AccountsPage}=await import('./Accounts');const user=userEvent.setup();
    mocked.get.mockImplementation(async(path:string)=>{
      if(path==='/api/auth/me')return {user:{id:'admin-id',username:'admin',role:'admin'},csrf_token:'test'};
      if(path==='/api/accounts')return {items:[],total:0};
      if(path==='/api/accounts/summary')return {total:80,health:{live:78,dead:1,frozen:1},spam:{blocked:12,limited:3}};
      return {items:[],total:0};
    });
    wrap(<AuthProvider><AccountsPage/></AuthProvider>);
    const blocked=await screen.findByRole('button',{name:'Bị chặn: 12'});
    const cards=blocked.parentElement!;
    expect(cards.querySelectorAll('button')).toHaveLength(6);
    expect(cards.textContent).not.toContain('FloodWait');expect(cards.textContent).not.toContain('Lỗi kiểm tra');
    expect(cards.querySelector('small')).toBeNull();
    expect(screen.getByRole('button',{name:'Chưa check: 0'}).querySelector('strong')).toHaveTextContent('0');
    await user.click(blocked);
    await waitFor(()=>expect(mocked.get).toHaveBeenCalledWith('/api/accounts',expect.objectContaining({spam_status:'blocked',health_status:undefined}),expect.anything()));
    expect(blocked).toHaveAttribute('aria-pressed','true');
    await user.click(screen.getByRole('button',{name:'Đóng băng: 1'}));
    await waitFor(()=>expect(mocked.get).toHaveBeenCalledWith('/api/accounts',expect.objectContaining({spam_status:undefined,health_status:'frozen'}),expect.anything()));
    await user.click(screen.getByRole('button',{name:'Tất cả: 80'}));
    await waitFor(()=>expect(mocked.get).toHaveBeenCalledWith('/api/accounts',expect.objectContaining({spam_status:undefined,health_status:undefined}),expect.anything()));
  });
});

describe('Streamlined session controls',()=>{
  async function open(total=80){
    const {AccountsPage}=await import('./Accounts');
    mocked.get.mockImplementation(async(path:string)=>{
      if(path==='/api/auth/me')return {user:{id:'admin-id',username:'admin',role:'admin'},csrf_token:'test'};
      if(path==='/api/accounts')return {items:total?[{...account,id:'first',name:'First',health_status:'live',spam_status:'clear'},{...account,id:'second',name:'Second',health_status:'live',spam_status:'limited'}]:[],total};
      if(path==='/api/accounts/summary')return {total,health:{live:total},spam:{limited:1}};
      return {items:[],total:0};
    });
    mocked.post.mockResolvedValue({id:'op',status:'running'});
    wrap(<AuthProvider><AccountsPage/></AuthProvider>);
    await screen.findByRole('button',{name:'Thêm tài khoản'});
    await screen.findByRole('button',{name:`Tất cả: ${total}`});
    return userEvent.setup();
  }
  it('removes duplicate panels and empty actions, while keeping secondary filters accessible',async()=>{
    const user=await open(0);
    expect(screen.queryByRole('heading',{name:'Kiểm tra spam & đóng băng'})).not.toBeInTheDocument();
    expect(screen.queryByRole('combobox',{name:'Thao tác session'})).not.toBeInTheDocument();
    expect(screen.queryByRole('checkbox',{name:'Chọn trang hiện tại'})).not.toBeInTheDocument();
    expect(screen.getAllByRole('button',{name:'Thêm tài khoản'})).toHaveLength(1);
    expect(screen.queryByRole('combobox',{name:'Lọc theo xác thực'})).not.toBeInTheDocument();
    await user.click(screen.getByRole('button',{name:'Lọc thêm'}));
    expect(screen.getByRole('combobox',{name:'Lọc theo xác thực'})).toBeVisible();
    expect(screen.getByRole('combobox',{name:'Lọc bật tắt'})).toBeVisible();
  });
  it('checks all filtered accounts but preserves explicit exclusions when applying to selected SS',async()=>{
    const user=await open();
    await user.selectOptions(screen.getByRole('combobox',{name:'Thao tác session'}),'proxy_check');
    await user.click(screen.getByRole('button',{name:'Check proxy tất cả theo bộ lọc'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk',expect.objectContaining({action:'proxy_check',all_matching:true,account_ids:[],exclude_ids:[]})));
    await user.click(screen.getByRole('button',{name:'Chọn toàn bộ 80 kết quả lọc'}));
    await user.click(screen.getByRole('checkbox',{name:'Chọn Second'}));
    await user.selectOptions(screen.getByRole('combobox',{name:'Thao tác session'}),'stop');
    await user.click(screen.getByRole('button',{name:'Tắt đã chọn'}));
    expect(await screen.findByRole('dialog',{name:'Tắt hàng loạt'})).toBeVisible();
    await user.click(screen.getByRole('button',{name:'Xác nhận'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalledWith('/api/account-bulk',expect.objectContaining({action:'stop',all_matching:true,account_ids:[],exclude_ids:['second']})));
  });
  it('keeps a visible delete button enabled only for the current selection',async()=>{
    const user=await open();
    expect(screen.getByRole('button',{name:'Xóa đã chọn'})).toBeVisible();
    expect(screen.getByRole('button',{name:'Xóa đã chọn'})).toBeDisabled();
    await user.click(screen.getByRole('checkbox',{name:'Chọn First'}));
    expect(screen.getByRole('button',{name:'Xóa đã chọn'})).toBeEnabled();
    await user.click(screen.getByRole('checkbox',{name:'Chọn First'}));
    expect(screen.queryByRole('option',{name:'Xóa'})).not.toBeInTheDocument();
    expect(screen.getByRole('button',{name:'Xóa đã chọn'})).toBeDisabled();
    await user.click(screen.getByRole('checkbox',{name:'Chọn Second'}));
    expect(screen.getByRole('combobox',{name:'Thao tác session'})).toHaveValue('spam_check');
    expect(mocked.post).not.toHaveBeenCalled();
  });
});


describe('Proxy result export menu',()=>{
  it('exports the chosen category using the other filters and reports empty results',async()=>{
    const {ProxyExportMenu}=await import('../components/ProxyExportMenu');const user=userEvent.setup();
    const download=vi.mocked(api.download);download.mockResolvedValue(new Blob([]));
    wrap(<ProxyExportMenu filters={{worker_id:'worker-1',proxy_status:'dead'}}/>);
    await user.click(screen.getByText('Xuất proxy',{exact:true}));
    await user.click(screen.getByRole('button',{name:'Đang chạy → .txt'}));
    expect(download).toHaveBeenCalledWith('/api/account-proxies/export',expect.objectContaining({worker_id:'worker-1',proxy_status:undefined,status:'alive'}));
    expect(await screen.findByText('Không có proxy thuộc nhóm này.')).toBeVisible();
    await user.click(screen.getByText('Xuất proxy',{exact:true}));await user.click(screen.getByRole('button',{name:'Die → .txt'}));
    expect(download).toHaveBeenLastCalledWith('/api/account-proxies/export',expect.objectContaining({status:'dead'}));
  });
});
