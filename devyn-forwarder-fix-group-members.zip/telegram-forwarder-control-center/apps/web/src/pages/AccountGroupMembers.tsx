import {useEffect,useState} from 'react';
import {api,ApiError} from '../api/client';
import type {Account,Page} from '../api/types';
import {Alert} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import type {AccountGroup} from './AccountGroups';

export function AccountGroupMembers({group,onBack,onChanged}:{group:AccountGroup;onBack:()=>void;onChanged:()=>void}){
 const [mode,setMode]=useState<'members'|'add'>('members'),[q,setQ]=useState(''),[page,setPage]=useState(1),[selected,setSelected]=useState<Set<string>>(new Set()),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const search=useDebounced(q);
 const accounts=useQuery(signal=>api.get<Page<Account>>('/api/accounts',{group_id:mode==='members'?group.id:undefined,q:search||undefined,page,page_size:50},signal),[group.id,mode,search,page]);
 useEffect(()=>{setPage(1);setSelected(new Set());},[mode,search,group.id]);
 function toggle(id:string){setSelected(old=>{const next=new Set(old);if(next.has(id))next.delete(id);else next.add(id);return next;});}
 async function add(){
  if(!selected.size)return;setBusy(true);setError('');setNotice('');
  try{const result=await api.post<{assigned:number}>('/api/account-groups/assign',{group_id:group.id,account_ids:[...selected]});setSelected(new Set());setMode('members');setQ('');setPage(1);setNotice(`Đã thêm ${result.assigned} SS vào nhóm.`);accounts.reload();onChanged();}
  catch(e){setError(e instanceof ApiError?e.message:'Không thêm được SS.');}finally{setBusy(false);}
 }
 return <div className="group-members stack tight">
  <div className="row between"><button className="btn sm" disabled={busy} onClick={onBack}>← Các nhóm</button><strong>{group.name}</strong><button className="btn sm primary" disabled={busy} onClick={()=>{setMode(mode==='members'?'add':'members');setQ('');setNotice('');setError('');}}>{mode==='members'?'Thêm SS':'Xem SS trong nhóm'}</button></div>
  <input className="input" aria-label="Tìm SS trong nhóm" placeholder={mode==='members'?'Tìm SS trong nhóm…':'Tìm SS để thêm…'} value={q} onChange={e=>setQ(e.target.value)} />
  {mode==='add'&&<p className="hint">Tích SS rồi bấm Thêm vào nhóm. SS thuộc nhóm khác sẽ được chuyển sang nhóm này.</p>}
  {error&&<Alert tone="bad">{error}</Alert>}{accounts.error&&<Alert tone="bad">{accounts.error.message}</Alert>}{notice&&<Alert tone="ok">{notice}</Alert>}
  <div className="group-member-list" aria-busy={accounts.loading||accounts.refreshing}>
   {(accounts.loading||accounts.refreshing)?<p className="hint">Đang tải…</p>:!accounts.data?.items.length?<p className="hint">{mode==='members'?'Nhóm chưa có SS phù hợp. Bấm Thêm SS để chọn tài khoản.':'Không tìm thấy tài khoản.'}</p>:accounts.data.items.map(a=><div className="group-member-item" key={a.id}>
    {mode==='add'&&<input type="checkbox" aria-label={`Thêm ${a.name}`} checked={selected.has(a.id)} disabled={busy||a.group_id===group.id||a.pending_deletion} onChange={()=>toggle(a.id)}/>}
    <div><strong>{a.name}</strong><div className="hint">{a.telegram_username?`@${a.telegram_username}`:a.phone_masked||'Session'}{mode==='add'&&a.group_name?` · ${a.group_id===group.id?'Đã ở nhóm này':`Nhóm ${a.group_name}`}`:''}</div></div>
   </div>)}
  </div>
  <div className="row between"><div className="row"><button className="btn sm" disabled={busy||page<=1||accounts.refreshing} onClick={()=>setPage(p=>p-1)}>Trước</button><span className="hint">Trang {page} / {Math.max(1,Math.ceil((accounts.data?.total??0)/50))} · {accounts.data?.total??0} SS</span><button className="btn sm" disabled={busy||accounts.refreshing||page*50>=(accounts.data?.total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div>{mode==='add'&&<button className="btn sm primary" disabled={busy||!selected.size||accounts.refreshing} onClick={()=>void add()}>{busy?'Đang thêm…':`Thêm vào nhóm (${selected.size})`}</button>}</div>
 </div>;
}
