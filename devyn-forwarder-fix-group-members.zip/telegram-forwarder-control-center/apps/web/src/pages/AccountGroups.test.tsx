import {render,screen,waitFor,within} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn(),patch:vi.fn()},request:vi.fn()};});
import {api} from '../api/client';
import {AccountGroups} from './AccountGroups';

it('opens a group and displays the sessions added directly inside it',async()=>{
 let added=false;
 vi.mocked(api.get).mockImplementation(async(_path,query)=>({items:query?.group_id?(added?[{id:'a1',name:'SS 1',group_id:'g1'}]:[]):[{id:'a1',name:'SS 1',group_id:null}],total:query?.group_id?(added?1:0):1}));
 vi.mocked(api.post).mockImplementation(async()=>{added=true;return {assigned:1};});
 const user=userEvent.setup();render(<AccountGroups groups={[{id:'g1',name:'Nhóm 1',count:0}]} selection={{all_matching:false,account_ids:[],exclude_ids:[],filters:{}}} count={0} onClose={()=>{}} onChanged={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:'Xem SS'}));
 expect(await screen.findByText(/Nhóm chưa có SS/)).toBeInTheDocument();
 await user.click(screen.getByRole('button',{name:'Thêm SS'}));await user.click(await screen.findByLabelText('Thêm SS 1'));
 await user.click(screen.getByRole('button',{name:'Thêm vào nhóm (1)'}));
 expect(await screen.findByText('Đã thêm 1 SS vào nhóm.')).toBeInTheDocument();await waitFor(()=>expect(within(screen.getByRole('dialog')).getByText('SS 1')).toBeVisible());
 expect(api.post).toHaveBeenCalledWith('/api/account-groups/assign',{group_id:'g1',account_ids:['a1']});
});

it('requires choosing a destination before changing any selected sessions',()=>{
 render(<AccountGroups groups={[{id:'g1',name:'Nhóm 1',count:1}]} selection={{all_matching:false,account_ids:['a1'],exclude_ids:[],filters:{}}} count={1} onClose={()=>{}} onChanged={()=>{}}/>);
 expect(screen.getByLabelText('Nhóm đích')).toHaveValue('');expect(screen.getByRole('button',{name:'Áp dụng (1)'})).toBeDisabled();
});
