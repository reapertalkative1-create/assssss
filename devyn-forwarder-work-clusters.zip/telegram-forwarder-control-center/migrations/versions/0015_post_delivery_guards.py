"""Persist fixed senders and post reservations, including existing post queues."""
from alembic import op
import sqlalchemy as sa
import uuid
from sqlalchemy.dialects import postgresql,sqlite
revision='0015'
down_revision='0014'
branch_labels=None
depends_on=None


def upgrade():
    owners=op.create_table('post_target_owners',
        sa.Column('target_key',sa.String(520),primary_key=True),
        sa.Column('account_id',sa.Uuid(),sa.ForeignKey('telegram_accounts.id',ondelete='CASCADE'),nullable=False),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    op.create_index('ix_post_target_owners_account_id','post_target_owners',['account_id'])
    deliveries=op.create_table('post_deliveries',
        sa.Column('source_chat_id',sa.BigInteger(),primary_key=True),
        sa.Column('message_id',sa.BigInteger(),primary_key=True),
        sa.Column('dest_chat_id',sa.BigInteger(),primary_key=True),
        sa.Column('job_id',sa.Uuid(),nullable=False),sa.Column('route_id',sa.Uuid(),nullable=False),
        sa.Column('created_at',sa.DateTime(timezone=True),nullable=False))
    conn=op.get_bind();meta=sa.MetaData()
    routes=sa.Table('forward_routes',meta,autoload_with=conn)
    jobs=sa.Table('forward_jobs',meta,autoload_with=conn)
    ins=postgresql.insert if conn.dialect.name=='postgresql' else sqlite.insert
    rows=conn.execute(sa.select(routes).order_by(routes.c.created_at,routes.c.id)).mappings().all()
    for r in rows:
        cfg=r['link_config']
        if not cfg or not cfg.get('queued_at'):continue
        keys={f'chat:{dst}' for dst in r['destination_chat_ids']}
        keys.update(('chat:' if ref.lstrip('-').isdigit() else 'ref:')+ref for ref in cfg['targets'])
        for key in sorted(keys):
            conn.execute(ins(owners).values(target_key=key,account_id=uuid.UUID(str(r['account_id'])),created_at=r['created_at']).on_conflict_do_nothing(index_elements=['target_key']))
        for job in conn.execute(sa.select(jobs).where(jobs.c.route_id==r['id']).order_by(jobs.c.created_at,jobs.c.id)).mappings():
            conn.execute(ins(deliveries).values(**{k:job[k] for k in ('source_chat_id','message_id','dest_chat_id','created_at')},route_id=uuid.UUID(str(job['route_id'])),job_id=uuid.UUID(str(job['id']))).on_conflict_do_nothing(index_elements=['source_chat_id','message_id','dest_chat_id']))


def downgrade():
    op.drop_table('post_deliveries')
    op.drop_index('ix_post_target_owners_account_id',table_name='post_target_owners')
    op.drop_table('post_target_owners')
