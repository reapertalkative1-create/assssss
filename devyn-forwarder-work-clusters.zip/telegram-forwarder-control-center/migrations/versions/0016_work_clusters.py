"""Named reusable work clusters; existing routes and deliveries stay unchanged."""
from alembic import op
import sqlalchemy as sa

revision = '0016'
down_revision = '0015'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('work_clusters',
        sa.Column('id', sa.Uuid(), primary_key=True),
        sa.Column('name', sa.String(64), nullable=False),
        sa.Column('name_key', sa.String(64), nullable=False, unique=True),
        sa.Column('account_ids', sa.JSON(), nullable=False),
        sa.Column('targets', sa.JSON(), nullable=False),
        sa.Column('mode', sa.String(8), nullable=False),
        sa.Column('delay_seconds', sa.Integer(), nullable=False),
        sa.Column('revision', sa.Integer(), nullable=False),
        sa.Column('created_by', sa.Uuid(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False))


def downgrade():
    op.drop_table('work_clusters')
