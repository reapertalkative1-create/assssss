import pytest
from app.errors import ApiError
from app.services.post_links import parse_targets
from tests.unit.test_accounts_api import env
from tests.unit.test_multi_senders import body,setup


def test_errors_show_exact_input_lines_and_keep_all_invalid_rows():
    lines=[f'@group_{i:03d}' for i in range(80)]+['Nhóm chưa có link','https://t.me/group_001/123']
    with pytest.raises(ApiError) as result:parse_targets('\ufeff'+'\r\n'.join(lines))
    error=result.value
    assert error.code=='invalid_target' and 'Nhóm chưa có link' in error.message and '81' in error.message
    assert error.details['invalid_count']==2 and error.details['valid_count']==80
    assert [(i['line'],i['value']) for i in error.details['invalid_targets']]==[(81,lines[80]),(82,lines[81])]


def test_error_details_are_bounded_and_line_numbers_include_blank_and_comment_rows():
    with pytest.raises(ApiError) as result:parse_targets('# comment\n\n'+'\n'.join(['x'*5000]*105))
    d=result.value.details
    assert d['invalid_count']==105 and len(d['invalid_targets'])==100
    assert d['invalid_targets'][0]['line']==3 and len(d['invalid_targets'][0]['value'])==301
    assert parse_targets('#comment\n\n@Target_group\nhttps://t.me/target_group')==['@target_group']


def test_validation_endpoint_needs_no_ss_and_never_creates_drafts_or_jobs(env):
    c,h=env.client,env.h
    r=c.post('/api/post-routes/validate-targets',headers=h,json={'targets_text':'@good_group\nNhóm lỗi\nhttps://evil.example/group'})
    assert r.status_code==422,r.text
    assert r.json()['error']['details']['invalid_targets'][0]['value']=='Nhóm lỗi'
    assert r.json()['error']['details']['invalid_count']==2
    r=c.post('/api/post-routes/validate-targets',headers=h,json={'targets_text':'@Good_group\nhttps://t.me/good_group\n-100123'})
    assert r.status_code==200 and r.json()['count']==2
    assert c.get('/api/routes').json()['total']==0 and c.get('/api/jobs').json()['total']==0


def test_batch_errors_return_line_details_without_partial_drafts(env):
    w,ids=setup(env,2);c,h=env.client,env.h
    r=c.post('/api/post-routes/batches',headers=h,json=body(ids,targets_text='@valid_group\nTên nhóm bị lỗi'))
    assert r.status_code==422,r.text
    assert r.json()['error']['details']['invalid_targets'][0]['line']==2
    assert 'Tên nhóm bị lỗi' in r.json()['error']['message']
    assert c.get('/api/routes').json()['total']==0
