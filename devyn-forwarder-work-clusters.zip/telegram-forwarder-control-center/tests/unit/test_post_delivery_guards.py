import asyncio
import uuid
from datetime import timedelta
from sqlalchemy import select,update
from app.db import make_engine,make_sessionmaker
from app.models import ForwardJob,ForwardRoute,PostDelivery,PostTargetOwner,TelegramAccount
from app.services import jobs as jobsvc
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_routes_jobs_api import jw,SRC,DST,DST2
from tests.unit.test_post_routes import create,verify
from tests.unit.test_multi_senders import body,setup


def start_post(env,st):
    route,_=create(env,st);verify(env,st,route['id'])
    r=env.client.post('/api/routes/'+route['id']+'/start',headers=env.h)
    assert r.status_code==200,r.text
    return r.json()


def test_reservations_survive_new_draft_and_deleting_old_route(env,jw):
    st=jw();c,h=env.client,env.h
    first=start_post(env,st)
    second=start_post(env,st)
    assert second['status']=='stopped' and second['link_config']['duplicate_count']==2
    for action in ('start','resume'):
        assert c.post('/api/routes/'+second['id']+'/'+action,headers=h).json()['status']=='stopped'
    assert c.get('/api/jobs').json()['total']==2
    c.post('/api/routes/'+first['id']+'/stop',headers=h,json={'cancel_pending':True})
    assert c.post('/api/routes/'+first['id']+'/delete',headers=h,json={'confirm_name':first['name']}).status_code==200
    assert c.get('/api/jobs').json()['total']==0
    third=start_post(env,st)
    assert third['link_config']['queued_count']==0 and third['link_config']['duplicate_count']==2
    assert c.get('/api/jobs').json()['total']==0
    assert run_db(env.settings,lambda db:db.scalar(select(PostDelivery.job_id).limit(1))) is not None


def test_group_sender_stays_fixed_across_batches_and_aliases(env,jw):
    st=jw();c,h=env.client,env.h
    first=start_post(env,st)
    other=env.make_account('A comes first',st.worker);env.authorize(st.worker,other)
    payload=body([other,st.aid],post_link='https://t.me/source_group/124',targets_text='@target_two\n@target_one\n@brand_new')
    response=c.post('/api/post-routes/batches',headers=h,json=payload)
    assert response.status_code==201,response.text
    assigned={row['account_id']:row['link_config']['targets'] for row in response.json()['items']}
    assert set(assigned[st.aid])=={'@target_one','@target_two'} and assigned[other]==['@brand_new']
    payload=body([other],targets_text='@target_one')
    r=c.post('/api/post-routes/batches',headers=h,json=payload)
    assert r.status_code==409 and r.json()['error']['code']=='target_owner_mismatch'
    # New alias cannot bypass the canonical Telegram chat owner.
    r=c.post('/api/post-routes',headers=h,json={'name':'Alias','account_id':other,'post_link':'https://t.me/source_group/124','targets_text':'@another_alias'})
    rid=r.json()['id'];assert c.post('/api/routes/'+rid+'/verify',headers=h).status_code==202
    cmd=st.worker.poll()[0]
    st.worker.result(cmd['id'],result={'post':{'source_chat_id':SRC,'message_id':124,'targets':[{'index':0,'id':DST,'ok':True,'can_send':True}]}})
    r=c.post('/api/routes/'+rid+'/start',headers=h)
    assert r.status_code==409 and r.json()['error']['code']=='target_owner_mismatch'
    assert run_db(env.settings,lambda db:db.get(PostTargetOwner,'ref:@another_alias')) is None
    assert c.get('/api/jobs').json()['total']==2


def test_unknown_send_is_held_until_explicit_review(env,jw):
    st=jw();c,h=env.client,env.h;route=start_post(env,st);rid=route['id']
    job=st.worker.claim()[0];assert job['post_once']
    st.worker.start([job]);st.worker.results([st.worker.retry(job,'network_error')])
    result=c.get('/api/jobs/'+job['id']).json()
    assert result['status']=='failed' and result['last_error_code']=='delivery_uncertain'
    assert c.get('/api/routes/'+rid).json()['link_config']['pause_reason']=='delivery_uncertain'
    assert st.worker.claim()==[]
    assert c.post('/api/jobs/'+job['id']+'/retry',headers=h).status_code==409
    assert c.post('/api/jobs/bulk',headers=h,json={'action':'retry','status':'failed','route_id':rid}).status_code==409
    assert c.post('/api/routes/'+rid+'/resume',headers=h).status_code==409
    r=c.post('/api/jobs/'+job['id']+'/review-delivery',headers=h,json={'delivered':False})
    assert r.status_code==200 and r.json()['status']=='pending'
    assert c.get('/api/routes/'+rid).json()['status']=='paused'  # review does not start sending
    assert c.post('/api/jobs/'+job['id']+'/review-delivery',headers=h,json={'delivered':True}).status_code==409
    assert c.post('/api/routes/'+rid+'/resume',headers=h).status_code==200
    async def overdue(db):
        await db.execute(update(ForwardJob).where(ForwardJob.route_id==uuid.UUID(rid)).values(available_at=utcnow()-timedelta(minutes=2),claimed_at=utcnow()-timedelta(minutes=2),started_at=utcnow()-timedelta(minutes=2)))
    run_db(env.settings,overdue)
    retry=st.worker.claim()[0];st.worker.start([retry]);st.worker.results([st.worker.fail(retry,'delivery_uncertain')])
    r=c.post('/api/jobs/'+retry['id']+'/review-delivery',headers=h,json={'delivered':True})
    assert r.status_code==200 and r.json()['status']=='succeeded' and r.json()['result']['manually_confirmed']


def test_expired_running_post_is_not_retried_after_worker_restart(env,jw):
    st=jw();c,h=env.client,env.h;route=start_post(env,st)
    job=st.worker.claim()[0];st.worker.start([job])
    async def expire(db):
        await db.execute(update(ForwardJob).where(ForwardJob.id==uuid.UUID(job['id'])).values(lease_expires_at=utcnow()-timedelta(seconds=1)))
        return await jobsvc.recover_abandoned(db,utcnow(),env.settings)
    run_db(env.settings,expire)
    j=c.get('/api/jobs/'+job['id']).json()
    assert j['status']=='failed' and j['last_error_code']=='delivery_uncertain'
    assert c.get('/api/routes/'+route['id']).json()['status']=='paused'
    assert st.worker.claim()==[]


def test_proxy_or_restriction_between_claim_and_send_prevents_start(env,jw):
    st=jw();c,h=env.client,env.h;route=start_post(env,st)
    job=st.worker.claim()[0]
    async def bad_proxy(db):(await db.get(TelegramAccount,uuid.UUID(st.aid))).__setattr__('proxy_status','dead')
    run_db(env.settings,bad_proxy)
    assert st.worker.start([job]).json()['lost']==[job['id']]
    assert st.worker.claim()==[]
    c.post('/api/routes/'+route['id']+'/pause',headers=h)
    r=c.post('/api/routes/'+route['id']+'/resume',headers=h)
    assert r.status_code==409 and r.json()['error']['code']=='proxy_dead'
    async def fix_proxy(db):
        a=await db.get(TelegramAccount,uuid.UUID(st.aid));a.proxy_status='alive';a.spam_status='limited'
    run_db(env.settings,fix_proxy)
    assert st.worker.claim()==[]
    assert c.post('/api/routes/'+route['id']+'/resume',headers=h).status_code==409


def test_concurrent_post_reservations_only_create_one_job(env,jw):
    st=jw()
    r1,_=create(env,st);r2,_=create(env,st)
    async def go():
        engine=make_engine(env.settings.database_url);sessions=make_sessionmaker(engine)
        async def enqueue(rid):
            async with sessions() as db:
                r=await db.get(ForwardRoute,uuid.UUID(rid));r.destination_chat_ids=[DST]
                result=await jobsvc.enqueue(db,r,[(SRC,123)],utcnow())
                await db.commit();return result
        try:return await asyncio.gather(enqueue(r1['id']),enqueue(r2['id']))
        finally:await engine.dispose()
    results=asyncio.run(go())
    assert sorted(results)==[(0,1),(1,0)]
    assert env.client.get('/api/jobs').json()['total']==1


def test_post_worker_reports_uncertainty_but_respects_explicit_waits():
    from tests.unit.test_forward_engine import build,AID
    from worker.telegram_backend import BackendError
    async def go():
        eng,client,backend,mgr=build()
        job={'id':'job','epoch':1,'account_id':AID,'source_chat_id':SRC,'message_id':123,'dest_chat_id':DST,'mode':'forward','post_once':True}
        backend.forward_script=[BackendError('network_error'),BackendError('flood_wait',7200),BackendError('destination_forbidden')]
        uncertain=await eng._run_job(job);waiting=await eng._run_job(job);forbidden=await eng._run_job(job)
        assert uncertain['status']=='failed' and uncertain['error_code']=='delivery_uncertain'
        assert waiting['status']=='retry' and waiting['retry_after']==7200
        assert forbidden['status']=='failed' and forbidden['error_code']=='destination_forbidden'
    asyncio.run(go())


def test_floodwait_longer_than_one_day_blocks_every_route_for_same_ss(env,jw):
    st=jw();c,h=env.client,env.h;route=start_post(env,st)
    job=st.worker.claim()[0];st.worker.start([job])
    before=utcnow();st.worker.results([st.worker.retry(job,'flood_wait',3*86400)])
    from datetime import datetime
    a=c.get('/api/accounts/'+st.aid).json()
    until=datetime.fromisoformat(a['flood_wait_until'].replace('Z','+00:00'))
    assert (until-before).total_seconds()>=3*86400
    assert c.get('/api/jobs/'+job['id']).json()['status']=='retry_wait'
    assert c.get('/api/routes/'+route['id']).json()['status']=='active'
    assert st.worker.claim()==[]


def test_1000_selected_sessions_for_200_groups_only_assigns_200(env):
    w=env.make_worker();c,h=env.client,env.h
    async def seed(db):
        ids=[]
        for i in range(1000):
            aid=uuid.uuid4();ids.append(str(aid));db.add(TelegramAccount(id=aid,name=f'Fleet {i:04d}',name_key=f'fleet {i:04d}',auth_state='authorized',assigned_worker_id=uuid.UUID(w.id)))
        return ids
    ids=run_db(env.settings,seed)
    response=c.post('/api/post-routes/batches',headers=h,json=body(ids,targets_text='\n'.join(f'@group_{i:03d}' for i in range(200))))
    assert response.status_code==201,response.text
    data=response.json();assert len(data['items'])==200 and data['unused_senders']==800
    targets=[target for row in data['items'] for target in row['link_config']['targets']]
    assert len(targets)==len(set(targets))==200
    assert c.get('/api/jobs').json()['total']==0
