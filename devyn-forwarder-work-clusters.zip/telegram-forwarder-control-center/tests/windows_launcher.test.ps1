param([string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$originalLocation = Get-Location
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('tfcc launcher space & ' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $testRoot)
function Assert-True { param($Value, [string]$Message); if (-not $Value) { throw $Message } }
function Assert-Fails { param([scriptblock]$Action); $failed = $false; try { & $Action } catch { $failed = $true }; Assert-True $failed 'Expected an error, but the action succeeded.' }
try {
    $launcher = Join-Path $ProjectRoot 'scripts/windows.ps1'
    $tokens = $null; $parseErrors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($launcher, [ref]$tokens, [ref]$parseErrors)
    Assert-True ($parseErrors.Count -eq 0) 'PowerShell syntax errors.'
    . $launcher -NoBrowser
    $script:AppRoot = $testRoot
    $script:ConfigFile = Join-Path $testRoot '.env.docker'
    $script:ReadyFile = Join-Path $testRoot '.docker-ready'
    New-DockerConfig
    $config = Read-DockerConfig
    Assert-True ($config['TFCC_DB_PASSWORD'] -match '^[0-9a-f]{64}$') 'DB password must have 32 random bytes.'
    Assert-True ($config['TFCC_SECRET_KEY'] -match '^[0-9a-f]{64}$') 'App secret must have 32 random bytes.'
    $rawKey = [Convert]::FromBase64String($config['TFCC_SESSION_ENCRYPTION_KEY'].Replace('-', '+').Replace('_', '/'))
    Assert-True ($rawKey.Length -eq 32) 'Invalid Fernet key.'
    $hash = (Get-FileHash -LiteralPath $script:ConfigFile).Hash
    New-DockerConfig
    Assert-True ((Get-FileHash -LiteralPath $script:ConfigFile).Hash -eq $hash) 'Rerun overwrote existing keys.'
    $saved = [IO.File]::ReadAllText($script:ConfigFile)
    [IO.File]::AppendAllText($script:ConfigFile, "`r`nTFCC_HTTP_PORT=not-a-port`r`n")
    Assert-Fails { Read-DockerConfig }
    [IO.File]::WriteAllText($script:ConfigFile, $saved)

    $script:MockEngine = 'linux'; $script:MockVersion = '2.40.3'; $script:MockExit = 0
    $script:InteractiveCalls = 0
    function docker {
        [CmdletBinding(PositionalBinding=$false)]
        param([Parameter(ValueFromPipeline=$true)]$InputObject, [Parameter(ValueFromRemainingArguments=$true)][string[]]$Values)
        $global:LASTEXITCODE = $script:MockExit
        if ($Values[0] -eq 'info') { return $script:MockEngine }
        if ($Values -contains 'version') { return $script:MockVersion }
        if ($Values -contains 'create-admin') { $script:InteractiveCalls++ }
        if ($Values -contains 'input-probe' -or $Values -contains 'response-probe') {
            Assert-True ($OutputEncoding.GetPreamble().Length -eq 0) 'Native input must use UTF-8 without BOM.'
            if ($Values -contains 'response-probe') { return ([char]0xFEFF + '{"ok":true}') }
            return '{"ok":true}'
        }
    }
    Assert-Docker
    $script:MockEngine = 'windows'; Assert-Fails { Assert-Docker }; $script:MockEngine = 'linux'
    $script:MockVersion = '2.19.0'; Assert-Fails { Assert-Docker }; $script:MockVersion = '2.40.3'
    $script:MockExit = 9; Assert-Fails { Invoke-Docker -DockerArgs @('info') }; $script:MockExit = 0
    $originalEncoding = $OutputEncoding
    try {
        $OutputEncoding = New-Object Text.UTF8Encoding $true
        foreach ($probe in @('input-probe', 'response-probe')) {
            $response = Invoke-DockerJson -DockerArgs @($probe) -InputJson '{}'
            Assert-True $response.ok 'JSON response was not decoded.'
            Assert-True ($OutputEncoding.GetPreamble().Length -eq 3) 'Caller output encoding was not restored.'
        }
    } finally { $OutputEncoding = $originalEncoding }

    $script:Calls = New-Object 'Collections.Generic.List[string]'
    $script:AdminStatus = 0
    function Invoke-Docker {
        param([string[]]$DockerArgs, [int[]]$AllowedCodes = @(0))
        $script:Calls.Add(($DockerArgs -join '|'))
        if ($DockerArgs -contains 'docker/admin_status.py') { return $script:AdminStatus }
        return 0
    }
    $script:AutoCredential = 'tfw_' + ('a' * 32) + '.' + ('s' * 43)
    function Invoke-DockerJson {
        param([string[]]$DockerArgs, [string]$InputJson)
        if ($DockerArgs -contains '--wait-online') {
            return [pscustomobject]@{ id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; name = 'Local-MY-PC'; status = 'online' }
        }
        return [pscustomobject]@{ id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; name = 'Local-MY-PC'; credential = $script:AutoCredential; previous_registered = $null }
    }
    Start-Application -Config $config
    Assert-True (@($script:Calls | Where-Object { $_ -match 'stop\|worker$' }).Count -eq 1) 'Any old worker must drain first.'
    Assert-True (@($script:Calls | Where-Object { $_ -match '--profile\|telegram\|up.*\|worker$' }).Count -eq 1) 'Worker must connect without Telegram API keys.'
    Assert-True ((Read-DockerConfig)['TFCC_WORKER_CREDENTIAL'] -eq $script:AutoCredential) 'Auto credential was not saved.'
    $autoHash = (Get-FileHash -LiteralPath $script:ConfigFile).Hash
    $script:Calls.Clear()
    $config['TFCC_WORKER_CREDENTIAL'] = 'test-credential'
    $config['TFCC_WORKER_TELEGRAM_API_ID'] = '123'
    $config['TFCC_WORKER_TELEGRAM_API_HASH'] = 'test-hash'
    Start-Application -Config $config
    Assert-True (@($script:Calls | Where-Object { $_ -match '--profile\|telegram\|up.*\|worker$' }).Count -eq 1) 'Complete worker config must start the worker profile.'

    $Mode = 'Run'
    Assert-Fails { Main }
    $script:Calls.Clear()
    Start-Setup
    $workerStop = -1; $apiStop = -1; $migration = -1
    for ($i = 0; $i -lt $script:Calls.Count; $i++) {
        if ($script:Calls[$i] -match 'stop\|--timeout\|30\|worker$') { $workerStop = $i }
        if ($script:Calls[$i] -match 'stop\|web\|api$') { $apiStop = $i }
        if ($script:Calls[$i] -match 'alembic\|upgrade\|head$') { $migration = $i }
    }
    Assert-True ($workerStop -ge 0 -and $apiStop -gt $workerStop -and $migration -gt $apiStop) 'Setup must drain the worker and stop API writes before migrating delivery history.'
    Assert-True (Test-Path -LiteralPath $script:ReadyFile) 'Setup did not mark successful completion.'
    Assert-True ($script:InteractiveCalls -eq 0) 'Setup must preserve an existing admin.'
    Main
    Assert-True ((Get-FileHash -LiteralPath $script:ConfigFile).Hash -eq $autoHash) 'Run/setup changed persisted configuration.'
    $script:AdminStatus = 3
    function Read-Host { param([string]$Prompt); return 'test-admin' }
    Start-Setup
    Assert-True ($script:InteractiveCalls -eq 1) 'Fresh setup must create an admin interactively.'
    [IO.File]::WriteAllText($script:ReadyFile, 'different-installation')
    Assert-Fails { Main }
    $held = [IO.File]::Open((Join-Path $script:AppRoot '.launcher.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    try { Assert-Fails { Main } } finally { $held.Dispose() }
    Write-Host 'PASS: syntax, keys, rerun safety, Docker checks, auto connection without Telegram keys, setup, run and launch lock.'
} finally {
    Set-Location -LiteralPath $originalLocation
    Remove-Item -LiteralPath $testRoot -Recurse -Force
}
