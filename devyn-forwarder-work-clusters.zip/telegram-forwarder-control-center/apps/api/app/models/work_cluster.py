"""Reusable sender/target configurations, separate from individual deliveries."""
import uuid
from datetime import datetime
from sqlalchemy import JSON, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
from app.types import UTCDateTime, utcnow


class WorkCluster(Base):
    __tablename__ = 'work_clusters'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)
    account_ids: Mapped[list] = mapped_column(JSON)
    targets: Mapped[list] = mapped_column(JSON)
    mode: Mapped[str] = mapped_column(String(8), default='forward')
    delay_seconds: Mapped[int] = mapped_column(Integer, default=60)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
