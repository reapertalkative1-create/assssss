"""Persistent ownership and reservations for one-pass post delivery."""
import uuid
from datetime import datetime
from sqlalchemy import BigInteger, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
from app.types import UTCDateTime, utcnow


class PostTargetOwner(Base):
    __tablename__ = 'post_target_owners'
    target_key: Mapped[str] = mapped_column(String(520), primary_key=True)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey('telegram_accounts.id', ondelete='CASCADE'), index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class PostDelivery(Base):
    __tablename__ = 'post_deliveries'
    source_chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    message_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    dest_chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    # Audit pointers intentionally survive deletion of an account, route or job.
    job_id: Mapped[uuid.UUID] = mapped_column()
    route_id: Mapped[uuid.UUID] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
