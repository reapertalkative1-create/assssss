import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import ForwardJob, ForwardRoute, Role, RouteCheckpoint, TelegramAccount, WorkerCommand
from app.schemas import Page
from app.schemas_accounts import CommandAccepted
from app.schemas_forwarding import RouteCreate, RouteDelete, RouteOut, RouteStop, RouteUpdate
from app.services import accounts as acct_svc
from app.services import jobs as job_svc
from app.services import routes as svc
from app.types import utcnow

router = APIRouter(prefix="/api/routes", tags=["routes"])
admin_only = require_role(Role.ADMIN)


async def _out(db: AsyncSession, routes: list[ForwardRoute]) -> list[dict]:
    ids = [r.id for r in routes]
    stats, cps = await svc.stats_for(db, ids), await svc.checkpoints_for(db, ids)
    accounts={a.id:a for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.id.in_({r.account_id for r in routes})))).scalars()} if routes else {}
    commands={str(c.id):c for c in (await db.execute(select(WorkerCommand).where(WorkerCommand.route_id.in_(ids),WorkerCommand.type=='verify_post'))).scalars()} if ids else {}
    return [{
        "id": r.id, "name": r.name, "account_id": r.account_id, "account_name": accounts[r.account_id].name if r.account_id in accounts else None,
        'account_restriction':('frozen' if accounts[r.account_id].health_status=='frozen' or accounts[r.account_id].health_override=='frozen' else accounts[r.account_id].spam_status if accounts[r.account_id].spam_status in ('limited','blocked') else None) if r.account_id in accounts else None,
        'account_wait_until':accounts[r.account_id].flood_wait_until if r.account_id in accounts else None,
        'account_issue':svc.account_issue(accounts[r.account_id]) if r.account_id in accounts else None,
        'link_config':{k:v for k,v in r.link_config.items() if k not in ('verify_command_id','request_signature')} if r.link_config else None,
        'verification_pending':bool(r.link_config and (c:=commands.get(r.link_config.get('verify_command_id',''))) and c.status in ('pending','delivered') and c.expires_at>utcnow()),
        'verification_error':r.link_config.get('verification_error') if r.link_config else None,
        "source_chat_ids": r.source_chat_ids, "destination_chat_ids": r.destination_chat_ids, "mode": r.mode,
        "filters": r.filters, "priority": r.priority, "rate_per_minute": r.rate_per_minute,
        "max_attempts": r.max_attempts, "status": r.status, "verified": svc.verification_ok(r),
        "verified_at": r.verified_at, "verification": r.verification, "stats": stats[r.id],
        "checkpoints": cps[r.id], "created_at": r.created_at, "updated_at": r.updated_at,
    } for r in routes]


async def _get(db: AsyncSession, route_id: uuid.UUID) -> ForwardRoute:
    r = await db.get(ForwardRoute, route_id)
    if r is None:
        raise ApiError(404, "not_found", "Không tìm thấy tuyến chuyển tiếp.")
    return r


@router.get("", response_model=Page[RouteOut])
async def list_routes(
    q: str | None = Query(default=None, max_length=64),
    status: str | None = Query(default=None, pattern="^(stopped|active|paused)$"),
    account_id: uuid.UUID | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    _: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(ForwardRoute)
    if q:
        stmt = stmt.where(ForwardRoute.name_key.contains(q.strip().lower(), autoescape=True))
    if status:
        stmt = stmt.where(ForwardRoute.status == status)
    if account_id:
        stmt = stmt.where(ForwardRoute.account_id == account_id)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(ForwardRoute.created_at.desc(), ForwardRoute.name_key)
                             .offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[RouteOut](items=await _out(db, list(rows)), total=total, page=page, page_size=page_size)


@router.post("", response_model=RouteOut, status_code=201)
async def create_route(body: RouteCreate, request: Request, auth: AuthContext = Depends(admin_only),
                       db: AsyncSession = Depends(get_db, scope="function")):
    if await db.get(TelegramAccount, body.account_id) is None:
        raise ApiError(404, "account_not_found", "Không tìm thấy tài khoản Telegram.")
    r = ForwardRoute(name=body.name, name_key=body.name.lower(), account_id=body.account_id,
                     source_chat_ids=body.source_chat_ids, destination_chat_ids=body.destination_chat_ids,
                     mode=body.mode, filters=body.filters.model_dump(), priority=body.priority,
                     rate_per_minute=body.rate_per_minute, max_attempts=body.max_attempts, created_by=auth.user.id)
    db.add(r)
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên tuyến đã tồn tại.") from None
    await record_audit(db, request, "route.create", actor=auth.user, target_type="route", target_id=str(r.id),
                       details={"name": r.name, "sources": len(r.source_chat_ids), "destinations": len(r.destination_chat_ids),
                                "mode": r.mode})
    return (await _out(db, [r]))[0]


@router.get("/{route_id}", response_model=RouteOut)
async def get_route(route_id: uuid.UUID, _: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return (await _out(db, [await _get(db, route_id)]))[0]


@router.patch("/{route_id}", response_model=RouteOut)
async def update_route(route_id: uuid.UUID, body: RouteUpdate, request: Request,
                       auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    r = await _get(db, route_id)
    changed = []
    if r.link_config is not None:raise ApiError(409,'post_route_locked','Dùng biểu mẫu Gửi bài từ liên kết để sửa đợt gửi.')
    for field in ("mode", "priority", "rate_per_minute", "max_attempts"):
        v = getattr(body, field)
        if v is not None and v != getattr(r, field):
            setattr(r, field, v)
            changed.append(field)
    if body.filters is not None and body.filters.model_dump() != r.filters:
        r.filters = body.filters.model_dump()
        if r.status == "active":
            await svc.check_no_loops(db, r)
        changed.append("filters")
    if body.name is not None and body.name != r.name:
        r.name, r.name_key = body.name, body.name.lower()
        changed.append("name")
    new_src = body.source_chat_ids if body.source_chat_ids is not None else r.source_chat_ids
    new_dst = body.destination_chat_ids if body.destination_chat_ids is not None else r.destination_chat_ids
    if new_src != r.source_chat_ids or new_dst != r.destination_chat_ids:
        if r.status != "stopped":
            raise ApiError(409, "route_must_be_stopped", "Hãy dừng tuyến trước khi đổi nguồn/đích.")
        if set(new_src) & set(new_dst):
            raise ApiError(422, "validation_error", "Một chat không thể vừa là nguồn vừa là đích.")
        r.source_chat_ids, r.destination_chat_ids = new_src, new_dst
        svc.invalidate_verification(r)   # new chats must be verified again before the route can start
        changed.append("chats")
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên tuyến đã tồn tại.") from None
    if changed:
        await record_audit(db, request, "route.update", actor=auth.user, target_type="route", target_id=str(r.id),
                           details={"changed": changed})
    return (await _out(db, [r]))[0]


@router.post("/{route_id}/delete", status_code=200)
async def delete_route(route_id: uuid.UUID, body: RouteDelete, request: Request,
                       auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    r = await _get(db, route_id)
    if body.confirm_name != r.name:
        raise ApiError(422, "confirmation_mismatch", "Tên xác nhận không khớp với tên tuyến.")
    if r.status != "stopped":
        raise ApiError(409, "route_must_be_stopped", "Hãy dừng tuyến trước khi xóa.")
    busy = (await db.execute(select(func.count()).select_from(ForwardJob).where(
        ForwardJob.route_id == r.id, ForwardJob.status.in_(("claimed", "running"))))).scalar_one()
    if busy:
        raise ApiError(409, "jobs_in_progress", "Còn tác vụ đang chạy, thử lại sau ít giây.")
    removed = (await db.execute(delete(ForwardJob).where(ForwardJob.route_id == r.id))).rowcount or 0
    await db.execute(delete(RouteCheckpoint).where(RouteCheckpoint.route_id == r.id))
    await db.execute(delete(WorkerCommand).where(WorkerCommand.route_id == r.id))
    await record_audit(db, request, "route.delete", actor=auth.user, target_type="route", target_id=str(r.id),
                       details={"name": r.name, "jobs_removed": removed})
    await db.delete(r)
    return {"status": "deleted", "jobs_removed": removed}


@router.post("/{route_id}/verify", response_model=CommandAccepted, status_code=202)
async def verify_route(route_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                       db: AsyncSession = Depends(get_db, scope="function")):
    """Asks the owning worker whether the account can READ every source and WRITE to every destination."""
    r = await _get(db, route_id)
    acct = await db.get(TelegramAccount, r.account_id)
    if acct.auth_state != "authorized":
        raise ApiError(409, "account_not_authorized", "Tài khoản Telegram chưa được xác thực.")
    if request.app.state.secret_box is None:
        raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session.")
    settings, now = request.app.state.settings, utcnow()
    if acct.flood_wait_until and acct.flood_wait_until>now:raise ApiError(409,'flood_wait','Telegram yêu cầu tài khoản chờ. Kiểm tra lại sau khi hết thời gian chờ.')
    worker = await acct_svc.worker_can_take_commands(db, acct.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
    if r.link_config:
        if r.link_config.get('queued_at'):raise ApiError(409,'post_route_locked','Đợt đã tạo hàng đợi; không xác minh lại làm đổi danh sách đích.')
        old_id=r.link_config.get('verify_command_id')
        old=await db.get(WorkerCommand,uuid.UUID(old_id)) if old_id else None
        if old and old.status in ('pending','delivered') and old.expires_at>now:return {'command_id':old.id,'status':old.status}
        cmd=acct_svc.create_command(db,request.app.state.secret_box,worker_id=worker.id,account_id=acct.id,type='verify_post',payload={'post_link':r.link_config['post_link'],'targets':r.link_config['targets']},ttl=1800,created_by=auth.user.id,now=now,route_id=r.id)
        r.link_config={**r.link_config,'verify_command_id':str(cmd.id),'verification_error':None,'checks':[]}
        svc.invalidate_verification(r)
    else:
        cmd = acct_svc.create_command(db, request.app.state.secret_box, worker_id=worker.id, account_id=acct.id,
                                      type="verify_chats", payload={"chat_ids": sorted(svc.all_chats(r))},
                                      ttl=settings.command_ttl_seconds, created_by=auth.user.id, now=now, route_id=r.id)
    await record_audit(db, request, "route.verify", actor=auth.user, target_type="route", target_id=str(r.id),
                       details={"command_id": str(cmd.id)})
    return {"command_id": cmd.id, "status": "pending"}


async def _transition(route_id, action, request, auth, db, cancel_pending=False):
    r = (await db.execute(select(ForwardRoute).where(ForwardRoute.id==route_id).with_for_update())).scalar_one_or_none()
    if r is None:raise ApiError(404,'not_found','Không tìm thấy tuyến.')
    acct = await db.get(TelegramAccount, r.account_id)
    now = utcnow()
    target = {"start": "active", "resume": "active", "pause": "paused", "stop": "stopped"}[action]
    if target=='active' and r.link_config and r.link_config.get('queued_at') and not r.link_config.get('pause_reason'):
        unfinished=(await db.execute(select(ForwardJob.id).where(ForwardJob.route_id==r.id,
            ForwardJob.status.in_(('pending','retry_wait','claimed','running'))).limit(1))).first()
        if not unfinished:
            # Completed or entirely deduplicated batches never enable an idle SS.
            r.status='stopped'
            return (await _out(db,[r]))[0]
    if action == "pause" and r.status == "stopped":
        raise ApiError(409, "route_not_active", "Tuyến đang dừng, không thể tạm dừng.")
    if action == "resume" and r.status == "stopped":
        raise ApiError(409, "route_not_paused", "Tuyến đang dừng; hãy dùng start.")
    if r.status != target:   # idempotent: repeating a call changes nothing and writes no audit
        if target == "active":
            previous_desired=acct.desired_state
            if r.link_config:
                await acct_svc.worker_can_take_commands(db,acct.assigned_worker_id,request.app.state.settings.heartbeat_timeout_seconds,now)
                acct.desired_state='running'
            await svc.check_startable(db, r, acct)
            if r.link_config and not r.link_config.get('queued_at'):
                if r.link_config.get('batch_id'):
                    others=(await db.execute(select(ForwardRoute).where(ForwardRoute.id!=r.id,ForwardRoute.link_config['batch_id'].as_string()==r.link_config['batch_id']))).scalars().all()
                    if any(set(other.destination_chat_ids)&set(r.destination_chat_ids) for other in others):
                        raise ApiError(409,'duplicate_batch_target','Có nhóm Telegram trùng giữa các SS trong cụm. Sửa danh sách nhóm rồi kiểm tra lại trước khi gửi.')
                from datetime import datetime
                from app.services.post_delivery import bind_route
                await bind_route(db,r,now)
                base=datetime.fromisoformat(r.link_config['scheduled_at']) if r.link_config.get('scheduled_at') else now
                created,duplicates=await job_svc.enqueue(db,r,[(r.source_chat_ids[0],r.link_config['message_id'])],max(base,now),spacing_seconds=r.link_config['delay_seconds'])
                r.link_config={**r.link_config,'queued_at':now.isoformat()}
                if not created:
                    target='stopped'
                    acct.desired_state=previous_desired
            r.started_at = now
        r.status = target
        await record_audit(db, request, f"route.{action}", actor=auth.user, target_type="route", target_id=str(r.id))
    if action == "stop" and cancel_pending:
        n = await job_svc.cancel_pending_for_route(db, r.id, now)
        if n:
            await record_audit(db, request, "route.cancel_pending", actor=auth.user, target_type="route",
                               target_id=str(r.id), details={"jobs": n})
    return (await _out(db, [r]))[0]


@router.post("/{route_id}/start", response_model=RouteOut)
async def start_route(route_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                      db: AsyncSession = Depends(get_db, scope="function")):
    return await _transition(route_id, "start", request, auth, db)


@router.post("/{route_id}/pause", response_model=RouteOut)
async def pause_route(route_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                      db: AsyncSession = Depends(get_db, scope="function")):
    return await _transition(route_id, "pause", request, auth, db)


@router.post("/{route_id}/resume", response_model=RouteOut)
async def resume_route(route_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                       db: AsyncSession = Depends(get_db, scope="function")):
    return await _transition(route_id, "resume", request, auth, db)


@router.post("/{route_id}/stop", response_model=RouteOut)
async def stop_route(route_id: uuid.UUID, request: Request, body: RouteStop | None = None,
                     auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return await _transition(route_id, "stop", request, auth, db, cancel_pending=bool(body and body.cancel_pending))
