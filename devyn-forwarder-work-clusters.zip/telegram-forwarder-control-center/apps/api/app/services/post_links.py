"""Parse only Telegram links; resolving a reference never joins a group."""
import re
from urllib.parse import urlsplit, parse_qs
from app.errors import ApiError
USERNAME = re.compile(r'[A-Za-z][A-Za-z0-9_]{3,31}')

def telegram_path(value):
    value=str(value).strip()
    if not value.startswith(('https://','http://')):value='https://'+value
    u=urlsplit(value)
    if u.scheme not in ('http','https') or u.netloc.lower() not in ('t.me','telegram.me','www.t.me') or u.fragment:raise ValueError('Chỉ dùng liên kết t.me / telegram.me.')
    return u.path.strip('/').split('/'),parse_qs(u.query,keep_blank_values=True)

def parse_post_link(value):
    parts,query=telegram_path(value)
    if set(query)-{'single','thread'}:raise ValueError('Dùng link bài viết gốc, không dùng link bình luận.')
    if parts and parts[0]=='s':parts=parts[1:]
    if len(parts) in (3,4) and parts[0]=='c' and parts[1].isdigit():
        peer=-int('100'+parts[1]);path='c/'+parts[1];ids=parts[2:]
    elif len(parts) in (2,3) and USERNAME.fullmatch(parts[0]):
        peer='@'+parts[0].lower();path=parts[0].lower();ids=parts[1:]
    else:raise ValueError('Link cần dạng t.me/tenkenh/123 hoặc t.me/c/123456789/123.')
    if not all(i.isdigit() and 0<int(i)<=2147483647 for i in ids) or isinstance(peer,int) and abs(peer)>10**15:raise ValueError('ID bài viết không hợp lệ.')
    return {'peer':peer,'message_id':int(ids[-1]),'url':'https://t.me/'+path+'/'+'/'.join(ids)}

def parse_targets(text):
    refs=[];seen=set();issues=[];invalid_count=0
    for number,line in enumerate(text.lstrip('\ufeff').splitlines(),1):
        raw=line.strip()
        if not raw or raw.startswith('#'):continue
        try:
            if re.fullmatch(r'-[1-9][0-9]{0,14}',raw):ref=str(int(raw))
            elif USERNAME.fullmatch(raw.lstrip('@')):ref='@'+raw.lstrip('@').lower()
            else:
                parts,query=telegram_path(raw)
                if query:raise ValueError
                if len(parts)==1 and USERNAME.fullmatch(parts[0]):ref='@'+parts[0].lower()
                elif len(parts)==1 and re.fullmatch(r'\+[A-Za-z0-9_-]{8,128}',parts[0]):ref='https://t.me/'+parts[0]
                elif len(parts)==2 and parts[0]=='joinchat' and re.fullmatch(r'[A-Za-z0-9_-]{8,128}',parts[1]):ref='https://t.me/+'+parts[1]
                else:raise ValueError
        except ValueError:
            invalid_count+=1
            if len(issues)<100:
                issues.append({'line':number,'value':raw[:300]+('…' if len(raw)>300 else ''),
                    'reason':'Dùng @username, t.me/nhom, link mời nhóm đã tham gia hoặc ID âm.'})
            continue
        if ref not in seen:seen.add(ref);refs.append(ref)
    if invalid_count:
        first=issues[0]
        raise ApiError(422,'invalid_target',f'Dòng {first["line"]}: “{first["value"]}” không hợp lệ. Có {invalid_count} dòng cần sửa.',
            details={'invalid_targets':issues,'invalid_count':invalid_count,'valid_count':len(refs)})
    if len(refs)>1000:raise ApiError(422,'too_many_targets','Tối đa 1.000 nhóm mỗi đợt.')
    if not refs:raise ApiError(422,'empty_targets','Nhập ít nhất một nhóm.')
    return refs

async def store_verification(db,cmd,result,status,error_code,now):
    from app.models import ForwardRoute
    from sqlalchemy import select
    route=(await db.execute(select(ForwardRoute).where(ForwardRoute.id==cmd.route_id).with_for_update())).scalar_one_or_none()
    if route is None or not route.link_config or route.account_id!=cmd.account_id or route.link_config.get('verify_command_id')!=str(cmd.id):return False
    config=dict(route.link_config);route.verification=None;route.verified_at=None
    config.pop('message_id',None);config['checks']=[]
    config['verification_error']=error_code or 'invalid_verification'
    if status=='done' and isinstance(result,dict):
        expected=parse_post_link(config['post_link']);source=result.get('source_chat_id');message=result.get('message_id');checks=result.get('targets')
        if type(source) is int and -10**15<=source<0 and type(message) is int and message==expected['message_id'] and (not isinstance(expected['peer'],int) or source==expected['peer']) and isinstance(checks,list) and len(checks)==len(config['targets']):
            cleaned=[];chats={str(source):{'ok':True,'can_send':False,'title':str(result.get('source_title') or '')[:100]}};destinations=[]
            for index,value in enumerate(checks):
                if not isinstance(value,dict) or value.get('index')!=index:break
                cid=value.get('id');valid_id=type(cid) is int and -10**15<=cid<0
                ok=valid_id and value.get('ok') is True and cid!=source
                can_send=ok and value.get('can_send') is True
                code=value.get('error_code') if value.get('error_code') in ('chat_unavailable','destination_forbidden','not_a_group','not_joined') else None
                title=str(value.get('title') or '')[:100]
                cleaned.append({'index':index,'id':cid if valid_id else None,'ok':ok,'can_send':can_send,'title':title,'error_code':code or (None if can_send else 'destination_forbidden')})
                if valid_id:
                    if cid not in destinations:destinations.append(cid)
                    chats[str(cid)]={'ok':ok,'can_send':can_send,'title':title}
            if len(cleaned)==len(checks):
                route.source_chat_ids=[source];route.destination_chat_ids=destinations;route.verification=chats;route.verified_at=now
                config.update(message_id=message,checks=cleaned,verification_error=None if all(c['can_send'] for c in cleaned) else 'destination_forbidden')
    route.link_config=config
    return config.get('verification_error') is None
