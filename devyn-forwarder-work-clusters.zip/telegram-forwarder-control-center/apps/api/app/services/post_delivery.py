"""Keep a destination with its chosen account; reserve each post only once."""
import uuid
from sqlalchemy import select
from sqlalchemy.dialects import postgresql, sqlite
from app.errors import ApiError
from app.models import PostDelivery, PostTargetOwner, TelegramAccount


def insert(db, model):
    return (postgresql.insert if db.get_bind().dialect.name == 'postgresql' else sqlite.insert)(model)


def target_key(ref):
    return 'chat:'+ref if ref.lstrip('-').isdigit() else 'ref:'+ref


async def owners_for(db, refs):
    keys=[target_key(ref) for ref in refs]
    found={}
    for offset in range(0,len(keys),400):
        found.update((await db.execute(select(PostTargetOwner.target_key,PostTargetOwner.account_id)
            .where(PostTargetOwner.target_key.in_(keys[offset:offset+400])))).all())
    return {ref:found[target_key(ref)] for ref in refs if target_key(ref) in found}


async def owner_error(db, ref, owner):
    account=await db.get(TelegramAccount,owner)
    name=account.name if account else str(owner)
    raise ApiError(409,'target_owner_mismatch',f'Nhóm {ref} đang do SS "{name}" phụ trách. Chọn SS này; không tự chuyển việc sang tài khoản khác.')


async def partition(db, refs, accounts):
    ids=[uuid.UUID(a['id']) for a in accounts]
    owners=await owners_for(db,refs)
    assignments={aid:[] for aid in ids}
    for ref,owner in owners.items():
        if owner not in assignments:await owner_error(db,ref,owner)
        assignments[owner].append(ref)
    # Balance new destinations only. Known destinations never move because an
    # account is restricted, deselected, renamed, offline or receives FloodWait.
    for ref in refs:
        if ref not in owners:
            aid=min(ids,key=lambda aid:len(assignments[aid]))
            assignments[aid].append(ref)
    return assignments


async def bind_route(db, route, now):
    keys={f'chat:{dst}' for dst in route.destination_chat_ids}
    keys.update(target_key(ref) for ref in route.link_config['targets'])
    keys=sorted(keys)  # consistent lock order for simultaneous route starts
    for offset in range(0,len(keys),200):
        await db.execute(insert(db,PostTargetOwner).values([
            {'target_key':key,'account_id':route.account_id,'created_at':now} for key in keys[offset:offset+200]
        ]).on_conflict_do_nothing(index_elements=['target_key']))
    for offset in range(0,len(keys),400):
        rows=(await db.execute(select(PostTargetOwner).where(PostTargetOwner.target_key.in_(keys[offset:offset+400])))).scalars()
        for row in rows:
            if row.account_id!=route.account_id:await owner_error(db,row.target_key.split(':',1)[1],row.account_id)


async def reserve(db, route, rows, now):
    """INSERT..RETURNING provides exact winners even under concurrent starts."""
    accepted=set()
    for offset in range(0,len(rows),150):
        chunk=rows[offset:offset+150]
        result=await db.execute(insert(db,PostDelivery).values([
            {'source_chat_id':r['source_chat_id'],'message_id':r['message_id'],'dest_chat_id':r['dest_chat_id'],
             'job_id':r['id'],'route_id':route.id,'created_at':now} for r in chunk
        ]).on_conflict_do_nothing(index_elements=['source_chat_id','message_id','dest_chat_id']).returning(PostDelivery.job_id))
        accepted.update(result.scalars())
    return [r for r in rows if r['id'] in accepted]


async def owns_job(db, job):
    receipt=await db.get(PostDelivery,(job.source_chat_id,job.message_id,job.dest_chat_id))
    owner=await db.get(PostTargetOwner,f'chat:{job.dest_chat_id}')
    return (receipt is not None and receipt.job_id==job.id and owner is not None and owner.account_id==job.account_id)
