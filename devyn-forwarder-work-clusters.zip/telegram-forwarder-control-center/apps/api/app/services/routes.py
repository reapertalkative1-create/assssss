import uuid
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.errors import ApiError
from app.models import ForwardJob, ForwardRoute, RouteCheckpoint, TelegramAccount


def account_issue(acct):
    if acct.auth_state!='authorized' or acct.health_status=='dead':return 'account_not_authorized'
    if acct.spam_status in ('limited','blocked') or acct.health_status=='frozen' or acct.health_override=='frozen':return 'account_restricted'
    if acct.proxy_status=='dead':return 'proxy_dead'
    if acct.connection_state=='error':return acct.connection_error or 'account_not_connected'
    return None


def all_chats(route: ForwardRoute) -> set[int]:
    return set(route.source_chat_ids) | set(route.destination_chat_ids)


def verification_ok(route: ForwardRoute) -> bool:
    """Every source must be readable and every destination writable for this account (checked by the worker)."""
    v = route.verification or {}
    if route.link_config:
        checks=route.link_config.get('checks',[])
        if not route.source_chat_ids or not route.destination_chat_ids or not route.link_config.get('message_id') or len(checks)!=len(route.link_config['targets']) or not all(c.get('ok') and c.get('can_send') for c in checks):return False
    if route.verified_at is None or not v:
        return False
    try:
        info = {int(k): val for k, val in v.items()}
    except ValueError:
        return False
    if not all_chats(route) <= set(info):
        return False
    return (all(info[c].get("ok") for c in route.source_chat_ids)
            and all(info[c].get("ok") and info[c].get("can_send") for c in route.destination_chat_ids))


def invalidate_verification(route: ForwardRoute) -> None:
    route.verified_at, route.verification = None, None


async def check_startable(db: AsyncSession, route: ForwardRoute, acct: TelegramAccount) -> None:
    """Refuses to forward anywhere that was not verified as accessible/allowed for this account."""
    if acct.auth_state != "authorized":
        raise ApiError(409, "account_not_authorized", "Tài khoản Telegram chưa được xác thực.")
    if acct.spam_status in ('limited','blocked') or acct.health_status=='frozen' or acct.health_override=='frozen':
        raise ApiError(409,'account_restricted','Tài khoản đang bị hạn chế/đóng băng. Kiểm tra và xử lý trước khi gửi.')
    if acct.proxy_status=='dead':
        raise ApiError(409,'proxy_dead','Proxy đang lỗi. Kiểm tra hoặc sửa proxy trước khi gửi; không tự chuyển sang IP trực tiếp.')
    uncertain=(await db.execute(select(ForwardJob.id).where(ForwardJob.route_id==route.id,
        ForwardJob.last_error_code=='delivery_uncertain',ForwardJob.status.in_(('failed','dead_letter'))).limit(1))).first()
    if uncertain:raise ApiError(409,'delivery_uncertain','Có nhóm chưa rõ đã gửi hay chưa. Mở tiến độ từng nhóm để đối chiếu trước khi tiếp tục.')
    if acct.assigned_worker_id is None:
        raise ApiError(409, "no_worker_assigned", "Tài khoản chưa được gán cho worker nào.")
    if acct.desired_state != "running":
        raise ApiError(409, "account_not_running", "Hãy bật (start) tài khoản trước khi chạy tuyến.")
    if not verification_ok(route):
        raise ApiError(409, "route_not_verified",
                       "Chưa xác minh quyền truy cập: mọi nguồn phải đọc được và mọi đích phải gửi được. Hãy chạy verify.")
    await check_no_loops(db, route)


async def check_no_loops(db: AsyncSession, route: ForwardRoute) -> None:
    # Loop protection. Messages our own account writes arrive as "outgoing" in the destination chat; if a route
    # reads that chat AND is allowed to forward outgoing messages, the system would re-forward its own copies.
    others = (await db.execute(select(ForwardRoute).where(
        ForwardRoute.account_id == route.account_id, ForwardRoute.id != route.id, ForwardRoute.status != "stopped"))).scalars().all()
    mine_reads_outgoing = bool(route.filters.get("include_outgoing"))
    for o in others:
        if mine_reads_outgoing and set(route.source_chat_ids) & set(o.destination_chat_ids):
            raise ApiError(409, "possible_loop", "Tuyến này đọc lại tin do tuyến khác gửi và đang bật include_outgoing: có thể lặp vô hạn.")
        if o.filters.get("include_outgoing") and set(route.destination_chat_ids) & set(o.source_chat_ids):
            raise ApiError(409, "possible_loop", "Đích của tuyến này là nguồn của một tuyến đang bật include_outgoing: có thể lặp vô hạn.")


async def stats_for(db: AsyncSession, route_ids: list[uuid.UUID]) -> dict[uuid.UUID, dict[str, int]]:
    out: dict[uuid.UUID, dict[str, int]] = {rid: {} for rid in route_ids}
    if route_ids:
        for rid, st, n in (await db.execute(select(ForwardJob.route_id, ForwardJob.status, func.count())
                                            .where(ForwardJob.route_id.in_(route_ids))
                                            .group_by(ForwardJob.route_id, ForwardJob.status))).all():
            out[rid][st] = n
    return out


async def checkpoints_for(db: AsyncSession, route_ids: list[uuid.UUID]) -> dict[uuid.UUID, dict[str, int]]:
    out: dict[uuid.UUID, dict[str, int]] = {rid: {} for rid in route_ids}
    if route_ids:
        for cp in (await db.execute(select(RouteCheckpoint).where(RouteCheckpoint.route_id.in_(route_ids)))).scalars():
            out[cp.route_id][str(cp.source_chat_id)] = cp.last_message_id
    return out


async def upsert_checkpoint(db: AsyncSession, route_id: uuid.UUID, source: int, message_id: int, now: datetime) -> None:
    cp = await db.get(RouteCheckpoint, (route_id, source))
    if cp is None:
        db.add(RouteCheckpoint(route_id=route_id, source_chat_id=source, last_message_id=message_id, updated_at=now))
    elif message_id > cp.last_message_id:
        cp.last_message_id, cp.updated_at = message_id, now


async def routes_for_worker(db: AsyncSession, worker_id: uuid.UUID) -> list[dict]:
    """What a worker must watch: ACTIVE routes of authorized accounts assigned to it, with their checkpoints."""
    rows = (await db.execute(
        select(ForwardRoute).join(TelegramAccount, TelegramAccount.id == ForwardRoute.account_id).where(
            ForwardRoute.status == "active", TelegramAccount.assigned_worker_id == worker_id,
            ForwardRoute.link_config.is_(None),
            TelegramAccount.auth_state == "authorized", TelegramAccount.pending_deletion.is_(False)))).scalars().all()
    cps = await checkpoints_for(db, [r.id for r in rows])
    return [{"route_id": r.id, "account_id": r.account_id, "name": r.name, "source_chat_ids": r.source_chat_ids,
             "destination_chat_ids": r.destination_chat_ids, "mode": r.mode, "filters": r.filters,
             "version": r.updated_at.isoformat(), "checkpoints": cps[r.id]} for r in rows]
