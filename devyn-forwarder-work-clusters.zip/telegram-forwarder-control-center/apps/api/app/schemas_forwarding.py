import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ContentType = Literal["text", "photo", "video", "voice", "audio", "sticker", "document", "other"]
ChatId = int  # Telegram "marked" chat id (negative for groups/channels)


def _chat_ids(v: list[int]) -> list[int]:
    if not 1 <= len(v) <= 50:
        raise ValueError("Cần 1–50 chat.")
    if len(set(v)) != len(v):
        raise ValueError("Danh sách chat bị trùng.")
    if any(c == 0 or abs(c) > 10**15 for c in v):
        raise ValueError("Chat id không hợp lệ.")
    return v


def _keywords(v: list[str]) -> list[str]:
    out = []
    for k in v:
        k = " ".join(k.split()).lower()
        if not 1 <= len(k) <= 100:
            raise ValueError("Mỗi từ khóa dài 1–100 ký tự.")
        if k not in out:
            out.append(k)
    if len(out) > 50:
        raise ValueError("Tối đa 50 từ khóa.")
    return out


class RouteFilters(BaseModel):
    model_config = ConfigDict(extra="forbid")
    keywords_include: list[str] = []   # message must contain at least one (case-insensitive); empty = no requirement
    keywords_exclude: list[str] = []   # message must contain none of them
    content_types: list[ContentType] = []  # empty = every type
    include_outgoing: bool = False     # also forward messages sent by the account itself (off: avoids loops)

    _k1 = field_validator("keywords_include")(_keywords)
    _k2 = field_validator("keywords_exclude")(_keywords)

    @field_validator("content_types")
    @classmethod
    def _types(cls, v):
        return list(dict.fromkeys(v))


class RouteCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    account_id: uuid.UUID
    source_chat_ids: list[int]
    destination_chat_ids: list[int]
    mode: Literal["forward", "copy"] = "forward"
    filters: RouteFilters = RouteFilters()
    priority: int = Field(default=5, ge=1, le=9)
    rate_per_minute: int = Field(default=20, ge=1, le=600)
    max_attempts: int = Field(default=5, ge=1, le=10)

    _s = field_validator("source_chat_ids")(_chat_ids)
    _d = field_validator("destination_chat_ids")(_chat_ids)

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        v = " ".join(v.split())
        if not 1 <= len(v) <= 64:
            raise ValueError("Tên tuyến dài 1–64 ký tự.")
        return v

    @model_validator(mode="after")
    def _no_self_forward(self):
        if set(self.source_chat_ids) & set(self.destination_chat_ids):
            raise ValueError("Một chat không thể vừa là nguồn vừa là đích của cùng một tuyến.")
        return self


class RouteUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    source_chat_ids: list[int] | None = None
    destination_chat_ids: list[int] | None = None
    mode: Literal["forward", "copy"] | None = None
    filters: RouteFilters | None = None
    priority: int | None = Field(default=None, ge=1, le=9)
    rate_per_minute: int | None = Field(default=None, ge=1, le=600)
    max_attempts: int | None = Field(default=None, ge=1, le=10)

    @field_validator("name")
    @classmethod
    def _name(cls, v):
        return None if v is None else RouteCreate._name.__func__(RouteCreate, v)

    @field_validator("source_chat_ids", "destination_chat_ids")
    @classmethod
    def _ids(cls, v):
        return None if v is None else _chat_ids(v)


class RouteStop(BaseModel):
    model_config = ConfigDict(extra="forbid")
    cancel_pending: bool = False


class RouteDelete(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirm_name: str = Field(max_length=64)


class RouteOut(BaseModel):
    account_issue: str | None = None
    account_restriction: str | None = None
    account_wait_until: datetime | None = None
    link_config: dict | None = None
    verification_pending: bool = False
    verification_error: str | None = None
    id: uuid.UUID
    name: str
    account_id: uuid.UUID
    account_name: str | None
    source_chat_ids: list[int]
    destination_chat_ids: list[int]
    mode: str
    filters: RouteFilters
    priority: int
    rate_per_minute: int
    max_attempts: int
    status: Literal["stopped", "active", "paused"]
    verified: bool
    verified_at: datetime | None
    verification: dict | None
    stats: dict[str, int]
    checkpoints: dict[str, int]
    created_at: datetime
    updated_at: datetime


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    route_id: uuid.UUID
    account_id: uuid.UUID
    source_chat_id: int
    message_id: int
    dest_chat_id: int
    status: str
    priority: int
    attempts: int
    max_attempts: int
    available_at: datetime
    last_error_code: str | None
    result: dict | None
    created_at: datetime
    finished_at: datetime | None


class BulkJobAction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: Literal["retry", "cancel"]
    status: Literal["failed", "dead_letter", "retry_wait", "pending"]
    route_id: uuid.UUID | None = None
    limit: int = Field(default=500, ge=1, le=1000)


class QueueMetrics(BaseModel):
    by_status: dict[str, int]
    oldest_pending_age_seconds: float | None
    succeeded_last_5m: int
    needs_attention: int


# ---------------- worker-facing ----------------
class RouteConfigOut(BaseModel):
    route_id: uuid.UUID
    account_id: uuid.UUID
    name: str
    source_chat_ids: list[int]
    destination_chat_ids: list[int]
    mode: str
    filters: dict
    version: str
    checkpoints: dict[str, int]


class EnqueueItem(BaseModel):
    source_chat_id: int
    message_id: int = Field(gt=0)


class EnqueueRequest(BaseModel):
    route_id: uuid.UUID
    items: list[EnqueueItem] = Field(default_factory=list, max_length=200)
    checkpoints: dict[int, int] = Field(default_factory=dict)  # source chat -> highest message id seen (even if filtered out)


class EnqueueResponse(BaseModel):
    created: int
    duplicates: int


class ClaimRequest(BaseModel):
    max_jobs: int = Field(default=10, ge=1, le=20)
    wait_seconds: int = Field(default=0, ge=0, le=25)


class ClaimedJob(BaseModel):
    post_once: bool = False
    id: uuid.UUID
    epoch: int
    route_id: uuid.UUID
    account_id: uuid.UUID
    source_chat_id: int
    message_id: int
    dest_chat_id: int
    mode: str
    attempt: int
    max_attempts: int


class ClaimResponse(BaseModel):
    jobs: list[ClaimedJob]


class JobRef(BaseModel):
    id: uuid.UUID
    epoch: int = Field(ge=1)


class StartRequest(BaseModel):
    jobs: list[JobRef] = Field(max_length=50)


class StartResponse(BaseModel):
    started: list[uuid.UUID]
    lost: list[uuid.UUID]


class JobResultIn(BaseModel):
    id: uuid.UUID
    epoch: int = Field(ge=1)
    status: Literal["succeeded", "retry", "failed"]
    error_code: str | None = Field(default=None, max_length=64)
    retry_after: int | None = Field(default=None, ge=0, le=2147483647)
    dest_message_id: int | None = None


class ResultsRequest(BaseModel):
    results: list[JobResultIn] = Field(max_length=50)


class ResultsResponse(BaseModel):
    outcomes: list[dict]
