"""Uniform error shape. Generic validation errors omit input values; target-list errors explicitly report the submitted group lines."""
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

log = logging.getLogger("tfcc.errors")


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str, *, details: dict | None = None):
        self.status_code, self.code, self.message = status_code, code, message
        self.details = details
        super().__init__(message)


def _body(request: Request, code: str, message: str, **extra) -> dict:
    return {"error": {"code": code, "message": message, **extra}, "request_id": getattr(request.state, "request_id", None)}


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(ApiError)
    async def _api_error(request: Request, exc: ApiError):
        return JSONResponse(status_code=exc.status_code, content=_body(request, exc.code, exc.message,
            **({'details':exc.details} if exc.details is not None else {})))

    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError):
        fields = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
        return JSONResponse(
            status_code=422,
            content=_body(request, "validation_error", "Dữ liệu không hợp lệ.", fields=fields),
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        log.exception("unhandled_error", extra={"path": request.url.path})
        return JSONResponse(status_code=500, content=_body(request, "internal_error", "Lỗi hệ thống."))
