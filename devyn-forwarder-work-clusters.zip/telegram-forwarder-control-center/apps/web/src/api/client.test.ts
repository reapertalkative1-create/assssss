import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ApiError, api, setCsrfToken, setUnauthorizedHandler } from "./client";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => { fetchMock = vi.fn(); vi.stubGlobal("fetch", fetchMock); setCsrfToken(""); setUnauthorizedHandler(null); });
afterEach(() => vi.unstubAllGlobals());

describe("api client", () => {
  it('preserves structured target validation details',async()=>{
    const details={invalid_count:1,invalid_targets:[{line:81,value:'Nhóm lỗi',reason:'Sai định dạng'}]};
    fetchMock.mockResolvedValue(json({error:{code:'invalid_target',message:'Dòng 81 lỗi',details}},422));
    expect(await api.post('/api/post-routes/validate-targets',{}).catch(e=>e)).toMatchObject({code:'invalid_target',details});
  });
  it("sends the CSRF token only on state-changing requests and never in the URL", async () => {
    setCsrfToken("tok-123");
    fetchMock.mockResolvedValue(json({ ok: true }));
    await api.get("/api/x", { q: "a b", empty: "", page: 2 });
    await api.post("/api/y", { a: 1 });
    const [getUrl, getInit] = fetchMock.mock.calls[0];
    const [, postInit] = fetchMock.mock.calls[1];
    expect(getUrl).toBe("/api/x?q=a+b&page=2");
    expect(getInit.headers["X-CSRF-Token"]).toBeUndefined();
    expect(postInit.headers["X-CSRF-Token"]).toBe("tok-123");
    expect(postInit.credentials).toBe("same-origin");
    expect(getUrl).not.toContain("tok-123");
  });

  it("turns API errors into ApiError with code, message and field errors", async () => {
    fetchMock.mockResolvedValue(json({ error: { code: "validation_error", message: "Dữ liệu không hợp lệ.", fields: [{ field: "name", message: "Nhập tên." }] }, request_id: "rid1" }, 422));
    const err = await api.post("/api/z", {}).catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err).toMatchObject({ status: 422, code: "validation_error", requestId: "rid1", fields: [{ field: "name", message: "Nhập tên." }] });
  });

  it("calls the unauthorized handler on 401, except for the login call itself", async () => {
    const handler = vi.fn();
    setUnauthorizedHandler(handler);
    fetchMock.mockResolvedValue(json({ error: { code: "unauthenticated", message: "x" } }, 401));
    await api.get("/api/accounts").catch(() => {});
    expect(handler).toHaveBeenCalledTimes(1);
    await api.post("/api/auth/login", { username: "a", password: "b" }).catch(() => {});
    expect(handler).toHaveBeenCalledTimes(1);
  });

  it("maps network failures to a readable error and handles 204", async () => {
    fetchMock.mockRejectedValueOnce(new TypeError("Failed to fetch"));
    expect(await api.get("/api/a").catch((e) => e)).toMatchObject({ status: 0, code: "network" });
    fetchMock.mockResolvedValueOnce(new Response(null, { status: 204 }));
    expect(await api.post("/api/auth/logout")).toBeUndefined();
  });

  it("falls back gracefully when the server returns a non-JSON error", async () => {
    fetchMock.mockResolvedValue(new Response("<html>bad gateway</html>", { status: 502, headers: { "content-type": "text/html" } }));
    expect(await api.get("/api/a").catch((e) => e)).toMatchObject({ status: 502, message: "Lỗi máy chủ (502)." });
  });
});


describe('file download',()=>{
  it('returns a blob with credentials and preserves normal error handling',async()=>{
    fetchMock.mockResolvedValueOnce(new Response('socks5://127.0.0.1:1080\n',{headers:{'content-type':'text/plain'}}));
    const result=await api.download('/api/account-proxies/export',{status:'alive',proxy_status:undefined});
    expect(result.size).toBeGreaterThan(0);expect(fetchMock.mock.calls[0][0]).toBe('/api/account-proxies/export?status=alive');
    expect(fetchMock.mock.calls[0][1].credentials).toBe('same-origin');
    fetchMock.mockResolvedValueOnce(json({error:{code:'forbidden',message:'Không đủ quyền.'}},403));
    await expect(api.download('/api/account-proxies/export',{status:'dead'})).rejects.toMatchObject({code:'forbidden'});
  });
});
