import {useState} from 'react';
import {api,ApiError,request} from '../api/client';
import type {Page,WorkCluster,WorkClusterSummary,WorkClusterRun} from '../api/types';
import {Modal} from '../components/Modal';
import {ConfirmDialog} from '../components/ConfirmDialog';
import {Pagination} from '../components/DataTable';
import {Alert,EmptyState,Pill,TextField} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import {postDraftKey,usePostDraft} from '../hooks/usePostDraft';
import {fmtDateTime} from '../lib/format';
import {useToast} from '../state/toast';
import {PostRouteForm} from './PostRoute';

type Dialog={kind:'new'}|{kind:'edit'|'run'|'history'|'delete';cluster:WorkClusterSummary};

export function WorkClusters({owner,isAdmin,onOpenBatch}:{owner:string;isAdmin:boolean;onOpenBatch:(id:string)=>void}){
 const toast=useToast();
 const [q,setQ]=useState(''),[page,setPage]=useState(1),[dialog,setDialog]=useState<Dialog|null>(null);
 const search=useDebounced(q);
 const list=useQuery(signal=>api.get<Page<WorkClusterSummary>>('/api/work-clusters',{q:search,page,page_size:12},signal),[search,page]);
 function saved(c:WorkCluster){setDialog(null);list.reload();toast.success(`Đã lưu cụm “${c.name}”. Bấm Bài mới khi cần gửi.`);}
 function openBatch(id:string){setDialog(null);onOpenBatch(id);}
 return <section className="work-clusters stack tight" aria-label="Cụm làm việc">
  <div className="cluster-toolbar"><div><h2>Cụm của bạn <span>{list.data?.total??0}</span></h2><p>Chọn cụm → dán bài mới → kiểm tra và chạy.</p></div>{isAdmin&&<button className="btn primary" onClick={()=>setDialog({kind:'new'})}>+ Tạo cụm làm việc</button>}</div>
  <div className="cluster-search"><input className="input" aria-label="Tìm cụm làm việc" placeholder="Tìm tên cụm…" maxLength={64} value={q} onChange={e=>{setQ(e.target.value);setPage(1);}}/><button className="btn sm" onClick={list.reload} disabled={list.refreshing}>Làm mới</button></div>
  {list.error&&<Alert tone="bad">{list.error.message}</Alert>}
  {list.loading&&<p className="hint" role="status">Đang tải cụm làm việc…</p>}
  {list.data&&!list.data.items.length&&<EmptyState title={search?'Không tìm thấy cụm':'Tạo cụm cho công việc hằng ngày'}>{search?'Thử tìm bằng tên khác.':'Đặt tên, chọn SS và lưu nhóm nhận một lần. Mỗi bài mới có tiến độ riêng.'}</EmptyState>}
  <div className="cluster-grid">{list.data?.items.map(c=><article className="cluster-card" key={c.id}>
   <div className="cluster-card-head"><span className="cluster-icon" aria-hidden="true">▦</span><div><h3 title={c.name}>{c.name}</h3><span className="hint">Cập nhật {fmtDateTime(c.updated_at)}</span></div>{isAdmin&&<details className="session-actions"><summary className="btn ghost sm" aria-label={`Thao tác cụm ${c.name}`}>•••</summary><div className="route-menu"><button className="btn sm" onClick={()=>setDialog({kind:'edit',cluster:c})}>Sửa tên & cấu hình</button><button className="btn sm danger" onClick={()=>setDialog({kind:'delete',cluster:c})}>Xóa cụm</button></div></details>}</div>
   <div className="cluster-facts"><span><b>{c.account_count}</b> SS</span><span><b>{c.target_count}</b> nhóm nhận</span><span>{c.delay_seconds}s / nhóm</span></div>
   <div className="cluster-card-foot"><span className="hint">{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'}</span><div className="row"><button className="btn sm" onClick={()=>setDialog({kind:'history',cluster:c})}>Lịch sử</button>{isAdmin&&<button className="btn sm primary" onClick={()=>setDialog({kind:'run',cluster:c})}>Bài mới</button>}</div></div>
  </article>)}</div>
  {list.data&&list.data.total>12&&<Pagination page={page} pageSize={12} total={list.data.total} onPage={setPage}/>}
  {dialog?.kind==='new'&&<PostRouteForm clusterMode draftOwner={owner} onClose={()=>setDialog(null)} onSaved={()=>{}} onClusterSaved={saved}/>}
  {dialog&&(dialog.kind==='edit'||dialog.kind==='run')&&<ClusterDialog key={`${dialog.kind}:${dialog.cluster.id}`} id={dialog.cluster.id} kind={dialog.kind} owner={owner} onClose={()=>setDialog(null)} onSaved={saved} onOpenBatch={openBatch}/>}
  {dialog?.kind==='history'&&<ClusterHistory key={dialog.cluster.id} cluster={dialog.cluster} onClose={()=>setDialog(null)} onOpenBatch={openBatch} onNew={isAdmin?()=>setDialog({kind:'run',cluster:dialog.cluster}):undefined}/>}
  {dialog?.kind==='delete'&&<ConfirmDialog title={`Xóa cụm “${dialog.cluster.name}”?`} confirmLabel="Xóa cụm" danger onClose={()=>setDialog(null)} onConfirm={async()=>{await request('DELETE',`/api/work-clusters/${dialog.cluster.id}`);list.reload();toast.success('Đã xóa cấu hình cụm.');}}><p>Các SS và lượt gửi đã tạo vẫn được giữ trong mục Lịch sử / tuyến. Lượt đang chạy tiếp tục theo cấu hình cũ.</p></ConfirmDialog>}
 </section>;
}

function ClusterDialog({id,kind,owner,onClose,onSaved,onOpenBatch}:{id:string;kind:'edit'|'run';owner:string;onClose:()=>void;onSaved:(c:WorkCluster)=>void;onOpenBatch:(id:string)=>void}){
 const detail=useQuery(signal=>api.get<WorkCluster>(`/api/work-clusters/${id}`,undefined,signal),[id]);
 if(!detail.data)return <Modal title={kind==='edit'?'Sửa cụm làm việc':'Bài mới'} onClose={onClose}><p className="hint">{detail.error?detail.error.message:'Đang lấy cấu hình cụm…'}</p>{detail.error&&<button className="btn" onClick={detail.reload}>Thử lại</button>}</Modal>;
 return kind==='edit'?<PostRouteForm key={`${id}:${detail.data.revision}`} clusterMode cluster={detail.data} draftOwner={owner} onClose={onClose} onSaved={()=>{}} onClusterSaved={onSaved}/>:<ClusterRunForm key={`${id}:${detail.data.revision}`} cluster={detail.data} owner={owner} onClose={onClose} onCreated={onOpenBatch}/>;
}

export function ClusterRunForm({cluster:c,owner,onClose,onCreated}:{cluster:WorkCluster;owner:string;onClose:()=>void;onCreated:(id:string)=>void}){
 const cache=usePostDraft(postDraftKey(owner,`cluster-run:${c.id}:${c.revision}`),{link:'',targets:'',senders:[],delay:'60',mode:'forward',requestId:crypto.randomUUID()});
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function create(){
  if(!cache.draft.link.trim()){setError('Dán liên kết bài viết Telegram.');return;}
  setBusy(true);setError('');
  try{const r=await api.post<{batch_id:string}>(`/api/work-clusters/${c.id}/runs`,{request_id:cache.draft.requestId,revision:c.revision,post_link:cache.draft.link.trim()});cache.complete();onCreated(r.batch_id);}
  catch(e){setError(e instanceof ApiError?e.message:'Không tạo được lượt gửi.');setBusy(false);}
 }
 return <Modal title={`Bài mới · ${c.name}`} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button><button className="btn primary" disabled={busy||!!c.missing_account_ids.length} onClick={()=>void create()}>{busy?'Đang tạo…':'Tạo lượt gửi'}</button></>}>
  <div className="cluster-run-summary"><strong>{c.account_count} SS · {c.target_count} nhóm nhận</strong><span>{c.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'} · nghỉ {c.delay_seconds}s / nhóm</span></div>
  <TextField label="Liên kết bài viết Telegram" placeholder="https://t.me/tenkenh/123" maxLength={500} value={cache.draft.link} disabled={busy} onChange={e=>{cache.update({link:e.target.value});setError('');}} hint="Dùng SS và nhóm đã lưu trong cụm. Mỗi bài tạo một lượt riêng."/>
  <div className="cluster-draft-note"><span className="hint" role="status">{cache.savedAt?'Đã lưu tạm link bài · trong trình duyệt này':'Link bài được tự lưu tạm khi bạn nhập.'}</span>{cache.draft.link&&<button className="btn ghost sm" disabled={busy} onClick={()=>{cache.clear();setError('');}}>Xóa link tạm</button>}</div>
  <details className="cluster-preview"><summary>Xem SS & nhóm nhận</summary><div><strong>{c.account_count} SS</strong><p>{c.senders.map(a=>a.name).join(' · ')}</p><strong>{c.target_count} nhóm nhận</strong><pre>{c.targets.join('\n')}</pre></div></details>
  <p className="hint">Tạo lượt xong, kiểm tra nhóm rồi bấm Bắt đầu. Bài trùng được bỏ qua; các giới hạn Telegram vẫn được giữ.</p>
  {!!c.missing_account_ids.length&&<Alert tone="bad">{c.missing_account_ids.length} SS đã/đang bị xóa. Sửa cấu hình cụm trước khi tạo lượt.</Alert>}
  {cache.storageError&&<Alert tone="bad">{cache.storageError}</Alert>}{error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}

function ClusterHistory({cluster:c,onClose,onOpenBatch,onNew}:{cluster:WorkClusterSummary;onClose:()=>void;onOpenBatch:(id:string)=>void;onNew?:()=>void}){
 const [page,setPage]=useState(1);
 const history=useQuery(signal=>api.get<Page<WorkClusterRun>>(`/api/work-clusters/${c.id}/runs`,{page,page_size:10},signal),[c.id,page],{interval:5000});
 return <Modal wide title={`Lịch sử · ${c.name}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Đóng</button>{onNew&&<button className="btn primary" onClick={onNew}>Bài mới</button>}</>}>
  <p className="hint">Mỗi lượt giữ bài viết, SS và nhóm nhận tại thời điểm tạo. Sửa cụm chỉ áp dụng cho lượt sau.</p>
  {history.error&&<Alert tone="bad">{history.error.message}</Alert>}{history.loading&&<p className="hint">Đang tải lịch sử…</p>}
  {history.data&&!history.data.total&&<EmptyState title="Chưa có lượt gửi">Bấm Bài mới để dùng cấu hình đã lưu.</EmptyState>}
  <div className="cluster-history">{history.data?.items.map(r=><div className="cluster-history-row" key={r.batch_id}><div><strong>{fmtDateTime(r.created_at)}</strong><a href={r.post_link} target="_blank" rel="noreferrer">{r.post_link}</a><span className="hint">{r.account_count} SS · {r.target_count} nhóm nhận</span></div><Pill tone={r.active_count?'ok':r.paused_count?'warn':'idle'}>{r.active_count?'Đang chạy':r.paused_count?'Tạm dừng':r.started_count?'Đã chạy':'Bản nháp'}</Pill><button className="btn sm" onClick={()=>onOpenBatch(r.batch_id)}>Mở lượt</button></div>)}</div>
  {history.data&&history.data.total>10&&<Pagination page={page} pageSize={10} total={history.data.total} onPage={setPage}/>}
 </Modal>;
}
