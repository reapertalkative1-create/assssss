import type {ApiError} from '../api/client';
export interface TargetIssue {line:number;value:string;reason:string}
export interface TargetIssuesData {invalid_targets:TargetIssue[];invalid_count:number;valid_count:number}
export function targetIssues(error:ApiError):TargetIssuesData|null{
 const d=error.details as TargetIssuesData|undefined;
 return d&&Array.isArray(d.invalid_targets)&&d.invalid_targets.every(i=>Number.isInteger(i.line)&&i.line>0&&typeof i.value==='string'&&typeof i.reason==='string')?d:null;
}
export function TargetIssues({data,onLocate}:{data:TargetIssuesData;onLocate:(line:number)=>void}){
 return <section className="target-issues" role="alert" aria-label="Nhóm cần sửa">
  <strong>{data.invalid_count} dòng cần sửa · {data.valid_count} nhóm đúng định dạng</strong>
  <div className="target-issue-list">{data.invalid_targets.map(issue=><div className="target-issue" key={issue.line}>
   <span>Dòng {issue.line}</span><div><code>{issue.value}</code><small>{issue.reason}</small></div><button className="btn sm" onClick={()=>onLocate(issue.line)}>Sửa dòng {issue.line}</button>
  </div>)}</div>
  {data.invalid_count>data.invalid_targets.length&&<p className="hint">Đang hiện {data.invalid_targets.length} dòng lỗi đầu tiên. Sửa rồi kiểm tra lại để xem tiếp.</p>}
 </section>;
}
