import {useState} from 'react';
import {api,ApiError} from '../api/client';
import type {Route} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,Pill} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {SenderChecks} from './SenderChecks';
import {deliveryDone,deliveryLabel} from './PostRoute';
export function PostBatch({batchId,onClose,onDetail}:{batchId:string;onClose:()=>void;onDetail:(route:Route)=>void}){
 const live=useQuery(signal=>api.get<{items:Route[]}>(`/api/post-routes/batches/${batchId}`,undefined,signal),[batchId],{interval:2000});
 const [busy,setBusy]=useState(false),[progress,setProgress]=useState(''),[errors,setErrors]=useState<string[]>([]),[filter,setFilter]=useState('');
 const rows=live.data?.items??[];
 const ready=rows.filter(r=>r.verified&&!r.account_restriction&&!r.account_issue&&!r.link_config?.pause_reason&&!deliveryDone(r)&&r.status==='stopped');
 async function perform(action:'verify'|'start'|'pause'|'resume'|'stop',targets:Route[]){
  setBusy(true);setErrors([]);let n=0;
  // Small, sequential requests: each account keeps its own checks and cooldown.
  for(const r of targets){
   setProgress(`${++n}/${targets.length} · ${r.account_name}`);
   try{await api.post(`/api/routes/${r.id}/${action}`);}
   catch(e){setErrors(old=>[...old,`${r.account_name}: ${e instanceof ApiError?e.message:'Thao tác thất bại.'}`]);}
  }
  setProgress(`Đã xử lý ${n} SS.`);setBusy(false);live.reload();
 }
 return <Modal wide title={rows[0]?.link_config?.work_cluster_name?`Lượt gửi · ${rows[0].link_config.work_cluster_name}`:'Lượt gửi · tài khoản & tiến độ'} onClose={onClose} dismissible={!busy} footer={<button className="btn" disabled={busy} onClick={onClose}>Đóng</button>}>
  {rows[0]?.link_config&&<div className="cluster-run-summary"><a href={rows[0].link_config.post_link} target="_blank" rel="noreferrer">{rows[0].link_config.post_link}</a><span>{rows[0].link_config.work_cluster_name?'Cấu hình được giữ riêng cho lượt này.':''}</span></div>}
  <div className="row between"><strong>{rows.length} SS · {rows.reduce((n,r)=>n+(r.link_config?.targets.length??0),0)} nhóm nhận</strong><span className="hint">{rows.reduce((n,r)=>n+(r.stats.succeeded??0),0)} đã gửi</span></div>
  {!!rows[0]?.link_config?.unused_senders&&<p className="hint">{rows[0].link_config.unused_senders} SS đã chọn không được phân công vì số SS nhiều hơn số nhóm nhận.</p>}
  <p className="hint">SS phụ trách nhóm được giữ giữa các đợt gửi. Bài trùng được bỏ qua; FloodWait chờ đúng hạn, không đổi SS. Chỉ đăng vào nhóm cho phép nội dung này.</p>
  <div className="post-guards"><span>SS cố định</span><span>Bỏ qua trùng: {rows.reduce((n,r)=>n+(r.link_config?.duplicate_count??0),0)}</span><span>Cần đối chiếu: {rows.filter(r=>r.link_config?.pause_reason==='delivery_uncertain').length}</span></div>
  <div className="row">
   <button className="btn sm" disabled={busy||!rows.some(r=>!r.link_config?.queued_at&&!r.verification_pending)} onClick={()=>void perform('verify',rows.filter(r=>!r.link_config?.queued_at&&!r.verification_pending))}>Kiểm tra tất cả</button>
   <button className="btn sm primary" disabled={busy||!ready.length} onClick={()=>void perform('start',ready)}>Bắt đầu SS đã đạt ({ready.length})</button>
   <button className="btn sm" disabled={busy||!rows.some(r=>r.status==='active')} onClick={()=>void perform('pause',rows.filter(r=>r.status==='active'))}>Tạm dừng</button>
   <button className="btn sm" disabled={busy||!rows.some(r=>r.status==='paused'&&!deliveryDone(r)&&!r.account_issue&&!r.link_config?.pause_reason)} onClick={()=>void perform('resume',rows.filter(r=>r.status==='paused'&&!deliveryDone(r)&&!r.account_issue&&!r.link_config?.pause_reason))}>Tiếp tục</button>
   <button className="btn sm" disabled={busy||!rows.some(r=>r.status!=='stopped')} onClick={()=>void perform('stop',rows.filter(r=>r.status!=='stopped'))}>Dừng</button>
  </div>
  {progress&&<p className="hint" role="status">{progress}</p>}{live.error&&<Alert tone="bad">{live.error.message}</Alert>}
  {!!errors.length&&<Alert tone="bad">{errors.slice(0,20).map((text,i)=><div key={i}>{text}</div>)}{errors.length>20&&<p>Và {errors.length-20} lỗi khác.</p>}</Alert>}
  <SenderChecks ids={[...new Set(rows.map(r=>r.account_id))]} disabled={busy} onFinished={live.reload}/>
  <input className="input" aria-label="Tìm SS trong cụm gửi" placeholder="Tìm tài khoản…" value={filter} onChange={e=>setFilter(e.target.value)}/>
  <div className="post-batch-list">{rows.filter(r=>!filter||(r.account_name??'').toLowerCase().includes(filter.toLowerCase())).map(r=><div className="post-batch-row" key={r.id}>
   <div><strong>{r.account_name}</strong><div className="hint">{r.link_config?.targets.length} nhóm · nghỉ {r.link_config?.delay_seconds}s / nhóm</div><details><summary className="hint">Nhóm được giao</summary><div className="hint">{r.link_config?.targets.join(' · ')}</div></details></div>
   <Pill tone={r.verification_error||r.account_restriction||r.account_issue||r.link_config?.pause_reason?'bad':r.verified?'ok':'idle'}>{deliveryLabel(r)}</Pill><button className="btn sm" disabled={busy} onClick={()=>onDetail(r)}>Chi tiết SS</button>
  </div>)}</div>
  {live.loading&&<p className="hint">Đang tải phân công…</p>}
 </Modal>;
}
