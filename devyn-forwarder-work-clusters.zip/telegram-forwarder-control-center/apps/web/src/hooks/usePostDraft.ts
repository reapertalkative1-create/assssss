import {useCallback,useEffect,useRef,useState} from 'react';
import type {Sender} from '../pages/SenderPicker';

export interface PostDraft {name?:string;link:string;targets:string;delay:string;mode:'forward'|'copy';senders:Sender[];requestId:string}
interface StoredDraft extends PostDraft {version:1;savedAt:number}
const TTL=7*24*60*60*1000;
export const postDraftKey=(owner:string,scope:string)=>`devyn.post-draft.v1:${encodeURIComponent(owner)}:${scope}`;

export function readPostDraft(key:string):StoredDraft|null{
 try{
  const raw=localStorage.getItem(key);if(!raw)return null;
  const d=JSON.parse(raw);
  if(d.version!==1||!Number.isFinite(d.savedAt)||Date.now()-d.savedAt>TTL||d.savedAt>Date.now()+60000){localStorage.removeItem(key);return null;}
  if(typeof d.link!=='string'||d.link.length>500||typeof d.targets!=='string'||d.targets.length>500000||typeof d.delay!=='string'||d.delay.length>10||!['forward','copy'].includes(d.mode)||!Array.isArray(d.senders)||d.senders.length>1000)return null;
  if(d.name!==undefined&&(typeof d.name!=='string'||d.name.length>64))return null;
  if(typeof d.requestId!=='string'||!(/^[0-9a-f-]{36}$/i.test(d.requestId)))return null;
  if(d.senders.some((a:Sender)=>!a||typeof a.id!=='string'||a.id.length>64||typeof a.name!=='string'||a.name.length>100))return null;
  // Persist identities only: never Telegram sessions, proxies, API hashes or credentials.
  return {...(d.name!==undefined?{name:d.name}:{}),version:1,savedAt:d.savedAt,link:d.link,targets:d.targets,delay:d.delay,mode:d.mode,requestId:d.requestId,senders:d.senders.map((a:Sender)=>({id:a.id,name:a.name}))};
 }catch{return null;}
}

export function usePostDraft(key:string,defaults:PostDraft){
 const [restored]=useState(()=>readPostDraft(key));
 const [draft,setDraft]=useState<PostDraft>(()=>restored??defaults);
 const [savedAt,setSavedAt]=useState<number|null>(restored?.savedAt??null),[storageError,setStorageError]=useState('');
 const current=useRef(draft),initial=useRef(defaults),dirty=useRef(false),finished=useRef(false);
 const timer=useRef<ReturnType<typeof setTimeout>>();current.current=draft;
 const persist=useCallback((notify=true)=>{
  if(finished.current||!dirty.current)return;
  const d=current.current,now=Date.now();
  try{
   const data:StoredDraft={...(d.name!==undefined?{name:d.name}:{}),version:1,savedAt:now,link:d.link,targets:d.targets,delay:d.delay,mode:d.mode,requestId:d.requestId,senders:d.senders.map(a=>({id:a.id,name:a.name}))};
   localStorage.setItem(key,JSON.stringify(data));
   if(notify){setSavedAt(now);setStorageError('');}
  }catch{if(notify)setStorageError('Trình duyệt không lưu được bản tạm. Giữ cửa sổ này mở hoặc sao chép nội dung trước khi rời trang.');}
 },[key]);
 useEffect(()=>{if(dirty.current){timer.current=setTimeout(()=>persist(),250);}return()=>clearTimeout(timer.current);},[draft,persist]);
 useEffect(()=>{
  const flush=()=>persist(false);
  const hidden=()=>{if(document.visibilityState==='hidden')flush();};
  window.addEventListener('pagehide',flush);document.addEventListener('visibilitychange',hidden);
  return()=>{clearTimeout(timer.current);flush();window.removeEventListener('pagehide',flush);document.removeEventListener('visibilitychange',hidden);};
 },[persist]);
 const update=useCallback((patch:Partial<PostDraft>)=>{
  dirty.current=true;finished.current=false;
  const next={...current.current,...patch,requestId:crypto.randomUUID()};current.current=next;setDraft(next);
 },[]);
 function remove(){clearTimeout(timer.current);try{localStorage.removeItem(key);setStorageError('');}catch{setStorageError('Không xóa được bản tạm trong trình duyệt.');}}
 function clear(){dirty.current=false;finished.current=false;remove();setSavedAt(null);setDraft({...initial.current,requestId:crypto.randomUUID()});}
 function complete(){finished.current=true;dirty.current=false;remove();}
 return {draft,update,savedAt,storageError,restored:!!restored,saveNow:()=>{dirty.current=true;persist();},clear,complete};
}
