import {act,renderHook,waitFor} from '@testing-library/react';
import {beforeEach,expect,it,vi} from 'vitest';
import {postDraftKey,readPostDraft,usePostDraft,type PostDraft} from './usePostDraft';
const fresh=():PostDraft=>({link:'',targets:'',delay:'60',mode:'forward',senders:[],requestId:crypto.randomUUID()});
beforeEach(()=>{localStorage.clear();vi.restoreAllMocks();});

it('flushes the latest edit on close and restores the entire draft with the same request ID',()=>{
 const key=postDraftKey('user-a','new');
 const first=renderHook(()=>usePostDraft(key,fresh()));
 act(()=>first.result.current.update({link:'https://t.me/source_group/123',targets:'@one_group\nNhóm lỗi',delay:'120',mode:'copy',senders:[{id:'a1',name:'SS 1',spam_response:'private-extra'}]}));
 const requestId=first.result.current.draft.requestId;first.unmount();
 const raw=localStorage.getItem(key)!;expect(raw).not.toContain('private-extra');expect(raw).not.toContain('spam_response');
 const second=renderHook(()=>usePostDraft(key,fresh()));
 expect(second.result.current.draft).toMatchObject({link:'https://t.me/source_group/123',targets:'@one_group\nNhóm lỗi',delay:'120',mode:'copy',senders:[{id:'a1',name:'SS 1'}],requestId});
 expect(second.result.current.restored).toBe(true);second.unmount();
});
it('autosaves and persists before reload, but never recreates a completed or cleared draft',async()=>{
 const key=postDraftKey('user-a','new');const view=renderHook(()=>usePostDraft(key,fresh()));
 act(()=>view.result.current.update({targets:'@one_group'}));
 await waitFor(()=>expect(readPostDraft(key)?.targets).toBe('@one_group'));
 act(()=>{view.result.current.update({targets:'@last_edit'});window.dispatchEvent(new Event('pagehide'));});
 expect(readPostDraft(key)?.targets).toBe('@last_edit');
 act(()=>view.result.current.clear());expect(localStorage.getItem(key)).toBeNull();expect(view.result.current.draft.targets).toBe('');
 act(()=>{view.result.current.update({targets:'@new_group'});view.result.current.saveNow();});
 act(()=>view.result.current.complete());view.unmount();expect(localStorage.getItem(key)).toBeNull();
});
it('separates users and edit/clone forms and expires temporary data after seven days',()=>{
 const key=postDraftKey('user-a','new');const first=renderHook(()=>usePostDraft(key,fresh()));
 act(()=>first.result.current.update({targets:'@private_group'}));first.unmount();
 expect(readPostDraft(postDraftKey('user-b','new'))).toBeNull();expect(readPostDraft(postDraftKey('user-a','edit:r1'))).toBeNull();expect(readPostDraft(postDraftKey('user-a','clone:r1'))).toBeNull();
 const data=JSON.parse(localStorage.getItem(key)!);data.savedAt=Date.now()-8*86400000;localStorage.setItem(key,JSON.stringify(data));
 expect(readPostDraft(key)).toBeNull();expect(localStorage.getItem(key)).toBeNull();
});
it('keeps input in memory and reports when browser storage is unavailable',()=>{
 const spy=vi.spyOn(Storage.prototype,'setItem').mockImplementation(()=>{throw new DOMException('Full','QuotaExceededError');});
 const view=renderHook(()=>usePostDraft(postDraftKey('u','new'),fresh()));
 act(()=>{view.result.current.update({targets:'@keep_this'});view.result.current.saveNow();});
 expect(view.result.current.draft.targets).toBe('@keep_this');expect(view.result.current.storageError).toContain('không lưu được');expect(view.result.current.savedAt).toBeNull();
 view.unmount();spy.mockRestore();
});
