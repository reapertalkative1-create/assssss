"""Forwarding engine: observe messages, filter them, queue them, execute claimed jobs, report results.

* Message text is used only for local filtering. Only ids go to the control plane; nothing about content is logged.
* Reliability: every observed message is queued with an idempotency key (the server dedupes), a per-source checkpoint
  moves forward only after the server accepted the items, and on every (re)connect the engine catches up from that
  checkpoint. Results that could not be reported are kept and retried so a finished send is not repeated needlessly.
* Pacing: the server enforces per-route and per-account rate limits and Telegram FloodWait; the worker additionally
  pauses briefly between sends and never sleeps through a FloodWait (it reports the exact seconds instead)."""
import asyncio
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass

from worker.accounts import DEAD_SESSION_CODES, AccountManager
from worker.backoff import Backoff
from worker.client import ControlPlaneClient, ControlPlaneError, RouteConfig, TransientError
from worker.filters import matches
from worker.telegram_backend import BackendError, MessageFacts, TelegramBackend

log = logging.getLogger("tfcc.forwarding")

PERMANENT = {"destination_forbidden", "chat_unavailable", "message_not_found", "forward_restricted", "media_unsupported"}
ENQUEUE_CHUNK = 200
MAX_ENQUEUE_JOBS = 1000
RESULT_CHUNK = 50


@dataclass
class _Entry:
    route_id: str
    chat_id: int
    message_id: int
    match: bool


class ForwardEngine:
    def __init__(self, client: ControlPlaneClient, manager: AccountManager, backend: TelegramBackend, *,
                 max_backfill: int = 200, backfill_rounds: int = 20, send_interval: float = 0.3, claim_wait: int = 10,
                 flush_interval: float = 0.5, max_jobs: int = 10, clock: Callable[[], float] = time.monotonic):
        self._client, self._manager, self._backend, self._clock = client, manager, backend, clock
        self._max_backfill, self._rounds, self._send_interval = max_backfill, backfill_rounds, send_interval
        self._claim_wait, self._flush_interval, self._max_jobs = claim_wait, flush_interval, max_jobs
        self.routes: dict[str, RouteConfig] = {}
        self._buffer: list[_Entry] = []
        # Live updates cannot advance checkpoints past history still being read.
        self._deferred_live: list[_Entry] = []
        self._flush_lock = asyncio.Lock()
        self._watch: dict[str, tuple[frozenset[int], object]] = {}
        self._synced: set[tuple[str, int]] = set()
        self._unsent: list[dict] = []
        self._locks: dict[str, asyncio.Lock] = {}

    # ------------------------------------------------------------------ configuration from the control plane
    async def on_routes(self, routes) -> None:
        old = self.routes
        new: dict[str, RouteConfig] = {}
        for r in routes:
            prev = old.get(r.route_id)
            if prev is not None:  # keep checkpoint progress made locally since the server last told us
                for src, mid in prev.checkpoints.items():
                    r.checkpoints[src] = max(r.checkpoints.get(src, 0), mid)
            new[r.route_id] = r
        self.routes = new
        self._buffer = [e for e in self._buffer if e.route_id in new and e.chat_id in new[e.route_id].sources]
        self._deferred_live = [e for e in self._deferred_live if e.route_id in new and e.chat_id in new[e.route_id].sources]
        self._synced = {k for k in self._synced if k[0] in new and k[1] in new[k[0]].sources}
        for aid in {r.account_id for r in new.values()} | set(self._watch):
            await self._sync_account(aid)

    async def on_account_connected(self, aid: str, handle) -> None:
        self._watch.pop(aid, None)
        self._synced = {k for k in self._synced if self.routes.get(k[0]) is None or self.routes[k[0]].account_id != aid}
        await self._sync_account(aid)

    async def on_account_dropped(self, aid: str) -> None:
        self._watch.pop(aid, None)
        self._synced = {k for k in self._synced if self.routes.get(k[0]) is None or self.routes[k[0]].account_id != aid}

    def _routes_of(self, aid: str) -> list[RouteConfig]:
        return [r for r in self.routes.values() if r.account_id == aid]

    async def _sync_account(self, aid: str) -> None:
        lock = self._locks.setdefault(aid, asyncio.Lock())
        async with lock:
            handle = self._manager.handle_for(aid)
            if handle is None:
                return
            routes = self._routes_of(aid)
            current = self._watch.get(aid)
            if not routes:
                if current:
                    self._backend.unwatch(handle, current[1])
                    self._watch.pop(aid, None)
                return
            chats = frozenset(c for r in routes for c in r.sources)
            if current is None or current[0] != chats:
                if current:
                    self._backend.unwatch(handle, current[1])
                token = self._backend.watch(handle, set(chats), lambda facts, aid=aid: self._on_message(aid, facts))
                self._watch[aid] = (chats, token)
            for r in routes:
                for src in r.sources:
                    if (r.route_id, src) not in self._synced:
                        await self._init_source(handle, r, src)

    def _on_message(self, aid: str, facts: MessageFacts) -> None:
        for r in self._routes_of(aid):
            if facts.chat_id in r.sources:
                entry = _Entry(r.route_id, facts.chat_id, facts.message_id, matches(r.filters, facts))
                target = self._buffer if (r.route_id, facts.chat_id) in self._synced else self._deferred_live
                target.append(entry)

    async def _init_source(self, handle, route: RouteConfig, src: int) -> None:
        """First time on a source: start from NOW (no history is forwarded). Afterwards: catch up from the checkpoint."""
        try:
            cp = route.checkpoints.get(src)
            if cp is None:
                latest = await self._backend.latest_message_id(handle, src)
                await self._client.enqueue(route.route_id, [], {src: latest})
                route.checkpoints[src] = latest
            else:
                for _ in range(self._rounds):
                    msgs = await self._backend.history_since(handle, src, cp, self._max_backfill)
                    for m in msgs:
                        self._buffer.append(_Entry(route.route_id, src, m.message_id, matches(route.filters, m)))
                    if msgs:
                        cp = max(m.message_id for m in msgs)
                    await self._flush()
                    if route.checkpoints.get(src, 0) < cp:
                        return  # retry from the acknowledged checkpoint next heartbeat
                    if len(msgs) < self._max_backfill:
                        break
                else:
                    return  # continue next heartbeat without releasing live updates
            self._synced.add((route.route_id, src))
            pending, self._deferred_live = self._deferred_live, []
            for entry in pending:
                if (entry.route_id, entry.chat_id) == (route.route_id, src):
                    if entry.message_id > route.checkpoints.get(src, 0):
                        self._buffer.append(entry)
                else:
                    self._deferred_live.append(entry)
        except (BackendError, ControlPlaneError) as exc:
            log.warning("source_init_failed", extra={"route": route.route_id, "chat": src, "error": getattr(exc, "code", type(exc).__name__)})

    # ------------------------------------------------------------------ queueing
    async def _flush(self) -> None:
        async with self._flush_lock:
            await self._flush_locked()

    async def _flush_locked(self) -> None:
        batch, self._buffer = self._buffer, []
        by_route: dict[str, list[_Entry]] = {}
        for e in batch:
            by_route.setdefault(e.route_id, []).append(e)
        batches = list(by_route.items())
        for route_index, (rid, entries) in enumerate(batches):
            route = self.routes.get(rid)
            if route is None:
                continue
            entries.sort(key=lambda e: (e.chat_id, e.message_id))   # ascending: a checkpoint never jumps over unsent ids
            chunk_size = min(ENQUEUE_CHUNK, MAX_ENQUEUE_JOBS // max(1, len(route.destinations)))
            for i in range(0, len(entries), chunk_size):
                chunk = entries[i:i + chunk_size]
                items = [(e.chat_id, e.message_id) for e in chunk if e.match]
                cps: dict[int, int] = {}
                for e in chunk:
                    cps[e.chat_id] = max(cps.get(e.chat_id, 0), e.message_id)
                try:
                    await self._client.enqueue(rid, items, cps)
                except ControlPlaneError as exc:
                    self._buffer = entries[i:] + self._buffer
                    log.warning("enqueue_rejected", extra={"route": rid, "error": getattr(exc, "code", type(exc).__name__)})
                    break
                except BaseException:
                    remaining = [e for _, pending in batches[route_index + 1:] for e in pending]
                    self._buffer = entries[i:] + remaining + self._buffer
                    raise
                route = self.routes.get(rid)
                if route:
                    for src, mid in cps.items():
                        route.checkpoints[src] = max(route.checkpoints.get(src, 0), mid)

    # ------------------------------------------------------------------ executing jobs
    async def _run_job(self, job: dict) -> dict:
        base = {"id": job["id"], "epoch": job["epoch"]}
        aid = str(job["account_id"])
        handle = self._manager.handle_for(aid)
        if handle is None:  # fenced or stopped meanwhile: do not touch Telegram
            return {**base, "status": "retry", "error_code": "account_not_connected", "retry_after": 10}
        try:
            dest_id = await self._backend.forward(handle, job["source_chat_id"], job["message_id"], job["dest_chat_id"], job["mode"])
            return {**base, "status": "succeeded", "dest_message_id": dest_id}
        except BackendError as exc:
            if exc.code in PERMANENT:
                return {**base, "status": "failed", "error_code": exc.code}
            if exc.code in DEAD_SESSION_CODES:
                await self._manager.report_error(aid, exc.code)
            if job.get('post_once') and exc.code in ('network_error','telegram_error','internal_error'):
                return {**base,'status':'failed','error_code':'delivery_uncertain'}
            return {**base, "status": "retry", "error_code": exc.code, "retry_after": exc.retry_after}
        except Exception as exc:
            log.error("forward_error", extra={"error": type(exc).__name__})
            if job.get('post_once'):
                return {**base,'status':'failed','error_code':'delivery_uncertain'}
            return {**base, "status": "retry", "error_code": "internal_error"}

    async def _report(self, results: list[dict]) -> None:
        self._unsent.extend(results)
        await self._resend_unsent()

    async def _resend_unsent(self) -> None:
        while self._unsent:
            chunk = self._unsent[:RESULT_CHUNK]
            try:
                await self._client.post_job_results(chunk)
            except ControlPlaneError as exc:
                log.warning("results_rejected", extra={"error": type(exc).__name__})
                return
            del self._unsent[:len(chunk)]

    async def execute_once(self) -> int:
        """One claim -> start -> send -> report cycle. Returns the number of jobs attempted."""
        await self._resend_unsent()
        if self._unsent:
            raise TransientError("results_pending")
        jobs = await self._client.claim_jobs(self._max_jobs, self._claim_wait)
        if not jobs:
            return 0
        started, _lost = await self._client.start_jobs(jobs)
        results, flood_until = [], {}   # account id -> monotonic time until which Telegram told us to wait
        blocked_accounts=set()
        for job in jobs:
            if str(job["id"]) not in started:
                continue
            aid = str(job["account_id"])
            if aid in blocked_accounts:
                result={'id':job['id'],'epoch':job['epoch'],'status':'retry','error_code':'account_spam_restricted','retry_after':30}
                results.append(result);self._unsent.append(result);continue
            remaining = flood_until.get(aid, 0) - self._clock()
            if remaining > 0:
                # Telegram demanded a pause for this whole account: do not send the rest of the batch, hand the
                # jobs back with the time that is left (the server does not count it as a failed attempt).
                result = {"id": job["id"], "epoch": job["epoch"], "status": "retry", "error_code": "flood_wait",
                          "retry_after": int(remaining) + 1}
                results.append(result)
                self._unsent.append(result)
                continue
            result = await self._run_job(job)
            results.append(result)
            self._unsent.append(result)  # retain before cancellation at the next await
            if result.get("error_code") == "flood_wait":
                flood_until[aid] = self._clock() + (result.get("retry_after") or 30)
            if result.get('error_code') in ('account_spam_restricted','account_frozen'):blocked_accounts.add(aid)
            await asyncio.sleep(self._send_interval)
        await self._resend_unsent()
        return len(results)

    # ------------------------------------------------------------------ loops
    async def _sleep(self, seconds: float, stop: asyncio.Event) -> None:
        try:
            await asyncio.wait_for(stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def run(self, stop: asyncio.Event) -> None:
        await asyncio.gather(self._enqueue_loop(stop), self._execute_loop(stop))

    async def _enqueue_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            await self._sleep(self._flush_interval, stop)
            if self._buffer:
                try:
                    await self._flush()
                except Exception as exc:
                    log.error("flush_failed", extra={"error": type(exc).__name__})

    async def _execute_loop(self, stop: asyncio.Event) -> None:
        backoff = Backoff(1.0, 30.0)
        while not stop.is_set():
            if not self._manager.connected_accounts():
                await self._sleep(1.0, stop)
                continue
            try:
                n = await self.execute_once()
                backoff.reset()
                if n == 0 and self._claim_wait < 1:
                    await self._sleep(1.0, stop)
            except TransientError:
                await self._sleep(backoff.next(), stop)
            except ControlPlaneError:
                await self._sleep(5.0, stop)  # credential problems are handled by the heartbeat loop
            except Exception as exc:
                log.error("execute_failed", extra={"error": type(exc).__name__})
                await self._sleep(2.0, stop)

    async def shutdown(self) -> None:
        try:
            await asyncio.wait_for(self._flush(), timeout=5)
            await asyncio.wait_for(self._resend_unsent(), timeout=5)
        except Exception:
            pass
