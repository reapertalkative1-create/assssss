"""Exercise the card's Run action through the HTTP boundary and worker delivery."""
import asyncio
import uuid
from types import SimpleNamespace

from sqlalchemy import select

from app.models import ForwardJob, PostTargetOwner, TelegramAccount
from tests.conftest import run_db
from tests.unit.test_accounts_api import env  # noqa: F401
from tests.unit.test_multi_senders import setup
from tests.unit.test_routes_jobs_api import WJ
from tests.unit.test_work_clusters import create
from worker.forwarding import ForwardEngine


def prepare(env, count=132):
    worker, ids = setup(env, 2)
    worker.__class__ = WJ
    cluster, _ = create(env, ids, targets_text='\n'.join(f'@review_group_{i:03d}' for i in range(count)),
                        post_link='https://t.me/review_source/30')
    return worker, ids, cluster


def start(env, cluster):
    result = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h,
                             json={'request_id': str(uuid.uuid4()), 'revision': cluster['revision']})
    assert result.status_code == 201, result.text
    return result.json()


def test_two_senders_132_targets_reach_worker_with_real_references(env):
    worker, ids, cluster = prepare(env)
    result = start(env, cluster)
    assert len(result['started']) == 2 and result['failures'] == []
    assert result['cluster']['total_count'] == 132
    assert result['cluster']['run_status'] == 'running'
    assert env.client.get('/api/jobs').json()['total'] == 132
    for aid in ids:
        assert worker.lease(aid).status_code == 200
    jobs = worker.claim()
    assert len(jobs) == 2  # One paced job per account.
    assert worker.start(jobs).json()['started'] == [job['id'] for job in jobs]
    sent = []

    class Backend:
        async def assert_managed_destination(self, handle, dest):
            assert isinstance(dest, str) and dest.startswith('@review_group_')

        async def forward(self, handle, source, message_id, dest, mode):
            assert source == '@review_source' and message_id == 30
            assert isinstance(dest, str) and dest.startswith('@review_group_')
            sent.append(dest)
            return 700 + len(sent)

    async def execute():
        engine = ForwardEngine(None, SimpleNamespace(handle_for=lambda aid: object()), Backend())
        return [await engine._run_job(job) for job in jobs]

    results = asyncio.run(execute())
    assert all(row['status'] == 'succeeded' for row in results), results
    worker.results(results)
    assert len(set(sent)) == 2
    card = env.client.get(f"/api/work-clusters/{cluster['id']}").json()
    assert card['done_count'] == 2 and card['total_count'] == 132


def test_repeated_start_returns_the_active_loop_without_duplicate_jobs(env):
    _worker, _ids, cluster = prepare(env)
    start(env, cluster)
    repeated = start(env, cluster)
    assert repeated['started'] == [] and repeated['failures'] == []
    card = repeated['cluster']
    assert card['run_status'] == 'running' and card['loop_active'] is True
    assert card['total_count'] == 132 and card['done_count'] == 0
    assert all(row['status'] == 'pending' for row in card['outcomes'])
    assert env.client.get('/api/jobs').json()['total'] == 132


def test_restricted_senders_show_failure_and_keep_stopped_accounts_stopped(env):
    _worker, ids, cluster = prepare(env)
    async def restrict(db):
        for aid in ids:
            account = await db.get(TelegramAccount, uuid.UUID(aid))
            account.spam_status = 'limited'
    run_db(env.settings, restrict)
    result = start(env, cluster)
    assert result['started'] == [] and len(result['failures']) == 2
    card = result['cluster']
    assert card['run_status'] == 'blocked' and not card['running']
    assert card['total_count'] == card['error_count'] == 132
    assert card['done_count'] == card['completed_count'] == 0
    assert all(o['error_code'] == 'account_restricted' and o['error_message'] for o in card['outcomes'])
    assert env.client.get('/api/jobs').json()['total'] == 0
    assert all(env.client.get('/api/accounts/' + aid).json()['desired_state'] == 'stopped' for aid in ids)
    assert run_db(env.settings, lambda db: db.scalar(select(PostTargetOwner.target_key).limit(1))) is None


def test_one_failed_sender_does_not_rollback_other_sender_jobs(env):
    _worker, ids, cluster = prepare(env)
    async def restrict(db):
        (await db.get(TelegramAccount, uuid.UUID(ids[0]))).spam_status = 'limited'
    run_db(env.settings, restrict)
    result = start(env, cluster)
    assert len(result['started']) == len(result['failures']) == 1
    card = result['cluster']
    assert card['running'] and card['total_count'] == 132 and card['error_count'] == 66
    assert env.client.get('/api/jobs').json()['total'] == 66
    async def read_jobs(db):
        return set((await db.execute(select(ForwardJob.account_id))).scalars())
    assert run_db(env.settings, read_jobs) == {uuid.UUID(ids[1])}


def test_unstarted_draft_is_not_completed_zero_of_zero(env):
    _worker, _ids, cluster = prepare(env)
    response = env.client.post(f"/api/work-clusters/{cluster['id']}/runs", headers=env.h,
                               json={'request_id': str(uuid.uuid4()), 'revision': cluster['revision']})
    assert response.status_code == 201, response.text
    card = env.client.get(f"/api/work-clusters/{cluster['id']}").json()
    assert card['run_status'] == 'not_started'
    assert card['total_count'] == 132 and card['completed_count'] == 0
