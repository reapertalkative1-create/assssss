"""Persistent forward loops. Each sender owns a disjoint set of destinations.

A pass is stored before delivery; API/worker restarts cannot reshuffle an open
pass or enqueue it twice. Failed deliveries finish their job, not the session.
"""
import logging
from datetime import datetime, timedelta

from sqlalchemy import select

from app.errors import ApiError
from app.models import ForwardJob, ForwardRoute, TelegramAccount, WorkCluster
from app.services import accounts, jobs, post_delivery, routes
from app.services.post_links import parse_post_link, target_ids

OPEN = ('pending', 'claimed', 'running', 'retry_wait')
log = logging.getLogger('tfcc.forward_loops')


async def loop_routes(db, cluster_id):
    return list((await db.execute(select(ForwardRoute).where(
        ForwardRoute.link_config['work_cluster_id'].as_string() == str(cluster_id),
        ForwardRoute.link_config['forward_loop'].as_boolean().is_(True),
        ForwardRoute.link_config['loop_enabled'].as_boolean().is_(True)
    ).order_by(ForwardRoute.id).with_for_update())).scalars())


async def advance_route(db, route, settings, now):
    """Start/recover one sender, or enqueue its next pass after every job settles."""
    config = dict(route.link_config or {})
    if not config.get('loop_enabled'):
        return False
    if config.get('retry_start_at') and datetime.fromisoformat(config['retry_start_at']) > now:
        return False
    pending = await db.scalar(select(ForwardJob.id).where(
        ForwardJob.route_id == route.id, ForwardJob.status.in_(OPEN)).limit(1))
    if pending and route.status == 'active':
        return False
    account = await db.get(TelegramAccount, route.account_id)
    if account is None or account.pending_deletion:
        raise ApiError(409, 'account_not_found', 'SS đã bị xóa hoặc đang xóa. Sửa cấu hình cụm trước khi chạy lại.')
    if config.get('queued_at') and account.desired_state != 'running':
        raise ApiError(409, 'account_not_running', 'SS đang dừng. Bật lại SS để tiếp tục; các SS khác vẫn chạy.')
    await accounts.worker_can_take_commands(db, account.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
    # check_startable retains authentication, restriction and proxy checks.
    # The savepoint rolls this change back if that sender cannot start yet.
    account.desired_state = 'running'
    config.update(auto_start=True, managed_targets_only=False)
    post = parse_post_link(config['post_link'])
    if not route.source_chat_ids:
        route.source_chat_ids = [post['peer']] if isinstance(post['peer'], int) else [-1]
        if isinstance(post['peer'], str):
            config['source_peer'] = post['peer']
        route.destination_chat_ids, config['dest_peers'] = target_ids(config['targets'])
    config['message_id'] = post['message_id']
    route.link_config = dict(config)
    await routes.check_startable(db, route, account)
    if not config.get('queued_at'):
        await post_delivery.bind_route(db, route, now)
    for key in ('start_error_code', 'start_error_message', 'retry_start_at', 'pause_reason'):
        config.pop(key, None)
    if not pending:
        next_at = now
        if config.get('queued_at'):
            previous = (await db.execute(select(ForwardJob.finished_at, ForwardJob.cooldown_seconds).where(
                ForwardJob.route_id == route.id, ForwardJob.finished_at.is_not(None)
            ).order_by(ForwardJob.finished_at.desc()).limit(1))).first()
            if previous:
                next_at = max(now, previous[0] + timedelta(seconds=max(
                    config['delay_seconds'], previous[1])))
            config['loop_pass'] = config.get('loop_pass', 1) + 1
        else:
            config['loop_pass'] = 1
        config['pass_started_at'] = now.isoformat()
        route.link_config = dict(config)
        await jobs.enqueue(db, route, [(route.source_chat_ids[0], post['message_id'])], next_at,
                           spacing_seconds=config['delay_seconds'])
        config['queued_at'] = now.isoformat()
    route.link_config = dict(config)
    route.status = 'active'
    route.started_at = route.started_at or now
    return True


async def try_advance_route(db, route_id, settings, now):
    """One sender's failure must not roll back another sender's work."""
    failure = None
    try:
        async with db.begin_nested():
            route = await db.get(ForwardRoute, route_id, populate_existing=True)
            changed = await advance_route(db, route, settings, now)
        return changed, None
    except ApiError as exc:
        failure = (exc.code, exc.message)
    except Exception as exc:
        log.warning('forward_loop_sender_failed', extra={'route_id': str(route_id), 'error': type(exc).__name__})
        failure = ('start_failed', 'Chưa tạo được công việc gửi. Cụm sẽ thử lại; xem nhật ký máy chủ để biết chi tiết.')
    route = await db.get(ForwardRoute, route_id, populate_existing=True)
    route.link_config = {**route.link_config, 'start_error_code': failure[0],
                         'start_error_message': failure[1],
                         'retry_start_at': (now + timedelta(seconds=30)).isoformat()}
    return False, failure


async def continue_forward_loops(db, settings, now):
    # Same cluster lock as Start/Stop: a concurrent stop fences future passes.
    cluster_ids = list((await db.execute(select(WorkCluster.id).where(
        WorkCluster.cluster_type == 'forward', WorkCluster.loop_active.is_(True)))).scalars())
    advanced = 0
    for cid in cluster_ids:
        cluster = (await db.execute(select(WorkCluster).where(WorkCluster.id == cid)
            .with_for_update().execution_options(populate_existing=True))).scalar_one_or_none()
        if cluster is None or not cluster.loop_active:
            continue
        for route in await loop_routes(db, cid):
            changed, _ = await try_advance_route(db, route.id, settings, now)
            advanced += int(changed)
    return advanced
