import {useEffect,useRef,useState} from 'react';
import {Link} from 'react-router-dom';
import {api,ApiError} from '../api/client';
import type {Job,Page,Route,WorkCluster,WorkClusterSeed} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,Pill,SelectField,TextArea,TextField} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {fmtDateTime} from '../lib/format';
import {errorLabel,jobStatus} from '../lib/labels';

const pending=(r:Route)=>['pending','retry_wait','claimed','running'].reduce((n,k)=>n+(r.stats[k]??0),0);
export const deliveryDone=(r:Route)=>!!r.link_config?.queued_at&&!r.link_config.pause_reason&&pending(r)===0&&(Object.values(r.stats).some(n=>n>0)||(r.link_config.duplicate_count??0)>0);
export function deliveryLabel(r:Route){
 if(!r.link_config)return r.status==='active'?'Theo dõi nguồn':r.status==='paused'?'Tạm dừng':'Đã dừng';
 if(r.link_config.pause_reason==='delivery_uncertain')return 'Cần đối chiếu kết quả';
 if(r.account_issue)return errorLabel(r.account_issue)||'SS cần xử lý';
 if(r.link_config.queued_at&&r.link_config.queued_count===0&&(r.link_config.duplicate_count??0)>0)return 'Bỏ qua bài trùng';
 if(deliveryDone(r))return (r.stats.failed??0)+(r.stats.dead_letter??0)>0?'Xong · có lỗi':'Hoàn tất';
 if(r.account_restriction)return 'SS đang hạn chế';
 if(r.account_wait_until&&Date.parse(r.account_wait_until)>Date.now())return 'Telegram yêu cầu chờ';
 if(r.verification_pending)return 'Đang kiểm tra';
 if(r.verification_error)return 'Kiểm tra chưa đạt';
 if(r.status==='paused')return 'Tạm dừng';
 if(r.status==='active')return r.link_config.scheduled_at&&Date.parse(r.link_config.scheduled_at)>Date.now()?'Chờ lịch':'Đang gửi';
 if(r.link_config.queued_at)return 'Đã dừng';
 return r.verified?'Sẵn sàng':'Bản nháp';
}
import {SenderPicker,type Sender} from './SenderPicker';
import {useAccountSelection} from '../state/accountSelection';
import {postDraftKey,usePostDraft,type PostDraft} from '../hooks/usePostDraft';
import {TargetIssues,targetIssues,type TargetIssuesData} from './TargetIssues';


export function PostRouteForm({route,clone=false,fromAccounts=false,draftOwner='local',clusterMode=false,cluster,initialCluster,onClusterSaved,onClose,onSaved}:{clusterMode?:boolean;cluster?:WorkCluster;initialCluster?:WorkClusterSeed;onClusterSaved?:(c:WorkCluster)=>void;route?:Route;clone?:boolean;fromAccounts?:boolean;draftOwner?:string;onClose:()=>void;onSaved:(r:Route)=>void}){
 const config=route?.link_config;
 const cache=usePostDraft(postDraftKey(draftOwner,clusterMode?`cluster:${cluster?`${cluster.id}:${cluster.revision}`:initialCluster?`import:${initialCluster.seed_key}`:'new'}`:route?`${clone?'clone':'edit'}:${route.id}`:'new'),{
  ...(clusterMode?{name:cluster?.name??initialCluster?.name??''}:{}),
  link:cluster?.post_link??config?.post_link??'',targets:cluster?.targets.join('\n')??initialCluster?.targets.join('\n')??config?.targets.join('\n')??'',delay:String(cluster?.delay_seconds??initialCluster?.delay_seconds??config?.delay_seconds??(clusterMode?150:60)),delayMax:String(cluster?.delay_max_seconds??cluster?.delay_seconds??initialCluster?.delay_seconds??180),mode:cluster?.mode??initialCluster?.mode??route?.mode??'forward',
  senders:cluster?.senders??initialCluster?.senders??(route?[{id:route.account_id,name:route.account_name??route.account_id}]:[]),requestId:crypto.randomUUID(),
 });
 const {senders,link,targets,delay,delayMax=delay,mode,requestId,name=''}=cache.draft;
 const {saved}=useAccountSelection();const initialized=useRef(false),targetInput=useRef<HTMLTextAreaElement>(null);
 const [selecting,setSelecting]=useState(false),[checking,setChecking]=useState(false),[validated,setValidated]=useState<number|null>(null);
 const [busy,setBusy]=useState(false),[loadingFile,setLoadingFile]=useState(false),[error,setError]=useState(''),[issues,setIssues]=useState<TargetIssuesData|null>(null);
 const locked=busy||checking;
 function change(patch:Partial<PostDraft>){cache.update(patch);setError('');if('targets' in patch){setIssues(null);setValidated(null);}}
 const setSenders=(value:Sender[])=>change({senders:value}),setTargets=(value:string)=>change({targets:value});
 function report(e:unknown){const detail=e instanceof ApiError?targetIssues(e):null;setIssues(detail);setError(detail?'':e instanceof ApiError?e.message:'Không lưu được đợt gửi.');}
 function locate(line:number){
  const el=targetInput.current;if(!el)return;
  const breaks=[...targets.matchAll(/\r\n|[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]/g)];
  const prev=breaks[line-2],next=breaks[line-1];const start=prev?(prev.index??0)+prev[0].length:0,end=next?.index??targets.length;
  el.focus();el.setSelectionRange(start,end);el.scrollTop=Math.max(0,(line-3)*(parseFloat(getComputedStyle(el).lineHeight)||18));el.scrollIntoView?.({block:'center',behavior:'smooth'});
 }
 async function validate(){setChecking(true);setError('');setIssues(null);setValidated(null);try{const r=await api.post<{count:number}>('/api/post-routes/validate-targets',{targets_text:targets});setValidated(r.count);}catch(e){report(e);}finally{setChecking(false);}}
 useEffect(()=>{if(!fromAccounts||!saved||initialized.current)return;initialized.current=true;api.post<{items:Sender[];skipped_count:number}>('/api/post-routes/senders',saved.selection).then(r=>{setSenders(r.items);if(r.skipped_count)setError(`Bỏ qua ${r.skipped_count} SS đã/đang xóa.`);}).catch(e=>setError(e instanceof ApiError?e.message:'Không lấy được SS đã tích.'));},[fromAccounts,saved]);
 async function file(file?:File){if(!file)return;setError('');if(file.size>500000){setError('File nhóm tối đa 500 KB.');return;}setLoadingFile(true);try{setTargets(await file.text());}catch{setError('Không đọc được file TXT.');}finally{setLoadingFile(false);}}
 async function save(){
  if(!senders.length||(!clusterMode&&!link.trim())||!targets.trim()||(clusterMode&&!name.trim())){setError(clusterMode?'Đặt tên cụm, chọn SS và nhập danh sách nhóm.':'Chọn tài khoản, dán link bài viết và danh sách nhóm.');return;}
  if(!/^\d+$/.test(delay)||Number(delay)<5||Number(delay)>86400){setError('Thời gian nghỉ từ 5 đến 86.400 giây.');return;}
  if(clusterMode&&(!/^\d+$/.test(delayMax)||Number(delayMax)<Number(delay)||Number(delayMax)>86400)){setError('Mốc nghỉ đến phải từ mốc bắt đầu đến 86.400 giây.');return;}
  setBusy(true);setError('');
  const body={name:route&&!clone?route.name:`Đợt gửi ${crypto.randomUUID().slice(0,8)}`,account_id:senders[0]?.id,post_link:link.trim(),targets_text:targets,delay_seconds:Number(delay),scheduled_at:null,mode};
  try{if(clusterMode){const data={name:name.trim(),account_ids:senders.map(a=>a.id),targets_text:targets,post_link:link.trim(),delay_seconds:Number(delay),delay_max_seconds:Number(delayMax),mode};const saved=cluster?await api.patch<WorkCluster>(`/api/work-clusters/${cluster.id}`,{...data,revision:cluster.revision}):await api.post<WorkCluster>('/api/work-clusters',{...data,request_id:requestId});cache.complete();onClusterSaved?.(saved);return;}let result:Route;if(route&&!clone){result=await api.patch<Route>(`/api/post-routes/${route.id}`,body);}else{const {account_id:_,name:__,scheduled_at:___,...post}=body;const batch=await api.post<{items:Route[]}>('/api/post-routes/batches',{...post,account_ids:senders.map(a=>a.id),request_id:requestId});result=batch.items[0];}cache.complete();onSaved(result);}
  catch(e){report(e);setBusy(false);}
 }
 const lines=targets.split(/\r?\n/).filter(s=>s.trim()&&!s.trim().startsWith('#')).length;
 return <Modal wide title={clusterMode?(cluster?'Sửa cụm làm việc':'Tạo cụm làm việc'):route&&!clone?'Sửa đợt gửi':'Gửi bài từ liên kết'} onClose={onClose} dismissible={!locked&&!loadingFile} footer={<><button className="btn" disabled={locked||loadingFile} onClick={onClose}>Đóng</button><button className="btn primary" disabled={locked||selecting||loadingFile} onClick={()=>void save()}>{busy?'Đang lưu…':clusterMode?(cluster?'Lưu cụm':'Tạo cụm'):'Lưu đợt gửi'}</button></>}>
  <div className="post-draft-bar"><div><strong>{cache.savedAt?`${cache.restored?'Đã khôi phục bản tạm':'Đã lưu tạm'} · ${new Date(cache.savedAt).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'})}`:'Tự lưu tạm'}</strong><span>Trong trình duyệt này · giữ 7 ngày</span></div><div className="row"><button className="btn sm" disabled={locked||loadingFile} onClick={cache.saveNow}>Lưu tạm</button><button className="btn ghost sm" disabled={locked||loadingFile} onClick={()=>{cache.clear();setError('');setIssues(null);setValidated(null);}}>Xóa bản tạm</button></div></div>
  {initialCluster&&<Alert>{initialCluster.senders.length} SS và {initialCluster.targets.length} nhóm từ các dòng đã chọn. Đặt tên để lưu cụm.{initialCluster.mixed_settings&&' Các dòng có cách gửi/thời gian nghỉ khác nhau; kiểm tra lại hai ô này trước khi lưu.'}</Alert>}
  {cache.storageError&&<Alert tone="bad">{cache.storageError}</Alert>}
  <div className="post-form-grid">
   <div className="stack tight">
    {clusterMode&&<TextField label="Tên cụm làm việc" value={name} maxLength={64} disabled={locked} onChange={e=>change({name:e.target.value})} placeholder="Ví dụ: Cộng đồng khách hàng" hint="Lưu bài viết, SS, nhóm nhận và khoảng nghỉ cùng một nơi."/>}
    <SenderPicker onBusyChange={setSelecting} value={senders} onChange={setSenders} disabled={locked} single={!!route&&!clone}/>
    {!!cluster?.missing_account_ids.length&&<button className="btn sm" disabled={locked} onClick={()=>setSenders(senders.filter(a=>!cluster.missing_account_ids.includes(a.id)))}>Bỏ SS đã xóa ({cluster.missing_account_ids.length})</button>}
    {!route||clone?<p className="hint">Giữ SS đã phụ trách nhóm; nhóm mới được chia giữa {senders.length} SS đã chọn. SS dư không nhận việc. Lưu nháp để xem phân công.</p>:null}
    <div className="post-guards"><span>SS cố định</span><span>Chống gửi trùng</span><span>Chờ FloodWait</span><span>Dừng khi hạn chế</span></div>
    <div className="sender-filters"><SelectField label="Cách gửi bài" value={mode} disabled={locked} onChange={e=>change({mode:e.target.value as 'forward'|'copy'})}><option value="forward">Chuyển tiếp · giữ nguồn</option><option value="copy">Sao chép nội dung</option></SelectField>
    {clusterMode?<fieldset className="cluster-delay"><legend>Nghỉ giữa hai nhóm (giây)</legend><div><TextField label="Từ" type="number" min={5} max={86400} value={delay} disabled={locked} onChange={e=>change({delay:e.target.value})}/><span>–</span><TextField label="Đến" type="number" min={Number(delay)||5} max={86400} value={delayMax} disabled={locked} onChange={e=>change({delayMax:e.target.value})}/></div><small>Ngẫu nhiên trong khoảng đã lưu. Telegram có thể yêu cầu chờ lâu hơn.</small></fieldset>:<TextField label="Nghỉ giữa hai nhóm (giây)" type="number" min={5} max={86400} value={delay} disabled={locked} onChange={e=>change({delay:e.target.value})}/>}</div>
    <p className="hint">{clusterMode?'Bấm Chạy trên thẻ cụm để lặp liên tục đến khi bấm Dừng. Mỗi SS có nhóm riêng, chọn thứ tự ngẫu nhiên mỗi vòng; nhóm lỗi không dừng cụm.':'Gửi một lượt sau khi bạn bấm bắt đầu; SS đang tắt sẽ được bật khi bắt đầu gửi.'} FloodWait áp dụng cho cả SS, không tự đổi tài khoản.</p>
   </div>
   <div className="stack tight">
    {<TextField label="Liên kết bài viết Telegram" value={link} maxLength={500} disabled={locked} onChange={e=>change({link:e.target.value})} placeholder="https://t.me/tenkenh/123" hint={clusterMode?"Lưu theo cụm. Lần sau bấm Chạy để dùng lại; sửa liên kết khi đổi bài.":"Dán liên kết lấy từ Sao chép liên kết tin nhắn. Mỗi đợt một bài."}/>}
    <label className="field">File danh sách nhóm .txt<input type="file" accept=".txt,text/plain" disabled={locked||selecting||loadingFile} onChange={e=>void file(e.target.files?.[0])}/></label>
    <TextArea label="Nhóm nhận bài" inputRef={targetInput} rows={11} value={targets} maxLength={500000} disabled={locked||loadingFile} onChange={e=>setTargets(e.target.value)} spellCheck={false} placeholder={'@nhom_cua_ban\nhttps://t.me/nhom_cua_ban_2\n-1001234567890'}/>
    {issues&&<TargetIssues data={issues} onLocate={locate}/>}
    <div className="row between"><button className="btn sm" disabled={locked||loadingFile||!targets.trim()} onClick={()=>void validate()}>{checking?'Đang kiểm tra…':'Kiểm tra danh sách'}</button>{validated!==null&&<span className="hint" role="status">{validated} nhóm đúng định dạng</span>}</div>
    <div className="row between"><span className="hint">{lines} dòng · tối đa 1.000 nhóm · tự bỏ dòng trống, # và trùng</span>{targets===config?.targets.join('\n')&&config?.checks?.some(c=>!c.can_send)&&<button disabled={locked} className="btn sm" onClick={()=>setTargets(config.checks!.filter(c=>c.can_send).map(c=>config.targets[c.index]).join('\n'))}>Chỉ giữ nhóm hợp lệ</button>}</div>
    <p className="hint">Chỉ dùng nhóm/kênh bạn có quyền đăng. Link mời chỉ tra được nhóm SS đã tham gia; ứng dụng không tự vào nhóm. Bài nguồn bảo vệ chuyển tiếp sẽ được báo lỗi.</p>
   </div>
  </div>
  {error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}

export function PostRouteDetail({route,onClose,onVerify,onAction}:{route:Route;onClose:()=>void;onVerify:()=>Promise<void>;onAction:(action:'start'|'pause'|'resume'|'stop')=>Promise<void>}){
 const live=useQuery(signal=>api.get<Route>(`/api/routes/${route.id}`,undefined,signal),[route.id],{interval:2000});const r=live.data??route;const c=r.link_config!;
 const [tab,setTab]=useState('groups'),[filter,setFilter]=useState(''),[page,setPage]=useState(1),[busy,setBusy]=useState(false),[reviewError,setReviewError]=useState('');
 const jobs=useQuery(signal=>api.get<Page<Job>>('/api/jobs',{route_id:r.id,status:filter||undefined,page,page_size:50},signal),[r.id,filter,page],{enabled:!!c.queued_at,interval:2000});
 const [groupPage,setGroupPage]=useState(1);
 async function action(a:'start'|'pause'|'resume'|'stop'){setBusy(true);try{await onAction(a);live.reload();jobs.reload();}finally{setBusy(false);}}
 async function review(j:Job,delivered:boolean){setBusy(true);setReviewError('');try{await api.post(`/api/jobs/${j.id}/review-delivery`,{delivered});live.reload();jobs.reload();}catch(e){setReviewError(e instanceof ApiError?e.message:'Không lưu được kết quả đối chiếu.');}finally{setBusy(false);}}
 const checks=new Map(c.checks?.map(x=>[x.index,x]));
 const title=(id:number)=>c.checks?.find(v=>v.id===id)?.title||String(id);
 return <Modal wide title={`Tiến độ gửi · ${r.account_name??r.name}`} onClose={onClose} dismissible={!busy} footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{!c.queued_at&&<button className="btn" disabled={busy||r.verification_pending} onClick={async()=>{setBusy(true);try{await onVerify();live.reload();}finally{setBusy(false);}}}>{r.verification_pending?'Đang kiểm tra…':'Kiểm tra nhóm'}</button>}{r.status==='active'&&!deliveryDone(r)&&<><button className="btn" disabled={busy} onClick={()=>void action('pause')}>Tạm dừng</button><button className="btn" disabled={busy} onClick={()=>void action('stop')}>Dừng</button></>}{r.status==='paused'&&!deliveryDone(r)&&<button className="btn primary" disabled={busy||!!r.account_issue||!!c.pause_reason} onClick={()=>void action('resume')}>Tiếp tục</button>}{r.status==='stopped'&&r.verified&&!deliveryDone(r)&&<button className="btn primary" disabled={busy||!!r.account_issue||!!c.pause_reason} onClick={()=>void action('start')}>{c.queued_at?'Chạy tiếp':'Bắt đầu gửi'}</button>}</>}>
  <div className="post-detail-head"><div><strong>{r.account_name}</strong><span className="hint"> · {r.mode==='copy'?'Sao chép':'Giữ nguồn'} · nghỉ {c.delay_seconds}{c.delay_max_seconds&&c.delay_max_seconds!==c.delay_seconds?`–${c.delay_max_seconds}`:''}s / nhóm</span><p><a href={c.post_link} target="_blank" rel="noreferrer">{c.post_link}</a></p></div><Pill tone={deliveryDone(r)?'ok':r.verification_error?'bad':r.status==='active'?'ok':'warn'}>{deliveryLabel(r)}</Pill></div>
  <div className="proxy-list-summary"><strong>{r.destination_chat_ids.length||c.targets.length} nhóm</strong><span className="proxy-count-live">Đã gửi {r.stats.succeeded??0}</span><span>Đang chờ {pending(r)}</span><span className="proxy-count-dead">Lỗi {(r.stats.failed??0)+(r.stats.dead_letter??0)}</span>{c.scheduled_at&&<span>Lịch: {fmtDateTime(c.scheduled_at)}</span>}</div>
  {!!c.duplicate_count&&<p className="hint">Bỏ qua {c.duplicate_count} nhóm: bài này đã có trong một đợt gửi trước. Không tạo thêm tác vụ gửi trùng.</p>}
  {r.account_issue&&!r.account_restriction&&<Alert tone="bad">{errorLabel(r.account_issue)}. Hàng đợi giữ nguyên SS; xử lý lỗi trước khi tiếp tục.</Alert>}
  {c.pause_reason==='delivery_uncertain'&&<Alert>Chưa rõ bài đã đến Telegram hay chưa. Mở <button className="btn sm" onClick={()=>setTab('jobs')}>Tiến độ từng nhóm</button>, kiểm tra trực tiếp trong nhóm rồi ghi nhận kết quả. Tool không tự gửi lại.</Alert>}
  {reviewError&&<Alert tone="bad">{reviewError}</Alert>}
  {r.verification_error&&<Alert tone="bad">{errorLabel(r.verification_error)||r.verification_error} Kiểm tra bài nguồn và các nhóm bên dưới trước khi chạy.</Alert>}
  {r.account_restriction&&<Alert tone="bad">SS đang bị hạn chế/đóng băng, hàng đợi được giữ lại. <Link to="/accounts" onClick={onClose}>Kiểm tra tài khoản Telegram</Link>.</Alert>}
  {r.account_wait_until&&Date.parse(r.account_wait_until)>Date.now()&&<Alert>Telegram yêu cầu SS chờ đến {fmtDateTime(r.account_wait_until)}. Không đổi tài khoản để tiếp tục gửi.</Alert>}
  {live.error&&<Alert tone="bad">{live.error.message}</Alert>}
  <div className="seg"><button aria-pressed={tab==='groups'} onClick={()=>setTab('groups')}>Nhóm & quyền gửi</button><button aria-pressed={tab==='jobs'} onClick={()=>setTab('jobs')}>Tiến độ từng nhóm</button></div>
  {tab==='groups'?<><div className="proxy-list-table"><table className="table"><thead><tr><th>Nhóm</th><th>Tên Telegram</th><th>Quyền gửi</th></tr></thead><tbody>{c.targets.slice((groupPage-1)*50,groupPage*50).map((ref,i)=>{const check=checks.get((groupPage-1)*50+i);return <tr key={ref}><td className="mono">{ref}</td><td>{check?.title||'—'}</td><td><Pill tone={!check?'idle':check.can_send?'ok':'bad'}>{!check?'Chưa kiểm tra':check.can_send?'Gửi được':check.error_code==='not_joined'?'Chưa tham gia':check.error_code==='not_a_group'?'Không phải nhóm':'Không có quyền'}</Pill></td></tr>;})}</tbody></table></div><div className="row"><button className="btn sm" disabled={groupPage<=1} onClick={()=>setGroupPage(p=>p-1)}>Trước</button><span className="hint">Trang {groupPage}/{Math.max(1,Math.ceil(c.targets.length/50))}</span><button className="btn sm" disabled={groupPage*50>=c.targets.length} onClick={()=>setGroupPage(p=>p+1)}>Sau</button></div></>:<>
   <select className="select" aria-label="Lọc tiến độ gửi" value={filter} onChange={e=>{setFilter(e.target.value);setPage(1);}}><option value="">Mọi kết quả</option>{Object.entries(jobStatus).map(([v,s])=><option key={v} value={v}>{s.label}</option>)}</select>
   {jobs.error&&<Alert tone="bad">{jobs.error.message}</Alert>}
   <div className="proxy-list-table"><table className="table"><thead><tr><th>Nhóm</th><th>Kết quả</th><th>Sớm nhất</th></tr></thead><tbody>{jobs.data?.items.map(j=><tr key={j.id}><td>{title(j.dest_chat_id)}</td><td><Pill tone={jobStatus[j.status].tone}>{jobStatus[j.status].label}</Pill>{j.last_error_code&&<span className="hint proxy-list-reason">{errorLabel(j.last_error_code)}</span>}{j.last_error_code==='delivery_uncertain'&&['failed','dead_letter'].includes(j.status)&&<div className="stack tight"><span className="hint">Sau khi kiểm tra trực tiếp trong nhóm:</span><div className="row"><button className="btn sm" disabled={busy} onClick={()=>void review(j,true)}>Đã gửi</button><button className="btn sm" disabled={busy} onClick={()=>void review(j,false)}>Chưa gửi · thử lại</button></div></div>}</td><td>{fmtDateTime(j.available_at)}</td></tr>)}</tbody></table></div>
   {!c.queued_at&&<p className="hint">Chưa tạo hàng đợi. Kiểm tra nhóm rồi bấm Bắt đầu gửi.</p>}
   <div className="row"><button className="btn sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Trước</button><span className="hint">Trang {page}/{Math.max(1,Math.ceil((jobs.data?.total??0)/50))}</span><button className="btn sm" disabled={page*50>=(jobs.data?.total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div>
  </>}
 </Modal>;
}
