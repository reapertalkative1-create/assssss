import {render,screen,waitFor,within} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter} from 'react-router-dom';
import {beforeEach,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn(),patch:vi.fn(),put:vi.fn(),upload:vi.fn()},request:vi.fn()};});
vi.mock('../state/toast',()=>({useToast:()=>({success:vi.fn(),error:vi.fn()})}));
import {api,ApiError} from '../api/client';
import type {WorkCluster} from '../api/types';
import {PostRouteForm} from './PostRoute';
import {ClusterLivePanel,ClusterRunButton,ClusterRunForm,WorkClusters} from './WorkClusters';
import {ClusterMessageDialog} from './ClusterMessageDialog';

const cluster:WorkCluster={id:'cluster-1',name:'Khách hàng',post_link:'https://t.me/source_group/456',delay_max_seconds:120,account_count:1,target_count:2,mode:'copy',delay_seconds:90,revision:3,created_at:'2026-11-14T10:00:00Z',updated_at:'2026-11-14T10:00:00Z',account_ids:['a1'],senders:[{id:'a1',name:'SS Một'}],targets:['@group_one','@group_two'],missing_account_ids:[],cluster_type:'forward'};
const accounts={items:[{id:'a1',name:'SS Một',auth_state:'authorized',desired_state:'stopped',health_status:'live',spam_status:'clear',pending_deletion:false}],total:1};
const wrap=(node:React.ReactNode)=>render(<MemoryRouter>{node}</MemoryRouter>);
beforeEach(()=>{localStorage.clear();vi.clearAllMocks();vi.mocked(api.get).mockImplementation(async path=>path==='/api/post-routes/senders'?accounts:path==='/api/work-clusters'?{items:[cluster],total:1}:path==='/api/account-groups'?[]:cluster);});

it('shows the reason a 132-target cluster could not start instead of completed zero of zero',()=>{
 wrap(<ClusterLivePanel cluster={{...cluster,total_count:132,completed_count:0,error_count:132,
  done_count:0,running:false,run_status:'blocked',outcomes:[{ref:'@review_group',status:'blocked',
  error_code:'worker_offline',error_message:'Worker của tài khoản đang offline.'}]}}/>);
 expect(screen.getByText('Không thể bắt đầu')).toBeVisible();
 expect(screen.getByText('Worker của tài khoản đang offline.')).toBeVisible();
 expect(screen.getByText(/132 nhóm/)).toBeVisible();
 expect(screen.queryByText('Hoàn tất')).not.toBeInTheDocument();
});

it('keeps the Run button available when the server skipped an already queued post',async()=>{
 const user=userEvent.setup();
 vi.mocked(api.post).mockResolvedValue({kind:'forward',started:[],failures:[],cluster:{...cluster,running:false,run_status:'skipped'}});
 wrap(<ClusterRunButton cluster={cluster} canStart onRefresh={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:/Chạy/}));
 await waitFor(()=>expect(screen.getByRole('button',{name:/Chạy/})).toBeEnabled());
 expect(screen.queryByRole('button',{name:'Dừng'})).not.toBeInTheDocument();
});

it('explains skipped targets without claiming that messages were sent',()=>{
 wrap(<ClusterLivePanel cluster={{...cluster,total_count:132,completed_count:132,done_count:0,error_count:0,
  running:false,run_status:'skipped',outcomes:[]}}/>);
 expect(screen.getByText('Đã có lượt trước')).toBeVisible();
 expect(screen.getByText(/Không tạo bản gửi trùng/)).toBeVisible();
 expect(screen.getByText('✓ 0 đã gửi')).toBeVisible();
 expect(screen.queryByText('Hoàn tất')).not.toBeInTheDocument();
});

it('preserves the cluster name and configuration on close, then saves without needing a post link',async()=>{
 const user=userEvent.setup(),saved=vi.fn();
 let view=wrap(<PostRouteForm clusterMode draftOwner="cluster-owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={saved}/>);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('');
 expect(screen.getByLabelText('Từ')).toHaveValue(150);expect(screen.getByLabelText('Đến')).toHaveValue(180);
 await user.type(screen.getByLabelText('Tên cụm làm việc'),'Khách hàng hôm nay');
 await user.click(await screen.findByLabelText('Chọn SS SS Một'));
 await user.type(screen.getByLabelText('Nhóm nhận bài'),'@group_one\n@group_two');
 view.unmount();
 view=wrap(<PostRouteForm clusterMode draftOwner="cluster-owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={saved}/>);
 expect(screen.getByLabelText('Tên cụm làm việc')).toHaveValue('Khách hàng hôm nay');
 expect(screen.getByLabelText('Nhóm nhận bài')).toHaveValue('@group_one\n@group_two');
 expect(await screen.findByLabelText('Chọn SS SS Một')).toBeChecked();
 vi.mocked(api.post).mockResolvedValue(cluster);
 await user.click(screen.getByRole('button',{name:/^Tạo cụm$/}));
 expect(api.post).toHaveBeenCalledWith('/api/work-clusters',{request_id:expect.any(String),name:'Khách hàng hôm nay',account_ids:['a1'],targets_text:'@group_one\n@group_two',delay_seconds:150,delay_max_seconds:180,post_link:'',mode:'forward'});
 expect(saved).toHaveBeenCalledWith(cluster);view.unmount();
 expect(Object.keys(localStorage).filter(k=>k.includes('cluster-owner'))).toEqual([]);
});

it('reuses the saved cluster and retries a failed new-post request with the same ID',async()=>{
 const user=userEvent.setup(),created=vi.fn();
 let view=wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={created}/>);
 expect(screen.getByText('1 SS · 2 nhóm nhận')).toBeVisible();
 expect(screen.queryByLabelText('Nhóm nhận bài')).not.toBeInTheDocument();
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('https://t.me/source_group/456');
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveAttribute('readonly');
 vi.mocked(api.post).mockRejectedValue(new ApiError(0,'network','Mất kết nối'));
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 expect(await screen.findByText('Mất kết nối')).toBeVisible();
 const first=vi.mocked(api.post).mock.calls[0];view.unmount();
 view=wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={created}/>);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue('https://t.me/source_group/456');
 vi.mocked(api.post).mockResolvedValue({batch_id:'batch-new'});
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 expect(vi.mocked(api.post).mock.calls[1]).toEqual(first);
 expect(first).toEqual(['/api/work-clusters/cluster-1/runs',{request_id:expect.any(String),revision:3}]);
 await user.click(await screen.findByRole('button',{name:'Mở lượt & tiến độ'}));
 expect(created).toHaveBeenCalledWith('batch-new');view.unmount();
 expect(Object.keys(localStorage).filter(k=>k.includes('cluster-run'))).toEqual([]);
});

it('blocks creating a new run with deleted accounts and edits require the current revision',async()=>{
 const user=userEvent.setup(),c={...cluster,missing_account_ids:['a1']};
 const view=wrap(<ClusterRunForm cluster={c} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 expect(screen.getByRole('button',{name:'Chạy'})).toBeDisabled();expect(screen.getByText(/Sửa cấu hình cụm trước/)).toBeVisible();view.unmount();
 wrap(<PostRouteForm clusterMode cluster={cluster} draftOwner="owner" onClose={()=>{}} onSaved={()=>{}} onClusterSaved={()=>{}}/>);
 await user.clear(screen.getByLabelText('Tên cụm làm việc'));await user.type(screen.getByLabelText('Tên cụm làm việc'),'Cụm đổi tên');
 vi.mocked(api.patch).mockResolvedValue({...cluster,name:'Cụm đổi tên',revision:4});
 await user.click(screen.getByRole('button',{name:'Lưu cụm'}));
 expect(api.patch).toHaveBeenCalledWith('/api/work-clusters/cluster-1',{name:'Cụm đổi tên',account_ids:['a1'],targets_text:'@group_one\n@group_two',delay_seconds:90,delay_max_seconds:120,post_link:'https://t.me/source_group/456',mode:'copy',revision:3});
});

it('opens the correct historical run and keeps each post separate',async()=>{
 const user=userEvent.setup(),open=vi.fn();
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'?{items:[cluster],total:1}:path.endsWith('/runs')?{items:[{batch_id:'yesterday',post_link:'https://t.me/source_group/123',created_at:'2026-11-13T10:00:00Z',account_count:1,target_count:2,active_count:0,paused_count:0,started_count:1},{batch_id:'today',post_link:'https://t.me/source_group/124',created_at:'2026-11-14T10:00:00Z',account_count:1,target_count:2,active_count:0,paused_count:0,started_count:0}],total:2}:cluster);
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={open}/>);
 await user.click(await screen.findByRole('button',{name:'Lịch sử'}));
 const post=await screen.findByRole('link',{name:'https://t.me/source_group/123'});
 await user.click(within(post.closest('.cluster-history-row') as HTMLElement).getByRole('button',{name:'Mở lượt'}));
 expect(open).toHaveBeenCalledWith('yesterday');expect(api.post).not.toHaveBeenCalled();
});

it('hides configuration and new-post actions from operators',async()=>{
 wrap(<WorkClusters owner="operator" isAdmin={false} onOpenBatch={()=>{}}/>);
 await waitFor(()=>expect(screen.getByRole('heading',{name:'Khách hàng'})).toBeVisible());
 expect(screen.queryByRole('button',{name:/Tạo cụm|^Chạy$/})).not.toBeInTheDocument();
 expect(screen.queryByLabelText('Thao tác cụm Khách hàng')).not.toBeInTheDocument();
 expect(screen.getByRole('button',{name:'Lịch sử'})).toBeVisible();
});

it('checks management permissions before starting a saved run and only starts once',async()=>{
 const user=userEvent.setup();let reads=0;
 const row={id:'r1',account_id:'a1',account_name:'SS Một',name:'Run',status:'stopped',verified:false,stats:{},link_config:{post_link:cluster.post_link,targets:['@group_one'],delay_seconds:150}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?{...row,verified:++reads>1}:path.includes('/commands/')?{status:'done'}:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'saved-run',items:[row]}:path.endsWith('/verify')?{command_id:'verify-1'}:{});
 wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 await user.dblClick(screen.getByRole('button',{name:'Chạy'}));
 await screen.findByRole('button',{name:'Mở lượt & tiến độ'});
 const calls=vi.mocked(api.post).mock.calls.map(c=>c[0]);
 expect(calls).toEqual(['/api/work-clusters/cluster-1/runs','/api/routes/r1/verify','/api/routes/r1/start']);
 expect(vi.mocked(api.post).mock.calls[0][1]).toEqual({revision:3,request_id:expect.any(String)});
});

it('does not start an unverified destination and keeps its saved configuration',async()=>{
 const user=userEvent.setup();
 const row={id:'r1',account_id:'a1',account_name:'SS Một',name:'Run',status:'stopped',verified:false,stats:{},link_config:{post_link:cluster.post_link,targets:['@group_one'],delay_seconds:150}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?row:path.includes('/commands/')?{status:'done'}:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'saved-run',items:[row]}:{command_id:'verify-1'});
 wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 await screen.findByRole('button',{name:'Mở lượt & tiến độ'});
 expect(vi.mocked(api.post).mock.calls.some(c=>c[0].endsWith('/start'))).toBe(false);
 expect(screen.getByLabelText('Liên kết bài viết Telegram')).toHaveValue(cluster.post_link);
});

it('rejects a reversed interval without saving and keeps both ends editable',async()=>{
 const user=userEvent.setup();
 wrap(<PostRouteForm clusterMode cluster={cluster} draftOwner="owner" onClose={()=>{}} onSaved={()=>{}}/>);
 await user.clear(screen.getByLabelText('Đến'));await user.type(screen.getByLabelText('Đến'),'80');
 await user.click(screen.getByRole('button',{name:'Lưu cụm'}));
 expect(await screen.findByText(/Mốc nghỉ đến phải/)).toBeVisible();
 expect(api.patch).not.toHaveBeenCalled();
});

it('starts the saved post straight from the cluster card button',async()=>{
 const user=userEvent.setup();
 vi.mocked(api.post).mockResolvedValue({kind:'forward',batch_id:'run-from-card',items:[],started:[],pending_verification:[],failures:[]});
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(await screen.findByRole('button',{name:/Chạy$/}));
 expect(api.post).toHaveBeenCalledWith('/api/work-clusters/cluster-1/start',{request_id:expect.any(String),revision:3});
 // While the batch runs the card swaps the green Run button for the red Stop button.
 expect(await screen.findByRole('button',{name:'Dừng'})).toBeVisible();
 expect(screen.queryByRole('button',{name:/Chạy$/})).not.toBeInTheDocument();
});
it('stops a running cluster from the card and shows the Stop state in red',async()=>{
 const user=userEvent.setup();
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'
   ?{items:[{...cluster,running:true,run_status:'running',batch_id:'b1',total_count:2,completed_count:1,done_count:1,error_count:0,outcomes:[{ref:'@group_one',status:'done'},{ref:'@group_two',status:'pending'}]}],total:1}
   :cluster);
 vi.mocked(api.post).mockResolvedValue({stopped:2,cluster:{}});
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(await screen.findByRole('button',{name:'Dừng'}));
 expect(api.post).toHaveBeenCalledWith('/api/work-clusters/cluster-1/stop');
 expect(await screen.findByRole('button',{name:/Chạy$/})).toBeVisible();
});
it('shows each group result right on the cluster card',async()=>{
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'
   ?{items:[{...cluster,running:true,run_status:'running',batch_id:'b1',total_count:3,completed_count:2,done_count:1,error_count:1,loop_pass:2,
     outcomes:[{ref:'@group_one',title:'Nhóm Một',status:'done'},{ref:'@group_two',title:'Nhóm Hai',status:'failed',error_code:'chat_write_forbidden'},{ref:'@group_three',title:'Nhóm Ba',status:'pending'}]}],total:1}
   :cluster);
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 expect(await screen.findByText('Nhóm Một')).toBeVisible();
 expect(screen.getByText('Đã gửi')).toBeVisible();
 // Failed groups surface a readable Vietnamese reason instead of the raw error code.
 expect(screen.getByText('Không có quyền gửi')).toBeVisible();
 expect(screen.getByText(/vòng 2/)).toBeVisible();
 expect(screen.getByRole('progressbar')).toHaveAttribute('aria-valuenow','67');
});
it('continues verification and start after the busy dialog is closed',async()=>{
 const user=userEvent.setup(),closed=vi.fn();let reads=0;
 let finish!: (value:{status:string})=>void;
 const pending=new Promise<{status:string}>(resolve=>{finish=resolve;});
 const row={id:'r1',account_id:'a1',account_name:'SS Một',name:'Run',status:'stopped',verified:false,stats:{},link_config:{post_link:cluster.post_link,targets:['@group_one'],delay_seconds:150}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?{...row,verified:++reads>1}:path.includes('/commands/')?await pending:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'background',items:[row]}:path.endsWith('/verify')?{command_id:'verify-1'}:{});
 const view=wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={closed} onCreated={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 await waitFor(()=>expect(api.post).toHaveBeenCalledWith('/api/routes/r1/verify'));
 expect(screen.getByRole('button',{name:'Kiểm tra tình trạng'})).toBeEnabled();
 await user.click(screen.getAllByRole('button',{name:'Đóng'})[1]);
 expect(closed).toHaveBeenCalled();view.unmount();
 finish({status:'done'});
 await waitFor(()=>expect(api.post).toHaveBeenCalledWith('/api/routes/r1/start'));
});

it('opens the running batch status while verification is pending',async()=>{
 const user=userEvent.setup(),opened=vi.fn();
 let finish!: (value:{status:string})=>void;
 const pending=new Promise<{status:string}>(resolve=>{finish=resolve;});
 const row={id:'r1',account_id:'a1',account_name:'SS Một',status:'stopped',verified:false,stats:{},link_config:{}};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/routes/r1'?row:path.includes('/commands/')?await pending:cluster);
 vi.mocked(api.post).mockImplementation(async path=>path.endsWith('/runs')?{batch_id:'running',items:[row]}:{command_id:'verify-1'});
 wrap(<ClusterRunForm cluster={cluster} owner="owner" onClose={()=>{}} onCreated={opened}/>);
 await user.click(screen.getByRole('button',{name:'Chạy'}));
 await user.click(await screen.findByRole('button',{name:'Kiểm tra tình trạng'}));
 expect(opened).toHaveBeenCalledWith('running');finish({status:'done'});
});


it('saves a message with multiple daily times and sends it without closing the dialog',async()=>{
 const user=userEvent.setup();
 vi.mocked(api.get).mockImplementation(async path=>path.endsWith('/message-runs')?{items:[],total:0}:{...cluster,message_text:'Xin chào 😀'});
 vi.mocked(api.put).mockResolvedValue({...cluster,message_schedule_times:['09:00','18:30'],message_schedule_enabled:true});
 vi.mocked(api.post).mockResolvedValue({id:'run-1'});
 const view=wrap(<ClusterMessageDialog id="cluster-1" onClose={()=>{}}/>);
 const text=await screen.findByLabelText('Nội dung / chú thích');
 await user.clear(text);await user.type(text,'Xin chào 😀');
 await user.click(screen.getByRole('button',{name:'Thêm giờ'}));
 await user.click(screen.getByRole('button',{name:'Thêm giờ'}));
 await user.click(screen.getByRole('button',{name:'Lưu nội dung & lịch'}));
 await waitFor(()=>expect(api.put).toHaveBeenCalledWith('/api/work-clusters/cluster-1/message',expect.objectContaining({text:'Xin chào 😀',schedule_times:['09:00']})));
 await user.click(screen.getByRole('button',{name:'Gửi ngay'}));
 await waitFor(()=>expect(api.post).toHaveBeenCalledWith('/api/work-clusters/cluster-1/message-runs',{request_id:expect.any(String)}));
 expect(screen.getAllByRole('button',{name:'Đóng'})[0]).toBeVisible();view.unmount();
});

it('creates message clusters through a separate form with no Telegram post link',async()=>{
 const user=userEvent.setup();
 wrap(<WorkClusters owner="message-owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(screen.getByRole('button',{name:'+ Cụm gửi tin nhắn'}));
 const dialog=screen.getByRole('dialog');
 expect(within(dialog).getByLabelText('Tên cụm làm việc')).toBeVisible();
 expect(within(dialog).getByLabelText('Nhóm nhận bài')).toBeVisible();
 expect(within(dialog).queryByLabelText('Liên kết bài viết Telegram')).not.toBeInTheDocument();
 await user.type(within(dialog).getByLabelText('Tên cụm làm việc'),'Thông báo riêng');
 await user.type(within(dialog).getByLabelText('Nhóm nhận bài'),'@group_one');
 await user.type(within(dialog).getByLabelText('Nội dung tin nhắn'),'Xin chào ★ 😀');
 await user.click(await within(dialog).findByLabelText('Chọn SS SS Một'));
 await user.click(within(dialog).getByRole('button',{name:'Thêm giờ'}));
 vi.mocked(api.post).mockResolvedValue({...cluster,cluster_type:'message'});
 vi.mocked(api.put).mockResolvedValue({});
 await user.click(within(dialog).getByRole('button',{name:'Tạo cụm gửi tin nhắn'}));
 await waitFor(()=>expect(api.post).toHaveBeenCalledWith('/api/work-clusters',expect.objectContaining({cluster_type:'message',name:'Thông báo riêng',targets_text:'@group_one'})));
 await waitFor(()=>expect(api.put).toHaveBeenCalledWith('/api/work-clusters/cluster-1/message',expect.objectContaining({text:'Xin chào ★ 😀',schedule_times:['09:00']})));
});

 it('shows the stop-loop control and running badge for an active loop session',async()=>{
  const user=userEvent.setup();
  const c={...cluster,cluster_type:'message' as const,message_text:'Hello loop',message_loop_enabled:true,loop_active:true};
  vi.mocked(api.get).mockImplementation(async path=>path.endsWith('/message-runs')?{items:[],total:0}:c);
  const view=wrap(<ClusterMessageDialog id="cluster-1" onClose={()=>{}}/>);
  await waitFor(()=>expect(view.getByText(/Vòng lặp đang chạy/)).toBeTruthy());
  const stop=await view.findByRole('button',{name:'Dừng vòng lặp'});
  vi.mocked(api.post).mockResolvedValue({stopped:1,loop_active:false});
  await user.click(stop);
  await waitFor(()=>expect(api.post).toHaveBeenCalledWith('/api/work-clusters/cluster-1/loop/stop'));
 });

it('explains a loop that is waiting on Telegram instead of looking stopped',async()=>{
 const paused={...cluster,id:'loop-1',cluster_type:'message' as const,message_text:'hello',message_loop_enabled:true,
   loop_active:true,loop_block_reason:'flood_wait',loop_wait_until:new Date(Date.now()+12*60000).toISOString()};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'?{items:[paused],total:1}:cluster);
 const user=userEvent.setup();
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(await screen.findByRole('button',{name:'Cụm gửi tin nhắn'}));
 expect(await screen.findByText('Vòng lặp đang chờ')).toBeVisible();
 expect(screen.getByText(/Thử lại sau 12 phút/)).toBeVisible();
});
it('tells the operator why the loop switched itself off',async()=>{
 const blocked={...cluster,id:'loop-2',cluster_type:'message' as const,message_text:'hello',message_loop_enabled:true,
   loop_active:false,loop_block_reason:'senders_stopped'};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'?{items:[blocked],total:1}:cluster);
 const user=userEvent.setup();
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 await user.click(await screen.findByRole('button',{name:'Cụm gửi tin nhắn'}));
 expect(await screen.findByText(/Tất cả SS trong cụm đã dừng/)).toBeVisible();
});

it('keeps Stop available when every forward sender is waiting after a failure',async()=>{
 const waiting={...cluster,cluster_type:'forward' as const,loop_active:true,running:false,
   run_status:'blocked',total_count:2,error_count:2,outcomes:[{ref:'@group_one',status:'blocked',
   error_code:'account_restricted',error_message:'Tài khoản đang bị hạn chế.'}]};
 vi.mocked(api.get).mockImplementation(async path=>path==='/api/work-clusters'?{items:[waiting],total:1}:waiting);
 wrap(<WorkClusters owner="owner" isAdmin onOpenBatch={()=>{}}/>);
 expect(await screen.findByRole('button',{name:'Dừng'})).toBeEnabled();
 expect(screen.getByText('Đang chờ SS sẵn sàng')).toBeVisible();
 expect(screen.getByText(/Tự lặp đến khi bấm Dừng/)).toBeVisible();
 expect(screen.queryByRole('button',{name:/Chạy$/})).not.toBeInTheDocument();
});
