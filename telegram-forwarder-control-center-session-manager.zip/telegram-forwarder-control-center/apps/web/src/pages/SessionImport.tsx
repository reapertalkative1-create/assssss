import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import type { Page, Worker } from "../api/types";
import { Modal } from "../components/Modal";
import { Alert, SelectField, TextField } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { sessionFiles,toBase64 } from "../lib/sessionFiles";
import { errorLabel } from "../lib/labels";

type Item = { index: number; filename: string; status: string; account_id?: string; command_id?: string; error_code?: string; retry_after?: number };
const terminal = (s: string) => ["done", "failed", "expired", "error", "duplicate"].includes(s);
const statuses: Record<string,string> = {queued:"Đang chờ",pending:"Đang chờ",delivered:"Đang kiểm tra",done:"Thành công",failed:"Lỗi",expired:"Hết thời gian — kiểm tra lại",error:"File không hợp lệ",duplicate:"Trùng — đã bỏ qua"};
const importErrors: Record<string,string> = {invalid_telethon_session:"Không phải session Telethon hợp lệ hoặc file chưa được đóng hoàn toàn.",session_has_no_auth_key:"Session chưa đăng nhập.",session_check_timeout:"Kiểm tra mất quá lâu. Có thể thử lại.",internal_error:"Worker chưa kiểm tra được. Có thể thử lại."};

export function SessionImport({ onClose }: { onClose: () => void }) {
  const [files,setFiles]=useState<File[]>([]);
  const [worker,setWorker]=useState("");
  const [apiId,setApiId]=useState("");
  const [apiHash,setApiHash]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [items,setItems]=useState<Item[]>([]);
  const [page,setPage]=useState(1);
  const [sent,setSent]=useState(0);
  const [paused,setPaused]=useState(false);
  const cancel=useRef(false);
  const input=useRef<HTMLInputElement>(null);
  const workers=useQuery(signal=>api.get<Page<Worker>>("/api/workers",{page_size:100},signal),[]);
  const online=(workers.data?.items??[]).filter(w=>w.status==="online"||w.status==="degraded");
  useEffect(()=>{if(!worker&&online.length===1)setWorker(online[0].id);},[workers.data,worker]);
  const ids=items.filter(i=>i.command_id&&!terminal(i.status)).map(i=>i.command_id!);
  const key=ids.join(",");
  useEffect(()=>{
    if(!key)return;
    let cancelled=false;
    let timer:ReturnType<typeof setTimeout>;
    async function poll(){
      try{
        const ids=key.split(",");
        const updates:Partial<Item>[]=[];
        for(let i=0;i<ids.length;i+=100){
          if(cancelled)return;
          const r=await api.post<{items:Partial<Item>[]}>("/api/accounts/import-sessions/status",{command_ids:ids.slice(i,i+100)});
          updates.push(...r.items);
        }
        if(cancelled)return;
        const mapped=new Map(updates.map(x=>[x.command_id,x]));
        setItems(old=>old.map(item=>({...item,...mapped.get(item.command_id)})));
        setError("");
      }catch(e){if(!cancelled)setError(e instanceof ApiError?e.message:"Không tải được tiến độ; sẽ thử lại.");}
      if(!cancelled)timer=setTimeout(()=>void poll(),2000);
    }
    void poll();
    return()=>{cancelled=true;clearTimeout(timer);};
  },[key]);

  async function submit(){
    if(!worker||!files.length||!(/^[1-9][0-9]*$/.test(apiId))||Number(apiId)>2147483647||!(/^[0-9a-f]{32}$/i.test(apiHash.trim()))){setError("Chọn worker online, chọn file và nhập đúng api_id/api_hash.");return;}
    setBusy(true);setError("");setPaused(false);cancel.current=false;
    const hash=apiHash.trim();
    let buffer:{filename:string;content:string}[]=[];let bytes=0;let index=0;
    async function flush(){
      if(!buffer.length)return;
      const r=await api.post<{items:Item[]}>("/api/accounts/import-sessions",{worker_id:worker,api_id:Number(apiId),api_hash:hash,files:buffer});
      const rows=r.items.map(x=>({...x,index:index++}));const count=buffer.length;
      setItems(old=>[...old,...rows]);
      setSent(n=>n+count);buffer=[];bytes=0;
    }
    try{
      for await(const entry of sessionFiles(files)){
        if(cancel.current){setPaused(true);break;}
        if(entry.error){const row={index:index++,filename:entry.name,status:"error",error_code:entry.error};setItems(old=>[...old,row]);continue;}
        if(buffer.length>=100||bytes+entry.bytes!.length>8*1024*1024)await flush();
        buffer.push({filename:entry.name,content:toBase64(entry.bytes!)});bytes+=entry.bytes!.length;
      }
      if(!cancel.current)await flush();
      setApiHash("");setFiles([]);if(input.current)input.current.value="";
    }catch(e){setError(e instanceof ApiError?e.message:e instanceof Error?e.message:"Không nhập được session. Chọn lại file để tiếp tục, session trùng sẽ tự bỏ qua.");}
    finally{setBusy(false);}
  }
  async function retry(item:Item){
    if(!item.account_id)return;
    try{
      const r=await api.post<{command_id:string;status:string}>(`/api/accounts/${item.account_id}/import-session/retry`);
      setItems(old=>old.map(x=>x.index===item.index?{...x,...r,error_code:undefined,retry_after:undefined}:x));
    }catch(e){setError(e instanceof ApiError?e.message:"Không thể thử lại.");}
  }
  const active=items.some(i=>!terminal(i.status));
  return <Modal title="Nhập session hàng loạt" onClose={onClose} dismissible={!busy}
    footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{busy&&<button className="btn" onClick={()=>{cancel.current=true;}}>Dừng tải thêm</button>}{!busy&&!items.length&&<button className="btn primary" disabled={busy||workers.loading} onClick={()=>void submit()}>{busy?"Đang nhập…":"Nhập và kiểm tra session"}</button>}</>}>
    {!items.length&&!busy?<>
      <p>Chọn nhiều file Telethon <strong>.session</strong> hoặc ZIP chứa các file đó. Không giới hạn tổng số session; web tự chia lô khi tải lên. Mỗi file session tối đa 1 MiB. Dừng ứng dụng đang dùng các session này trước khi nhập.</p>
      <SelectField label="Worker" value={worker} onChange={e=>setWorker(e.target.value)}><option value="">Chọn worker online</option>{online.map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</SelectField>
      {workers.error&&<Alert tone="bad">{workers.error.message}</Alert>}
      {!workers.loading&&!online.length&&<Alert>Chưa có worker online. Chạy run.cmd trước.</Alert>}
      <label className="field">File session hoặc ZIP<input ref={input} type="file" multiple accept=".session,.zip" disabled={busy} onChange={e=>setFiles(Array.from(e.target.files??[]))}/></label>
      <p className="hint">Đã chọn {files.length} file. ZIP lớn được đọc từng session, không nạp toàn bộ vào bộ nhớ. Không hỗ trợ Pyrogram hoặc tdata. api_id/api_hash dùng cho lô này; nếu các tài khoản dùng nhiều API khác nhau, nhập thành từng lô.</p>
      <TextField label="api_id" inputMode="numeric" value={apiId} onChange={e=>setApiId(e.target.value.trim())} disabled={busy}/>
      <TextField label="api_hash" type="password" autoComplete="new-password" value={apiHash} onChange={e=>setApiHash(e.target.value)} disabled={busy}/>
    </>:<>
      <p className="hint">Đã gửi {sent} session. {busy?"Đang đọc và tải từng lô…":paused?"Đã dừng tải thêm. Các lô đã gửi vẫn được xử lý.":"Đã tải xong."}</p>
      <p role="status">Thành công: {items.filter(i=>i.status==="done").length} / {items.length} · Đang chờ/xử lý: {items.filter(i=>!terminal(i.status)).length} · Trùng: {items.filter(i=>i.status==="duplicate").length} · Lỗi: {items.filter(i=>["failed","expired","error"].includes(i.status)).length}</p>
      <p className="hint">Worker kiểm tra tối đa 3 session cùng lúc, không cần OTP nếu còn hiệu lực. Đóng cửa sổ này không hủy hàng đợi. Tài khoản thành công ở trạng thái Tắt, bạn có thể Bật khi cần.</p>
      <div style={{maxHeight:360,overflow:"auto"}}><table className="table"><thead><tr><th>File</th><th>Kết quả</th></tr></thead><tbody>{items.slice((page-1)*50,page*50).map(i=><tr key={i.index}><td>{i.filename}</td><td>{statuses[i.status]??i.status}{i.error_code&&<p className="hint">{importErrors[i.error_code]??(i.status==="error"?i.error_code:errorLabel(i.error_code))}{i.retry_after?` — chờ ${i.retry_after} giây`:""}</p>}{["failed","expired"].includes(i.status)&&<button className="btn sm" onClick={()=>void retry(i)}>Kiểm tra lại</button>}</td></tr>)}</tbody></table></div>
      <div className="row"><button className="btn sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Trước</button><span>Trang {page}/{Math.max(1,Math.ceil(items.length/50))}</span><button className="btn sm" disabled={page*50>=items.length} onClick={()=>setPage(p=>p+1)}>Sau</button></div>
      {!active&&!busy&&<Alert>Đã xử lý xong lô. Tài khoản thành công xuất hiện trong danh sách. Session hết hiệu lực cần đăng nhập lại bằng OTP.</Alert>}
    </>}
    {error&&<Alert tone="bad">{error}</Alert>}
  </Modal>;
}
