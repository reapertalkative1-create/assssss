import {useState} from "react";
import {api,ApiError} from "../api/client";
import {useQuery} from "../hooks/useQuery";
import {Alert,Pill} from "../components/ui";
import {Modal} from "../components/Modal";
import {Pagination} from "../components/DataTable";
import {errorLabel} from "../lib/labels";
export const healthLabels:Record<string,string>={unknown:"Chưa check",live:"Live — đăng nhập được",dead:"Die / phiên hết hiệu lực",frozen:"Đóng băng",waiting:"FloodWait — cần chờ",error:"Lỗi kiểm tra"};
export const bulkActions:Record<string,string>={start:"Bật",stop:"Tắt",check:"Check session",mark_frozen:"Đánh dấu đóng băng",clear_mark:"Bỏ dấu đóng băng"};
type Job={id:string;action:string;status:string;total:number;counts:Record<string,number>;created_at:string};
type Details=Job&{items:{account_id:string;name:string;status:string;error_code?:string}[];items_total:number};
export function BulkJobs({isAdmin}:{isAdmin:boolean}){
  const [jobPage,setJobPage]=useState(1),[jobStatus,setJobStatus]=useState("");
  const jobs=useQuery(s=>api.get<{items:Job[];total:number}>("/api/account-bulk",{page:jobPage,page_size:10,status:jobStatus||undefined},s),[jobPage,jobStatus],{interval:3000});
  const [opened,setOpened]=useState<string>();
  return <section className="card stack"><h2>Tác vụ hàng loạt</h2>
    <select className="select" aria-label="Lọc tác vụ hàng loạt" value={jobStatus} onChange={e=>{setJobStatus(e.target.value);setJobPage(1);}}><option value="">Mọi tác vụ</option><option value="running">Đang xử lý</option><option value="done">Hoàn tất</option><option value="cancelled">Đã dừng</option></select>
    {jobs.error&&<Alert tone="bad">{jobs.error.message}</Alert>}
    {!jobs.data?.items.length&&<p className="muted">Chưa có tác vụ. Chọn session để bật, tắt hoặc kiểm tra hàng loạt.</p>}
    {jobs.data?.items.map(j=><div key={j.id} className="row" style={{justifyContent:"space-between",flexWrap:"wrap"}}><span><strong>{bulkActions[j.action]}</strong> · {j.total} session · Xong {j.counts.done??0} · Lỗi {j.counts.error??0} · Chờ {(j.counts.pending??0)+(j.counts.queued??0)}</span><span><Pill tone="idle">{j.status==="running"?"Đang xử lý":j.status==="done"?"Hoàn tất":j.status==="stopping"?"Đang dừng":"Đã dừng"}</Pill> <button className="btn sm" onClick={()=>setOpened(j.id)}>Chi tiết</button></span></div>)}
    {jobs.data&&<Pagination page={jobPage} pageSize={10} total={jobs.data.total} onPage={setJobPage}/>}
    {opened&&<BulkJobDetails id={opened} isAdmin={isAdmin} onClose={()=>{setOpened(undefined);jobs.reload();}}/>}
    <p className="hint">Tác vụ lưu trên máy chủ và tiếp tục khi đóng web. Bật/Tắt là yêu cầu trạng thái; worker sẽ áp dụng khi kết nối. Tác vụ Check ghi kết quả riêng cho từng session.</p>
  </section>;
}
function BulkJobDetails({id,isAdmin,onClose}:{id:string;isAdmin:boolean;onClose:()=>void}){
  const [page,setPage]=useState(1),[status,setStatus]=useState("");
  const [error,setError]=useState("");
  const detail=useQuery(s=>api.get<Details>(`/api/account-bulk/${id}`,{page,status:status||undefined},s),[id,page,status],{interval:3000});
  async function cancel(){try{await api.post(`/api/account-bulk/${id}/cancel`);detail.reload();}catch(e){setError(e instanceof ApiError?e.message:"Không dừng được.");}}
  async function retry(){try{await api.post(`/api/account-bulk/${id}/retry`);onClose();}catch(e){setError(e instanceof ApiError?e.message:"Không thử lại được.");}}
  return <Modal title="Kết quả tác vụ hàng loạt" onClose={onClose} footer={<><button className="btn" onClick={onClose}>Đóng</button>{isAdmin&&!!detail.data?.counts.error&&<button className="btn" onClick={()=>void retry()}>Thử lại các mục lỗi</button>}{isAdmin&&detail.data?.status==="running"&&<button className="btn danger" onClick={()=>void cancel()}>Dừng xếp hàng</button>}</>}>
    <p>{detail.data&&`${bulkActions[detail.data.action]}: ${detail.data.total} session · Xong ${detail.data.counts.done??0} · Lỗi ${detail.data.counts.error??0}`}</p>
    <select className="select" aria-label="Lọc kết quả tác vụ" value={status} onChange={e=>{setStatus(e.target.value);setPage(1);}}><option value="">Mọi kết quả</option><option value="error">Chỉ lỗi</option><option value="done">Thành công</option><option value="pending">Chưa xử lý</option><option value="queued">Đã gửi worker</option><option value="cancelled">Đã hủy xếp hàng</option></select>
    {(error||detail.error)&&<Alert tone="bad">{error||detail.error?.message}</Alert>}
    <div className="table-wrap"><table className="table"><thead><tr><th>Session</th><th>Kết quả</th></tr></thead><tbody>{detail.data?.items.map(i=><tr key={i.account_id}><td>{i.name}</td><td>{({done:"Thành công",error:"Lỗi",pending:"Đang chờ",queued:"Worker xử lý",cancelled:"Đã dừng"} as Record<string,string>)[i.status]??i.status}{i.error_code&&<div className="hint">{errorLabel(i.error_code)}</div>}</td></tr>)}</tbody></table></div>
    {detail.data&&<Pagination page={page} pageSize={50} total={detail.data.items_total} onPage={setPage}/>}
    <p className="hint">Dừng xếp hàng chỉ hủy phần chưa gửi. Lệnh worker đã nhận vẫn hoàn tất và được ghi kết quả.</p>
  </Modal>;
}
