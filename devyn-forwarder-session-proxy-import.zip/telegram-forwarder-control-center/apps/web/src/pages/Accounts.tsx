import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import type { Account, AuthState, Command, CommandAccepted, DeleteResult, Page, Worker } from "../api/types";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { Alert, Check, EmptyState, PageHead, Pill, SelectField, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtAgo } from "../lib/format";
import { authState, connectionState, errorLabel } from "../lib/labels";
import { useAuth } from "../state/auth";
import {ProxyExportMenu} from "../components/ProxyExportMenu";
import {ProxyImport} from "./ProxyImport";
import {RestrictionStatus} from "../components/RestrictionStatus";
import {SessionActivity} from "./SessionActivity";
import {BulkAppeal} from "./BulkAppeal";
import {SpamPanel,spamLabels} from "./SpamPanel";
import {bulkActions,healthLabels} from "./AccountBulk";
import { SessionImport } from "./SessionImport";
import { useToast } from "../state/toast";

type Dialog = {kind:"proxy_import"} | {kind:"bulk_appeal";jobId?:string} | {kind:"spam";a:Account} | {kind:"import"} | { kind: "api"; a: Account; loginAfter?: boolean } | { kind: "create" } | { kind: "login"; a: Account } | { kind: "assign"; a: Account } | { kind: "rename"; a: Account } | { kind: "delete"; a: Account };

/** Waits (long-polling on the server) until the worker finished a command. Resolves with the final command. */
export async function waitForCommand(accountId: string, commandId: string, signal?: AbortSignal, rounds = 4): Promise<Command> {
  let cmd: Command | undefined;
  for (let i = 0; i < rounds; i++) {
    cmd = await api.get<Command>(`/api/accounts/${accountId}/commands/${commandId}`, { wait_seconds: 15 }, signal);
    if (cmd.status === "done" || cmd.status === "failed" || cmd.status === "expired") return cmd;
  }
  return cmd!;
}

export function AccountsPage() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [state, setState] = useState("");
  const [healthFilter,setHealthFilter]=useState("");
  const [spamFilter,setSpamFilter]=useState("");
  const [proxyFilter,setProxyFilter]=useState("");
  const [workerFilter,setWorkerFilter]=useState("");
  const [desiredFilter,setDesiredFilter]=useState("");
  const [pageSize,setPageSize]=useState(50);
  const [selected,setSelected]=useState<Set<string>>(new Set());
  const [allMatching,setAllMatching]=useState(false);
  const [bulkAction,setBulkAction]=useState<string>();
  const [bulkBusy,setBulkBusy]=useState(false);
  const [menuAction,setMenuAction]=useState('spam_check');
  const [moreFilters,setMoreFilters]=useState(false);
  const workers=useQuery(signal=>api.get<Page<Worker>>("/api/workers",{page_size:100},signal),[]);
  const summary=useQuery(signal=>api.get<{total:number;health:Record<string,number>;running:number;spam?:Record<string,number>}>("/api/accounts/summary",undefined,signal),[],{interval:5000});
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busyId, setBusyId] = useState<string>();
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<Account>>("/api/accounts", { q: search, auth_state: state||undefined, worker_id:workerFilter||undefined, health_status:healthFilter||undefined, spam_status:spamFilter||undefined, proxy_status:proxyFilter||undefined, desired_state:desiredFilter||undefined, page, page_size: pageSize }, signal), [search, state, workerFilter,healthFilter,spamFilter,proxyFilter,desiredFilter,page,pageSize], { interval: 5000 });

  useEffect(()=>{setSelected(new Set());setAllMatching(false);setMenuAction('spam_check');setPage(1);},[search,state,healthFilter,spamFilter,proxyFilter,workerFilter,desiredFilter]);
  function toggle(id:string){setSelected(old=>{const next=new Set(old);if(next.has(id))next.delete(id);else next.add(id);return next;});}
  async function runBulk(action=bulkAction){
    if(!action)return;setBulkBusy(true);
    try{
      await api.post('/api/account-bulk',{action,all_matching:allMatching,account_ids:allMatching?[]:[...selected],exclude_ids:allMatching?[...selected]:[],filters:{q:search||undefined,auth_state:state||undefined,worker_id:workerFilter||undefined,health_status:healthFilter||undefined,spam_status:spamFilter||undefined,proxy_status:proxyFilter||undefined,desired_state:desiredFilter||undefined}});
      toast.success(action==='delete'?'Đã xếp hàng xóa các tài khoản đã chọn.':'Đã xếp hàng. Tiến độ và kết quả cập nhật ngay trên từng dòng session.');setBulkAction(undefined);setSelected(new Set());setAllMatching(false);list.reload();summary.reload();
    }catch(e){toast.error(e instanceof ApiError?e.message:'Không tạo được tác vụ.');}finally{setBulkBusy(false);}
  }
  const checkFilters={q:search||undefined,auth_state:state||undefined,worker_id:workerFilter||undefined,health_status:healthFilter||undefined,spam_status:spamFilter||undefined,proxy_status:proxyFilter||undefined,desired_state:desiredFilter||undefined};
  async function checkRestrictions(a?:Account){
    if(a)setBusyId(a.id);else setBulkBusy(true);
    try{
      await api.post('/api/account-bulk',{action:'spam_check',all_matching:!a,account_ids:a?[a.id]:[],exclude_ids:[],filters:a?{}:checkFilters});
      toast.success(a?`Đã xếp hàng check ${a.name}. Kết quả spam và đóng băng tự cập nhật trong bảng.`:'Đã xếp hàng check tất cả tài khoản theo bộ lọc. Theo dõi ngay trên từng dòng session.');
      list.reload();summary.reload();
    }catch(e){toast.error(e instanceof ApiError?e.message:'Không tạo được tác vụ kiểm tra.');}
    finally{if(a)setBusyId(undefined);else setBulkBusy(false);}
  }
  async function checkProxy(a?:Account){
    if(a)setBusyId(a.id);else setBulkBusy(true);
    try{await api.post('/api/account-bulk',{action:'proxy_check',all_matching:!a,account_ids:a?[a.id]:[],exclude_ids:[],filters:a?{}:checkFilters});toast.success('Đã xếp hàng check proxy. Kết quả hiện ngay trên dòng SS.');list.reload();}
    catch(e){toast.error(e instanceof ApiError?e.message:'Không check được proxy.');}
    finally{if(a)setBusyId(undefined);else setBulkBusy(false);}
  }
  async function act(a: Account, label: string, fn: () => Promise<unknown>) {
    setBusyId(a.id);
    try { await fn(); toast.success(label); list.reload(); }
    catch (e) { toast.error(e instanceof ApiError ? e.message : "Thao tác thất bại."); }
    finally { setBusyId(undefined); }
  }
  async function check(a: Account) {
    setBusyId(a.id);
    try {
      const acc = await api.post<CommandAccepted>(`/api/accounts/${a.id}/check`);
      const cmd = await waitForCommand(a.id, acc.command_id, undefined, 3);
      if (cmd.status === "done") toast.success(`Kết nối ${a.name} hoạt động bình thường.`);
      else toast.error(cmd.status === "expired" ? "Worker không phản hồi kịp." : errorLabel(cmd.error_code, cmd.retry_after) || "Kiểm tra thất bại.");
      list.reload();
    } catch (e) { toast.error(e instanceof ApiError ? e.message : "Kiểm tra thất bại."); }
    finally { setBusyId(undefined); }
  }

  const selectedCount=allMatching?Math.max(0,(list.data?.total??0)-selected.size):selected.size;
  useEffect(()=>{if(!selectedCount)setMenuAction('spam_check');},[selectedCount]);
  const checkActions=['spam_check','check','proxy_check'];
  const action=selectedCount||checkActions.includes(menuAction)?menuAction:'spam_check';
  const extraFilters=Number(!!state)+Number(!!desiredFilter)+Number(['waiting','error'].includes(healthFilter));
  const hasFilters=!!(q||state||healthFilter||spamFilter||proxyFilter||workerFilter||desiredFilter);
  function clearSelection(){setSelected(new Set());setAllMatching(false);setMenuAction('spam_check');}
  function clearFilters(){setQ('');setState('');setHealthFilter('');setSpamFilter('');setProxyFilter('');setWorkerFilter('');setDesiredFilter('');setPage(1);}
  async function applyAction(){
    if(selectedCount){
      if(action==='bulk_appeal')setDialog({kind:'bulk_appeal'});
      else setBulkAction(action);
      return;
    }
    if(action==='spam_check'){await checkRestrictions();return;}
    if(action==='proxy_check'){await checkProxy();return;}
    if(action!=='check')return;
    setBulkBusy(true);
    try{await api.post('/api/account-bulk',{action:'check',all_matching:true,account_ids:[],exclude_ids:[],filters:checkFilters});toast.success('Đã xếp hàng check session.');list.reload();}
    catch(e){toast.error(e instanceof ApiError?e.message:'Không tạo được lệnh check.');}
    finally{setBulkBusy(false);}
  }

  const cols: Column<Account>[] = [
    ...(isAdmin?[{key:'selection',header:'Chọn',cell:(a:Account)=><input type="checkbox" aria-label={`Chọn ${a.name}`} checked={allMatching?!selected.has(a.id):selected.has(a.id)} onChange={()=>toggle(a.id)}/> }]:[]),
    {key:'name',header:'Tài khoản & kết nối',width:'23%',cell:a=>{
      const c=connectionState[a.connection_state]??connectionState.disconnected;
      return <div className="ss-identity stack tight"><strong>{a.name}</strong><div className="muted small">{[a.telegram_username&&`@${a.telegram_username}`,a.phone_masked].filter(Boolean).join(' · ')||(a.telegram_user_id?`ID: ${a.telegram_user_id}`:a.auth_state==='authorized'?'Đã xác thực':'Chưa đăng nhập')}</div>
        <div className="row"><Pill tone={authState[a.auth_state].tone}>{authState[a.auth_state].label}</Pill><Pill tone={c.tone}>{c.label}</Pill></div>
        <details className="ss-meta"><summary>Thông tin</summary><div className="hint">Worker: {a.assigned_worker_name??'Chưa gán'}</div>{a.telegram_user_id&&<div className="hint">ID: {a.telegram_user_id}</div>}<div className="hint">{a.desired_state==='running'?'Đang bật':'Đang tắt'} · API {a.telegram_api_configured?'đã cấu hình':'chưa cấu hình'} · {a.has_session?'Có session':'Chưa có session'}</div>{a.connection_error&&<div className="hint">{errorLabel(a.connection_error)}</div>}</details>
      </div>;
    }},
    {key:'status',header:'Trạng thái',width:'22%',cell:a=><div className="ss-results stack tight">
      <RestrictionStatus a={a}/>
      {a.health_status==='live'&&<span className="hint">Live</span>}
      {a.health_status==='waiting'&&<Pill tone="warn">Chờ FloodWait</Pill>}
      {a.health_status==='error'&&<Pill tone="warn">Lỗi session</Pill>}
      <div className="hint">{a.spam_checked_at||a.health_checked_at?fmtAgo(a.spam_checked_at||a.health_checked_at):'Chưa check'}</div>
      {a.flood_wait_until&&<div className="hint">Chờ đến {new Date(a.flood_wait_until).toLocaleTimeString()}</div>}
    </div>},
    {key:'proxy',header:'Proxy',width:'190px',cell:a=><div className="ss-proxy stack tight">
      <span className={`proxy-state ${a.proxy_status==='alive'?'alive':a.proxy_status==='dead'?'dead':'unknown'}`} title={a.proxy_error?errorLabel(a.proxy_error):a.proxy_checked_at?new Date(a.proxy_checked_at).toLocaleString():undefined}>{a.proxy_label??'Chưa có proxy'}</span>
      {a.proxy_label&&<div className="hint">{a.proxy_status==='alive'?`Chạy${a.proxy_latency_ms!=null?` · ${a.proxy_latency_ms} ms`:''}`:a.proxy_status==='dead'?'Không kết nối':a.proxy_status==='checking'?'Đang check':'Chưa check'}</div>}
      {isAdmin&&<button className="btn sm" aria-label={`Check proxy — ${a.name}`} disabled={!a.proxy_label||a.proxy_status==='checking'||busyId===a.id||a.pending_deletion} onClick={()=>void checkProxy(a)}>Check proxy</button>}
    </div>},
    { key: "active", header: "Tiến độ & kết quả", width:"230px", cell: (a) => <SessionActivity a={a} isAdmin={isAdmin} onReload={list.reload} onAppeal={jobId=>setDialog({kind:"bulk_appeal",jobId})}/> },
    { key: "actions", header: "Kiểm tra / thao tác", align: "right", cell: (a) => {
      const disabled = busyId === a.id || a.pending_deletion;
      return (
        <div className="stack tight">{isAdmin&&<button className="btn sm primary" disabled={disabled||bulkBusy} aria-label={`Check spam / đóng băng — ${a.name}`} onClick={()=>void checkRestrictions(a)}>{busyId===a.id?"Đang xếp hàng…":"Check spam / đóng băng"}</button>}<details className="session-actions"><summary className="btn sm">Thao tác</summary><div className="actions" style={{flexDirection:"column",alignItems:"flex-end",marginTop:8}}>
          {isAdmin&&<button className="btn sm" disabled={disabled} onClick={()=>setDialog({kind:'spam',a})}>SpamBot / kháng nghị</button>}
          {a.pending_deletion && <span className="muted small">Đang chờ xóa</span>}
          {a.auth_state === "authorized" && (a.desired_state === "running"
            ? <button className="btn sm" disabled={disabled} onClick={() => void act(a, "Đã tắt tài khoản.", () => api.post(`/api/accounts/${a.id}/stop`))}>Tắt</button>
            : <button className="btn sm primary" disabled={disabled || !a.assigned_worker_id} title={a.assigned_worker_id ? "" : "Hãy gán worker trước"} onClick={() => void act(a, "Đã bật tài khoản.", () => api.post(`/api/accounts/${a.id}/start`))}>Bật</button>)}
          {isAdmin && a.session_imported && a.has_session && a.auth_state !== "authorized" && <button className="btn sm" disabled={disabled} onClick={() => void act(a,"Đã xếp hàng kiểm tra session.",()=>api.post(`/api/accounts/${a.id}/import-session/retry`))}>Kiểm tra session</button>}
          {a.auth_state === "authorized" && <button className="btn sm" disabled={disabled} onClick={() => void check(a)}>Kiểm tra</button>}
          {isAdmin && a.auth_state !== "authorized" && <button className="btn sm primary" disabled={disabled || !a.assigned_worker_id || a.auth_state === "importing"} title={a.assigned_worker_id ? "" : "Hãy gán worker trước"} onClick={() => setDialog(a.telegram_api_configured ? { kind: "login", a } : { kind: "api", a, loginAfter: true })}>Đăng nhập Telegram</button>}
          {isAdmin && <button className="btn sm" disabled={disabled || a.desired_state === "running"} title="Cấu hình api_id/api_hash cho tài khoản" onClick={() => setDialog({ kind: "api", a })}>API Telegram</button>}
          {isAdmin && <button className="btn sm" disabled={disabled} onClick={() => setDialog({ kind: "assign", a })}>Gán worker</button>}
          {isAdmin && <button className="btn sm" disabled={disabled} onClick={() => setDialog({ kind: "rename", a })}>Đổi tên</button>}
          {isAdmin && <button className="btn sm danger" disabled={busyId === a.id} onClick={() => setDialog({ kind: "delete", a })}>Xóa</button>}
        </div></details></div>);
    } },
  ];

  const close = () => setDialog(null);
  const saved = (msg: string) => { setDialog(null); toast.success(msg); list.reload(); };
  return (
    <div className="accounts-page stack">
      <PageHead title="Tài khoản Telegram" actions={isAdmin&&<><button className="btn" onClick={()=>setDialog({kind:'import'})} aria-label="Nhập session hàng loạt">Nhập session</button><button className="btn" onClick={()=>setDialog({kind:'proxy_import'})}>Nhập proxy</button><button className="btn primary" onClick={()=>setDialog({kind:'create'})}>Thêm tài khoản</button></>}/>
      <div className="session-stats" aria-label="Tổng quan session">
        <button className="stat-chip" aria-label={`Tất cả: ${summary.data?.total??0}`} aria-pressed={!healthFilter&&!spamFilter} onClick={()=>{setHealthFilter('');setSpamFilter('');}}><span className="stat-label">Tất cả</span><strong>{summary.data?.total??'—'}</strong></button>
        {(['unknown','live','dead','frozen'] as const).map(key=><button className="stat-chip" data-tone={key} aria-label={`${healthLabels[key]}: ${summary.data?.health[key]??0}`} aria-pressed={healthFilter===key&&!spamFilter} key={key} onClick={()=>{setHealthFilter(key);setSpamFilter('');}}><span className="stat-label"><i/>{({unknown:'Chưa check',live:'Live',dead:'Die / hết phiên',frozen:'Đóng băng'})[key]}</span><strong>{summary.data?(summary.data.health[key]??0):'—'}</strong></button>)}
        <button className="stat-chip" data-tone="blocked" aria-label={`Bị chặn: ${summary.data?.spam?.blocked??0}`} aria-pressed={spamFilter==='blocked'&&!healthFilter} onClick={()=>{setSpamFilter('blocked');setHealthFilter('');}}><span className="stat-label"><i/>Bị chặn</span><strong>{summary.data?(summary.data.spam?.blocked??0):'—'}</strong></button>
      </div>
      <section className="session-console" aria-label="Bộ lọc và thao tác session">
        <div className="session-filter-row">
          <input className="input" placeholder="Tìm tên hoặc username…" aria-label="Tìm tài khoản" value={q} onChange={e=>{setQ(e.target.value);setPage(1);}}/>
          <select className="select" aria-label="Lọc hạn chế spam" value={spamFilter} onChange={e=>setSpamFilter(e.target.value)}><option value="">Mọi tình trạng spam</option>{Object.entries(spamLabels).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select>
          <select className="select" aria-label="Lọc worker" value={workerFilter} onChange={e=>setWorkerFilter(e.target.value)}><option value="">Mọi worker</option>{workers.data?.items.map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</select>
          <select className="select" aria-label="Lọc proxy" value={proxyFilter} onChange={e=>setProxyFilter(e.target.value)}><option value="">Mọi proxy</option><option value="alive">Proxy đang chạy</option><option value="dead">Proxy die</option><option value="unknown">Proxy chưa check</option><option value="checking">Proxy đang check</option></select>
          {isAdmin&&<ProxyExportMenu filters={checkFilters}/>}
          <select className="select session-page-size" aria-label="Số dòng mỗi trang" value={pageSize} onChange={e=>{setPageSize(Number(e.target.value));setPage(1);}}>{[20,50,100].map(n=><option key={n} value={n}>{n} / trang</option>)}</select>
          <button className="btn sm" aria-expanded={moreFilters} aria-controls="session-extra-filters" onClick={()=>setMoreFilters(v=>!v)}>Lọc thêm{extraFilters?` (${extraFilters})`:''}</button>
          {hasFilters&&<button className="btn ghost sm" onClick={clearFilters}>Bỏ lọc</button>}
        </div>
        {moreFilters&&<div className="session-extra-filters" id="session-extra-filters">
          <select className="select" aria-label="Lọc theo xác thực" value={state} onChange={e=>setState(e.target.value)}><option value="">Mọi trạng thái xác thực</option>{(Object.keys(authState) as AuthState[]).map(s=><option key={s} value={s}>{authState[s].label}</option>)}</select>
          <select className="select" aria-label="Lọc tình trạng session" value={healthFilter} onChange={e=>setHealthFilter(e.target.value)}><option value="">Mọi tình trạng session</option>{Object.entries(healthLabels).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select>
          <select className="select" aria-label="Lọc bật tắt" value={desiredFilter} onChange={e=>setDesiredFilter(e.target.value)}><option value="">Bật và tắt</option><option value="running">Đang bật</option><option value="stopped">Đang tắt</option></select>
        </div>}
        {isAdmin&&!!list.data?.total&&<div className="session-selection">
          <div className="row">
            <Check label="Chọn trang" aria-label="Chọn trang hiện tại" checked={!!list.data?.items.length&&list.data.items.every(a=>allMatching?!selected.has(a.id):selected.has(a.id))} onChange={e=>{const checked=e.target.checked;setSelected(old=>{const next=new Set(old);for(const a of list.data?.items??[])if(allMatching?!checked:checked)next.add(a.id);else next.delete(a.id);return next;});}}/>
            {list.data.total>(list.data.items?.length??0)&&<button className="btn ghost sm" aria-label={`Chọn toàn bộ ${list.data.total} kết quả lọc`} onClick={()=>{setAllMatching(true);setSelected(new Set());}}>Chọn cả {list.data.total}</button>}
            {!!selectedCount&&<><strong className="session-selected-count">{selectedCount} đã chọn</strong><button className="btn ghost sm" onClick={clearSelection}>Bỏ chọn</button></>}
          </div>
          <div className="session-action-bar">
            <select className="select" aria-label="Thao tác session" value={action} onChange={e=>setMenuAction(e.target.value)} disabled={bulkBusy}>
              {checkActions.map(a=><option key={a} value={a}>{bulkActions[a]}</option>)}
              {!!selectedCount&&<optgroup label="Quản lý đã chọn">{Object.entries(bulkActions).filter(([key])=>!checkActions.includes(key)&&key!=='delete').map(([key,label])=><option key={key} value={key}>{label}</option>)}</optgroup>}
            </select>
            <button className="btn sm primary" disabled={bulkBusy||list.loading} aria-label={selectedCount?`${bulkActions[action]} đã chọn`:action==='spam_check'?`Check tất cả theo bộ lọc (${list.data.total})`:action==='proxy_check'?'Check proxy tất cả theo bộ lọc':'Check session tất cả theo bộ lọc'} title={selectedCount?`${selectedCount} SS đã chọn`:`Toàn bộ ${list.data.total} SS theo bộ lọc`} onClick={()=>void applyAction()}>{bulkBusy?'Đang xếp…':selectedCount?`Áp dụng (${selectedCount})`:`Check (${list.data.total})`}</button>
            <button className="btn sm danger session-delete-btn" disabled={!selectedCount||bulkBusy||list.loading} title={selectedCount?`Xóa ${selectedCount} SS đã chọn`:'Tích SS cần xóa'} onClick={()=>void runBulk('delete')}>Xóa đã chọn</button>
          </div>
        </div>}
      </section>
      <DataTable caption="Danh sách tài khoản Telegram" columns={cols} rows={list.data?.items} rowKey={(a) => a.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title={hasFilters?'Không có tài khoản phù hợp':'Chưa có session'}>{hasFilters?'Thử bỏ bớt bộ lọc.':'Nhập session hoặc thêm tài khoản để bắt đầu.'}</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={pageSize} total={list.data.total} onPage={setPage} />}

      {bulkAction&&<Modal title={`${bulkActions[bulkAction]} hàng loạt`} onClose={()=>setBulkAction(undefined)} dismissible={!bulkBusy} footer={<><button className="btn" disabled={bulkBusy} onClick={()=>setBulkAction(undefined)}>Hủy</button><button className="btn primary" disabled={bulkBusy} onClick={()=>void runBulk()}>{bulkBusy?'Đang tạo…':'Xác nhận'}</button></>}>
        <p>{bulkActions[bulkAction]} cho <strong>{allMatching?Math.max(0,(list.data?.total??0)-selected.size):selected.size}</strong> session {allMatching?'trong toàn bộ kết quả lọc':'đã chọn'}?</p>
        {bulkAction==='spam_check'&&<Alert>Check gửi /start tới @SpamBot. Có thể dùng lại kết quả mới trong 10 phút; tài khoản vừa tương tác kháng nghị sẽ được bỏ qua để giữ cuộc hội thoại.</Alert>}
        {bulkAction==='mark_frozen'&&<Alert>Đây là nhãn do bạn đánh dấu và sẽ yêu cầu tắt các tài khoản này, không phải kết luận tự động của Telegram.</Alert>}
        {bulkAction==='clear_mark'&&<p>Chỉ bỏ nhãn thủ công, không xóa lỗi đóng băng do Telegram xác nhận.</p>}
      </Modal>}
      {dialog?.kind==='proxy_import'&&<ProxyImport selection={{all_matching:allMatching,account_ids:allMatching?[]:[...selected],exclude_ids:allMatching?[...selected]:[],filters:checkFilters}} count={allMatching?Math.max(0,(list.data?.total??0)-selected.size):selected.size} total={list.data?.total??0} filters={checkFilters} onClose={close} onSaved={message=>saved(message)}/>}
      {dialog?.kind==='bulk_appeal'&&<BulkAppeal jobId={dialog.jobId} selection={{all_matching:allMatching,account_ids:allMatching?[]:[...selected],exclude_ids:allMatching?[...selected]:[],filters:{q:search||undefined,auth_state:state||undefined,health_status:healthFilter||undefined,spam_status:spamFilter||undefined,proxy_status:proxyFilter||undefined,worker_id:workerFilter||undefined,desired_state:desiredFilter||undefined}}} onClose={()=>{close();list.reload();}}/>}
      {dialog?.kind === 'spam'&&<SpamPanel a={dialog.a} onClose={()=>{close();list.reload();}}/>}
      {dialog?.kind === "import" && <SessionImport onClose={() => {close();list.reload();}} />}
      {dialog?.kind === "create" && <TelegramAccountForm onClose={close} onSaved={(a) => { list.reload(); setDialog({ kind: "login", a }); }} />}
      {dialog?.kind === "api" && <TelegramAccountForm a={dialog.a} onClose={close} onSaved={(a) => {
        list.reload();
        if (dialog.loginAfter) setDialog({ kind: "login", a });
        else saved("Đã lưu cấu hình API Telegram.");
      }} />}
      {dialog?.kind === "rename" && <NameDialog title={`Đổi tên ${dialog.a.name}`} action="Lưu tên" initial={dialog.a.name} onClose={close}
        submit={(name) => api.patch(`/api/accounts/${dialog.a.id}`, { name })} onDone={() => saved("Đã đổi tên.")} />}
      {dialog?.kind === "assign" && <AssignDialog a={dialog.a} onClose={close} onDone={() => saved("Đã cập nhật worker.")} />}
      {dialog?.kind === "login" && <LoginWizard a={dialog.a} onClose={() => { close(); list.reload(); }} />}
      {dialog?.kind === "delete" && <DeleteDialog a={dialog.a} onClose={close} onDone={() => saved("Đã xóa tài khoản.")} />}
    </div>
  );
}

function NameDialog({ title, action, initial, submit, onDone, onClose }: { title: string; action: string; initial: string; submit: (name: string) => Promise<unknown>; onDone: () => void; onClose: () => void }) {
  const [name, setName] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  async function go() {
    if (!name.trim()) { setFields({ name: "Nhập tên." }); return; }
    setBusy(true); setErr(undefined); setFields({});
    try { await submit(name); onDone(); } catch (e) { setFields(fieldErrors(e)); setErr(e instanceof ApiError ? e.message : "Thao tác thất bại."); setBusy(false); }
  }
  return (
    <Modal title={title} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy}>{action}</button></>}>
      <TextField label="Tên hiển thị" hint="Chỉ để bạn phân biệt, ví dụ: Sale Hà Nội 1" value={name} onChange={(e) => setName(e.target.value)} error={fields.name} maxLength={64} />
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

function AssignDialog({ a, onClose, onDone }: { a: Account; onClose: () => void; onDone: () => void }) {
  const workers = useQuery((signal) => api.get<Page<Worker>>("/api/workers", { page_size: 100 }, signal), []);
  const [value, setValue] = useState(a.assigned_worker_id ?? "");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  async function go() {
    setBusy(true); setErr(undefined);
    try { await api.put(`/api/accounts/${a.id}/assignment`, { worker_id: value || null }); onDone(); }
    catch (e) { setErr(e instanceof ApiError ? e.message : "Không gán được."); setBusy(false); }
  }
  const usable = (workers.data?.items ?? []).filter((w) => w.status !== "revoked");
  return (
    <Modal title={`Gán worker cho ${a.name}`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy || workers.loading}>Lưu</button></>}>
      <SelectField label="Worker" value={value} onChange={(e) => setValue(e.target.value)}
        hint="Đổi worker không làm hai worker dùng chung một phiên: worker mới chỉ nhận phiên sau khi worker cũ trả lại hoặc hết hạn (tối đa vài chục giây).">
        <option value="">Chưa gán</option>
        {usable.map((w) => <option key={w.id} value={w.id}>{w.name} ({w.platform}) — {w.status === "online" ? "online" : "không online"}</option>)}
      </SelectField>
      {a.auth_state === "awaiting_code" || a.auth_state === "awaiting_password" ? <Alert>Đăng nhập đang dở sẽ bị hủy và phải bắt đầu lại.</Alert> : null}
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

type Step = "phone" | "code" | "password" | "done";

export function LoginWizard({ a, onClose }: { a: Account; onClose: () => void }) {
  const [step, setStep] = useState<Step>(a.auth_state === "awaiting_code" ? "code" : a.auth_state === "awaiting_password" ? "password" : "phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  const abort = useRef(new AbortController());
  useEffect(() => () => abort.current.abort(), []);

  async function run(path: string, body: unknown, onDone: (cmd: Command) => void, onFail: (cmd: Command) => void) {
    setBusy(true); setError(undefined); setFields({});
    try {
      const acc = await api.post<CommandAccepted>(`/api/accounts/${a.id}${path}`, body);
      const cmd = await waitForCommand(a.id, acc.command_id, abort.current.signal);
      if (cmd.status === "done") onDone(cmd);
      else if (cmd.status === "expired" || cmd.status === "pending" || cmd.status === "delivered") setError("Worker không phản hồi kịp. Kiểm tra worker đang online rồi thử lại.");
      else { setError(errorLabel(cmd.error_code, cmd.retry_after)); onFail(cmd); }
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      setFields(fieldErrors(e)); setError(e instanceof ApiError ? e.message : "Thao tác thất bại.");
    } finally { setBusy(false); }
  }
  const afterSignIn = (cmd: Command) => setStep((cmd.result as { state?: string } | null)?.state === "awaiting_password" ? "password" : "done");

  function submitPhone() {
    const value = phone;
    setPhone("");   // secrets leave component state as soon as they are sent
    void run("/login/start", { phone: value }, () => setStep("code"), () => setPhone(value));
  }
  function submitCode() {
    const value = code;
    setCode("");
    void run("/login/code", { code: value }, afterSignIn, (cmd) => { if (cmd.error_code === "code_expired" || cmd.error_code === "login_session_lost") setStep("phone"); });
  }
  function submitPassword() {
    const value = password;
    setPassword("");
    void run("/login/password", { password: value }, () => setStep("done"), (cmd) => { if (cmd.error_code === "login_session_lost") setStep("phone"); });
  }

  const foot = step === "done" ? <button className="btn primary" onClick={onClose}>Xong</button> : (
    <>
      <button className="btn" onClick={onClose} disabled={busy}>Đóng</button>
      {step === "phone" && <button className="btn primary" disabled={busy || !phone.trim()} onClick={submitPhone}>Gửi mã xác nhận</button>}
      {step === "code" && <button className="btn primary" disabled={busy || !code.trim()} onClick={submitCode}>Xác nhận mã</button>}
      {step === "password" && <button className="btn primary" disabled={busy || !password} onClick={submitPassword}>Xác nhận mật khẩu</button>}
    </>);
  return (
    <Modal title={`Đăng nhập Telegram cho ${a.name}`} onClose={onClose} dismissible={!busy} footer={foot}>
      {step === "phone" && <TextField label="Số điện thoại" hint="Định dạng quốc tế, ví dụ +84901234567. Số này chỉ được gửi cho worker, không lưu trên máy chủ." type="tel" inputMode="tel"
        autoComplete="off" value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} autoFocus />}
      {step === "code" && <TextField label="Mã xác nhận" hint="Telegram vừa gửi mã vào ứng dụng Telegram (hoặc SMS) của số này." inputMode="numeric" autoComplete="one-time-code"
        value={code} onChange={(e) => setCode(e.target.value)} error={fields.code} maxLength={8} autoFocus />}
      {step === "password" && <TextField label="Mật khẩu hai lớp" hint="Tài khoản này bật xác minh hai bước trên Telegram." type="password" autoComplete="off"
        value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} autoFocus />}
      {step === "done" && <Alert tone="ok">Đã đăng nhập thành công. Phiên được lưu mã hóa. Bây giờ bạn có thể bật tài khoản.</Alert>}
      {busy && <p className="muted" role="status">Đang chờ worker xử lý…</p>}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}

function DeleteDialog({ a, onClose, onDone }: { a: Account; onClose: () => void; onDone: () => void }) {
  const [typed, setTyped] = useState("");
  const [logout, setLogout] = useState(true);
  const [force, setForce] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [waiting, setWaiting] = useState(false);
  const abort = useRef(new AbortController());
  useEffect(() => () => abort.current.abort(), []);

  async function go(forceNow = force) {
    setBusy(true); setError(undefined);
    try {
      const r = await api.post<DeleteResult>(`/api/accounts/${a.id}/delete`, { confirm_name: typed, telegram_logout: logout, force: forceNow });
      if (r.status === "deleted") { onDone(); return; }
      setWaiting(true);
      const until = Date.now() + 70000;
      while (Date.now() < until && !abort.current.signal.aborted) {
        await new Promise((res) => setTimeout(res, 2000));
        try { await api.get(`/api/accounts/${a.id}`, undefined, abort.current.signal); }
        catch (e) { if (e instanceof ApiError && e.status === 404) { onDone(); return; } if ((e as Error).name === "AbortError") return; }
      }
      setWaiting(false);
      setError("Worker chưa đăng xuất được phiên trên Telegram. Tài khoản vẫn còn nguyên. Bạn có thể thử lại hoặc chọn xóa ngay (phiên vẫn còn hiệu lực trên Telegram).");
      setBusy(false);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Không xóa được."); setBusy(false); setWaiting(false); }
  }
  const blocked = typed !== a.name;
  return (
    <Modal title={`Xóa tài khoản ${a.name}?`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button>
        {error && !force && a.has_session && <button className="btn danger" onClick={() => { setForce(true); void go(true); }} disabled={busy || blocked}>Xóa ngay, không đăng xuất</button>}
        <button className="btn danger solid" disabled={busy || blocked} onClick={() => void go()}>{busy ? "Đang xử lý…" : "Xóa tài khoản"}</button></>}>
      <p>Các tuyến và tác vụ của tài khoản này cũng bị xóa. Hành động này <strong>không thể hoàn tác</strong>.</p>
      {a.has_session && (
        <>
          <Check checked={logout} onChange={(e) => setLogout(e.target.checked)} disabled={force} label="Đăng xuất phiên này trên Telegram trước khi xóa" hint="Worker sẽ chấm dứt phiên phía Telegram (khuyên dùng). Cần worker đang online." />
          <Check checked={force} onChange={(e) => setForce(e.target.checked)} label="Xóa ngay, không đăng xuất" hint="Phiên vẫn còn hiệu lực trong mục Thiết bị của Telegram cho tới khi bạn tự chấm dứt." />
          {force && <Alert tone="warn">Phiên Telegram sẽ <strong>không bị thu hồi</strong>. Hãy vào Telegram → Cài đặt → Thiết bị để chấm dứt thủ công.</Alert>}
        </>
      )}
      <TextField label={`Gõ “${a.name}” để xác nhận`} value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off" spellCheck={false} />
      {waiting && <p className="muted" role="status">Đang chờ worker đăng xuất phiên trên Telegram…</p>}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}

/** Write-only application credentials; each Telegram account is configured independently. */
export function TelegramAccountForm({ a, onClose, onSaved }: { a?: Account; onClose: () => void; onSaved: (account: Account) => void }) {
  const [name, setName] = useState("");
  const [worker, setWorker] = useState("");
  const [apiId, setApiId] = useState("");
  const [apiHash, setApiHash] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  const workers = useQuery((signal) => api.get<Page<Worker>>("/api/workers", { page_size: 100 }, signal), [], { enabled: !a });
  const usable = (workers.data?.items ?? []).filter((w) => w.status !== "revoked");
  useEffect(() => {
    if (a || worker) return;
    const online = usable.filter((w) => w.status === "online" || w.status === "degraded");
    const choice = online.length === 1 ? online[0] : usable.length === 1 ? usable[0] : undefined;
    if (choice) setWorker(choice.id);
  }, [workers.data, worker, a]);

  async function submit() {
    const next: Record<string, string> = {};
    const id = Number(apiId);
    if (!a && !name.trim()) next.name = "Nhập tên hiển thị.";
    if (!a && !worker) next.worker_id = "Chọn worker cho tài khoản.";
    if (!/^[1-9][0-9]*$/.test(apiId) || !Number.isInteger(id) || id > 2147483647) next.api_id = "api_id phải là số nguyên dương lấy từ my.telegram.org.";
    if (!/^[0-9a-f]{32}$/i.test(apiHash.trim())) next.api_hash = "api_hash phải có 32 ký tự hexadecimal.";
    if (Object.keys(next).length) { setFields(next); return; }
    const config = { api_id: id, api_hash: apiHash.trim() };
    setApiHash(""); setBusy(true); setError(undefined); setFields({});
    try {
      const account = a
        ? await api.put<Account>(`/api/accounts/${a.id}/telegram-api`, config)
        : await api.post<Account>("/api/accounts", { name: name.trim(), worker_id: worker, ...config });
      onSaved(account);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Không lưu được cấu hình Telegram.");
      setFields(fieldErrors(e)); setBusy(false);
    }
  }

  return (
    <Modal title={a ? `API Telegram cho ${a.name}` : "Thêm tài khoản Telegram"} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" disabled={busy || (!a && workers.loading)} onClick={() => void submit()}>{busy ? "Đang lưu…" : a ? "Lưu cấu hình" : "Tạo và đăng nhập"}</button></>}>
      {!a && <>
        <TextField label="Tên hiển thị" value={name} onChange={(e) => setName(e.target.value)} maxLength={64} error={fields.name} autoFocus />
        <SelectField label="Worker" value={worker} onChange={(e) => setWorker(e.target.value)} error={fields.worker_id}>
          <option value="">Chọn worker</option>
          {usable.map((w) => <option key={w.id} value={w.id}>{w.name} — {w.status}</option>)}
        </SelectField>
        {workers.error && <Alert tone="bad">{workers.error.message}</Alert>}
        {!workers.loading && !usable.length && <Alert>Chưa có worker. Hãy chạy run.cmd để máy kết nối trước.</Alert>}
      </>}
      <p className="hint">Lấy thông tin ứng dụng tại <a href="https://my.telegram.org" target="_blank" rel="noreferrer">my.telegram.org → API development tools</a>. Dùng số điện thoại đã có tài khoản Telegram.</p>
      {a?.telegram_api_configured && <Alert>Đã lưu cấu hình. Nhập lại cả hai trường nếu muốn thay đổi; api_hash cũ không được hiển thị lại.</Alert>}
      <TextField label="api_id" inputMode="numeric" value={apiId} onChange={(e) => setApiId(e.target.value.trim())} error={fields.api_id} autoComplete="off" />
      <TextField label="api_hash" type="password" value={apiHash} onChange={(e) => setApiHash(e.target.value)} error={fields.api_hash} autoComplete="new-password" maxLength={32}
        hint="Được mã hóa khi lưu và chỉ cấp cho worker của tài khoản này. Sau khi lưu bạn sẽ nhập số điện thoại và OTP." />
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
