import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import type { Page, Worker } from "../api/types";
import { Modal } from "../components/Modal";
import { Alert, SelectField, TextArea, TextField } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { sessionFiles,toBase64 } from "../lib/sessionFiles";
import {spamLabels} from "./SpamPanel";
import { errorLabel } from "../lib/labels";

type Item = { index: number; filename: string; status: string; account_id?: string; command_id?: string; error_code?: string; retry_after?: number; spam_status?:string; spam_error?:string; proxy_label?:string|null };
const terminal = (s: string) => ["done", "failed", "expired", "error", "duplicate"].includes(s);
const statuses: Record<string,string> = {queued:"Đang chờ",pending:"Đang chờ",delivered:"Đang kiểm tra",done:"Thành công",failed:"Lỗi",expired:"Hết thời gian — kiểm tra lại",error:"File không hợp lệ",duplicate:"Trùng — đã bỏ qua"};
const importErrors: Record<string,string> = {invalid_telethon_session:"Không phải session Telethon hợp lệ hoặc file chưa được đóng hoàn toàn.",session_has_no_auth_key:"Session chưa đăng nhập.",session_check_timeout:"Kiểm tra mất quá lâu. Có thể thử lại.",internal_error:"Worker chưa kiểm tra được. Có thể thử lại."};

export function SessionImport({ onClose }: { onClose: () => void }) {
  const [files,setFiles]=useState<File[]>([]);
  const [worker,setWorker]=useState("");
  const [autoSpam,setAutoSpam]=useState(true);
  const [withProxy,setWithProxy]=useState(true);
  const [proxyText,setProxyText]=useState('');
  const [proxyProtocol,setProxyProtocol]=useState('socks5');
  const [counting,setCounting]=useState(false);
  const [loadingProxy,setLoadingProxy]=useState(false);
  const [apiId,setApiId]=useState("");
  const [apiHash,setApiHash]=useState("");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [pollError,setPollError]=useState('');
  const [uploaded,setUploaded]=useState(false);
  const [items,setItems]=useState<Item[]>([]);
  const [page,setPage]=useState(1);
  const [sent,setSent]=useState(0);
  const [paused,setPaused]=useState(false);
  const cancel=useRef(false);
  const input=useRef<HTMLInputElement>(null);
  const proxyLines=proxyText.split(/\r?\n/).map(line=>line.trim()).filter(line=>line&&!line.startsWith('#'));
  const workers=useQuery(signal=>api.get<Page<Worker>>("/api/workers",{page_size:100},signal),[]);
  const online=(workers.data?.items??[]).filter(w=>w.status==="online"||w.status==="degraded");
  useEffect(()=>{if(!worker&&online.length===1)setWorker(online[0].id);},[workers.data,worker]);
  const ids=items.filter(i=>i.command_id&&!terminal(i.status)).map(i=>i.command_id!);
  const key=ids.join(",");
  useEffect(()=>{
    if(!key)return;
    let cancelled=false;
    let timer:ReturnType<typeof setTimeout>;
    async function poll(){
      try{
        const ids=key.split(",");
        const updates:Partial<Item>[]=[];
        for(let i=0;i<ids.length;i+=100){
          if(cancelled)return;
          const r=await api.post<{items:Partial<Item>[]}>("/api/accounts/import-sessions/status",{command_ids:ids.slice(i,i+100)});
          updates.push(...r.items);
        }
        if(cancelled)return;
        const mapped=new Map(updates.map(x=>[x.command_id,x]));
        setItems(old=>old.map(item=>({...item,...mapped.get(item.command_id)})));
        setPollError("");
      }catch(e){if(!cancelled)setPollError(e instanceof ApiError?e.message:"Không tải được tiến độ; sẽ thử lại.");}
      if(!cancelled)timer=setTimeout(()=>void poll(),2000);
    }
    void poll();
    return()=>{cancelled=true;clearTimeout(timer);};
  },[key]);

  async function loadProxies(file?:File){
    if(!file)return;
    setError('');
    if(file.size>2000000){setError('File proxy tối đa 2 MB.');return;}
    setLoadingProxy(true);
    try{setProxyText(await file.text());}
    catch{setError('Không đọc được file proxy. Hãy dùng file .txt UTF-8 hoặc dán vào ô.');}
    finally{setLoadingProxy(false);}
  }
  async function submit(){
    if(!worker||!files.length||!(/^[1-9][0-9]*$/.test(apiId))||Number(apiId)>2147483647||!(/^[0-9a-f]{32}$/i.test(apiHash.trim()))){setError("Chọn worker online, chọn file và nhập đúng api_id/api_hash.");return;}
    if(withProxy&&!proxyLines.length){setError('Nhập proxy hoặc chọn file .txt. Mỗi SS cần một proxy riêng.');return;}
    if(withProxy&&new Set(proxyLines).size!==proxyLines.length){setError('Danh sách có proxy trùng. Mỗi SS cần một proxy riêng.');return;}
    setBusy(true);setError("");setPaused(false);setUploaded(false);cancel.current=false;
    const hash=apiHash.trim();
    let buffer:{filename:string;content:string}[]=[];let bytes=0;let index=0;let proxyOffset=0;
    async function flush(){
      if(!buffer.length)return;
      const r=await api.post<{items:Item[]}>("/api/accounts/import-sessions",{worker_id:worker,api_id:Number(apiId),api_hash:hash,files:buffer,auto_check_spam:autoSpam,
        ...(withProxy?{require_proxy:true,proxy_protocol:proxyProtocol,proxies:proxyLines.slice(proxyOffset,proxyOffset+buffer.length)}:{})});
      const rows=r.items.map(x=>({...x,index:index++}));const count=buffer.length;
      setItems(old=>[...old,...rows]);
      setSent(n=>n+count);proxyOffset+=count;buffer=[];bytes=0;
    }
    try{
      if(withProxy){
        setCounting(true);
        let count=0;
        // One file at a time, even on this preflight pass; no archive-sized buffer.
        for await(const entry of sessionFiles(files)){
          if(cancel.current){setPaused(true);return;}
          if(!entry.error)count++;
        }
        if(!count)throw Error('Không có file session đọc được. Kiểm tra lại các file đã chọn.');
        if(proxyLines.length<count)throw Error(`Có ${count} SS nhưng chỉ có ${proxyLines.length} proxy. Chưa tải SS nào; hãy bổ sung đủ proxy.`);
        setCounting(false);
      }
      for await(const entry of sessionFiles(files)){
        if(cancel.current){setPaused(true);break;}
        if(entry.error){const row={index:index++,filename:entry.name,status:"error",error_code:entry.error};setItems(old=>[...old,row]);continue;}
        if(buffer.length>=100||bytes+entry.bytes!.length>8*1024*1024)await flush();
        buffer.push({filename:entry.name,content:toBase64(entry.bytes!)});bytes+=entry.bytes!.length;
      }
      if(!cancel.current){await flush();setUploaded(true);}
      else setPaused(true);
      setApiHash("");setProxyText('');setFiles([]);if(input.current)input.current.value="";
    }catch(e){setError(e instanceof ApiError?e.message:e instanceof Error?e.message:"Không nhập được session. Chọn lại file để tiếp tục, session trùng sẽ tự bỏ qua.");}
    finally{setBusy(false);setCounting(false);}
  }
  async function retry(item:Item){
    if(!item.account_id)return;
    try{
      const r=await api.post<{command_id:string;status:string}>(`/api/accounts/${item.account_id}/import-session/retry`);
      setItems(old=>old.map(x=>x.index===item.index?{...x,...r,error_code:undefined,retry_after:undefined}:x));
    }catch(e){setError(e instanceof ApiError?e.message:"Không thể thử lại.");}
  }
  const active=items.some(i=>!terminal(i.status));
  return <Modal title="Nhập session hàng loạt" onClose={onClose} dismissible={!busy}
    footer={<><button className="btn" disabled={busy} onClick={onClose}>Đóng</button>{busy&&<button className="btn" onClick={()=>{cancel.current=true;}}>Dừng tải thêm</button>}{!busy&&!items.length&&<button className="btn primary" disabled={busy||workers.loading||loadingProxy} onClick={()=>void submit()}>{busy?"Đang nhập…":"Nhập và kiểm tra session"}</button>}</>}>
    {!items.length&&!busy?<>
      <p>Chọn nhiều file Telethon <strong>.session</strong> hoặc ZIP chứa các file đó. Không giới hạn tổng số session; web tự chia lô khi tải lên. Mỗi file session tối đa 1 MiB. Dừng ứng dụng đang dùng các session này trước khi nhập.</p>
      <SelectField label="Worker" value={worker} onChange={e=>setWorker(e.target.value)}><option value="">Chọn worker online</option>{online.map(w=><option key={w.id} value={w.id}>{w.name}</option>)}</SelectField>
      {workers.error&&<Alert tone="bad">{workers.error.message}</Alert>}
      {!workers.loading&&!online.length&&<Alert>Chưa có worker online. Chạy run.cmd trước.</Alert>}
      <label className="field">File session hoặc ZIP<input ref={input} type="file" multiple accept=".session,.zip" disabled={busy} onChange={e=>setFiles(Array.from(e.target.files??[]))}/></label>
      <p className="hint">Đã chọn {files.length} file. ZIP lớn được đọc từng session, không nạp toàn bộ vào bộ nhớ. Không hỗ trợ Pyrogram hoặc tdata. api_id/api_hash dùng cho lô này; nếu các tài khoản dùng nhiều API khác nhau, nhập thành từng lô.</p>
      <div className="import-proxy-box">
        <label><input type="checkbox" checked={withProxy} onChange={e=>setWithProxy(e.target.checked)}/> Nhập SS kèm proxy</label>
        {withProxy&&<>
          <div className="import-proxy-grid">
            <SelectField label="Loại proxy mặc định" value={proxyProtocol} onChange={e=>setProxyProtocol(e.target.value)}><option value="socks5">SOCKS5</option><option value="http">HTTP CONNECT</option><option value="socks4">SOCKS4</option></SelectField>
            <label className="field">File proxy .txt<input type="file" accept=".txt,text/plain" disabled={loadingProxy} onChange={e=>void loadProxies(e.target.files?.[0])}/></label>
          </div>
          <TextArea label="Proxy cho session mới" rows={4} value={proxyText} disabled={loadingProxy} maxLength={2000000} onChange={e=>setProxyText(e.target.value)} spellCheck={false} autoComplete="off" placeholder={'host:port:user:pass\nsocks5://user:pass@host:port'}/>
          <p className="hint">{loadingProxy?'Đang đọc file…':`${proxyLines.length} dòng proxy`} · Dòng 1 → SS 1, dòng 2 → SS 2, theo thứ tự file / bên trong ZIP. Mỗi SS một proxy riêng; dòng trống và # được bỏ qua. Proxy dư không dùng.</p>
          <p className="hint">Lưu proxy trước lần check đầu tiên. Proxy lỗi sẽ báo lỗi, không chuyển sang kết nối trực tiếp. SS trùng được bỏ qua và giữ proxy cũ.</p>
        </>}
      </div>
      <label><input type="checkbox" checked={autoSpam} onChange={e=>setAutoSpam(e.target.checked)} disabled={busy}/> Sau nhập: tự check phiên/API và spam qua @SpamBot (gửi /start)</label>
      <TextField label="api_id" inputMode="numeric" value={apiId} onChange={e=>setApiId(e.target.value.trim())} disabled={busy}/>
      <TextField label="api_hash" type="password" autoComplete="new-password" value={apiHash} onChange={e=>setApiHash(e.target.value)} disabled={busy}/>
    </>:<>
      <p className="hint">Đã gửi {sent} session. {counting?"Đang đếm SS để kiểm tra đủ proxy…":busy?"Đang đọc và tải từng lô…":paused?"Đã dừng tải thêm. Các lô đã gửi vẫn được xử lý.":uploaded?"Đã tải xong.":"Đã dừng tải."}</p>
      <p role="status">Thành công: {items.filter(i=>i.status==="done").length} / {items.length} · Đang chờ/xử lý: {items.filter(i=>!terminal(i.status)).length} · Trùng: {items.filter(i=>i.status==="duplicate").length} · Lỗi: {items.filter(i=>["failed","expired","error"].includes(i.status)).length}</p>
      <p className="hint">Worker kiểm tra phiên/API và, nếu đã chọn, hỏi @SpamBot sau khi xác thực. Kết quả session và SpamBot hiển thị riêng. Không tự gửi kháng nghị. Đóng cửa sổ này không hủy hàng đợi. Tài khoản thành công ở trạng thái Tắt, bạn có thể Bật khi cần.</p>
      <div style={{maxHeight:360,overflow:"auto"}}><table className="table"><thead><tr><th>File</th><th>Proxy</th><th>Kết quả</th></tr></thead><tbody>{items.slice((page-1)*50,page*50).map(i=><tr key={i.index}><td>{i.filename}</td><td>{i.proxy_label??'—'}</td><td>{statuses[i.status]??i.status}{i.spam_status&&<p className="hint">{spamLabels[i.spam_status]}{i.spam_error?` — ${errorLabel(i.spam_error)}`:""}</p>}{i.error_code&&<p className="hint">{importErrors[i.error_code]??(i.status==="error"?i.error_code:errorLabel(i.error_code))}{i.retry_after?` — chờ ${i.retry_after} giây`:""}</p>}{["failed","expired"].includes(i.status)&&<button className="btn sm" onClick={()=>void retry(i)}>Kiểm tra lại</button>}</td></tr>)}</tbody></table></div>
      <div className="row"><button className="btn sm" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Trước</button><span>Trang {page}/{Math.max(1,Math.ceil(items.length/50))}</span><button className="btn sm" disabled={page*50>=items.length} onClick={()=>setPage(p=>p+1)}>Sau</button></div>
      {!active&&!busy&&<Alert>Đã xử lý xong lô. Tài khoản thành công xuất hiện trong danh sách. Session hết hiệu lực cần đăng nhập lại bằng OTP.</Alert>}
    </>}
    {error&&<Alert tone="bad">{error}</Alert>}
    {pollError&&<Alert tone="bad">{pollError}</Alert>}
  </Modal>;
}
