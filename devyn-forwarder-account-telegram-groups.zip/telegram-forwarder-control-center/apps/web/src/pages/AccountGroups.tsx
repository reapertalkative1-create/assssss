import {useState} from 'react';
import {api,ApiError,request} from '../api/client';
import {Modal} from '../components/Modal';
import {Alert,TextField} from '../components/ui';

export interface AccountGroup {id:string;name:string;count:number}
type Selection={all_matching:boolean;account_ids:string[];exclude_ids:string[];filters:Record<string,string|undefined>};
export function AccountGroups({groups,selection,count,onClose,onChanged}:{groups:AccountGroup[];selection:Selection;count:number;onClose:()=>void;onChanged:(assigned:boolean)=>void}){
 const [name,setName]=useState(''),[editing,setEditing]=useState(''),[target,setTarget]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function perform(fn:()=>Promise<unknown>,assigned=false){setBusy(true);setError('');try{await fn();onChanged(assigned);}catch(e){setError(e instanceof ApiError?e.message:'Không thực hiện được.');}finally{setBusy(false);}}
 async function save(){if(!name.trim()){setError('Nhập tên nhóm.');return;}await perform(async()=>{if(editing)await api.patch(`/api/account-groups/${editing}`,{name:name.trim()});else await api.post('/api/account-groups',{name:name.trim()});setEditing('');setName('');});}
 return <Modal title="Nhóm tài khoản" onClose={onClose} dismissible={!busy} footer={<button className="btn primary" disabled={busy} onClick={onClose}>Đóng</button>}>
  <p className="hint">Mỗi session thuộc tối đa một nhóm. Xóa nhóm chỉ bỏ phân loại, không xóa session.</p>
  <div className="row group-create"><TextField label={editing?'Đổi tên nhóm':'Tạo nhóm'} value={name} maxLength={64} onChange={e=>setName(e.target.value)} placeholder="Tên nhóm…"/><button className="btn sm primary" disabled={busy} onClick={()=>void save()}>{editing?'Lưu':'Tạo nhóm'}</button>{editing&&<button className="btn sm" onClick={()=>{setEditing('');setName('');}}>Hủy</button>}</div>
  <div className="account-group-list">{groups.length===0?<p className="hint">Chưa có nhóm nào.</p>:groups.map(g=><div className="account-group-item" key={g.id}><div><strong>{g.name}</strong><span className="hint"> · {g.count} SS</span></div><div className="row"><button className="btn sm" disabled={busy} onClick={()=>{setEditing(g.id);setName(g.name);}}>Đổi tên</button><button className="btn sm danger" disabled={busy} onClick={()=>void perform(()=>request('DELETE',`/api/account-groups/${g.id}`))}>Xóa nhóm</button></div></div>)}</div>
  <div className="account-group-assign"><strong>Chuyển SS đã chọn</strong><div className="row"><select className="select" aria-label="Nhóm đích" value={target} onChange={e=>setTarget(e.target.value)}><option value="">Bỏ khỏi nhóm</option>{groups.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}</select><button className="btn sm primary" disabled={busy||!count} onClick={()=>void perform(()=>api.post('/api/account-groups/assign',{...selection,group_id:target||null}),true)}>Áp dụng ({count})</button></div></div>
  {error&&<Alert tone="bad">{error}</Alert>}
 </Modal>;
}
