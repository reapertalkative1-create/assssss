import {useEffect,useMemo,useRef,useState} from 'react';
import {api,ApiError,request} from '../api/client';
import type {WorkCluster} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,Check,TextArea,TextField} from '../components/ui';
import {SenderPicker,type Sender} from './SenderPicker';

type Draft={name:string;targets:string;delay:string;delayMax:string;senders:Sender[];text:string;times:string[];enabled:boolean;loop:boolean;requestId:string;savedAt:number|null};
const empty=(cluster?:WorkCluster):Draft=>({name:cluster?.name??'',targets:cluster?.targets.join('\n')??'',delay:String(cluster?.delay_seconds??150),delayMax:String(cluster?.delay_max_seconds??180),senders:cluster?.senders??[],text:cluster?.message_text??'',times:cluster?.message_schedule_times??[],enabled:cluster?.message_schedule_enabled??false,loop:cluster?.message_loop_enabled??false,requestId:crypto.randomUUID(),savedAt:null});
const key=(owner:string,cluster?:WorkCluster)=>`devyn.message-cluster-draft.v1:${encodeURIComponent(owner)}:${cluster?cluster.id+':'+cluster.revision:'new'}`;
function useDraft(owner:string,cluster?:WorkCluster){
 const storageKey=key(owner,cluster),initial=useMemo(()=>empty(cluster),[cluster?.id,cluster?.revision]);
 const [draft,setDraft]=useState<Draft>(()=>{try{const x=JSON.parse(localStorage.getItem(storageKey)||'null');return x&&typeof x.name==='string'&&typeof x.targets==='string'&&Array.isArray(x.senders)&&Date.now()-x.savedAt<7*86400000?{...initial,...x}:initial;}catch{return initial;}});
 const current=useRef(draft),dirty=useRef(false),finished=useRef(false);current.current=draft;
 const [storageError,setStorageError]=useState('');
 function persist(){if(!dirty.current||finished.current)return;try{const next={...current.current,savedAt:Date.now(),senders:current.current.senders.map(a=>({id:a.id,name:a.name}))};localStorage.setItem(storageKey,JSON.stringify(next));setStorageError('');}catch{setStorageError('Không lưu được bản tạm. Vui lòng sao chép nội dung trước khi đóng.');}}
 useEffect(()=>{const timer=setTimeout(persist,250);return()=>clearTimeout(timer);},[draft,storageKey]);
 useEffect(()=>{const flush=()=>{if(!dirty.current||finished.current)return;try{localStorage.setItem(storageKey,JSON.stringify({...current.current,savedAt:Date.now(),senders:current.current.senders.map(a=>({id:a.id,name:a.name}))}));}catch{}};window.addEventListener('pagehide',flush);return()=>{flush();window.removeEventListener('pagehide',flush);};},[storageKey]);
 const update=(patch:Partial<Draft>)=>{dirty.current=true;setDraft(v=>({...v,...patch,requestId:crypto.randomUUID()}));};
 const saveNow=()=>{dirty.current=true;persist();};
 const clear=()=>{localStorage.removeItem(storageKey);dirty.current=false;setDraft({...initial,requestId:crypto.randomUUID(),savedAt:null});};
 const complete=()=>{finished.current=true;dirty.current=false;localStorage.removeItem(storageKey);};
 return {draft,update,saveNow,clear,complete,storageError};
}

export function MessageClusterForm({owner,cluster,onClose,onSaved}:{owner:string;cluster?:WorkCluster;onClose:()=>void;onSaved:(c:WorkCluster)=>void}){
 const cache=useDraft(owner,cluster),d=cache.draft;
 const [busy,setBusy]=useState(false),[checking,setChecking]=useState(false),[error,setError]=useState(''),[validated,setValidated]=useState<number|null>(null),[time,setTime]=useState('09:00'),[mediaFile,setMediaFile]=useState<File|null>(null),[removeMedia,setRemoveMedia]=useState(false),[notice,setNotice]=useState('');
 const savedCluster=useRef<WorkCluster|null>(cluster??null);
 const locked=busy||checking;
 async function readTxt(file?:File){if(!file)return;if(file.size>500000){setError('File nhóm tối đa 500 KB.');return;}try{cache.update({targets:await file.text()});setValidated(null);setNotice('Đã nạp danh sách nhóm từ file TXT.');}catch{setError('Không đọc được file TXT.');}}
 async function validate(){setChecking(true);setError('');try{const r=await api.post<{count:number}>('/api/post-routes/validate-targets',{targets_text:d.targets});setValidated(r.count);}catch(e){setError(e instanceof ApiError?e.message:'Không kiểm tra được danh sách nhóm.');}finally{setChecking(false);}}
 async function save(){
  const text=d.text.trim(); if(!d.name.trim()||!d.senders.length||!d.targets.trim()){setError('Nhập tên cụm, chọn tài khoản gửi và nhập danh sách nhóm.');return;}
  if(!text&&!mediaFile&&!(cluster?.message_media_id&&!removeMedia)){setError('Nhập nội dung hoặc chọn ảnh/video trước khi lưu.');return;}
  if(!/^\d+$/.test(d.delay)||Number(d.delay)<5||Number(d.delay)>86400||!/^\d+$/.test(d.delayMax)||Number(d.delayMax)<Number(d.delay)||Number(d.delayMax)>86400){setError('Khoảng nghỉ phải từ 5 đến 86.400 giây và mốc đến không nhỏ hơn mốc từ.');return;}
  if(d.enabled&&!d.times.length){setError('Thêm ít nhất một khung giờ trước khi bật lịch.');return;}
  if((mediaFile||cluster?.message_media_id&&!removeMedia)&&d.text.length>1024){setError('Chú thích ảnh/video tối đa 1.024 ký tự.');return;}
  if(mediaFile&&mediaFile.size>20*1024*1024){setError('Tệp media tối đa 20 MB.');return;}
  setBusy(true);setError('');setNotice('');try{
   const body={name:d.name.trim(),account_ids:d.senders.map(a=>a.id),targets_text:d.targets,delay_seconds:Number(d.delay),delay_max_seconds:Number(d.delayMax),mode:'forward' as const,cluster_type:'message' as const,message_loop_enabled:d.loop};
   const existing=savedCluster.current;
   const saved=existing?await api.patch<WorkCluster>(`/api/work-clusters/${existing.id}`,{...body,revision:existing.revision}):await api.post<WorkCluster>('/api/work-clusters',{...body,request_id:d.requestId});
   savedCluster.current=saved;
   if(mediaFile){await api.upload(`/api/work-clusters/${saved.id}/message-media`,mediaFile);}
   else if(removeMedia&&saved.message_media_id)await request('DELETE',`/api/work-clusters/${saved.id}/message-media`);
   await api.put(`/api/work-clusters/${saved.id}/message`,{text:d.text,schedule_times:d.times,timezone:'Asia/Ho_Chi_Minh',schedule_enabled:d.enabled,loop_enabled:d.loop});
   cache.complete();onSaved({...saved,cluster_type:'message',message_text:d.text,message_schedule_times:d.times,message_schedule_enabled:d.enabled,message_loop_enabled:d.loop});
  }catch(e){setError(e instanceof ApiError?e.message:'Không lưu được cụm gửi tin nhắn.');}finally{setBusy(false);}
 }
 function addTime(){if(!d.times.includes(time)&&d.times.length<12)cache.update({times:[...d.times,time].sort()});}
 return <Modal wide title={cluster?'Sửa cụm gửi tin nhắn':'Tạo cụm gửi tin nhắn'} onClose={onClose} footer={<><button className="btn" disabled={locked} onClick={onClose}>Đóng</button><button className="btn primary" disabled={locked} onClick={()=>void save()}>{busy?'Đang lưu…':cluster?'Lưu cụm gửi tin nhắn':'Tạo cụm gửi tin nhắn'}</button></>}>
  <div className="message-cluster-form stack">
   {cache.storageError&&<Alert tone="bad">{cache.storageError}</Alert>}
   <div className="post-draft-bar"><div><strong>{d.savedAt?'Đã tự lưu tạm':'Tự lưu tạm'}</strong><span>Trong trình duyệt này · giữ 7 ngày</span></div><div className="row"><button className="btn sm" disabled={locked} onClick={cache.saveNow}>Lưu tạm</button><button className="btn ghost sm" disabled={locked} onClick={cache.clear}>Xóa bản tạm</button></div></div>
   <div className="message-form-intro"><strong>Cụm gửi tin nhắn</strong><span>Soạn một nội dung và gửi tuần tự tới các nhóm đã chọn. Không tự tham gia nhóm.</span></div>
   <TextField label="Tên cụm làm việc" value={d.name} maxLength={64} disabled={locked} onChange={e=>cache.update({name:e.target.value})} placeholder="Ví dụ: Thông báo cộng đồng"/>
   <label className="message-file-input"><strong>File danh sách nhóm .txt</strong><span>Mỗi nhóm/kênh một dòng · tối đa 500 KB</span><input type="file" accept=".txt,text/plain" disabled={locked} onChange={e=>{void readTxt(e.target.files?.[0]);e.currentTarget.value='';}}/></label>
   <TextArea label="Nhóm nhận bài" value={d.targets} disabled={locked} rows={6} onChange={e=>{cache.update({targets:e.target.value});setValidated(null);}} placeholder={'@nhom_cua_ban\nhttps://t.me/kenh_cua_ban\n-1001234567890'} hint="Tự bỏ dòng trống, dòng bắt đầu bằng # và dòng trùng."/>
   <div className="row between"><button className="btn sm" disabled={locked||!d.targets.trim()} onClick={()=>void validate()}>{checking?'Đang kiểm tra…':'Kiểm tra danh sách'}</button>{validated!==null&&<span className="hint" role="status">{validated} nhóm đúng định dạng</span>}</div>
   <SenderPicker value={d.senders} onChange={senders=>cache.update({senders})} disabled={locked}/>
   <fieldset className="cluster-delay"><legend>Nghỉ giữa hai nhóm (giây)</legend><div><TextField label="Từ" type="number" min={5} max={86400} value={d.delay} disabled={locked} onChange={e=>cache.update({delay:e.target.value})}/><span>–</span><TextField label="Đến" type="number" min={5} max={86400} value={d.delayMax} disabled={locked} onChange={e=>cache.update({delayMax:e.target.value})}/></div><small>Khoảng nghỉ được chọn ngẫu nhiên cho từng nhóm.</small></fieldset>
   <TextArea label="Nội dung tin nhắn" value={d.text} disabled={locked} rows={5} maxLength={4096} onChange={e=>cache.update({text:e.target.value})} placeholder="Nhập chữ, ký tự đặc biệt và emoji…"/>
   <div className="row" aria-label="Chèn emoji thường">{['😀','❤️','👍','🔥','🎉','✅','📣'].map(x=><button className="btn sm" type="button" key={x} disabled={locked} onClick={()=>cache.update({text:d.text+x})}>{x}</button>)}</div>
   <label className="message-file-input"><strong>Ảnh hoặc video</strong><span>JPEG, PNG, WebP, MP4 hoặc MOV · tối đa 20 MB</span><input type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime" disabled={locked} onChange={e=>{setMediaFile(e.target.files?.[0]??null);setRemoveMedia(false);}}/></label>
   {(mediaFile||cluster?.message_media_id)&&<div className="row"><span>{mediaFile?`Đã chọn: ${mediaFile.name}`:`Đã có ${cluster?.message_media_type==='video'?'video':'ảnh'} đã tải`}</span>{(mediaFile||cluster?.message_media_id)&&<button className="btn sm danger" type="button" disabled={locked} onClick={()=>{setMediaFile(null);setRemoveMedia(true);}}>Bỏ media</button>}</div>}
   <p className="hint">Emoji Unicode và ký tự đặc biệt được giữ nguyên. Emoji Premium Telegram chưa được hỗ trợ trong bản này; cần custom-emoji ID/entity và quyền tài khoản Telegram tương ứng.</p>
   <section className="message-schedule"><h3>Lên lịch gửi nhiều khung giờ</h3><p className="hint">Múi giờ: Việt Nam (Asia/Ho_Chi_Minh).</p><div className="row"><TextField label="Giờ gửi" type="time" value={time} disabled={locked} onChange={e=>setTime(e.target.value)}/><button className="btn sm" type="button" disabled={locked||d.times.length>=12||d.times.includes(time)} onClick={addTime}>Thêm giờ</button></div><div className="row">{d.times.map(t=><button className="btn sm" type="button" key={t} disabled={locked} onClick={()=>cache.update({times:d.times.filter(x=>x!==t)})}>{t} ×</button>)}</div><Check label="Bật lịch gửi tự động" checked={d.enabled} disabled={locked} onChange={e=>cache.update({enabled:e.target.checked})}/></section>
   <section className="message-loop"><Check label="Lặp vòng ngẫu nhiên khi hết danh sách" hint="Mỗi lượt xáo trộn lại toàn bộ nhóm. Tắt: mỗi nhóm cố định một SS như chế độ phân công cũ." checked={d.loop} disabled={locked} onChange={e=>cache.update({loop:e.target.checked})}/><p className="hint">Khi bật, mỗi SS nhận một tập nhóm ngẫu nhiên riêng trong lượt đầu; hết vòng, hệ thống lặp lại với thứ tự xáo trộn mới cho đến khi bạn dừng. Không tự tham gia nhóm/kênh chưa tham gia.</p></section>
   {notice&&<p className="hint" role="status">{notice}</p>}{error&&<Alert tone="bad">{error}</Alert>}
  </div>
 </Modal>;
}
