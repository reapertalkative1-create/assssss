import {useState} from 'react';
import {api} from '../api/client';
import type {Route} from '../api/types';
import {Modal} from '../components/Modal';
import {Pagination} from '../components/DataTable';
import {Alert,Pill} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {useRouteSelection} from '../hooks/useRouteSelection';
import {deliveryLabel} from './PostRoute';
import {RouteBulkActions,skipRoute} from './RouteBulkActions';

export function PostBatch({batchId,isAdmin=false,onClose,onDetail,onSaveCluster}:{batchId:string;isAdmin?:boolean;onClose:()=>void;onDetail:(route:Route)=>void;onSaveCluster?:(ids:string[])=>Promise<void>}){
 const live=useQuery(signal=>api.get<{items:Route[]}>(`/api/post-routes/batches/${batchId}`,undefined,signal),[batchId],{interval:2000});
 const [busy,setBusy]=useState(false),[filter,setFilter]=useState(''),[status,setStatus]=useState(''),[page,setPage]=useState(1);
 const selection=useRouteSelection(),rows=live.data?.items??[];
 const filtered=rows.filter(r=>(!filter||(r.account_name??'').toLowerCase().includes(filter.toLowerCase()))&&(!status||(status==='ready'?!skipRoute('start',r):status==='issues'?!!(r.account_issue||r.account_restriction||r.verification_error||r.link_config?.pause_reason):r.status===status)));
 const shown=filtered.slice((page-1)*50,page*50),allPage=!!shown.length&&shown.every(r=>selection.chosen.has(r.id));
 return <Modal wide title={rows[0]?.link_config?.work_cluster_name?`Lượt gửi · ${rows[0].link_config.work_cluster_name}`:'Lượt gửi · tài khoản & tiến độ'} onClose={onClose} dismissible={!busy} footer={<button className="btn" disabled={busy} onClick={onClose}>Đóng</button>}>
  {rows[0]?.link_config&&<div className="cluster-run-summary"><a href={rows[0].link_config.post_link} target="_blank" rel="noreferrer">{rows[0].link_config.post_link}</a><span>{rows.length} SS · {rows.reduce((n,r)=>n+(r.link_config?.targets.length??0),0)} nhóm nhận · {rows.reduce((n,r)=>n+(r.stats.succeeded??0),0)} đã gửi</span></div>}
  <div className="post-guards"><span>SS cố định</span><span>Bỏ qua trùng: {rows.reduce((n,r)=>n+(r.link_config?.duplicate_count??0),0)}</span><span>Cần đối chiếu: {rows.filter(r=>r.link_config?.pause_reason==='delivery_uncertain').length}</span></div>
  <div className="route-pick-tools"><input className="input" disabled={busy} aria-label="Tìm SS trong lượt gửi" placeholder="Tìm tài khoản…" value={filter} onChange={e=>{setFilter(e.target.value);setPage(1);}}/><select className="select" disabled={busy} aria-label="Lọc SS trong lượt gửi" value={status} onChange={e=>{setStatus(e.target.value);setPage(1);}}><option value="">Mọi trạng thái</option><option value="ready">Có thể bắt đầu</option><option value="issues">SS lỗi / hạn chế</option><option value="active">Đang chạy</option><option value="paused">Tạm dừng</option><option value="stopped">Đã dừng</option></select></div>
  <div className="route-pick-tools"><label className="route-page-check"><input type="checkbox" aria-label="Chọn trang SS hiện tại" checked={allPage} disabled={busy||!shown.length} ref={el=>{if(el)el.indeterminate=!allPage&&shown.some(r=>selection.chosen.has(r.id));}} onChange={()=>allPage?selection.remove(shown.map(r=>r.id)):selection.add(shown)}/>Chọn trang này</label><button className="btn sm" disabled={busy||!filtered.length} onClick={()=>selection.add(filtered)}>Chọn kết quả lọc ({filtered.length})</button></div>
  <RouteBulkActions selected={selection.rows} isAdmin={isAdmin} onRefresh={live.reload} onRemove={selection.remove} onClear={selection.clear} onSaveCluster={onSaveCluster} onBusyChange={setBusy}/>
  {live.error&&<Alert tone="bad">{live.error.message}</Alert>}
  <div className="post-batch-list">{shown.map(r=><div className={`post-batch-row ${selection.chosen.has(r.id)?'route-picked':''}`} key={r.id}>
   <input type="checkbox" aria-label={`Chọn SS ${r.account_name??r.name}`} checked={selection.chosen.has(r.id)} disabled={busy} onChange={()=>selection.toggle(r)}/>
   <div className="post-batch-identity"><strong>{r.account_name}</strong><div className="hint">{r.link_config?.targets.length} nhóm · nghỉ {r.link_config?.delay_seconds}{r.link_config?.delay_max_seconds&&r.link_config.delay_max_seconds!==r.link_config.delay_seconds?`–${r.link_config.delay_max_seconds}`:''}s / nhóm</div><details><summary className="hint">Nhóm được giao</summary><div className="hint">{r.link_config?.targets.join(' · ')}</div></details></div>
   <Pill tone={r.verification_error||r.account_restriction||r.account_issue||r.link_config?.pause_reason?'bad':r.verified?'ok':'idle'}>{deliveryLabel(r)}</Pill><button className="btn sm" disabled={busy} onClick={()=>onDetail(r)}>Chi tiết SS</button>
  </div>)}</div>
  {live.loading&&<p className="hint">Đang tải phân công…</p>}
  {!live.loading&&!filtered.length&&<p className="hint">Không có SS phù hợp bộ lọc.</p>}
  <Pagination page={page} pageSize={50} total={filtered.length} onPage={setPage}/>
 </Modal>;
}
