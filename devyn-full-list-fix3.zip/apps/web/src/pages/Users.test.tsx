import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { UsersPage } from "./Users";
import { api } from "../api/client";
import { ToastProvider } from "../state/toast";

vi.mock("../api/client", async (orig) => ({
  ...await orig<typeof import("../api/client")>(),
  api: { get: vi.fn(), post: vi.fn() },
}));
vi.mock("../state/auth", () => ({ useAuth: () => ({ user: { id: "me", role: "admin" } }) }));

describe("create user password", () => {
  it("is visible and sends exact characters without retaining them after creation", async () => {
    vi.mocked(api.get).mockResolvedValue({ items: [], total: 0, page: 1, page_size: 20 });
    vi.mocked(api.post).mockResolvedValue({});
    const user = userEvent.setup();
    render(<ToastProvider><UsersPage /></ToastProvider>);
    await user.click(screen.getByRole("button", { name: "Thêm người dùng" }));
    const password = screen.getByLabelText("Mật khẩu ban đầu");
    expect(password).toHaveAttribute("type", "text");
    expect(password).toHaveAttribute("spellcheck", "false");
    const exactPassword = '  Đặc-Biệt-9&|^%!"\\$  ';
    await user.type(screen.getByLabelText("Tên đăng nhập"), "new-user");
    await user.type(password, exactPassword);
    expect(password).toHaveValue(exactPassword);
    await user.click(screen.getByRole("button", { name: "Tạo người dùng" }));
    await waitFor(() => expect(api.post).toHaveBeenCalledWith("/api/users", {
      username: "new-user", password: exactPassword, role: "operator",
    }));
    await waitFor(() => expect(screen.queryByLabelText("Mật khẩu ban đầu")).not.toBeInTheDocument());
  });
});
