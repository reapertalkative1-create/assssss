import {useState} from 'react';
import {api,request} from '../api/client';
import type {WorkCluster,ClusterMessageRun,Page} from '../api/types';
import {Modal} from '../components/Modal';
import {Alert,TextArea,TextField,Check,Pill} from '../components/ui';
import {useQuery} from '../hooks/useQuery';
import {fmtDateTime} from '../lib/format';

export function ClusterMessageDialog({id,onClose}:{id:string;onClose:()=>void}){
 const detail=useQuery(signal=>api.get<WorkCluster>(`/api/work-clusters/${id}`,undefined,signal),[id]);
 if(!detail.data)return <Modal title="Gửi tin nhắn" onClose={onClose}><p>{detail.error?.message??'Đang tải cấu hình…'}</p></Modal>;
 return <MessageForm cluster={detail.data} onClose={onClose}/>;
}
function MessageForm({cluster:c,onClose}:{cluster:WorkCluster;onClose:()=>void}){
 const base=`/api/work-clusters/${c.id}`;
 const [text,setText]=useState(c.message_text??''),[times,setTimes]=useState(c.message_schedule_times??[]),[time,setTime]=useState('09:00');
 const [enabled,setEnabled]=useState(c.message_schedule_enabled??false),[media,setMedia]=useState(c.message_media_type??null);
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const history=useQuery(signal=>api.get<Page<ClusterMessageRun>>(`${base}/message-runs`,{page_size:20},signal),[c.id],{interval:5000});
 const [requestId,setRequestId]=useState(()=>crypto.randomUUID());
 async function action(fn:()=>Promise<void>){setBusy(true);setError('');setNotice('');try{await fn();}catch(e){setError(e instanceof Error?e.message:'Thao tác thất bại.');}finally{setBusy(false);history.reload();}}
 async function save(scheduleEnabled=enabled){await api.put(`${base}/message`,{text,schedule_times:times,timezone:'Asia/Ho_Chi_Minh',schedule_enabled:scheduleEnabled});}
 return <Modal wide title={`Gửi tin nhắn · ${c.name}`} onClose={onClose} footer={<>{c.loop_active&&<button className="btn danger" disabled={busy} onClick={()=>void action(async()=>{await api.post(`${base}/loop/stop`);setNotice('Đã dừng vòng lặp và hủy các lệnh chờ. Tin đang gửi có thể hoàn tất.');})}>Dừng vòng lặp</button>}<button className="btn" onClick={onClose}>Đóng</button><button className="btn" disabled={busy} onClick={()=>void action(async()=>{await save();setNotice('Đã lưu nội dung và lịch gửi.');})}>Lưu nội dung & lịch</button><button className="btn primary" disabled={busy} onClick={()=>void action(async()=>{await save();await api.post(`${base}/message-runs`,{request_id:requestId});setRequestId(crypto.randomUUID());setNotice('Đã tạo lượt gửi. Có thể đóng bảng; theo dõi kết quả bên dưới.');})}>Gửi ngay</button></>}>
  <div className="stack">
   <p className="hint">{c.account_count} SS · {c.target_count} nhóm · nghỉ ngẫu nhiên {c.delay_seconds}–{c.delay_max_seconds??c.delay_seconds}s. Mỗi lượt xáo trộn nhóm một lần, không tự tham gia nhóm.</p>
   {c.message_loop_enabled&&<div className="cluster-loop-status"><Pill tone={c.loop_active?'ok':'idle'}>{c.loop_active?'Vòng lặp đang chạy — hệ thống tự tạo lượt mới khi xong':'Vòng lặp đã bật — bấm Gửi ngay để bắt đầu'}</Pill></div>}
   <TextArea label="Nội dung / chú thích" value={text} onChange={e=>setText(e.target.value)} rows={5} maxLength={media?1024:4096} placeholder="Nhập nội dung và emoji…"/>
   <div className="row" aria-label="Chèn emoji">{['😀','❤️','👍','🔥','🎉','✅','📣'].map(emoji=><button key={emoji} className="btn sm" disabled={busy} onClick={()=>setText(t=>t+emoji)}>{emoji}</button>)}</div>
   <p className="hint">Emoji thường được giữ nguyên. Emoji Premium cần ID custom-emoji và quyền Telegram tương ứng; bản này chưa có bộ chọn emoji Premium.</p>
   <label className="stack tight">Ảnh hoặc video (tối đa 20 MB)<input aria-label="Ảnh hoặc video" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime" disabled={busy} onChange={e=>{const file=e.target.files?.[0];if(!file)return;void action(async()=>{const r=await api.upload<{media_type:'photo'|'video'}>(`${base}/message-media`,file);setMedia(r.media_type);setNotice('Đã tải media. Bấm Lưu để lưu chú thích.');});e.target.value='';}}/></label>
   {media&&<div className="row"><span>Đã chọn {media==='photo'?'ảnh':'video'}</span><button className="btn sm danger" disabled={busy} onClick={()=>void action(async()=>{await request('DELETE',`${base}/message-media`);setMedia(null);})}>Bỏ media</button></div>}
   <h3>Lịch gửi hằng ngày</h3><p className="hint">Giờ Việt Nam (Asia/Ho_Chi_Minh). Máy chủ và worker phải đang chạy. Không gửi bù các mốc giờ đã bỏ lỡ.</p>
   <div className="row"><TextField label="Giờ gửi" type="time" value={time} onChange={e=>setTime(e.target.value)}/><button className="btn" disabled={busy||!time||times.length>=12||times.includes(time)} onClick={()=>setTimes(t=>[...t,time].sort())}>Thêm giờ</button></div>
   <div className="row">{times.map(t=><button className="btn sm" key={t} disabled={busy} onClick={()=>setTimes(values=>values.filter(x=>x!==t))} aria-label={`Bỏ giờ ${t}`}>{t} ×</button>)}</div>
   <Check label="Bật lịch gửi nhiều lần trong ngày" checked={enabled} onChange={e=>setEnabled(e.target.checked)}/>
   <button className="btn" disabled={busy} onClick={()=>void action(async()=>{await save(false);setEnabled(false);setNotice('Đã tắt lịch. Các lượt đã tạo vẫn có thể tiếp tục; bấm Dừng lượt nếu cần.');})}>Tắt lịch gửi</button>
   {notice&&<p role="status">{notice}</p>}{error&&<Alert tone="bad">{error}</Alert>}
   <div className="row"><h3>Tình trạng gửi tin nhắn</h3><button className="btn sm" onClick={history.reload}>Kiểm tra tình trạng</button></div>
   <p className="hint">Đóng bảng không dừng công việc. Dừng lượt chỉ hủy các lệnh chưa nhận; tin đang gửi có thể hoàn tất.</p>
   {history.error&&<Alert tone="bad">{history.error.message}</Alert>}
   {!history.data?.items.length&&<p>Chưa có lượt gửi tin nhắn.</p>}
   {history.data?.items.map(run=><div className="stack tight" key={run.id}><div className="row"><strong>{fmtDateTime(run.created_at)}</strong><span>{({'queued':'Đang chờ','running':'Đang chạy','paused':'Tạm dừng','stopped':'Đã dừng','completed':'Hoàn tất','completed_with_errors':'Hoàn tất có lỗi'} as Record<string,string>)[run.status]??run.status} · {run.completed_commands}/{run.total_commands}{run.loop_pass&&run.loop_pass>1?` · vòng ${run.loop_pass}`:''}</span>{['queued','running'].includes(run.status)&&<button className="btn sm danger" disabled={busy} onClick={()=>void action(async()=>{await api.post(`${base}/message-runs/${run.id}/stop`);})}>Dừng lượt</button>}</div>
    {!!run.outcomes.length&&<details><summary>Kết quả từng nhóm</summary>{run.outcomes.map((o,i)=><p key={i}>{o.ref||'Nhóm nhận'} · {o.status==='done'?'Đã gửi':o.error_code??o.status}</p>)}</details>}
   </div>)}
  </div>
 </Modal>;
}
