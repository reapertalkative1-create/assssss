"""Reusable sender/target configurations, separate from individual deliveries."""
import uuid
from datetime import datetime
from sqlalchemy import Boolean, JSON, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
from app.types import UTCDateTime, utcnow


class WorkCluster(Base):
    __tablename__ = 'work_clusters'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)
    cluster_type: Mapped[str] = mapped_column(String(16), default='forward', server_default='forward')
    account_ids: Mapped[list] = mapped_column(JSON)
    targets: Mapped[list] = mapped_column(JSON)
    mode: Mapped[str] = mapped_column(String(8), default='forward')
    delay_seconds: Mapped[int] = mapped_column(Integer, default=150)
    delay_max_seconds: Mapped[int] = mapped_column(Integer, default=180)
    post_link: Mapped[str | None] = mapped_column(String(500), nullable=True)
    message_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    message_media_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    message_media_type: Mapped[str | None] = mapped_column(String(8), nullable=True)
    message_schedule_times: Mapped[list | None] = mapped_column(JSON, default=list, nullable=True)
    message_schedule_timezone: Mapped[str] = mapped_column(String(64), default="Asia/Ho_Chi_Minh")
    message_schedule_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    message_loop_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    loop_active: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    loop_block_reason: Mapped[str | None] = mapped_column(String(32), nullable=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class ClusterMessageRun(Base):
    __tablename__ = 'cluster_message_runs'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    cluster_id: Mapped[uuid.UUID] = mapped_column(nullable=False, index=True)
    slot_key: Mapped[str] = mapped_column(String(80), unique=True)
    scheduled_for: Mapped[datetime] = mapped_column(UTCDateTime)
    status: Mapped[str] = mapped_column(String(32), default='queued')
    total_commands: Mapped[int] = mapped_column(Integer, default=0)
    completed_commands: Mapped[int] = mapped_column(Integer, default=0)
    current_cycle: Mapped[int] = mapped_column(Integer, default=1)
    current_pass: Mapped[int] = mapped_column(Integer, default=0)
    loop_session_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
    loop_pass: Mapped[int] = mapped_column(Integer, default=1)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
