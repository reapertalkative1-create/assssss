"""API entrypoint. The API only orchestrates; Telegram work happens in workers."""
import asyncio
import logging
import re
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from sqlalchemy import select
from fastapi.middleware.cors import CORSMiddleware

from app import __version__
from app.config import Settings, get_settings
from app.crypto import build_secret_box
from app.db import make_engine, make_sessionmaker
from app.errors import register_error_handlers
from app.logging_config import request_id_var, setup_logging
from app.ratelimit import SlidingWindowLimiter
from app.routers import (
    work_clusters, account_groups, post_routes, proxy_checks, settings as settings_router, account_proxy, account_appeals, account_spam, account_bulk, accounts, audit, auth, dashboard, health, jobs, routes, users, worker_accounts, worker_api, worker_jobs, workers, ws,
)
from app.services.accounts import expire_commands
from app.services.jobs import recover_abandoned
from app.services.workers import mark_stale_offline
from app.types import utcnow

_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
access_log = logging.getLogger("tfcc.access")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    settings.assert_production_ready()
    setup_logging(settings.env)
    logging.getLogger("aiosqlite").setLevel(logging.WARNING)

    secret_box = build_secret_box(settings.session_encryption_key.get_secret_value(), settings.session_encryption_key_file)
    engine = make_engine(settings.database_url)

    sessionmaker = make_sessionmaker(engine)

    async def sweeper() -> None:
        """Marks workers offline when their heartbeat expires (status is also computed at read time)."""
        while True:
            await asyncio.sleep(settings.worker_sweep_interval_seconds)
            try:
                async with sessionmaker() as db:
                    now = utcnow()
                    await mark_stale_offline(db, now, settings.heartbeat_timeout_seconds)
                    await expire_commands(db, now)  # also wipes any undelivered OTP/password payloads
                    await recover_abandoned(db, now, settings)  # jobs whose worker vanished
                    await db.commit()
            except Exception:
                logging.getLogger("tfcc.sweeper").exception("sweep_failed")

    async def bulk_scheduler():
        from app.services.account_bulk import tick
        while True:
            try:
                async with sessionmaker() as db:
                    await expire_commands(db,utcnow())
                    await tick(db,settings,secret_box)
                    from app.models import WorkCluster
                    from app.routers.work_clusters import create_message_run, continue_loop_sessions
                    from zoneinfo import ZoneInfo
                    clusters = (await db.execute(select(WorkCluster).where(WorkCluster.message_schedule_enabled.is_(True)))).scalars().all()
                    now = utcnow()
                    for cluster in clusters:
                        try:
                            local = now.astimezone(ZoneInfo(cluster.message_schedule_timezone))
                        except Exception:
                            continue
                        slot = local.strftime('%H:%M')
                        if slot not in (cluster.message_schedule_times or []):
                            continue
                        slot_key = f'{cluster.id}:{local:%Y-%m-%d}:{slot}'
                        try:
                            async with db.begin_nested():
                                await create_message_run(db, settings, secret_box, cluster, cluster.created_by, slot_key, now)
                        except Exception as exc:
                            logging.getLogger('tfcc.cluster_messages').warning('scheduled_message_skipped', extra={'cluster_id': str(cluster.id), 'error': type(exc).__name__})
                    # Randomised loop: keep starting the next pass until the operator stops the cluster.
                    try:
                        await continue_loop_sessions(db, settings, secret_box, now)
                    except Exception:
                        logging.getLogger('tfcc.cluster_messages').exception('loop_continue_failed')
                    try:
                        from app.services.forward_loops import continue_forward_loops
                        await continue_forward_loops(db, settings, now)
                    except Exception:
                        logging.getLogger('tfcc.forward_loops').exception('forward_loop_continue_failed')
                    await db.commit()
            except Exception:
                logging.getLogger('tfcc.bulk').error('bulk_tick_failed')
            await asyncio.sleep(1)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        from app.services.spam import restore_blocked_statuses
        from sqlalchemy.exc import SQLAlchemyError
        try:await restore_blocked_statuses(sessionmaker,secret_box)
        except SQLAlchemyError:logging.getLogger('tfcc.accounts').error('blocked_history_refresh_failed')
        task = asyncio.create_task(sweeper()) if settings.worker_sweep_interval_seconds > 0 else None
        bulk_task=asyncio.create_task(bulk_scheduler()) if settings.worker_sweep_interval_seconds > 0 else None
        try:
            yield
        finally:
            if task:
                task.cancel()
            if bulk_task:
                bulk_task.cancel()
                await asyncio.gather(bulk_task,return_exceptions=True)
            await engine.dispose()

    prod = settings.env == "production"
    app = FastAPI(
        title="Telegram Forwarder Control Center",
        version=__version__,
        lifespan=lifespan,
        docs_url=None if prod else "/docs",
        redoc_url=None,
        openapi_url=None if prod else "/openapi.json",
    )
    app.state.settings = settings
    app.state.engine = engine
    app.state.secret_box = secret_box  # None => account/session features answer 503
    app.state.sessionmaker = sessionmaker
    app.state.login_limiter = SlidingWindowLimiter(settings.login_ip_max_attempts, settings.login_ip_window_seconds)

    app.state.worker_auth_limiter = SlidingWindowLimiter(settings.worker_auth_ip_max_attempts, settings.login_ip_window_seconds)

    register_error_handlers(app)

    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
            allow_headers=["Content-Type", "X-CSRF-Token"],
        )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        incoming = request.headers.get("x-request-id", "")
        rid = incoming if _REQUEST_ID_RE.fullmatch(incoming) else uuid.uuid4().hex
        request.state.request_id = rid
        token = request_id_var.set(rid)
        started = time.perf_counter()
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
            response.headers["X-Request-ID"] = rid
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["Referrer-Policy"] = "no-referrer"
            if request.url.path.startswith("/api/"):
                response.headers["Cache-Control"] = "no-store"
            return response
        finally:
            access_log.info(
                "request",
                extra={"method": request.method, "path": request.url.path, "status": status,
                       "duration_ms": round((time.perf_counter() - started) * 1000, 1)},
            )
            request_id_var.reset(token)

    app.include_router(health.router)
    app.include_router(settings_router.router)
    app.include_router(proxy_checks.router)
    app.include_router(proxy_checks.worker_router)
    app.include_router(auth.router)
    app.include_router(users.router)
    app.include_router(audit.router)
    app.include_router(workers.router)
    app.include_router(worker_api.router)
    app.include_router(account_proxy.router)
    app.include_router(account_appeals.router)
    app.include_router(account_spam.router)
    app.include_router(account_groups.router)
    app.include_router(account_bulk.router)
    app.include_router(accounts.router)
    app.include_router(worker_accounts.router)
    app.include_router(routes.router)
    app.include_router(post_routes.router)
    app.include_router(work_clusters.router)
    app.include_router(jobs.router)
    app.include_router(jobs.queue_router)
    app.include_router(worker_jobs.router)
    app.include_router(dashboard.router)
    app.include_router(ws.router)
    return app


app = create_app()
