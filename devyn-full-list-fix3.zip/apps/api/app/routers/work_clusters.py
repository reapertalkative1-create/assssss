"""Named configurations and explicit, immutable snapshots for each new post."""
import logging
import uuid
import random
import re
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from typing import Literal
from fastapi import APIRouter, Depends, Query, Request, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import case, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import (ClusterMessageRun, ForwardJob, ForwardRoute, Role, TelegramAccount, Worker, WorkerCommand, WorkCluster)
from app.routers.post_routes import PostBatchInput, batch_routes, save_batch
from app.routers.routes import _out
from app.services.post_links import parse_post_link, parse_targets
from app.services import accounts as acct_svc
from app.services import workers as worker_svc
from app.types import utcnow

router = APIRouter(prefix='/api/work-clusters', tags=['work-clusters'])
admin = require_role(Role.ADMIN)


class ClusterInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=64)
    account_ids: list[uuid.UUID] = Field(min_length=1, max_length=1000)
    targets_text: str = Field(min_length=1, max_length=500000)
    delay_seconds: int = Field(default=150, ge=5, le=86400)
    delay_max_seconds: int | None = Field(default=None, ge=5, le=86400)
    post_link: str | None = Field(default=None, max_length=500)
    cluster_type: Literal['forward', 'message'] = 'forward'
    message_loop_enabled: bool = False

    @model_validator(mode='after')
    def valid_interval(self):
        if self.delay_max_seconds is None:
            self.delay_max_seconds = self.delay_seconds if 'delay_seconds' in self.model_fields_set else 180
        if self.delay_max_seconds < self.delay_seconds:
            raise ValueError('Mốc nghỉ đến phải lớn hơn hoặc bằng mốc từ.')
        return self
    mode: Literal['forward', 'copy'] = 'forward'

    @field_validator('name')
    @classmethod
    def clean_name(cls, value):
        value = ' '.join(value.split())
        if not value or len(value.casefold()) > 64:
            raise ValueError('Nhập tên cụm từ 1 đến 64 ký tự.')
        return value


class ClusterCreate(ClusterInput):
    request_id: uuid.UUID


class ClusterUpdate(ClusterInput):
    revision: int = Field(ge=1)


class ClusterRun(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: uuid.UUID
    revision: int = Field(ge=1)
    post_link: str | None = Field(default=None, max_length=500)



class ClusterMessageInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    text: str = Field(default='', max_length=4096)
    schedule_times: list[str] = Field(default_factory=list, max_length=12)
    timezone: str = Field(default='Asia/Ho_Chi_Minh', max_length=64)
    schedule_enabled: bool = False
    loop_enabled: bool = False
    
    @field_validator('schedule_times')
    @classmethod
    def validate_times(cls, values):
        if len(set(values)) != len(values) or any(not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', x) for x in values):
            raise ValueError('Giờ gửi phải là các mốc HH:MM khác nhau.')
        return sorted(values)

    @field_validator('timezone')
    @classmethod
    def validate_timezone(cls, value):
        try: ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError): raise ValueError('Múi giờ không hợp lệ.') from None
        return value


class MessageRunInput(BaseModel):
    request_id: uuid.UUID

class RoutesPreview(BaseModel):
    model_config = ConfigDict(extra='forbid')
    route_ids: list[uuid.UUID] = Field(min_length=1, max_length=10000)


@router.post('/from-routes/preview')
async def preview_routes(body: RoutesPreview, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    import hashlib
    ids = set(body.route_ids)
    rows = list((await db.execute(select(ForwardRoute).where(ForwardRoute.id.in_(ids)).order_by(ForwardRoute.id))).scalars())
    if len(rows) != len(ids):
        raise ApiError(409, 'routes_changed', 'Có dòng đã bị xóa. Chọn lại danh sách trước khi lưu thành cụm.')
    if any(not row.link_config for row in rows):
        raise ApiError(422, 'post_routes_only', 'Chỉ chọn các lượt gửi bài từ liên kết để tạo cụm. Bỏ chọn tuyến theo dõi nguồn.')
    account_ids = list(dict.fromkeys(str(row.account_id) for row in rows))
    if len(account_ids) > 1000:
        raise ApiError(422, 'too_many_senders', 'Một cụm tối đa 1.000 SS. Chọn ít SS hơn để tạo cụm.')
    refs = []
    seen = set()
    for row in rows:
        for ref in row.link_config.get('targets', []):
            if ref not in seen:
                seen.add(ref); refs.append(ref)
                if len(refs) > 1000:
                    raise ApiError(422, 'too_many_targets', 'Một cụm tối đa 1.000 nhóm nhận. Thu hẹp lựa chọn trước khi tạo cụm.')
    targets = parse_targets('\n'.join(refs))
    accounts = dict((await db.execute(select(TelegramAccount.id, TelegramAccount.name).where(
        TelegramAccount.id.in_([uuid.UUID(a) for a in account_ids]), TelegramAccount.pending_deletion.is_(False)))).all())
    if len(accounts) != len(account_ids):
        raise ApiError(409, 'senders_changed', 'Có SS đã/đang bị xóa. Bỏ chọn dòng của SS đó trước khi tạo cụm.')
    modes = {row.mode for row in rows}
    delays = {row.link_config.get('delay_seconds', 60) for row in rows}
    key = hashlib.sha256('|'.join(f'{r.id}:{r.updated_at.isoformat()}' for r in rows).encode()).hexdigest()[:24]
    return {'seed_key': key, 'name': '', 'senders': [{'id': aid, 'name': accounts[uuid.UUID(aid)]} for aid in account_ids],
            'targets': targets, 'mode': next(iter(modes)) if len(modes) == 1 else 'forward',
            'delay_seconds': max(delays), 'mixed_settings': len(modes) > 1 or len(delays) > 1}


async def require_cluster(db, cid, *, lock=False):
    stmt = select(WorkCluster).where(WorkCluster.id == cid)
    if lock: stmt = stmt.with_for_update()
    obj = (await db.execute(stmt)).scalar_one_or_none()
    if obj is None:
        raise ApiError(404, 'not_found', 'Không tìm thấy cụm làm việc.')
    return obj


def summary(obj, live=None):
    """Card-sized view of a cluster. `live` carries the run state painted on the card."""
    return {'id': str(obj.id), 'name': obj.name, 'cluster_type': obj.cluster_type, 'account_count': len(obj.account_ids),
            'target_count': len(obj.targets), 'mode': obj.mode, 'delay_seconds': obj.delay_seconds,
            'delay_max_seconds': obj.delay_max_seconds, 'post_link': obj.post_link, 'message_text': obj.message_text, 'message_media_id': obj.message_media_id,
            'message_media_type': obj.message_media_type, 'message_schedule_times': obj.message_schedule_times or [],
            'message_schedule_timezone': obj.message_schedule_timezone, 'message_schedule_enabled': obj.message_schedule_enabled, 'message_loop_enabled': obj.message_loop_enabled, 'loop_active': getattr(obj, 'loop_active', False),
            'loop_block_reason': getattr(obj, 'loop_block_reason', None),
            'revision': obj.revision, 'created_at': obj.created_at, 'updated_at': obj.updated_at, **(live or EMPTY_LIVE)}


EMPTY_LIVE = {'run_status': None, 'running': False, 'run_id': None, 'batch_id': None,
              'completed_count': 0, 'total_count': 0, 'done_count': 0, 'error_count': 0,
              'loop_pass': None, 'run_started_at': None, 'last_run_at': None, 'outcomes': [],
              'loop_wait_until': None}
OUTCOME_LIMIT = 30


def _live_message_run(run, running: bool):
    outcomes = list((run.result or {}).get('outcomes', []))[-OUTCOME_LIMIT:]
    return {'run_status': run.status, 'running': running, 'run_id': str(run.id),
            'completed_count': run.completed_commands, 'total_count': run.total_commands,
            'done_count': sum(1 for o in outcomes if o.get('status') == 'done'),
            'error_count': sum(1 for o in outcomes if o.get('status') not in ('done', 'delivered')),
            'loop_pass': run.loop_pass, 'run_started_at': run.scheduled_for,
            'last_run_at': run.created_at, 'outcomes': outcomes}


async def live_states(db, clusters):
    """Latest run of every cluster on the page, plus the per-group outcomes so the card can show them."""
    ids = [c.id for c in clusters]
    if not ids:
        return {}
    live = {cid: dict(EMPTY_LIVE) for cid in ids}
    message_ids = [c.id for c in clusters if c.cluster_type == 'message']
    if message_ids:
        ranked = select(ClusterMessageRun.cluster_id,
                        func.row_number().over(partition_by=ClusterMessageRun.cluster_id,
                                               order_by=(ClusterMessageRun.created_at.desc(), ClusterMessageRun.id)).label('rn'),
                        ClusterMessageRun.id.label('run_id'), ClusterMessageRun.status,
                        ClusterMessageRun.total_commands, ClusterMessageRun.completed_commands,
                        ClusterMessageRun.loop_pass, ClusterMessageRun.scheduled_for,
                        ClusterMessageRun.created_at.label('run_created'), ClusterMessageRun.result).where(
            ClusterMessageRun.cluster_id.in_(message_ids)).subquery()
        rows = (await db.execute(select(ranked).where(ranked.c.rn == 1))).mappings().all()
        for row in rows:
            status, result, completed = row['status'], row['result'], row['completed_commands']
            if status in ('queued', 'running'):
                run = await db.get(ClusterMessageRun, row['run_id'], populate_existing=True)
                if run is not None:
                    await refresh_message_run(db, run)
                    status, result, completed = run.status, run.result, run.completed_commands
            outcomes = list((result or {}).get('outcomes', []))[-OUTCOME_LIMIT:]
            live[row['cluster_id']].update({
                'run_status': status, 'running': status in ('queued', 'running'),
                'run_id': str(row['run_id']), 'completed_count': completed,
                'total_count': row['total_commands'],
                'done_count': sum(1 for o in outcomes if o.get('status') == 'done'),
                'error_count': sum(1 for o in outcomes if o.get('status') not in ('done', 'delivered')),
                'loop_pass': row['loop_pass'], 'run_started_at': row['scheduled_for'],
                'last_run_at': row['run_created'], 'outcomes': outcomes})
    forward_ids = [c.id for c in clusters if c.cluster_type != 'message']
    if forward_ids:
        config = ForwardRoute.link_config
        cid_col = config['work_cluster_id'].as_string()
        batch_col = config['batch_id'].as_string()
        batches = (await db.execute(select(cid_col.label('cluster_id'), batch_col.label('batch_id'),
                                          func.max(case((config['loop_enabled'].as_boolean().is_(True), 1), else_=0)).label('loop_enabled'),
                                          func.max(ForwardRoute.created_at).label('created_at')).where(
            cid_col.in_([str(cid) for cid in forward_ids]), batch_col.is_not(None)).group_by(
            cid_col, batch_col))).mappings().all()
        latest_batch: dict = {}
        active_loop_ids = {str(c.id) for c in clusters if c.cluster_type == 'forward' and c.loop_active}
        for row in batches:
            current = latest_batch.get(row['cluster_id'])
            def rank(batch):
                return (batch['loop_enabled'] if row['cluster_id'] in active_loop_ids else 0, batch['created_at'])
            if current is None or rank(row) > rank(current):
                latest_batch[row['cluster_id']] = dict(row)
        by_key = {str(cid): cid for cid in live}
        for cluster_key, head in latest_batch.items():
            cluster_id = by_key.get(str(cluster_key))
            if cluster_id is None:
                continue
            cluster_id = str(cluster_key)
            routes = (await db.execute(select(ForwardRoute).where(
                batch_col == head['batch_id'], cid_col == str(cluster_key)))).scalars().all()
            if not routes:
                continue
            route_ids = [r.id for r in routes]
            # Each loop pass has fresh jobs. Paint the latest attempt for each
            # target, rather than letting an old failure hide later successes.
            latest_jobs = select(ForwardJob.route_id, ForwardJob.dest_chat_id, ForwardJob.status,
                ForwardJob.last_error_code, func.row_number().over(
                    partition_by=(ForwardJob.route_id, ForwardJob.dest_chat_id),
                    order_by=(ForwardJob.created_at.desc(), ForwardJob.id.desc())).label('rn')
                ).where(ForwardJob.route_id.in_(route_ids)).subquery()
            rows = (await db.execute(select(latest_jobs.c.route_id, latest_jobs.c.dest_chat_id,
                latest_jobs.c.status, latest_jobs.c.last_error_code, func.count()).where(
                latest_jobs.c.rn == 1).group_by(latest_jobs.c.route_id, latest_jobs.c.dest_chat_id,
                latest_jobs.c.status, latest_jobs.c.last_error_code))).all()
            by_route: dict = {}
            for route_id, dest_id, status, error_code, count in rows:
                by_route.setdefault(route_id, {}).setdefault(dest_id, []).append((status, error_code, count))
            groups: dict = {}
            per_sender = any((r.link_config or {}).get('target_strategy') == 'per_sender_all' for r in routes)
            sender_names = dict((await db.execute(select(TelegramAccount.id, TelegramAccount.name).where(
                TelegramAccount.id.in_([r.account_id for r in routes])))).all()) if per_sender else {}
            for route in routes:
                config_data = route.link_config or {}
                def group_key(ref):
                    return (str(route.account_id), ref) if per_sender else ref
                sender = {'account_id': str(route.account_id), 'account_name': sender_names.get(route.account_id)} if per_sender else {}
                checks, refs = config_data.get('checks') or [], config_data.get('targets') or []
                # Targets refs that had no numeric id offline were queued under a pseudo-id;
                # map them back so the card shows the group the user typed, not -2157930728.
                peers = config_data.get('dest_peers') or {}
                mapped_refs = {str(dst): peers.get(str(dst), str(dst)) for dst in route.destination_chat_ids}
                for check in checks:
                    index = check.get('index')
                    if check.get('id') is not None and isinstance(index, int) and 0 <= index < len(refs):
                        mapped_refs[str(check['id'])] = refs[index]
                duplicates = {str(dst) for dst in config_data.get('duplicate_targets', [])}
                for dst in duplicates:
                    ref = mapped_refs.get(dst, dst)
                    groups.setdefault(group_key(ref), {**sender, 'ref': ref, 'title': None, 'statuses': {'skipped': 1},
                                            'error': 'duplicate_post', 'message': None})
                # A failed start or an unstarted draft has targets even when no job exists yet.
                represented = {mapped_refs.get(str(dst), str(dst)) for dst in by_route.get(route.id, {})}
                represented.update(mapped_refs.get(dst, dst) for dst in duplicates)
                for ref in refs:
                    if ref in represented:
                        continue
                    code = config_data.get('start_error_code')
                    groups.setdefault(group_key(ref), {**sender, 'ref': ref, 'title': None,
                                            'statuses': {'blocked' if code else 'not_started': 1},
                                            'error': code, 'message': config_data.get('start_error_message')})
                dest_ids = {c.get('id') for c in checks if c.get('id') is not None}
                for dest_id, entries in by_route.get(route.id, {}).items():
                    check = next((c for c in checks if c.get('id') == dest_id), None)
                    if check is None and dest_ids:
                        continue
                    index = check.get('index') if check else None
                    ref = refs[index] if isinstance(index, int) and index < len(refs) else (
                        peers.get(str(dest_id)) or str(dest_id))
                    entry = groups.setdefault(group_key(ref), {**sender, 'ref': ref, 'title': (check or {}).get('title'),
                                                    'statuses': {}, 'error': None, 'message': None})
                    for status, error_code, count in entries:
                        entry['statuses'][status] = entry['statuses'].get(status, 0) + count
                        if error_code and not entry['error']:
                            entry['error'] = error_code
            outcomes = []
            for ref, entry in groups.items():
                statuses = entry['statuses']
                if any(statuses.get(s) for s in ('pending', 'claimed', 'running', 'retry_wait')):
                    status = 'pending'
                elif statuses.get('failed') or statuses.get('dead_letter'):
                    status = 'failed'
                elif statuses.get('cancelled'):
                    status = 'stopped'
                elif statuses.get('blocked'):
                    status = 'blocked'
                elif statuses.get('not_started'):
                    status = 'not_started'
                elif statuses.get('skipped'):
                    status = 'skipped'
                else:
                    status = 'done'
                outcomes.append({'ref': entry['ref'], 'title': entry['title'], 'status': status,
                                 **({'account_id': entry['account_id'], 'account_name': entry.get('account_name')} if per_sender else {}),
                                 'error_code': entry['error'] if status in ('failed', 'blocked', 'skipped') else None,
                                 'error_message': entry.get('message')})
            running = any(o['status'] == 'pending' for o in outcomes)
            failed = sum(1 for o in outcomes if o['status'] in ('failed', 'blocked'))
            if running:
                run_status = 'running'
            elif any(o['status'] == 'blocked' for o in outcomes):
                run_status = 'blocked'
            elif failed:
                run_status = 'completed_with_errors'
            elif any(o['status'] == 'stopped' for o in outcomes):
                run_status = 'stopped'
            elif not outcomes or any(o['status'] == 'not_started' for o in outcomes):
                run_status = 'not_started'
            elif all(o['status'] == 'skipped' for o in outcomes):
                run_status = 'skipped'
            else:
                run_status = 'completed'
            loop_batch = any((r.link_config or {}).get('forward_loop') for r in routes)
            loop_on = loop_batch and any(c.id == by_key[str(cluster_key)] and c.loop_active for c in clusters)
            if loop_batch and not loop_on:
                running, run_status = False, 'stopped'
            live[by_key[str(cluster_key)]].update({
                'run_status': run_status, 'running': running, 'batch_id': head['batch_id'],
                'loop_pass': max((r.link_config or {}).get('loop_pass', 1) for r in routes) if loop_batch else None,
                'run_started_at': head['created_at'], 'last_run_at': head['created_at'],
                'progress_unit': 'deliveries' if per_sender else 'groups',
                'total_count': len(outcomes),
                'completed_count': sum(1 for o in outcomes if o['status'] in ('done', 'failed', 'stopped', 'skipped')),
                'done_count': sum(1 for o in outcomes if o['status'] == 'done'),
                'error_count': failed, 'outcomes': outcomes[-OUTCOME_LIMIT:]})
    # Loop clusters that are between passes explain themselves: waiting on a Telegram flood
    # wait shows the deadline, a hard stop shows why the loop switched off.
    loops = [c for c in clusters if getattr(c, 'loop_active', False) and c.cluster_type == 'message']
    if loops:
        from app.config import get_settings
        try:
            readiness = await loop_readiness(db, loops, get_settings())
        except Exception:
            readiness = {}
        for cluster in loops:
            state = readiness.get(cluster.id) or {}
            if state.get('wait_until'):
                live[cluster.id]['loop_wait_until'] = state['wait_until']
    return live


async def detail(db, obj, live=None):
    rows = (await db.execute(select(TelegramAccount.id, TelegramAccount.name).where(
        TelegramAccount.id.in_([uuid.UUID(v) for v in obj.account_ids]),
        TelegramAccount.pending_deletion.is_(False)))).all()
    names = {str(aid): name for aid, name in rows}
    missing = [aid for aid in obj.account_ids if aid not in names]
    return {**summary(obj, live), 'account_ids': obj.account_ids, 'targets': obj.targets,
            'senders': [{'id': aid, 'name': names.get(aid, 'SS đã xóa · ' + aid[:8])} for aid in obj.account_ids],
            'missing_account_ids': missing}


async def values(db, body):
    targets = parse_targets(body.targets_text, max_refs=10000)
    ids = list(dict.fromkeys(body.account_ids))
    count = (await db.execute(select(func.count()).select_from(TelegramAccount).where(
        TelegramAccount.id.in_(ids), TelegramAccount.pending_deletion.is_(False)))).scalar_one()
    if count != len(ids):
        raise ApiError(409, 'senders_changed', 'Có SS đã bị xóa hoặc đang xóa. Bỏ SS đó khỏi cụm rồi lưu lại.')
    data = {'name': body.name, 'name_key': body.name.casefold(), 'account_ids': [str(v) for v in ids],
            'targets': targets, 'mode': body.mode, 'delay_seconds': body.delay_seconds,
            'delay_max_seconds': body.delay_max_seconds, 'cluster_type': body.cluster_type, 'message_loop_enabled': body.message_loop_enabled}
    if 'post_link' in body.model_fields_set:
        try: data['post_link'] = parse_post_link(body.post_link)['url'] if body.post_link and body.post_link.strip() else None
        except ValueError as exc: raise ApiError(422, 'invalid_post_link', str(exc)) from None
    return data


async def flush(db):
    try: await db.flush()
    except IntegrityError:
        raise ApiError(409, 'name_taken', 'Tên cụm đã tồn tại hoặc yêu cầu đang được lưu. Đổi tên hoặc thử lại.') from None


@router.get('')
async def listing(q: str = Query('', max_length=64), kind: Literal['forward', 'message'] | None = Query(None), page: int = Query(1, ge=1), page_size: int = Query(12, ge=1, le=50),
                  auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    stmt = select(WorkCluster)
    if q.strip(): stmt = stmt.where(WorkCluster.name_key.contains(q.strip().casefold(), autoescape=True))
    if kind: stmt = stmt.where(WorkCluster.cluster_type == kind)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = list((await db.execute(stmt.order_by(WorkCluster.updated_at.desc(), WorkCluster.id)
                                 .offset((page-1)*page_size).limit(page_size))).scalars())
    live = await live_states(db, rows)
    return {'items': [summary(row, live.get(row.id)) for row in rows], 'total': total, 'page': page, 'page_size': page_size}


@router.get('/{cid}')
async def get(cid: uuid.UUID, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid)
    live = await live_states(db, [obj])
    return await detail(db, obj, live.get(obj.id))


@router.post('', status_code=201)
async def create(body: ClusterCreate, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    data = await values(db, body)
    existing = await db.get(WorkCluster, body.request_id)
    if existing:
        if existing.created_by != auth.user.id or any(getattr(existing, k) != v for k, v in data.items()):
            raise ApiError(409, 'request_conflict', 'Yêu cầu này đã lưu với nội dung khác. Mở lại biểu mẫu để tiếp tục.')
        return await detail(db, existing)
    obj = WorkCluster(id=body.request_id, created_by=auth.user.id, **data)
    db.add(obj)
    await flush(db)
    await record_audit(db, request, 'work_cluster.create', actor=auth.user, target_type='work_cluster', target_id=str(obj.id),
                       details={'accounts': len(obj.account_ids), 'targets': len(obj.targets)})
    return await detail(db, obj)


@router.patch('/{cid}')
async def update(cid: uuid.UUID, body: ClusterUpdate, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    if body.cluster_type != obj.cluster_type:
        raise ApiError(409, 'cluster_type_immutable', 'Không đổi loại cụm đã lưu. Hãy tạo cụm mới.')
    if obj.revision != body.revision:
        raise ApiError(409, 'cluster_changed', 'Cụm đã được sửa ở cửa sổ khác. Đóng và mở lại để lấy cấu hình mới.')
    for key, value in (await values(db, body)).items(): setattr(obj, key, value)
    obj.revision += 1
    await flush(db)
    await record_audit(db, request, 'work_cluster.update', actor=auth.user, target_type='work_cluster', target_id=str(cid), details={'revision': obj.revision})
    return await detail(db, obj)


@router.delete('/{cid}')
async def remove(cid: uuid.UUID, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    await require_media_idle(db, cid)
    await db.delete(obj)
    await record_audit(db, request, 'work_cluster.delete', actor=auth.user, target_type='work_cluster', target_id=str(cid))
    return {'deleted': True}


@router.post('/{cid}/runs', status_code=201)
async def new_run(cid: uuid.UUID, body: ClusterRun, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    try: post = parse_post_link(body.post_link) if body.post_link is not None else None
    except ValueError as exc: raise ApiError(422, 'invalid_post_link', str(exc)) from None
    # Recover a lost successful response even if the cluster was edited/deleted meanwhile.
    existing = await batch_routes(db, body.request_id)
    if existing:
        if any(r.created_by != auth.user.id or r.link_config.get('work_cluster_id') != str(cid)
               or r.link_config.get('work_cluster_revision') != body.revision
               or (post is not None and r.link_config.get('post_link') != post['url']) for r in existing):
            raise ApiError(409, 'request_conflict', 'Yêu cầu đã được dùng cho bài khác. Mở Bài mới để tạo lượt khác.')
        return {'batch_id': str(body.request_id), 'items': await _out(db, existing), 'unused_senders': existing[0].link_config.get('unused_senders', 0)}
    obj = await require_cluster(db, cid, lock=True)
    if obj.cluster_type != 'forward':
        raise ApiError(409, 'message_cluster_route', 'Cụm gửi tin nhắn dùng nút gửi tin nhắn riêng.')
    if obj.revision != body.revision:
        raise ApiError(409, 'cluster_changed', 'Cụm đã thay đổi. Đóng và mở Bài mới để xem cấu hình mới trước khi tạo lượt.')
    if post is None:
        if not obj.post_link: raise ApiError(422, 'post_link_required', 'Sửa cụm và lưu liên kết bài viết trước khi chạy.')
        post = parse_post_link(obj.post_link)
    batch = PostBatchInput(request_id=body.request_id, account_ids=obj.account_ids, post_link=post['url'],
                           targets_text='\n'.join(obj.targets), delay_seconds=obj.delay_seconds, mode=obj.mode)
    result = await save_batch(batch, request, auth, db, cluster_context={
        'work_cluster_id': str(cid), 'work_cluster_name': obj.name, 'work_cluster_revision': obj.revision,
        'work_cluster_target_count': len(obj.targets), 'delay_max_seconds': obj.delay_max_seconds,
        'managed_targets_only': False})
    await record_audit(db, request, 'work_cluster.run_created', actor=auth.user, target_type='work_cluster', target_id=str(cid),
                       details={'batch_id': str(body.request_id), 'revision': obj.revision})
    return result




@router.put('/{cid}/message')
async def save_message(cid: uuid.UUID, body: ClusterMessageInput, request: Request, auth: AuthContext = Depends(admin),
                       db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    if not body.text.strip() and not obj.message_media_id:
        raise ApiError(422, 'message_empty', 'Nhập nội dung hoặc tải ảnh/video lên trước khi lưu.')
    if obj.message_media_id and len(body.text) > 1024:
        raise ApiError(422, 'caption_too_long', 'Chú thích ảnh/video tối đa 1.024 ký tự.')
    if body.schedule_enabled and not body.schedule_times:
        raise ApiError(422, 'schedule_empty', 'Chọn ít nhất một giờ gửi trong ngày.')
    obj.message_text = body.text
    obj.message_schedule_times = body.schedule_times
    obj.message_schedule_timezone = body.timezone
    obj.message_schedule_enabled = body.schedule_enabled
    obj.message_loop_enabled = body.loop_enabled
    if not body.loop_enabled and obj.loop_active:
        # Turning the loop off in the editor also stops any pass currently running.
        from sqlalchemy import update as _upd
        open_runs = (await db.execute(select(ClusterMessageRun).where(
            ClusterMessageRun.cluster_id == cid, ClusterMessageRun.status.in_(('queued', 'running'))).with_for_update())).scalars().all()
        stamp = utcnow()
        for item in open_runs:
            await db.execute(_upd(WorkerCommand).where(WorkerCommand.message_run_id == item.id,
                             WorkerCommand.status == 'pending').values(
                             status='expired', error_code='stopped', completed_at=stamp, payload_ciphertext=None))
            item.status = 'stopped'
        obj.loop_active = False
    await record_audit(db, request, 'work_cluster.message_saved', actor=auth.user, target_type='work_cluster', target_id=str(cid),
                       details={'has_text': bool(body.text), 'has_media': bool(obj.message_media_id), 'schedule_count': len(body.schedule_times)})
    return await detail(db, obj)


async def require_media_idle(db, cid):
    active = (await db.execute(select(WorkerCommand.id).join(ClusterMessageRun,
        ClusterMessageRun.id == WorkerCommand.message_run_id).where(
        ClusterMessageRun.cluster_id == cid, WorkerCommand.status.in_(('pending', 'delivered'))).limit(1))).first()
    if active:
        raise ApiError(409, 'media_in_use', 'Chờ lượt gửi kết thúc trước khi đổi hoặc xóa media.')


@router.post('/{cid}/message-media')
async def upload_message_media(cid: uuid.UUID, request: Request, file: UploadFile = File(...), auth: AuthContext = Depends(admin),
                                db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    await require_media_idle(db, cid)
    allowed = {'image/jpeg': ('.jpg', 'photo'), 'image/png': ('.png', 'photo'), 'image/webp': ('.webp', 'photo'),
               'video/mp4': ('.mp4', 'video'), 'video/quicktime': ('.mov', 'video')}
    if file.content_type not in allowed:
        raise ApiError(422, 'invalid_media_type', 'Chỉ nhận ảnh JPEG/PNG/WebP hoặc video MP4/MOV.')
    suffix, media_type = allowed[file.content_type]
    data = await file.read(20 * 1024 * 1024 + 1)
    if len(data) > 20 * 1024 * 1024:
        raise ApiError(413, 'media_too_large', 'Tệp tối đa 20 MB.')
    valid = (data.startswith(b'\xff\xd8\xff') if suffix == '.jpg' else
             data.startswith(b'\x89PNG\r\n\x1a\n') if suffix == '.png' else
             data[:4] == b'RIFF' and data[8:12] == b'WEBP' if suffix == '.webp' else
             len(data) >= 12 and data[4:8] == b'ftyp')
    if not valid:
        raise ApiError(422, 'invalid_media', 'Nội dung tệp không khớp định dạng đã khai báo.')
    base = Path(request.app.state.settings.media_dir).resolve()
    base.mkdir(parents=True, exist_ok=True)
    media_id = str(uuid.uuid4())
    (base / f'{media_id}{suffix}').write_bytes(data)
    old_id = obj.message_media_id
    obj.message_media_id, obj.message_media_type = media_id, media_type
    if old_id and old_id != media_id:
        for old in base.glob(f'{old_id}.*'):
            try: old.unlink()
            except OSError: pass
    await record_audit(db, request, 'work_cluster.message_media_uploaded', actor=auth.user, target_type='work_cluster', target_id=str(cid), details={'media_type': media_type})
    return {'media_id': media_id, 'media_type': media_type}


@router.delete('/{cid}/message-media')
async def delete_message_media(cid: uuid.UUID, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    await require_media_idle(db, cid)
    if obj.message_media_id:
        base = Path(request.app.state.settings.media_dir).resolve()
        for old in base.glob(f'{obj.message_media_id}.*') if base.exists() else []:
            try: old.unlink()
            except OSError: pass
    obj.message_media_id = obj.message_media_type = None
    return {'deleted': True}


@router.get('/{cid}/message-media')
async def get_message_media(cid: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid)
    if not obj.message_media_id: raise ApiError(404, 'not_found', 'Cụm chưa có media.')
    base = Path(request.app.state.settings.media_dir).resolve()
    files = list(base.glob(f'{obj.message_media_id}.*')) if base.exists() else []
    if len(files) != 1 or files[0].resolve().parent != base: raise ApiError(404, 'not_found', 'Không tìm thấy media.')
    return FileResponse(files[0])


async def create_message_run(db, settings, box, obj: WorkCluster, actor_id, slot_key: str, now=None, request: Request | None = None,
                            *, loop_session_id=None, loop_pass: int = 1, allow_active: bool = False):
    now = now or utcnow()
    if not (obj.message_text and obj.message_text.strip()) and not obj.message_media_id:
        raise ApiError(422, 'message_empty', 'Lưu nội dung tin nhắn hoặc ảnh/video trước khi gửi.')
    existing = (await db.execute(select(ClusterMessageRun).where(ClusterMessageRun.slot_key == slot_key))).scalar_one_or_none()
    if existing:
        if existing.cluster_id != obj.id:
            raise ApiError(409, 'request_conflict', 'Yêu cầu đã được dùng cho cụm khác.')
        return existing
    if not allow_active:
        active = (await db.execute(select(ClusterMessageRun.id).where(ClusterMessageRun.cluster_id == obj.id,
            ClusterMessageRun.status.in_(('queued', 'running'))).limit(1))).first()
        if active:
            raise ApiError(409, 'run_in_progress', 'Cụm đang có một lượt gửi tin nhắn chưa kết thúc.')
    accounts = (await db.execute(select(TelegramAccount).where(TelegramAccount.id.in_([uuid.UUID(x) for x in obj.account_ids]),
        TelegramAccount.pending_deletion.is_(False), TelegramAccount.auth_state == 'authorized', TelegramAccount.desired_state == 'running'))).scalars().all()
    by_id = {str(a.id): a for a in accounts}
    if allow_active:
        # Loop pass: keep the cycle alive by skipping senders Telegram has temporarily blocked or
        # that an operator stopped, instead of refusing the whole pass and stalling the loop.
        accounts = [a for a in accounts
                    if a.assigned_worker_id and (not a.flood_wait_until or a.flood_wait_until <= now)]
    else:
        if any(a.flood_wait_until and a.flood_wait_until > now for a in accounts):
            raise ApiError(409, 'flood_wait', 'Có SS đang phải chờ Telegram. Giữ nguyên thời gian chờ trước khi tạo lượt.')
        if set(obj.account_ids) - set(by_id):
            raise ApiError(409, 'senders_unavailable', 'Mọi SS trong cụm phải được xác thực và đang chạy trước khi gửi.')
    if not accounts:
        raise ApiError(409, 'no_senders_ready', 'Không có SS nào sẵn sàng gửi tin. Đợi flood_wait hết hoặc bật lại SS.')
    refs = list(dict.fromkeys(obj.targets))
    if not obj.message_loop_enabled:
        from app.services.post_delivery import partition
        assignments = await partition(db, refs, [{'id': str(a.id)} for a in accounts])
    else:
        # Stateless per-account random subset for each cycle
        rng=random.Random(f'{slot_key}:pass:{loop_pass}');aid_list=[str(a.id) for a in accounts];rng.shuffle(aid_list)
        refs_per_sender=max(1,len(refs)//len(aid_list) if aid_list else 1)
        cycle_refs=rng.sample(refs,len(refs));assignments={};cursor=0
        for aid in aid_list:
            chunk_size=min(refs_per_sender,len(cycle_refs)-cursor)
            assignments[uuid.UUID(aid)]=cycle_refs[cursor:cursor+chunk_size] if chunk_size>0 else []
            cursor+=chunk_size
        while cursor<len(cycle_refs):
            for aid in aid_list:
                if cursor>=len(cycle_refs):break
                assignments[uuid.UUID(aid)].append(cycle_refs[cursor]);cursor+=1
    worker_ids = {a.assigned_worker_id for a in accounts}
    workers = {w.id: w for w in (await db.execute(select(Worker).where(Worker.id.in_(worker_ids)))).scalars().all()}
    ready = []
    for account in accounts:
        worker = workers.get(account.assigned_worker_id)
        if worker is not None and worker_svc.effective_status(worker, now, settings.heartbeat_timeout_seconds) in ('online', 'degraded'):
            ready.append(account)
        elif not allow_active:
            raise ApiError(409, 'worker_unavailable', f'Worker của SS "{account.name}" đang offline.')
    accounts = ready
    if not accounts:
        raise ApiError(409, 'no_senders_ready', 'Không có SS nào có worker trực tuyến. Kiểm tra worker rồi chạy lại.')
    run = ClusterMessageRun(cluster_id=obj.id, slot_key=slot_key, scheduled_for=now, status='queued',
                            total_commands=len(refs), completed_commands=0, result={'outcomes': []}, created_at=now,
                            loop_session_id=loop_session_id if obj.message_loop_enabled else None,
                            loop_pass=loop_pass if obj.message_loop_enabled else 1,
                            current_pass=loop_pass - 1 if obj.message_loop_enabled else 0,
                            current_cycle=1)
    db.add(run)
    await db.flush()
    for account in accounts:
        worker = workers[account.assigned_worker_id]
        targets = list(assignments.get(account.id, []))
        random.SystemRandom().shuffle(targets)
        cursor = now
        for index, dest in enumerate(targets):
            gap = random.randint(obj.delay_seconds, obj.delay_max_seconds)
            payload = {'dest': dest, 'text': obj.message_text or '', 'media_id': obj.message_media_id,
                       'media_type': obj.message_media_type,
                       'cooldown_seconds': gap if index else 0}
            if index: cursor += timedelta(seconds=gap)
            cmd = acct_svc.create_command(db, box, worker_id=worker.id, account_id=account.id,
                type='send_message', payload=payload, ttl=max(3600, obj.delay_max_seconds * len(targets) + 3600),
                created_by=actor_id, now=now, message_run_id=run.id, available_at=cursor)
    run.status = 'completed' if run.total_commands == 0 else 'queued'
    if request is not None:
        await record_audit(db, request, 'work_cluster.message_run_created', actor_id=actor_id, target_type='work_cluster', target_id=str(obj.id),
                           details={'run_id': str(run.id), 'targets': len(refs)})
    return run


class ClusterQuickRun(BaseModel):
    """One press of the Run button on a cluster card."""
    model_config = ConfigDict(extra='forbid')
    request_id: uuid.UUID | None = None
    revision: int | None = Field(default=None, ge=1)


@router.post('/{cid}/start', status_code=201)
async def start_cluster(cid: uuid.UUID, request: Request, body: ClusterQuickRun | None = None,
                        auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    """Run button on the card. Message clusters get one queued pass (plus the loop when enabled);
    forward clusters keep producing randomised passes until Stop."""
    body = body or ClusterQuickRun()
    obj = await require_cluster(db, cid, lock=True)
    if obj.cluster_type == 'message':
        session_id = uuid.uuid4() if obj.message_loop_enabled else None
        if session_id:
            obj.loop_active = True
        slot = f"manual:{body.request_id or uuid.uuid4()}"
        run = await create_message_run(db, request.app.state.settings, request.app.state.secret_box, obj, auth.user.id,
                                       slot, request=request, loop_session_id=session_id, loop_pass=1)
        live = await live_states(db, [obj])
        return {'kind': 'message', 'run': message_run_out(run), 'cluster': summary(obj, live.get(obj.id))}
    if not obj.post_link:
        raise ApiError(422, 'post_link_required', 'Sửa cụm và lưu liên kết bài viết trước khi chạy.')
    if body.revision is not None and body.revision != obj.revision:
        raise ApiError(409, 'cluster_changed', 'Cụm đã thay đổi. Làm mới danh sách rồi chạy lại.')
    from app.services.forward_loops import loop_routes, try_advance_route
    # Retrying a lost response, including after Stop, must never restart a session.
    existing = await batch_routes(db, body.request_id) if body.request_id else []
    if existing:
        if any(r.created_by != auth.user.id or r.link_config.get('work_cluster_id') != str(cid)
               for r in existing):
            raise ApiError(409, 'request_conflict', 'Mã yêu cầu đã dùng cho cụm khác.')
    elif obj.loop_active:
        existing = await loop_routes(db, cid)
    if existing:
        live = await live_states(db, [obj])
        return {'kind': 'forward', 'batch_id': existing[0].link_config['batch_id'],
                'items': await _out(db, existing), 'started': [], 'failures': [],
                'cluster': summary(obj, live.get(obj.id))}
    batch_id = body.request_id or uuid.uuid4()
    batch = PostBatchInput(request_id=batch_id, account_ids=obj.account_ids, post_link=obj.post_link,
                           targets_text='\n'.join(obj.targets), delay_seconds=obj.delay_seconds, mode=obj.mode)
    result = await save_batch(batch, request, auth, db, cluster_context={
        'work_cluster_id': str(cid), 'work_cluster_name': obj.name, 'work_cluster_revision': obj.revision,
        'work_cluster_target_count': len(obj.targets), 'delay_max_seconds': obj.delay_max_seconds,
        'managed_targets_only': False, 'forward_loop': True, 'loop_enabled': True, 'loop_pass': 1,
        'target_strategy': 'per_sender_all'})
    obj.loop_active = True
    obj.loop_block_reason = None
    await db.flush()
    failures, started = [], []
    for row in result.get('items', []):
        route_id = row['id']
        changed, failure = await try_advance_route(db, route_id, request.app.state.settings, utcnow())
        if changed:
            started.append(str(route_id))
        if failure:
            failures.append({'route_id': str(route_id), 'account': row.get('account_name'),
                             'code': failure[0], 'error': failure[1]})
    await db.flush()
    live = await live_states(db, [obj])
    return {'kind': 'forward', 'batch_id': str(batch_id),
            'items': await _out(db, await batch_routes(db, batch_id)),
            'started': started, 'failures': failures,
            'cluster': summary(obj, live.get(obj.id))}



async def _issue_post_verify(route, request, auth, db):
    from app.services import accounts as _acct_svc
    acct = await db.get(TelegramAccount, route.account_id)
    if acct is None or acct.assigned_worker_id is None:
        raise ApiError(409, 'worker_unavailable', 'SS chưa được gán worker nên chưa kiểm tra quyền nhóm được.')
    now = utcnow()
    old_id = (route.link_config or {}).get('verify_command_id')
    old = await db.get(WorkerCommand, uuid.UUID(old_id)) if old_id else None
    if old is not None and old.status in ('pending', 'delivered') and old.expires_at > now:
        return None
    cmd = _acct_svc.create_command(db, request.app.state.secret_box, worker_id=acct.assigned_worker_id,
                                   account_id=acct.id, type='verify_post',
                                   payload={'post_link': route.link_config['post_link'],
                                            'targets': route.link_config['targets']},
                                   ttl=request.app.state.settings.command_ttl_seconds,
                                   created_by=auth.user.id, now=now, route_id=route.id)
    route.link_config = {**route.link_config, 'verify_command_id': str(cmd.id), 'verification_error': None, 'checks': []}
    from app.services import routes as route_svc
    route_svc.invalidate_verification(route)
    await db.flush()
    return cmd


@router.post('/{cid}/stop')
async def stop_cluster(cid: uuid.UUID, request: Request, auth: AuthContext = Depends(admin),
                       db: AsyncSession = Depends(get_db, scope='function')):
    """Red Stop button on the card: cancels every pending command/job of the latest run."""
    from sqlalchemy import update
    obj = await require_cluster(db, cid, lock=True)
    now = utcnow()
    stopped = 0
    if obj.cluster_type == 'message':
        open_runs = (await db.execute(select(ClusterMessageRun).where(
            ClusterMessageRun.cluster_id == cid, ClusterMessageRun.status.in_(('queued', 'running'))).with_for_update())).scalars().all()
        for item in open_runs:
            await db.execute(update(WorkerCommand).where(WorkerCommand.message_run_id == item.id,
                             WorkerCommand.status == 'pending').values(
                             status='expired', error_code='stopped', completed_at=now, payload_ciphertext=None))
            item.status = 'stopped'
        stopped = len(open_runs)
        obj.loop_active = False
    else:
        from app.services import jobs as job_svc
        from app.routers.routes import _transition
        obj.loop_active = False
        obj.loop_block_reason = None
        config = ForwardRoute.link_config
        rows = (await db.execute(select(ForwardRoute).where(
            config['work_cluster_id'].as_string() == str(cid),
            config['batch_id'].as_string().is_not(None)))).scalars().all()
        for route in rows:
            route.link_config = {**route.link_config, 'loop_enabled': False, 'auto_start': False}
            stopped += await job_svc.cancel_pending_for_route(db, route.id, now)
            await _transition(route.id, 'stop', request, auth, db, cancel_pending=True)
    await record_audit(db, request, 'work_cluster.stop', actor=auth.user, target_type='work_cluster', target_id=str(cid),
                       details={'cancelled': stopped})
    live = await live_states(db, [obj])
    return {'stopped': stopped, 'cluster': summary(obj, live.get(obj.id))}


@router.post('/{cid}/message-runs', status_code=201)
async def send_message_now(cid: uuid.UUID, body: MessageRunInput, request: Request, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    obj = await require_cluster(db, cid, lock=True)
    if obj.cluster_type != 'message':
        raise ApiError(409, 'wrong_cluster_type', 'Cụm này là cụm chuyển tiếp, không phải cụm gửi tin nhắn.')
    session_id = None
    if obj.message_loop_enabled:
        # A loop session keeps producing fresh randomised passes until the user stops it.
        obj.loop_active = True
        session_id = uuid.uuid4()
    run = await create_message_run(db, request.app.state.settings, request.app.state.secret_box, obj, auth.user.id,
                                   f'manual:{body.request_id}', request=request,
                                   loop_session_id=session_id, loop_pass=1)
    return message_run_out(run)


async def refresh_message_run(db, run):
    if run.status not in ('queued', 'running'):
        return
    open_count = (await db.execute(select(func.count()).select_from(WorkerCommand).where(
        WorkerCommand.message_run_id == run.id, WorkerCommand.status.in_(('pending', 'delivered'))))).scalar_one()
    if not open_count:
        errors = (await db.execute(select(func.count()).select_from(WorkerCommand).where(
            WorkerCommand.message_run_id == run.id, WorkerCommand.status.in_(('failed', 'expired'))))).scalar_one()
        run.status = 'completed_with_errors' if errors else 'completed'


@router.get('/{cid}/message-runs')
async def message_history(cid: uuid.UUID, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    await require_cluster(db, cid)
    stmt = select(ClusterMessageRun).where(ClusterMessageRun.cluster_id == cid).order_by(ClusterMessageRun.created_at.desc())
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    runs = (await db.execute(stmt.offset((page-1)*page_size).limit(page_size))).scalars().all()
    for run in runs: await refresh_message_run(db, run)
    return {'items': [message_run_out(r) for r in runs], 'total': total, 'page': page, 'page_size': page_size}


@router.post('/{cid}/message-runs/{run_id}/stop')
async def stop_message_run(cid: uuid.UUID, run_id: uuid.UUID, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    from sqlalchemy import update
    run = (await db.execute(select(ClusterMessageRun).where(ClusterMessageRun.id == run_id, ClusterMessageRun.cluster_id == cid).with_for_update())).scalar_one_or_none()
    if run is None: raise ApiError(404, 'not_found', 'Không tìm thấy lượt gửi.')
    if run.status in ('queued', 'running'):
        await db.execute(update(WorkerCommand).where(WorkerCommand.message_run_id == run.id, WorkerCommand.status == 'pending')
                         .values(status='expired', error_code='stopped', completed_at=utcnow(), payload_ciphertext=None))
        run.status = 'stopped'
    # Stopping any pass of a loop session cancels the whole loop so no fresh pass is scheduled.
    if run.loop_session_id:
        await stop_loop_session(db, cid, run.loop_session_id, utcnow())
    return message_run_out(run)


async def stop_loop_session(db, cid, session_id, now):
    """Expire every open pass of this loop and clear the cluster flag."""
    from sqlalchemy import update
    from app.models import WorkCluster
    cluster = await require_cluster(db, cid, lock=True)
    if cluster.loop_active:
        cluster.loop_active = False
    open_runs = (await db.execute(select(ClusterMessageRun).where(
        ClusterMessageRun.cluster_id == cid, ClusterMessageRun.loop_session_id == session_id,
        ClusterMessageRun.status.in_(('queued', 'running'))).with_for_update())).scalars().all()
    for item in open_runs:
        await db.execute(update(WorkerCommand).where(WorkerCommand.message_run_id == item.id,
                         WorkerCommand.status == 'pending').values(
                         status='expired', error_code='stopped', completed_at=now, payload_ciphertext=None))
        item.status = 'stopped'


@router.post('/{cid}/loop/stop')
async def stop_cluster_loop(cid: uuid.UUID, auth: AuthContext = Depends(admin), db: AsyncSession = Depends(get_db, scope='function')):
    """Stop the whole randomised loop for a message cluster (all passes)."""
    cluster = await require_cluster(db, cid, lock=True)
    if cluster.cluster_type != 'message':
        raise ApiError(409, 'wrong_cluster_type', 'Chỉ cụm gửi tin nhắn mới có vòng lặp.')
    from sqlalchemy import update
    open_runs = (await db.execute(select(ClusterMessageRun).where(
        ClusterMessageRun.cluster_id == cid, ClusterMessageRun.status.in_(('queued', 'running'))).with_for_update())).scalars().all()
    now = utcnow()
    for item in open_runs:
        await db.execute(update(WorkerCommand).where(WorkerCommand.message_run_id == item.id,
                         WorkerCommand.status == 'pending').values(
                         status='expired', error_code='stopped', completed_at=now, payload_ciphertext=None))
        item.status = 'stopped'
    cluster.loop_active = False
    return {'stopped': len(open_runs), 'loop_active': False}


def message_run_out(run):
    return {'id': str(run.id), 'cluster_id': str(run.cluster_id), 'scheduled_for': run.scheduled_for,
            'status': run.status, 'total_commands': run.total_commands, 'completed_commands': run.completed_commands,
            'loop_pass': getattr(run, 'loop_pass', 1), 'loop_session_id': str(run.loop_session_id) if getattr(run, 'loop_session_id', None) else None,
            'outcomes': (run.result or {}).get('outcomes', []), 'created_at': run.created_at}


async def loop_readiness(db, clusters, settings, now=None):
    """Why a loop-active message cluster cannot start its next pass right now.

    Distinguishes temporary blocks (flood wait, worker offline - retry later) from
    permanent ones (session stopped/broken - the loop is switched off so the card can say so).
    """
    from app.services import workers as worker_svc
    now = now or utcnow()
    ids = [c.id for c in clusters if c.cluster_type == 'message' and getattr(c, 'loop_active', False)]
    if not ids:
        return {}
    rows = (await db.execute(select(WorkCluster).where(WorkCluster.id.in_(ids)))).scalars().all()
    account_ids = {uuid.UUID(x) for c in rows for x in (c.account_ids or [])}
    accounts = (await db.execute(select(TelegramAccount).where(TelegramAccount.id.in_(account_ids)))).scalars().all() if account_ids else []
    by_id = {str(a.id): a for a in accounts}
    worker_ids = {a.assigned_worker_id for a in accounts if a.assigned_worker_id}
    workers = {w.id: w for w in (await db.execute(select(Worker).where(Worker.id.in_(worker_ids)))).scalars().all()} if worker_ids else {}
    out = {}
    for cluster in rows:
        mine = [by_id[x] for x in (cluster.account_ids or []) if x in by_id]
        ready, blocked_flood, blocked_worker, blocked_state = [], [], [], []
        for a in mine:
            if a.pending_deletion or a.auth_state != 'authorized':
                blocked_state.append(a)
            elif a.desired_state != 'running':
                blocked_state.append(a)
            elif not a.assigned_worker_id:
                blocked_worker.append(a)
            elif a.flood_wait_until and a.flood_wait_until > now:
                blocked_flood.append(a)
            else:
                worker = workers.get(a.assigned_worker_id)
                if worker is None or worker_svc.effective_status(worker, now, settings.heartbeat_timeout_seconds) not in ('online', 'degraded'):
                    blocked_worker.append(a)
                else:
                    ready.append(a)
        if ready:
            out[cluster.id] = {'reason': None, 'wait_until': None, 'ready': len(ready)}
        elif not mine:
            out[cluster.id] = {'reason': 'no_senders', 'wait_until': None, 'ready': 0}
        elif blocked_flood:
            out[cluster.id] = {'reason': 'flood_wait', 'wait_until': min(a.flood_wait_until for a in blocked_flood), 'ready': 0}
        elif blocked_worker:
            out[cluster.id] = {'reason': 'worker_offline', 'wait_until': None, 'ready': 0}
        elif blocked_state:
            out[cluster.id] = {'reason': 'senders_stopped', 'wait_until': None, 'ready': 0}
        else:
            out[cluster.id] = {'reason': 'unavailable', 'wait_until': None, 'ready': 0}
    return out


LOOP_PERMANENT_BLOCKS = ('senders_stopped', 'no_senders', 'unavailable')


async def continue_loop_sessions(db, settings, box, now=None):
    """Scheduler hook: for every loop-active message cluster with no queued/running pass,
    create the next randomised pass. Returns the number of passes started."""
    from sqlalchemy import update
    now = now or utcnow()
    clusters = (await db.execute(select(WorkCluster).where(
        WorkCluster.loop_active.is_(True), WorkCluster.cluster_type == 'message',
        WorkCluster.message_loop_enabled.is_(True)))).scalars().all()
    started = 0
    for cluster in clusters:
        open_runs = (await db.execute(select(ClusterMessageRun).where(
            ClusterMessageRun.cluster_id == cluster.id,
            ClusterMessageRun.status.in_(('queued', 'running'))))).scalars().all()
        if open_runs:
            # Mark passes whose commands all expired so a stuck pass cannot stall the loop.
            for item in open_runs:
                await refresh_message_run(db, item)
            if any(item.status in ('queued', 'running') for item in open_runs):
                continue
        last = (await db.execute(select(ClusterMessageRun).where(
            ClusterMessageRun.cluster_id == cluster.id,
            ClusterMessageRun.loop_session_id.isnot(None)).order_by(
            ClusterMessageRun.created_at.desc()).limit(1))).scalar_one_or_none()
        if last is None:
            # Loop flag without a session row: nothing to continue.
            cluster.loop_active = False
            continue
        # A sender Telegram temp-blocks or whose worker is offline is a *temporary* stall:
        # stay loop-active and retry on the next tick instead of dropping the pass silently.
        readiness = (await loop_readiness(db, [cluster], settings, now)).get(cluster.id) or {}
        if readiness.get('reason') in LOOP_PERMANENT_BLOCKS:
            cluster.loop_active = False
            cluster.loop_block_reason = readiness.get('reason')
            logging.getLogger('tfcc.cluster_messages').warning(
                'loop_stopped', extra={'cluster_id': str(cluster.id), 'reason': readiness.get('reason')})
            continue
        if readiness.get('reason'):
            cluster.loop_block_reason = readiness.get('reason')
            continue
        next_pass = (last.loop_pass or 1) + 1
        # cluster_message_runs.slot_key is VARCHAR(80): keep the key compact. Session UUID plus a
        # timestamp would overflow the column, and Postgres would reject every pass silently.
        slot_key = f'L{cluster.id.hex[:16]}{last.loop_session_id.hex[:16]}{next_pass}{now:%y%m%d%H%M%S%f}'[:80]
        try:
            async with db.begin_nested():
                await create_message_run(db, settings, box, cluster, cluster.created_by, slot_key, now,
                                         loop_session_id=last.loop_session_id, loop_pass=next_pass,
                                         allow_active=True)
            cluster.loop_block_reason = None
            started += 1
        except ApiError as exc:
            logging.getLogger('tfcc.cluster_messages').warning(
                'loop_pass_skipped', extra={'cluster_id': str(cluster.id), 'error': exc.code})
            if exc.code in ('no_senders_ready', 'message_empty'):
                cluster.loop_active = False
                cluster.loop_block_reason = exc.code
        except Exception as exc:
            # Never swallow this: an unrecorded failure here is exactly how a loop dies unnoticed.
            logging.getLogger('tfcc.cluster_messages').exception(
                'loop_pass_failed', extra={'cluster_id': str(cluster.id), 'pass': next_pass,
                                           'slot_key': slot_key, 'error': type(exc).__name__})
            cluster.loop_block_reason = 'pass_error'
    return started


@router.get('/{cid}/runs')
async def history(cid: uuid.UUID, page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=50),
                  auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope='function')):
    await require_cluster(db, cid)
    config = ForwardRoute.link_config
    batch_id = config['batch_id'].as_string()
    stmt = select(batch_id.label('batch_id'), func.min(ForwardRoute.created_at).label('created_at'),
                  func.max(config['post_link'].as_string()).label('post_link'),
                  func.count().label('account_count'),
                  func.max(config['work_cluster_target_count'].as_integer()).label('target_count'),
                  func.sum(case((ForwardRoute.status == 'active', 1), else_=0)).label('active_count'),
                  func.sum(case((ForwardRoute.status == 'paused', 1), else_=0)).label('paused_count'),
                  func.sum(case((config['queued_at'].as_string().is_not(None), 1), else_=0)).label('started_count'))
    stmt = stmt.where(config['work_cluster_id'].as_string() == str(cid)).group_by(batch_id)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(func.min(ForwardRoute.created_at).desc(), batch_id)
                            .offset((page-1)*page_size).limit(page_size))).mappings().all()
    return {'items': [dict(row) for row in rows], 'total': total, 'page': page, 'page_size': page_size}
