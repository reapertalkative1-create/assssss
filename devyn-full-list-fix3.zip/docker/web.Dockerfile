# syntax=docker/dockerfile:1
FROM node:22-bookworm-slim AS build
WORKDIR /web
COPY apps/web/package.json apps/web/package-lock.json ./
RUN --mount=type=secret,id=proxy_ca \
    if [ -f /run/secrets/proxy_ca ]; then export NODE_EXTRA_CA_CERTS=/run/secrets/proxy_ca; fi; \
    npm ci --no-audit --no-fund
COPY apps/web ./
COPY APP_VERSION /tmp/tfcc-app-version
RUN node -e "const fs=require('fs');const version=fs.readFileSync('/tmp/tfcc-app-version','utf8').trim();if(!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(version))throw Error('Invalid APP_VERSION');fs.mkdirSync('public',{recursive:true});fs.writeFileSync('public/version.json',JSON.stringify({version}));"
RUN npm run build

FROM nginx:1.28-alpine
COPY --chmod=644 docker/nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /web/dist /usr/share/nginx/html
