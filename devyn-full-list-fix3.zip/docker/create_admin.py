"""Create the setup administrator from UTF-8 JSON stdin, without a Docker TTY."""
import asyncio
import json
import sys

from argon2.exceptions import HashingError
from sqlalchemy.exc import SQLAlchemyError

from app.cli import create_admin
from app.config import get_settings
from app.schemas import normalize_username
from app.security import validate_password_policy


def reply(ok: bool, **fields) -> None:
    # ASCII output also works with Windows PowerShell's native output decoding.
    print(json.dumps({"ok": ok, **fields}, ensure_ascii=True))


def failure_details(exc: Exception) -> dict:
    """Only report known categories, exception class and SQLSTATE; never SQL/parameters."""
    sqlstate = None
    current = exc
    for _ in range(5):
        state = getattr(current, "sqlstate", None)
        if isinstance(state, str) and len(state) == 5 and state.isalnum():
            sqlstate = state
            break
        current = getattr(current, "orig", None) or getattr(current, "__cause__", None)
        if current is None:
            break
    code, message = "creation_failed", "Không tạo được tài khoản. Gửi mã lỗi bên dưới để kiểm tra."
    if sqlstate in {"28P01", "28000"}:
        code, message = "db_auth_failed", "Mật khẩu kết nối PostgreSQL không khớp cấu hình đã lưu; đây không phải mật khẩu tài khoản web. Giữ nguyên .env.docker và volume cũ."
    elif sqlstate in {"42P01", "42703", "3F000", "3D000"}:
        code, message = "db_schema_mismatch", "Cơ sở dữ liệu thiếu bảng/cột hoặc chưa nâng cấp đầy đủ. Chạy lại setup.cmd trong đúng thư mục cài đặt."
    elif sqlstate == "42501":
        code, message = "db_permission_denied", "PostgreSQL từ chối quyền ghi tài khoản. Kiểm tra quyền của người dùng cơ sở dữ liệu."
    elif sqlstate in {"53100", "53200", "53300", "53400"}:
        code, message = "db_resources", "PostgreSQL thiếu dung lượng/bộ nhớ hoặc đã hết kết nối. Kiểm tra tài nguyên Docker Desktop."
    elif isinstance(exc, HashingError):
        code, message = "password_hash_failed", "Không mã hóa được mật khẩu. Kiểm tra bộ nhớ cấp cho Docker Desktop."
    elif isinstance(exc, (OSError, TimeoutError)) or (sqlstate and sqlstate.startswith("08")):
        code, message = "db_unavailable", "Không kết nối được PostgreSQL. Kiểm tra container db trong Docker Desktop."
    elif isinstance(exc, SQLAlchemyError):
        code, message = "db_write_failed", "PostgreSQL không ghi được tài khoản. Gửi mã lỗi bên dưới để kiểm tra."
    details = {"code": code, "message": message, "error_type": type(exc).__name__}
    if sqlstate:
        details["sqlstate"] = sqlstate
    return details


INPUT_PROBE = "DEVYN-input-Đặc-biệt-&|^%!\"'\\$🙂"


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if args not in ([], ["--check-input"]):
        reply(False, code="invalid_arguments", message="Lệnh tạo tài khoản không hợp lệ.")
        return 1
    raw = sys.stdin.buffer.read(16385)
    if not raw.strip():
        reply(False, code="stdin_empty", message="Docker không nhận được dữ liệu từ setup. Không phải lỗi mật khẩu; cập nhật đầy đủ scripts/windows.ps1 rồi chạy lại setup.cmd.")
        return 1
    try:
        if len(raw) > 16384:
            raise ValueError
        # Accept the optional UTF-8 BOM produced by some Windows native pipelines.
        data = json.loads(raw.decode("utf-8-sig"))
        if args == ["--check-input"]:
            if data != {"probe": INPUT_PROBE}:
                raise ValueError
            reply(True, input_ready=True)
            return 0
        if not isinstance(data, dict) or set(data) != {"username", "password", "password_confirm"}:
            raise ValueError
        if not all(isinstance(value, str) for value in data.values()):
            raise ValueError
    except (ValueError, UnicodeError):
        reply(False, code="invalid_request", message="Dữ liệu từ setup đến Docker bị sai định dạng. Không phải lỗi xác nhận mật khẩu; cập nhật đầy đủ bản sửa rồi chạy lại setup.cmd.")
        return 1
    try:
        username = normalize_username(data["username"])
    except ValueError:
        reply(False, code="invalid_username", message="Tên đăng nhập cần 3–32 ký tự: chữ, số, dấu _, . hoặc -.")
        return 0
    if data["password"] != data["password_confirm"]:
        reply(False, code="password_mismatch", message="Hai mật khẩu không khớp. Vui lòng nhập lại.")
        return 0
    problem = validate_password_policy(data["password"], username)
    if problem:
        reply(False, code="invalid_password", message=problem)
        return 0
    try:
        asyncio.run(create_admin(get_settings().database_url, username, data["password"]))
    except SystemExit:
        # Username and policy were validated above; creation can still hit a duplicate.
        reply(False, code="username_exists", message="Tên đăng nhập đã tồn tại. Hãy dùng tên khác.")
        return 0
    except Exception as exc:
        # Do not print database parameters or the request on failure.
        reply(False, **failure_details(exc))
        return 1
    reply(True, username=username)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
