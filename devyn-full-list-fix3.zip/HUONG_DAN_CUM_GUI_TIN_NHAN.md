# Cụm gửi tin nhắn và vòng lặp tự động

Phiên bản `2026.11.16-message-loop`, database **0020**.

## Khái niệm

**Cụm gửi tin nhắn** là chức năng riêng cho việc soạn nội dung (text, ảnh, video, emoji) và gửi đến danh sách nhóm đã chọn. Khác với cụm chuyển tiếp (forward link bài viết), cụm gửi tin nhắn tạo tin nhắn mới với nội dung do bạn tự soạn.

**Vòng lặp tự động**: khi bật, hệ thống sẽ gửi liên tục đến tất cả nhóm trong danh sách, xong rồi shuffle ngẫu nhiên và tiếp tục gửi vòng mới, cho đến khi bạn bấm **Dừng vòng lặp**.

## Cập nhật

Giữ `.env.docker` và Docker volume. Giải nén đè toàn bộ nội dung ZIP vào đúng thư mục đang dùng, chạy **setup.cmd** một lần để cập nhật API/web/worker và nâng database lên 0020, rồi **run.cmd**. Trên web nhấn Ctrl+F5. Cuối trang ghi **Tin nhắn & lặp · 16.11.2026**.

## Tạo cụm gửi tin nhắn

1. Mở **Cụm làm việc → + Cụm gửi tin nhắn**.
2. Tải lên **File danh sách nhóm .txt** (mỗi dòng một link nhóm/kênh). Giới hạn 10.000 nhóm.
3. Nhập **Nhóm nhận bài** (cần quyền quản trị + quyền đăng), hoặc để trống nếu muốn gửi tất cả nhóm trong file.
4. **Tự lưu tạm**: bật khi muốn lưu tin nhắn vào Tin nhắn đã lưu của SS trước khi gửi sang nhóm khác (giúp tin nhắn xuất hiện tự nhiên hơn).
5. **Tên cụm làm việc**: đặt tên dễ nhớ.
6. Chọn **Tài khoản gửi** (một hoặc nhiều SS, mỗi SS sẽ gửi phần nhóm được phân ngẫu nhiên).
7. **Nghỉ giữa hai nhóm (giây)**: từ – đến, hệ thống random trong khoảng này.
8. Bấm **Kiểm tra danh sách** nếu muốn xem trước nhóm nào hợp lệ.

### Soạn nội dung tin nhắn

9. **Text** (1.024 ký tự với ảnh/video, 4.096 ký tự khi gửi text thuần). Hỗ trợ emoji thường. **Emoji Premium Telegram chưa hỗ trợ** — nếu dán vào, Telegram sẽ thay bằng emoji thường hoặc text.
10. **Ảnh/video**: bấm **Chọn tệp** → tải lên. JPEG/PNG/WebP (≤ 10 MB), MP4/MOV (≤ 50 MB). Bấm **Xoá ảnh/video** nếu muốn đổi sang text thuần.
11. **Emoji**: hỗ trợ tất cả emoji Unicode thường (😀🎉💯...). Ký tự đặc biệt (chữ Việt có dấu, chữ Hán, Cyrillic, emoji) đều OK.

### Lên lịch và vòng lặp

12. **Giờ gửi trong ngày** (tùy chọn): nhập nhiều khung giờ HH:MM (ví dụ 09:00, 14:30, 20:00). Chọn **Múi giờ** → bật **Bật lên lịch gửi**. Hệ thống chỉ chạy vào các giờ đã đặt.
13. **Bật vòng lặp tự động**: khi bật, hệ thống gửi hết danh sách → shuffle ngẫu nhiên danh sách → tiếp tục gửi vòng mới. Mỗi SS sẽ nhận ngẫu nhiên một nhóm trong vòng lặp, không theo partition cố định. Vòng lặp chỉ dừng khi bạn bấm **Dừng vòng lặp** hoặc tắt cụm.
14. Bấm **Lưu cụm**.

## Chạy cụm gửi tin nhắn

- **Chạy ngay**: bấm **Chạy** trên thẻ cụm. Cửa sổ pop-up hiện tiến độ từng SS, bấm **Mở lượt & tiến độ** để xem chi tiết.
- **Dừng**: bấm **Dừng thao tác** để dừng các lệnh chưa xử lý. Lượt hiện tại sẽ dừng nhưng loop chưa tắt.
- **Dừng vòng lặp** (khi loop đã bật): bấm nút **Dừng vòng lặp** bên cạnh badge "🔁 Vòng lặp". Tắt hoàn toàn vòng lặp, dừng cả lượt hiện tại.
- **Lịch sử**: mỗi lượt gửi được lưu với trạng thái, số tin đã gửi/lỗi, badge "Vòng X · Lượt Y" khi là loop pass.

## Cụm chuyển tiếp (forward) có loop không?

Hiện tại **chưa**. Loop mode chỉ có trong **Cụm gửi tin nhắn**. Cụm chuyển tiếp (forward link bài viết) vẫn dùng cơ chế partition cố định nhóm theo SS, chạy 1 lượt xong dừng. Có thể thêm loop cho forward trong phiên bản sau nếu cần.

## Giới hạn và lưu ý

- **Auto-join nhóm/kênh chưa tham gia**: CÓ (bạn đã cho phép). Khi tới lượt một nhóm mà tài khoản chưa ở trong đó, worker tự gọi `JoinChannelRequest` (nhóm công khai có @username) hoặc `ImportChatInviteRequest` (link mời `t.me/+...`), rồi gửi tin. Nếu Telegram chặn (FloodWait/PeerFlood/giới hạn tài khoản), worker trả mã lỗi tương ứng và **không** cố lách. Rủi ro khoá tài khoản do join hàng loạt là do bạn tự chịu.
- **Emoji Premium Telegram**: chưa hỗ trợ (cần custom-emoji ID/entity). Emoji Unicode thường thì gửi bình thường.
- **FloodWait / spam-ban**: khi Telegram giới hạn tần suất gửi hoặc tạm khóa SS, worker tự động đánh dấu `flood_wait_until` / `account_frozen`. Không bổ sung xoay SS/proxy tự động.
- **Khoảng nghỉ**: worker tuân theo `delay_seconds` trong payload, random trong khoảng Từ–Đến. Thực tế có thể chậm hơn do FloodWait hoặc lỗi proxy.
- **Vòng lặp:** mỗi pass mới shuffle danh sách nhóm và phân ngẫu nhiên cho từng SS. Pass trước không ảnh hưởng partition của pass sau. Nếu có 10.000 nhóm và 10 SS, mỗi SS nhận khoảng 1.000 nhóm, nhưng nhóm nào thuộc SS nào là ngẫu nhiên mỗi vòng.
- **Tắt loop trong form**: nếu bỏ chọn **Bật vòng lặp tự động** rồi Lưu cụm trong khi loop đang chạy, hệ thống sẽ dừng lượt hiện tại và tắt loop active.
- **Lịch trình (schedule)**: nếu bật lên lịch gửi + bật loop, lượt mới chỉ tạo vào giờ đã đặt. Ngoài khung giờ, scheduler bỏ qua.

## FAQ

**Q: Tôi có 10.000 nhóm, chọn 10 SS. Mỗi SS sẽ gửi bao nhiêu nhóm?**  
A: Mỗi pass chia đều ~ 1.000 nhóm/SS. Vòng lặp shuffle lại, nên SS này lần sau có thể nhận nhóm khác.

**Q: Vòng lặp dừng khi nào?**  
A: Chỉ dừng khi bạn bấm **Dừng vòng lặp** hoặc tắt cụm trong form. Loop tự chạy liên tục cho đến đó.

**Q: Có thể dùng emoji Premium không?**  
A: Chưa. Bạn có thể dán nhưng Telegram sẽ chuyển thành emoji thường hoặc text.

**Q: Nhóm nào chưa tham gia thì tự động join không?**  
A: Có. Worker tự join khi gặp `not_joined` (hỗ trợ @username, t.me/ten, link mời `t.me/+...` và ID âm). Nếu không join được (link hết hạn, bị ban, FloodWait…) thì nhóm đó bị đánh dấu lỗi và vòng lặp đi tiếp. Lưu ý: join quá nhiều trong thời gian ngắn có thể khiến Telegram hạn chế/khoá tài khoản — bạn đã xác nhận tự chịu rủi ro này.

**Q: Có thể chọn giờ gửi nhiều lần trong ngày không?**  
A: Có. Nhập nhiều mốc HH:MM (ví dụ 09:00, 14:30, 20:00), bật lên lịch. Hệ thống chỉ chạy vào giờ đã đặt.

**Q: Thư mục media cache ở đâu?**  
A: `uploads/message-media-cache/` trên máy chạy worker. Ảnh/video upload qua API được cache ở đó để worker dùng lại.

---
Cuối trang hiện **Tin nhắn & lặp · 16.11.2026**
