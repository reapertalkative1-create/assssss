"""Remember why a loop stopped so the cluster card can explain it."""
from alembic import op
import sqlalchemy as sa

revision = "0022"
down_revision = "0021"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("work_clusters", sa.Column("loop_block_reason", sa.String(length=32), nullable=True))


def downgrade():
    op.drop_column("work_clusters", "loop_block_reason")
