"""Repeat message clusters in fresh randomised cycles until stopped."""
from alembic import op
import sqlalchemy as sa
revision = "0020"
down_revision = "0019"
branch_labels = None
depends_on = None
def upgrade():
    op.add_column("work_clusters", sa.Column("message_loop_enabled", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("cluster_message_runs", sa.Column("current_cycle", sa.Integer(), nullable=False, server_default="1"))
    op.add_column("cluster_message_runs", sa.Column("current_pass", sa.Integer(), nullable=False, server_default="0"))
def downgrade():
    op.drop_column("cluster_message_runs", "current_pass")
    op.drop_column("cluster_message_runs", "current_cycle")
    op.drop_column("work_clusters", "message_loop_enabled")
