"""Saved cluster posts and persistent per-delivery pacing."""
from alembic import op
import sqlalchemy as sa

revision = '0017'
down_revision = '0016'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('work_clusters', sa.Column('post_link', sa.String(500), nullable=True))
    op.add_column('work_clusters', sa.Column('delay_max_seconds', sa.Integer(), nullable=False, server_default='180'))
    # Existing fixed intervals remain fixed until their owner edits the cluster.
    op.execute('UPDATE work_clusters SET delay_max_seconds = delay_seconds')
    op.add_column('forward_jobs', sa.Column('cooldown_seconds', sa.Integer(), nullable=False, server_default='0'))
    db = op.get_bind()
    clusters = sa.table('work_clusters', sa.column('id', sa.Uuid()), sa.column('post_link', sa.String()))
    routes = sa.table('forward_routes', sa.column('id', sa.Uuid()), sa.column('link_config', sa.JSON()), sa.column('created_at', sa.DateTime()))
    for cid in db.execute(sa.select(clusters.c.id)).scalars().all():
        config = db.execute(sa.select(routes.c.link_config).where(
            routes.c.link_config['work_cluster_id'].as_string() == str(cid)
        ).order_by(routes.c.created_at.desc(), routes.c.id.desc()).limit(1)).scalar_one_or_none()
        link = config.get('post_link') if isinstance(config, dict) else None
        if isinstance(link, str) and len(link) <= 500:
            db.execute(clusters.update().where(clusters.c.id == cid).values(post_link=link))


def downgrade():
    op.drop_column('forward_jobs', 'cooldown_seconds')
    op.drop_column('work_clusters', 'delay_max_seconds')
    op.drop_column('work_clusters', 'post_link')
