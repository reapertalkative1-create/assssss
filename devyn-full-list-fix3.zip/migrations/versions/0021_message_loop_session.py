"""Track a running loop session and per-pass history for message clusters."""
from alembic import op
import sqlalchemy as sa

revision = "0021"
down_revision = "0020"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("work_clusters", sa.Column("loop_active", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("cluster_message_runs", sa.Column("loop_session_id", sa.Uuid(), nullable=True))
    op.add_column("cluster_message_runs", sa.Column("loop_pass", sa.Integer(), nullable=False, server_default="1"))
    op.create_index("ix_cluster_message_runs_loop_session_id", "cluster_message_runs", ["loop_session_id"])


def downgrade():
    op.drop_index("ix_cluster_message_runs_loop_session_id", table_name="cluster_message_runs")
    op.drop_column("cluster_message_runs", "loop_pass")
    op.drop_column("cluster_message_runs", "loop_session_id")
    op.drop_column("work_clusters", "loop_active")
