"""Distinguish reusable message clusters from post-forward clusters."""
from alembic import op
import sqlalchemy as sa
revision = "0019"
down_revision = "0018"
branch_labels = None
depends_on = None
def upgrade():
    op.add_column("work_clusters", sa.Column("cluster_type", sa.String(16), nullable=False, server_default="forward"))
def downgrade():
    op.drop_column("work_clusters", "cluster_type")
