"""Message content, schedules and delivery runs for work clusters."""
from alembic import op
import sqlalchemy as sa

revision = '0018'
down_revision = '0017'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('work_clusters', sa.Column('message_text', sa.Text(), nullable=True))
    op.add_column('work_clusters', sa.Column('message_media_id', sa.String(36), nullable=True))
    op.add_column('work_clusters', sa.Column('message_media_type', sa.String(8), nullable=True))
    op.add_column('work_clusters', sa.Column('message_schedule_times', sa.JSON(), nullable=True))
    op.add_column('work_clusters', sa.Column('message_schedule_timezone', sa.String(64), nullable=False,
                                             server_default='Asia/Ho_Chi_Minh'))
    op.add_column('work_clusters', sa.Column('message_schedule_enabled', sa.Boolean(), nullable=False,
                                             server_default=sa.false()))
    op.execute("UPDATE work_clusters SET message_schedule_times = '[]' WHERE message_schedule_times IS NULL")
    op.add_column('worker_commands', sa.Column('message_run_id', sa.Uuid(), nullable=True))
    op.add_column('worker_commands', sa.Column('available_at', sa.DateTime(timezone=True), nullable=True))
    op.execute('UPDATE worker_commands SET available_at = created_at WHERE available_at IS NULL')
    op.create_index('ix_worker_commands_message_run_id', 'worker_commands', ['message_run_id'])
    op.create_table('cluster_message_runs',
        sa.Column('id', sa.Uuid(), primary_key=True),
        sa.Column('cluster_id', sa.Uuid(), nullable=False),
        sa.Column('slot_key', sa.String(80), nullable=False, unique=True),
        sa.Column('scheduled_for', sa.DateTime(timezone=True), nullable=False),
        sa.Column('status', sa.String(32), nullable=False),
        sa.Column('total_commands', sa.Integer(), nullable=False),
        sa.Column('completed_commands', sa.Integer(), nullable=False),
        sa.Column('result', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_index('ix_cluster_message_runs_cluster_id', 'cluster_message_runs', ['cluster_id'])


def downgrade():
    op.drop_index('ix_cluster_message_runs_cluster_id', table_name='cluster_message_runs')
    op.drop_table('cluster_message_runs')
    op.drop_index('ix_worker_commands_message_run_id', table_name='worker_commands')
    op.drop_column('worker_commands', 'available_at')
    op.drop_column('worker_commands', 'message_run_id')
    op.drop_column('work_clusters', 'message_schedule_enabled')
    op.drop_column('work_clusters', 'message_schedule_timezone')
    op.drop_column('work_clusters', 'message_schedule_times')
    op.drop_column('work_clusters', 'message_media_type')
    op.drop_column('work_clusters', 'message_media_id')
    op.drop_column('work_clusters', 'message_text')
