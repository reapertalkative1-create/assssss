"""A loop-enabled message cluster must survive per-sender problems between passes."""
import uuid
from datetime import timedelta

from sqlalchemy import select, update as sa_update

from app.crypto import build_secret_box
from app.models import ClusterMessageRun, TelegramAccount, WorkerCommand
from app.routers.work_clusters import continue_loop_sessions
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env  # noqa: F401


def _loop_cluster(env, senders=1):
    worker = env.make_worker()
    ids = []
    for index in range(senders):
        aid = env.make_account(f"LoopS{index}", worker)
        env.authorize(worker, aid)
        env.client.post(f"/api/accounts/{aid}/start", headers=env.h)
        ids.append(aid)
    created = env.client.post("/api/work-clusters", headers=env.h, json={
        "request_id": str(uuid.uuid4()), "name": f"Loop {uuid.uuid4().hex[:6]}", "account_ids": ids,
        "targets_text": "-1001111111111\n-1002222222222", "mode": "copy",
        "cluster_type": "message", "message_loop_enabled": True})
    assert created.status_code == 201, created.text
    cid = created.json()["id"]
    saved = env.client.put(f"/api/work-clusters/{cid}/message", headers=env.h, json={
        "text": "Loop body", "schedule_times": [], "timezone": "Asia/Ho_Chi_Minh",
        "schedule_enabled": False, "loop_enabled": True})
    assert saved.status_code == 200, saved.text
    started = env.client.post(f"/api/work-clusters/{cid}/start", headers=env.h,
                              json={"request_id": str(uuid.uuid4())})
    assert started.status_code == 201, started.text
    box = build_secret_box(env.settings.session_encryption_key.get_secret_value(),
                           env.settings.session_encryption_key_file)
    return cid, ids, box


def _close_open_pass(env, cid, *, account_id=None, flood_seconds=None, stop=False, fail=False):
    def _fn(db):
        async def _do(session):
            runs = (await session.execute(select(ClusterMessageRun).where(
                ClusterMessageRun.cluster_id == uuid.UUID(cid),
                ClusterMessageRun.status.in_(("queued", "running"))))).scalars().all()
            for run in runs:
                await session.execute(sa_update(WorkerCommand).where(
                    WorkerCommand.message_run_id == run.id).values(
                    status="failed" if fail else "done", error_code="flood_wait" if fail else None))
                run.completed_commands = run.total_commands
                run.status = "completed_with_errors" if fail else "completed"
            if account_id and (flood_seconds or stop):
                acct = await session.get(TelegramAccount, uuid.UUID(account_id))
                if flood_seconds:
                    acct.flood_wait_until = utcnow() + timedelta(seconds=flood_seconds)
                if stop:
                    acct.desired_state = "stopped"
            await session.flush()
        return _do(db)
    run_db(env.settings, _fn)


def _tick(env, box):
    async def _do(db):
        return await continue_loop_sessions(db, env.settings, box)
    return run_db(env.settings, _do)


def _passes(env, cid):
    return sorted(i["loop_pass"] for i in env.client.get(
        f"/api/work-clusters/{cid}/message-runs", headers=env.h).json()["items"])


def test_next_pass_starts_after_a_clean_pass(env):
    """Baseline: a finished pass without problems rolls straight into pass 2."""
    cid, _, box = _loop_cluster(env)
    _close_open_pass(env, cid)
    assert _tick(env, box) == 1
    assert _passes(env, cid) == [1, 2]


def test_a_flood_waited_sender_keeps_the_loop_alive_and_retries(env):
    """The bug: one sender on flood wait used to kill the loop silently. It must wait and retry."""
    cid, ids, box = _loop_cluster(env)
    _close_open_pass(env, cid, account_id=ids[0], flood_seconds=600, fail=True)
    assert _tick(env, box) == 0                       # nothing starts while the wait runs
    card = env.client.get(f"/api/work-clusters/{cid}", headers=env.h).json()
    assert card["loop_active"] is True                # the loop is still armed
    assert card["loop_block_reason"] == "flood_wait"
    assert card["loop_wait_until"]                    # card can show the retry deadline
    # Once the wait expires the very next tick produces the pass.
    def clear_flood(db):
        async def _do(session):
            acct = await session.get(TelegramAccount, uuid.UUID(ids[0]))
            acct.flood_wait_until = utcnow() - timedelta(seconds=1)
            await session.flush()
        return _do(db)
    run_db(env.settings, clear_flood)
    assert _tick(env, box) == 1
    assert _passes(env, cid) == [1, 2]


def test_one_flooded_sender_of_several_does_not_block_the_pass(env):
    """With two senders, the healthy one keeps the loop moving while the other waits."""
    cid, ids, box = _loop_cluster(env, senders=2)
    _close_open_pass(env, cid, account_id=ids[0], flood_seconds=600, fail=True)
    assert _tick(env, box) == 1
    assert _passes(env, cid) == [1, 2]


def test_loop_switches_off_with_a_reason_when_no_sender_can_send(env):
    """A stopped session is permanent: the loop stops but says why instead of looping forever."""
    cid, ids, box = _loop_cluster(env)
    _close_open_pass(env, cid, account_id=ids[0], stop=True)
    assert _tick(env, box) == 0
    card = env.client.get(f"/api/work-clusters/{cid}", headers=env.h).json()
    assert card["loop_active"] is False
    assert card["loop_block_reason"] == "senders_stopped"


def test_slot_keys_stay_unique_across_many_passes(env):
    """Regression: slot_key used to overflow VARCHAR(80), so every later pass was rejected."""
    from app.models import ClusterMessageRun
    cid, _, box = _loop_cluster(env)
    for expected in (2, 3, 4, 5):
        _close_open_pass(env, cid)
        assert _tick(env, box) == 1, f"pass {expected} was not created"
        assert _passes(env, cid) == list(range(1, expected + 1))

    def read_keys(db):
        async def _do(session):
            runs = (await session.execute(select(ClusterMessageRun).where(
                ClusterMessageRun.cluster_id == uuid.UUID(cid)))).scalars().all()
            return [r.slot_key for r in runs], [len(r.slot_key) for r in runs]
        return _do(db)
    keys, lengths = run_db(env.settings, read_keys)
    assert len(keys) == len(set(keys)), keys
    assert max(lengths) <= 80, lengths


def test_a_pass_error_is_recorded_not_swallowed(env, monkeypatch):
    """Regression: an unexpected INSERT error used to log nothing useful and look like a stall."""
    from app.routers import work_clusters as wc
    cid, _, box = _loop_cluster(env)
    _close_open_pass(env, cid)

    async def boom(*args, **kwargs):
        raise RuntimeError("column overflow simulation")
    monkeypatch.setattr(wc, "create_message_run", boom)
    assert _tick(env, box) == 0
    card = env.client.get(f"/api/work-clusters/{cid}", headers=env.h).json()
    assert card["loop_block_reason"] == "pass_error"
    assert card["loop_active"] is True
