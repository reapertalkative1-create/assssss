"""Guard the Windows launcher's release marker against stale frontend metadata."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def test_public_web_version_matches_release():
    expected = (ROOT / 'APP_VERSION').read_text(encoding='utf-8-sig').strip()
    actual = json.loads((ROOT / 'apps/web/public/version.json').read_text(encoding='utf-8-sig'))
    assert actual['version'] == expected

def test_docker_generates_version_from_release_before_build():
    dockerfile = (ROOT / 'docker/web.Dockerfile').read_text()
    assert 'COPY APP_VERSION /tmp/tfcc-app-version' in dockerfile
    assert dockerfile.index('COPY APP_VERSION') < dockerfile.index('RUN npm run build')
    assert "fs.writeFileSync('public/version.json'" in dockerfile
