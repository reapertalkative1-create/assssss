"""Continuous forwarding through real HTTP claim/start/result boundaries, no Telegram sends."""
import asyncio
import uuid
from datetime import timedelta
from types import SimpleNamespace

from sqlalchemy import select, update

from app.models import ForwardJob, ForwardRoute, TelegramAccount
from app.services.forward_loops import continue_forward_loops
from app.services.jobs import recover_abandoned
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env  # noqa: F401
from tests.unit.test_multi_senders import setup
from tests.unit.test_routes_jobs_api import WJ
from tests.unit.test_work_clusters import create
from worker.forwarding import ForwardEngine


def ready(env, senders=2, targets=6):
    worker, ids = setup(env, senders)
    worker.__class__ = WJ
    cluster, _ = create(env, ids, targets_text='\n'.join(f'@loop_group_{i}' for i in range(targets)),
                        post_link='https://t.me/loop_source/30', delay_seconds=5, delay_max_seconds=7)
    return worker, ids, cluster


def start(env, cluster, request_id=None):
    response = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h,
        json={'request_id': request_id or str(uuid.uuid4()), 'revision': cluster['revision']})
    assert response.status_code == 201, response.text
    return response.json()


def tick(env):
    return run_db(env.settings, lambda db: continue_forward_loops(db, env.settings, utcnow()))


def jobs(env):
    async def read(db):
        return list((await db.execute(select(ForwardJob))).scalars())
    return run_db(env.settings, read)


def elapsed(env):
    """Advance just the persisted job clock, without sleeping or changing account leases."""
    async def change(db):
        past = utcnow() - timedelta(seconds=120)
        await db.execute(update(ForwardJob).where(ForwardJob.finished_at.is_not(None)).values(
            finished_at=past, claimed_at=past, started_at=past))
        await db.execute(update(ForwardJob).where(ForwardJob.status == 'pending').values(available_at=past))
    run_db(env.settings, change)


def lease(worker, ids):
    for aid in ids:
        assert worker.lease(aid).status_code == 200


def card(env, cluster):
    return env.client.get('/api/work-clusters/' + cluster['id']).json()


def test_member_can_forward_without_calling_admin_guard(env):
    worker, ids, cluster = ready(env, targets=2)
    started = start(env, cluster)
    assert started['cluster']['loop_active'] and len(started['started']) == 2
    lease(worker, ids)
    claimed = worker.claim()
    assert len(claimed) == 2 and all(j['managed_targets_only'] is False for j in claimed)
    assert len({j['dest_peer'] for j in claimed}) == 2
    assert len(worker.start(claimed).json()['started']) == 2
    sent = []
    class Backend:
        async def assert_managed_destination(self, *args):
            raise AssertionError('Regular group members must not be rejected as non-admins')
        async def forward(self, handle, source, mid, dest, mode):
            assert source == '@loop_source' and mid == 30
            sent.append(dest)
            return len(sent)
    async def execute():
        engine = ForwardEngine(None, SimpleNamespace(handle_for=lambda aid: object()), Backend())
        return [await engine._run_job(job) for job in claimed]
    results = asyncio.run(execute())
    assert all(r['status'] == 'succeeded' for r in results)
    worker.results(results)
    assert card(env, cluster)['done_count'] == 2


def test_every_sender_visits_all_groups_each_pass_and_survives_scheduler_restarts(env, monkeypatch):
    from app.services import jobs as service
    shuffles = []
    def shuffle(destinations):
        shuffles.append(list(destinations))
        if len(shuffles) % 4 < 2:
            destinations.reverse()
    monkeypatch.setattr(service.random, 'shuffle', shuffle)
    worker, ids, cluster = ready(env)
    start(env, cluster)
    lease(worker, ids)
    for pass_no in range(1, 4):
        observed = []
        while len(observed) < 12:
            claimed = worker.claim()
            assert 1 <= len(claimed) <= 2
            assert len({j['dest_peer'] for j in claimed}) == len(claimed)
            assert len(worker.start(claimed).json()['started']) == len(claimed)
            worker.results([worker.ok(j) for j in claimed])
            observed += claimed
            elapsed(env)
        assert len({j['dest_peer'] for j in observed}) == 6
        for aid in ids:
            visits = [j['dest_peer'] for j in observed if j['account_id'] == aid]
            assert len(visits) == len(set(visits)) == 6
        assert len(jobs(env)) == pass_no * 12
        assert card(env, cluster)['loop_active'] is True
        # run_db uses a new engine/session each tick: all cursor state must be persisted.
        assert tick(env) == 2
        assert tick(env) == 0
        assert len(jobs(env)) == (pass_no + 1) * 12
    assert len(shuffles) == 8
    assert card(env, cluster)['loop_pass'] == 4
    assert len({j.idempotency_key for j in jobs(env)}) == 48


def test_failure_and_uncertain_delivery_skip_job_but_keep_sender_running(env):
    worker, ids, cluster = ready(env, senders=1, targets=3)
    start(env, cluster); lease(worker, ids)
    for code in ('admin_required', 'destination_forbidden', 'delivery_uncertain'):
        claimed = worker.claim()
        assert len(claimed) == 1
        worker.start(claimed)
        worker.results([worker.fail(claimed[0], code)])
        elapsed(env)
    current = card(env, cluster)
    assert current['loop_active'] and current['error_count'] == 3
    assert tick(env) == 1
    assert len(jobs(env)) == 6
    assert len(worker.claim()) == 1
    assert card(env, cluster)['loop_pass'] == 2


def test_flood_wait_blocks_only_affected_account_and_does_not_end_loop(env):
    worker, ids, cluster = ready(env, targets=2)
    start(env, cluster); lease(worker, ids)
    claimed = worker.claim(); worker.start(claimed)
    worker.results([worker.retry(claimed[0], 'flood_wait', 600), worker.ok(claimed[1])])
    elapsed(env)
    assert tick(env) == 0  # the healthy sender still has another group in its pass
    following = worker.claim()
    assert len(following) == 1 and following[0]['account_id'] == claimed[1]['account_id']
    worker.start(following); worker.results([worker.ok(following[0])]); elapsed(env)
    assert tick(env) == 1  # healthy sender repeats without waiting on the flooded sender
    assert card(env, cluster)['loop_active'] is True
    account = env.client.get('/api/accounts/' + claimed[0]['account_id']).json()
    assert account['flood_wait_until'] is not None


def test_next_pass_waits_for_the_previous_send_cooldown(env):
    worker, ids, cluster = ready(env, senders=1, targets=1)
    start(env, cluster); lease(worker, ids)
    first = worker.claim(); worker.start(first)
    worker.results([worker.ok(first[0])])
    assert tick(env) == 1
    rows = jobs(env)
    old = next(j for j in rows if j.status == 'succeeded')
    new = next(j for j in rows if j.status == 'pending')
    assert (new.available_at - old.finished_at).total_seconds() >= old.cooldown_seconds
    assert worker.claim() == []
    elapsed(env)
    assert len(worker.claim()) == 1


def test_all_failed_senders_wait_and_recover_without_pressing_start_again(env):
    worker, ids, cluster = ready(env, targets=2)
    async def restrict(db):
        for aid in ids:
            (await db.get(TelegramAccount, uuid.UUID(aid))).spam_status = 'limited'
    run_db(env.settings, restrict)
    failed = start(env, cluster)
    assert len(failed['failures']) == 2 and failed['cluster']['loop_active'] is True
    assert jobs(env) == [] and tick(env) == 0
    async def repair(db):
        for aid in ids:
            (await db.get(TelegramAccount, uuid.UUID(aid))).spam_status = 'clear'
        for route in (await db.execute(select(ForwardRoute))).scalars():
            route.link_config = {**route.link_config, 'retry_start_at': (utcnow()-timedelta(seconds=1)).isoformat()}
    run_db(env.settings, repair)
    assert tick(env) == 2
    lease(worker, ids)
    assert len(worker.claim()) == 2
    assert card(env, cluster)['error_count'] == 0


def test_stop_fences_claimed_jobs_future_passes_and_old_start_replays(env):
    worker, ids, cluster = ready(env, targets=2)
    request_id = str(uuid.uuid4())
    first = start(env, cluster, request_id); lease(worker, ids)
    repeated = start(env, cluster)
    assert repeated['batch_id'] == first['batch_id'] and len(jobs(env)) == 4
    claimed = worker.claim()
    stopped = env.client.post(f"/api/work-clusters/{cluster['id']}/stop", headers=env.h)
    assert stopped.status_code == 200 and stopped.json()['cluster']['loop_active'] is False
    assert worker.start(claimed).json()['started'] == []
    assert worker.claim() == [] and tick(env) == 0
    replay = start(env, cluster, request_id)
    assert replay['cluster']['loop_active'] is False and replay['cluster']['running'] is False
    assert len(jobs(env)) == 4
    restarted = start(env, cluster)
    assert restarted['cluster']['loop_active'] and restarted['batch_id'] != first['batch_id']
    assert len(jobs(env)) == 8


def test_more_senders_than_groups_all_get_a_turn_without_simultaneous_sends(env):
    worker, ids, cluster = ready(env, senders=3, targets=1)
    result = start(env, cluster)
    assert len(result['items']) == 3 and len(jobs(env)) == 3
    lease(worker, ids)
    seen = set()
    for _ in range(3):
        claimed = worker.claim()
        assert len(claimed) == 1
        assert claimed[0]['account_id'] not in seen
        seen.add(claimed[0]['account_id'])
        assert worker.claim() == []  # another sender cannot claim the occupied group
        worker.start(claimed); worker.results([worker.ok(claimed[0])]); elapsed(env)
    assert seen == set(ids)


def test_stopping_one_account_keeps_it_stopped_while_other_sender_loops(env):
    worker, ids, cluster = ready(env, targets=2)
    start(env, cluster); lease(worker, ids)
    claimed = worker.claim(); worker.start(claimed)
    worker.results([worker.ok(j) for j in claimed]); elapsed(env)
    assert env.client.post('/api/accounts/' + ids[0] + '/stop', headers=env.h).status_code == 200
    assert tick(env) == 0  # both senders still have a second group
    assert env.client.get('/api/accounts/' + ids[0]).json()['desired_state'] == 'stopped'
    following = worker.claim()
    assert len(following) == 1 and following[0]['account_id'] == ids[1]
    assert card(env, cluster)['loop_active'] is True


def test_new_draft_does_not_hide_the_active_loop_on_the_card(env):
    _worker, _ids, cluster = ready(env, targets=2)
    first = start(env, cluster)
    draft = env.client.post(f"/api/work-clusters/{cluster['id']}/runs", headers=env.h,
        json={'request_id': str(uuid.uuid4()), 'revision': cluster['revision']})
    assert draft.status_code == 201
    current = card(env, cluster)
    assert current['batch_id'] == first['batch_id']
    assert current['running'] and current['loop_active'] and current['total_count'] == 4


def test_recovery_after_worker_crash_keeps_other_groups_running(env):
    worker, ids, cluster = ready(env, senders=1, targets=2)
    result = start(env, cluster); lease(worker, ids)
    claimed = worker.claim(); worker.start(claimed)
    async def crash(db):
        job = await db.get(ForwardJob, uuid.UUID(claimed[0]['id']))
        job.lease_expires_at = utcnow() - timedelta(seconds=1)
        await db.flush()
        await recover_abandoned(db, utcnow(), env.settings)
    run_db(env.settings, crash)
    elapsed(env)
    route = env.client.get('/api/routes/' + result['items'][0]['id']).json()
    assert route['status'] == 'active'
    assert len(worker.claim()) == 1
    assert card(env, cluster)['loop_active'] is True


def test_each_sender_gets_full_list_without_rewriting_old_target_owners(env):
    from app.models import PostTargetOwner
    from app.services.post_links import target_ids
    worker, ids, cluster = ready(env, targets=3)
    old_owner = env.make_account('Existing one-off sender')
    refs = [f'@loop_group_{i}' for i in range(3)]
    destination_ids, _ = target_ids(refs)
    async def seed(db):
        for key in [*(f'ref:{r}' for r in refs), *(f'chat:{d}' for d in destination_ids)]:
            db.add(PostTargetOwner(target_key=key, account_id=uuid.UUID(old_owner)))
    run_db(env.settings, seed)
    result = start(env, cluster)
    assert result['failures'] == [] and len(result['items']) == 2
    assert all(set(r['link_config']['targets']) == set(refs) for r in result['items'])
    assert all(len({j.dest_chat_id for j in jobs(env) if str(j.account_id) == aid}) == 3 for aid in ids)
    async def owners(db):
        return set((await db.execute(select(PostTargetOwner.account_id))).scalars())
    assert run_db(env.settings, owners) == {uuid.UUID(old_owner)}
    lease(worker, ids)
    assert len(worker.claim()) == 2


def test_restart_mid_pass_keeps_pending_groups_and_does_not_repeat_completed_ones(env):
    worker, ids, cluster = ready(env, senders=1, targets=4)
    start(env, cluster); lease(worker, ids)
    original_ids = {j.id for j in jobs(env)}
    visited = set()
    for _ in range(3):
        claimed = worker.claim()
        assert len(claimed) == 1 and claimed[0]['dest_peer'] not in visited
        visited.add(claimed[0]['dest_peer'])
        worker.start(claimed); worker.results([worker.ok(claimed[0])]); elapsed(env)
        assert tick(env) == 0
        assert {j.id for j in jobs(env)} == original_ids


def test_concurrent_workers_never_claim_the_same_group_in_one_cluster(env):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    worker, ids, cluster = ready(env, targets=1)
    other = env.make_worker('second-worker'); other.__class__ = WJ
    response = env.client.put('/api/accounts/' + ids[1] + '/assignment', headers=env.h,
                              json={'worker_id': other.id})
    assert response.status_code == 200, response.text
    start(env, cluster); lease(worker, ids[:1]); lease(other, ids[1:])
    barrier = Barrier(2)
    def claim(w):
        barrier.wait(timeout=10)
        return w.claim()
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(claim, w) for w in (worker, other)]
        results = [f.result(timeout=20) for f in futures]
    assert sum(map(len, results)) == 1
    winner = 0 if results[0] else 1
    workers = (worker, other)
    workers[winner].start(results[winner])
    workers[winner].results([workers[winner].ok(results[winner][0])])
    assert len(workers[1-winner].claim()) == 1
