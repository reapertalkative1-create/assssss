"""Run/Stop straight from the cluster card, with per-group outcomes painted on the card."""
import uuid
from tests.unit.test_accounts_api import env  # noqa: F401  (pytest fixture)
from tests.unit.test_work_clusters import create as create_cluster
from tests.unit.test_multi_senders import setup
from tests.unit.test_routes_jobs_api import jw  # noqa: F401  (pytest fixture)


def _ready_message_cluster(env, targets='@group_one\n@group_two', loop=False):
    worker, ids = setup(env, 1)
    cluster, _ = create_cluster(env, ids, targets_text=targets, cluster_type='message', message_loop_enabled=loop)
    saved = env.client.put(f"/api/work-clusters/{cluster['id']}/message", headers=env.h, json={
        'text': 'Xin chao', 'schedule_times': [], 'timezone': 'Asia/Ho_Chi_Minh', 'schedule_enabled': False,
        'loop_enabled': loop})
    assert saved.status_code == 200, saved.text
    assert env.client.post(f'/api/accounts/{ids[0]}/start', headers=env.h).status_code == 200
    return worker, cluster, ids


def test_card_start_runs_a_single_random_pass_and_reports_stop(env):
    worker, cluster, ids = _ready_message_cluster(env)
    started = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={})
    assert started.status_code == 201, started.text
    body = started.json()
    assert body['kind'] == 'message' and body['run']['status'] in ('queued', 'completed')
    assert body['cluster']['running'] is True
    assert body['cluster']['run_status'] in ('queued', 'running')
    assert body['cluster']['total_count'] == 2
    assert body['cluster']['run_id'] == body['run']['id']
    # The listing paints the same live state on the card.
    listing = env.client.get('/api/work-clusters?kind=message', headers=env.h).json()['items']
    assert listing[0]['running'] is True and listing[0]['run_id'] == body['run']['id']
    commands = worker.poll()
    assert commands and all(c['type'] == 'send_message' for c in commands)
    # One destination only: each pass sends one random group and the loop goes on.
    assert len({c['payload']['dest'] for c in commands}) == 1
    stopped = env.client.post(f"/api/work-clusters/{cluster['id']}/stop", headers=env.h)
    assert stopped.status_code == 200, stopped.text
    assert stopped.json()['cluster']['running'] is False
    assert stopped.json()['cluster']['run_status'] == 'stopped'
    assert env.client.get('/api/work-clusters/' + cluster['id'], headers=env.h).json()['running'] is False


def test_card_shows_per_group_outcomes_as_they_arrive(env):
    worker, cluster, ids = _ready_message_cluster(env, targets='@group_one')
    started = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={}).json()
    run_id = started['run']['id']
    (cmd,) = worker.poll()
    assert worker.result(cmd['id'], result={'dest_ref': cmd['payload']['dest'], 'sent_message_id': 55}).status_code == 204
    card = env.client.get('/api/work-clusters/' + cluster['id'], headers=env.h).json()
    assert card['run_id'] == run_id
    assert [o['ref'] for o in card['outcomes']] == [cmd['payload']['dest']]
    assert card['outcomes'][0]['status'] == 'done'
    assert card['done_count'] == 1 and card['error_count'] == 0
    assert card['run_status'] == 'completed'
    assert card['running'] is False


def test_card_shows_a_failed_group_with_its_error_code(env):
    worker, cluster, _ids = _ready_message_cluster(env, targets='@group_one')
    env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={})
    (cmd,) = worker.poll()
    assert worker.result(cmd['id'], status='failed', error_code='destination_forbidden').status_code == 204
    card = env.client.get('/api/work-clusters/' + cluster['id'], headers=env.h).json()
    assert card['run_status'] == 'completed_with_errors'
    assert card['error_count'] == 1 and card['done_count'] == 0
    assert card['outcomes'][0]['error_code'] == 'destination_forbidden'


def test_card_start_refuses_a_second_pass_while_one_is_open_and_replays_safely(env):
    _worker, cluster, _ids = _ready_message_cluster(env)
    first = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={})
    assert first.status_code == 201, first.text
    again = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={})
    assert again.status_code == 409
    assert again.json()['error']['code'] == 'run_in_progress'
    # Idempotent replay of the same request returns the same run instead of a duplicate.
    request_id = str(uuid.uuid4())
    env.client.post(f"/api/work-clusters/{cluster['id']}/stop", headers=env.h)
    first_run = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h,
                                json={'request_id': request_id}).json()['run']['id']
    replay = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h,
                             json={'request_id': request_id})
    assert replay.status_code == 201
    assert replay.json()['run']['id'] == first_run


def test_loop_flag_keeps_the_card_running_until_stop(env):
    _worker, cluster, _ids = _ready_message_cluster(env, loop=True)
    started = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={}).json()
    assert started['cluster']['loop_active'] is True
    assert started['cluster']['running'] is True
    stopped = env.client.post(f"/api/work-clusters/{cluster['id']}/stop", headers=env.h).json()['cluster']
    assert stopped['loop_active'] is False and stopped['running'] is False


def test_forward_cluster_stop_without_a_batch_is_a_no_op(env):
    aid = env.make_account()
    cluster, _ = create_cluster(env, [aid], post_link='https://t.me/source_group/123')
    stopped = env.client.post(f"/api/work-clusters/{cluster['id']}/stop", headers=env.h)
    assert stopped.status_code == 200
    assert stopped.json()['stopped'] == 0
    card = env.client.get('/api/work-clusters/' + cluster['id'], headers=env.h).json()
    assert card['running'] is False and card['run_status'] is None


def test_forward_start_without_a_post_link_is_refused(env):
    aid = env.make_account()
    cluster, _ = create_cluster(env, [aid], post_link='')
    response = env.client.post(f"/api/work-clusters/{cluster['id']}/start", headers=env.h, json={})
    assert response.status_code == 422
    assert response.json()['error']['code'] == 'post_link_required'


def test_cluster_kinds_cannot_cross_their_endpoints(env):
    aid = env.make_account()
    message, _ = create_cluster(env, [aid], cluster_type='message')
    forward, _ = create_cluster(env, [aid], name='Forward one', post_link='https://t.me/source_group/9')
    wrong = env.client.post(f"/api/work-clusters/{forward['id']}/message-runs", headers=env.h, json={'request_id': str(uuid.uuid4())})
    assert wrong.status_code == 409 and wrong.json()['error']['code'] == 'wrong_cluster_type'
    # A message cluster without content reports the same friendly error as before.
    empty = env.client.post(f"/api/work-clusters/{message['id']}/start", headers=env.h, json={})
    assert empty.status_code == 422 and empty.json()['error']['code'] == 'message_empty'


def test_forward_card_lists_each_group_and_its_result(env, jw):
    from tests.unit.test_post_routes import DST, DST2
    st = jw()
    body = {'request_id': str(uuid.uuid4()), 'name': 'Forward card', 'account_ids': [st.aid],
            'targets_text': '@target_one\nhttps://t.me/target_two', 'delay_seconds': 60,
            'post_link': 'https://t.me/source_group/123'}
    cluster = env.client.post('/api/work-clusters', headers=env.h, json=body)
    assert cluster.status_code == 201, cluster.text
    cid = cluster.json()['id']
    started = env.client.post(f"/api/work-clusters/{cid}/start", headers=env.h, json={})
    assert started.status_code == 201, started.text
    result = started.json()
    assert result['kind'] == 'forward' and result['batch_id']
    # No pre-verification: the worker auto-joins each channel on demand, so the run starts at once.
    assert result['started'] == [result['items'][0]['id']] and not result['failures']
    pending = st.worker.poll()
    assert not pending, 'cluster start must not issue a verify_post command'
    route = env.client.get('/api/routes/' + result['items'][0]['id'], headers=env.h).json()
    assert route['status'] == 'active'
    card = env.client.get('/api/work-clusters/' + cid, headers=env.h).json()
    assert {o['ref'] for o in card['outcomes']} == {'@target_one', '@target_two'}
    assert card['total_count'] == 2
    assert card['batch_id'] == result['batch_id']
    assert card['running'] is True
    stopped = env.client.post(f"/api/work-clusters/{cid}/stop", headers=env.h)
    assert stopped.status_code == 200
    assert stopped.json()['cluster']['running'] is False
    assert all(o['status'] == 'stopped' for o in stopped.json()['cluster']['outcomes'])
