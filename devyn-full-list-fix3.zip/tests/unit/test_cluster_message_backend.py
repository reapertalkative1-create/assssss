import asyncio
from types import SimpleNamespace
import telethon.types as tt
from worker.telegram_backend import BackendError, TelethonBackend

class Chat: pass
class Channel: pass

def test_send_text_and_media_only_to_managed_group(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)
    calls=[]
    class Client:
        async def get_entity(self, dest):
            e=Chat(); e.left=False; e.kicked=False; e.broadcast=False
            return e
        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=False,is_creator=True,is_admin=False,post_messages=True,
                                   has_default_permissions=True,is_banned=False,
                                   participant=SimpleNamespace(left=False,banned_rights=None))
        async def send_message(self, entity, text, **kw):
            calls.append(('text',text,kw)); return SimpleNamespace(id=77)
        async def send_file(self, entity, path, **kw):
            calls.append(('file',path,kw)); return SimpleNamespace(id=78)
    backend=TelethonBackend(123,'a'*32);handle=SimpleNamespace(client=Client())
    assert asyncio.run(backend.send_message_payload(handle,'@group',{'text':'hello 😀'}))==77
    assert asyncio.run(backend.send_message_payload(handle,'@group',{'text':'caption','media_path':'/tmp/a.jpg','media_type':'photo'}))==78
    assert calls[0][1]=='hello 😀' and calls[1][2]['caption']=='caption'

def test_send_allows_plain_member_with_send_rights(monkeypatch):
    # Random-cluster sending targets up to 10k groups: the account is a member, not an admin.
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)
    sent=[]
    class Client:
        async def get_entity(self, dest):
            e=Chat(); e.left=False; e.kicked=False; e.broadcast=False
            return e
        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=False,is_creator=False,is_admin=False,
                                   has_default_permissions=True,is_banned=False,
                                   participant=SimpleNamespace(left=False,banned_rights=None))
        async def send_message(self, entity, text, **kw):
            sent.append(text); return SimpleNamespace(id=91)
    backend=TelethonBackend(123,'a'*32)
    assert asyncio.run(backend.send_message_payload(SimpleNamespace(client=Client()),'@group',{'text':'x'}))==91
    assert sent==['x']

def test_send_rejects_member_without_send_rights(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)
    back=BackendError('unused')
    class Client:
        async def get_entity(self, dest):
            e=Chat(); e.left=False; e.kicked=False; e.broadcast=False
            return e
        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=False,is_creator=False,is_admin=False,
                                   has_default_permissions=False,is_banned=True,
                                   participant=SimpleNamespace(left=False,banned_rights=None))
    backend=TelethonBackend(123,'a'*32)
    try: asyncio.run(backend.send_message_payload(SimpleNamespace(client=Client()),'@group',{'text':'x'}))
    except BackendError as exc: assert exc.code=='destination_forbidden'
    else: raise AssertionError('expected destination_forbidden')
