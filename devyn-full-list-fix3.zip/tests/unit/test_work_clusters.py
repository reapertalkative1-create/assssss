import uuid
from types import SimpleNamespace
from app.models import TelegramAccount
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_multi_senders import setup
from tests.unit.test_post_routes import verify
from tests.unit.test_routes_jobs_api import jw


def payload(ids, **extra):
    return {'request_id': str(uuid.uuid4()), 'name': 'Cụm khách hàng', 'account_ids': ids,
            'targets_text': '@target_one\nhttps://t.me/target_two', 'delay_seconds': 90, 'mode': 'copy', **extra}


def create(env, ids, **extra):
    body = payload(ids, **extra)
    response = env.client.post('/api/work-clusters', headers=env.h, json=body)
    assert response.status_code == 201, response.text
    return response.json(), body


def run(env, cluster, **extra):
    body = {'request_id': str(uuid.uuid4()), 'revision': cluster['revision'], 'post_link': 'https://t.me/source_group/123', **extra}
    response = env.client.post(f"/api/work-clusters/{cluster['id']}/runs", headers=env.h, json=body)
    assert response.status_code == 201, response.text
    return response.json(), body


def test_create_normalizes_and_persists_without_sending_and_retry_is_idempotent(env):
    aid = env.make_account()
    c, body = create(env, [aid, aid], name='  Khách   hàng  ', targets_text='@Target_one\nhttps://t.me/target_one\n# note')
    assert c['name'] == 'Khách hàng' and c['target_count'] == c['account_count'] == 1
    assert c['senders'] == [{'id': aid, 'name': 'acc1'}] and c['missing_account_ids'] == []
    assert env.client.get('/api/work-clusters/' + c['id']).json() == c
    replay = env.client.post('/api/work-clusters', headers=env.h, json=body)
    assert replay.status_code == 201 and replay.json()['id'] == c['id']
    assert env.client.post('/api/work-clusters', headers=env.h, json=payload([aid], name='KHÁCH HÀNG')).status_code == 409
    assert env.client.get('/api/work-clusters').json()['total'] == 1
    assert env.client.get('/api/routes').json()['total'] == env.client.get('/api/jobs').json()['total'] == 0


def test_daily_posts_snapshot_configuration_and_do_not_overwrite_history(env):
    worker, ids = setup(env, 2)
    c, original = create(env, ids)
    first, first_body = run(env, c)
    update = {k: v for k, v in original.items() if k != 'request_id'}
    update.update(revision=1, name='Cụm tháng mới', delay_seconds=120, targets_text='@new_group')
    changed = env.client.patch('/api/work-clusters/' + c['id'], headers=env.h, json=update)
    assert changed.status_code == 200, changed.text
    c2 = changed.json()
    assert c2['revision'] == 2
    assert env.client.patch('/api/work-clusters/' + c['id'], headers=env.h, json={**update, 'name': 'Stale edit'}).status_code == 409
    second, _ = run(env, c2, post_link='https://t.me/source_group/124')
    old = env.client.get('/api/post-routes/batches/' + first['batch_id']).json()['items']
    assert {r['link_config']['post_link'] for r in old} == {'https://t.me/source_group/123'}
    assert all(r['link_config']['delay_seconds'] == 90 and r['link_config']['work_cluster_name'] == c['name'] for r in old)
    assert second['items'][0]['link_config']['delay_seconds'] == 120
    assert second['items'][0]['link_config']['targets'] == ['@new_group']
    # A lost response can be recovered after a configuration update, without duplicating the run.
    replay = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=first_body)
    assert replay.status_code == 201 and replay.json()['items'][0]['id'] == old[0]['id']
    stale = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json={**first_body, 'request_id': str(uuid.uuid4())})
    assert stale.status_code == 409 and stale.json()['error']['code'] == 'cluster_changed'
    conflict = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json={**first_body, 'post_link': 'https://t.me/source_group/125'})
    assert conflict.status_code == 409
    history = env.client.get(f"/api/work-clusters/{c['id']}/runs", params={'page_size': 1}).json()
    assert history['total'] == 2 and len(history['items']) == 1
    assert history['items'][0]['batch_id'] == second['batch_id'] and history['items'][0]['started_count'] == 0
    old_route = old[0]
    attempted_edit = {'name': old_route['name'], 'account_id': old_route['account_id'], 'post_link': 'https://t.me/source_group/126',
                      'targets_text': '@target_one', 'mode': 'copy', 'delay_seconds': 5}
    assert env.client.patch('/api/post-routes/' + old_route['id'], headers=env.h, json=attempted_edit).status_code == 409
    assert env.client.get('/api/jobs').json()['total'] == 0 and worker.poll() == []


def test_deleted_ss_requires_explicit_configuration_repair(env):
    ids = [env.make_account('A'), env.make_account('B')]
    c, original = create(env, ids)
    async def mark(db): (await db.get(TelegramAccount, uuid.UUID(ids[1]))).__setattr__('pending_deletion', True)
    run_db(env.settings, mark)
    current = env.client.get('/api/work-clusters/' + c['id']).json()
    assert current['missing_account_ids'] == [ids[1]] and current['account_count'] == 2
    body = {'request_id': str(uuid.uuid4()), 'revision': 1, 'post_link': 'https://t.me/source_group/123'}
    assert env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=body).status_code == 409
    assert env.client.get('/api/routes').json()['total'] == 0
    repair = {k: v for k, v in original.items() if k != 'request_id'}
    repair.update(account_ids=ids[:1], revision=1)
    response = env.client.patch('/api/work-clusters/' + c['id'], headers=env.h, json=repair)
    assert response.status_code == 200 and response.json()['missing_account_ids'] == []
    created, _ = run(env, response.json())
    assert len(created['items']) == 1


def test_delete_keeps_accounts_and_created_runs(env):
    aid = env.make_account()
    c, _ = create(env, [aid])
    batch, body = run(env, c)
    assert env.client.delete('/api/work-clusters/' + c['id'], headers=env.h).status_code == 200
    assert env.client.get('/api/work-clusters/' + c['id']).status_code == 404
    assert env.client.get('/api/accounts/' + aid).status_code == 200
    assert env.client.get('/api/post-routes/batches/' + batch['batch_id']).status_code == 200
    replay = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=body)
    assert replay.status_code == 201 and replay.json()['batch_id'] == batch['batch_id']


def test_validation_is_atomic_and_search_treats_wildcards_literally(env):
    aid = env.make_account()
    for change, status in [({'name': '   '}, 422), ({'account_ids': [str(uuid.uuid4())]}, 409),
                           ({'targets_text': '@valid_group\nTên nhóm sai'}, 422), ({'delay_seconds': 0}, 422)]:
        response = env.client.post('/api/work-clusters', headers=env.h, json=payload([aid], **change))
        assert response.status_code == status, response.text
        if 'targets_text' in change: assert response.json()['error']['details']['invalid_targets'][0]['line'] == 2
    assert env.client.get('/api/work-clusters').json()['total'] == 0
    create(env, [aid], name='VIP 100%')
    create(env, [aid], name='Nhóm thường')
    found = env.client.get('/api/work-clusters', params={'q': '%'}).json()
    assert found['total'] == 1 and found['items'][0]['name'] == 'VIP 100%'
    assert env.client.get('/api/work-clusters', params={'q': 'NHÓM'}).json()['total'] == 1


def test_permissions_csrf_and_unknown_cluster(env, new_client, seed_user, login):
    aid = env.make_account()
    c, body = create(env, [aid])
    assert env.client.post('/api/work-clusters', json=body).status_code == 403
    seed_user('viewer', role='operator')
    viewer = new_client(); headers = login(viewer, 'viewer')
    assert viewer.get('/api/work-clusters/' + c['id']).status_code == 200
    assert viewer.post('/api/work-clusters', headers=headers, json=body).status_code == 403
    assert viewer.delete('/api/work-clusters/' + c['id'], headers=headers).status_code == 403
    assert viewer.post(f"/api/work-clusters/{c['id']}/runs", headers=headers, json={'request_id': str(uuid.uuid4()), 'revision': 1, 'post_link': 'https://t.me/source_group/123'}).status_code == 403
    assert env.client.get('/api/work-clusters/' + str(uuid.uuid4())).status_code == 404


def test_cluster_runs_keep_verification_restriction_and_duplicate_guards(env, jw):
    st = jw()
    c, _ = create(env, [st.aid])
    batch, _ = run(env, c)
    rid = batch['items'][0]['id']
    assert env.client.post(f'/api/routes/{rid}/start', headers=env.h).status_code == 409
    verify(env, st, rid)
    async def spam(db): (await db.get(TelegramAccount, uuid.UUID(st.aid))).__setattr__('spam_status', 'limited')
    run_db(env.settings, spam)
    assert env.client.post(f'/api/routes/{rid}/start', headers=env.h).status_code == 409
    assert env.client.get('/api/jobs').json()['total'] == 0
    async def clear(db): (await db.get(TelegramAccount, uuid.UUID(st.aid))).__setattr__('spam_status', 'clear')
    run_db(env.settings, clear)
    assert env.client.post(f'/api/routes/{rid}/start', headers=env.h).status_code == 200
    assert env.client.get('/api/jobs').json()['total'] == 2
    again, _ = run(env, c)
    next_id = again['items'][0]['id']
    verify(env, st, next_id)
    response = env.client.post(f'/api/routes/{next_id}/start', headers=env.h)
    assert response.status_code == 200, response.text
    assert response.json()['link_config']['duplicate_count'] == 2
    assert env.client.get('/api/jobs').json()['total'] == 2


def test_saved_post_and_interval_persist_and_run_without_retyping(env):
    aid = env.make_account()
    body = payload([aid], post_link='https://telegram.me/source_group/123', delay_seconds=150, delay_max_seconds=180)
    response = env.client.post('/api/work-clusters', headers=env.h, json=body)
    assert response.status_code == 201, response.text
    c = env.client.get('/api/work-clusters/' + response.json()['id']).json()
    assert c['post_link'] == 'https://t.me/source_group/123'
    assert (c['delay_seconds'], c['delay_max_seconds']) == (150, 180)
    run_body = {'request_id': str(uuid.uuid4()), 'revision': c['revision']}
    response = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=run_body)
    assert response.status_code == 201, response.text
    snapshot = response.json()['items'][0]['link_config']
    assert snapshot['post_link'] == c['post_link'] and snapshot['delay_max_seconds'] == 180
    assert snapshot['managed_targets_only'] is False
    patch = {k:v for k,v in body.items() if k != 'request_id'}
    patch.update(revision=c['revision'], post_link='https://t.me/source_group/124', delay_seconds=200, delay_max_seconds=240)
    assert env.client.patch('/api/work-clusters/' + c['id'], headers=env.h, json=patch).status_code == 200
    replay = env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=run_body)
    assert replay.status_code == 201 and replay.json()['items'][0]['link_config'] == snapshot
    run_body['request_id'] = str(uuid.uuid4())
    assert env.client.post(f"/api/work-clusters/{c['id']}/runs", headers=env.h, json=run_body).status_code == 409


def test_cluster_interval_defaults_and_reversed_bounds(env):
    body = payload([env.make_account()]);body.pop('delay_seconds')
    response = env.client.post('/api/work-clusters', headers=env.h, json=body)
    assert response.status_code == 201
    assert (response.json()['delay_seconds'], response.json()['delay_max_seconds']) == (150, 180)
    bad = {**body, 'request_id': str(uuid.uuid4()), 'name':'Invalid range', 'delay_seconds':180, 'delay_max_seconds':150}
    assert env.client.post('/api/work-clusters', headers=env.h, json=bad).status_code == 422
    assert env.client.get('/api/work-clusters').json()['total'] == 1


def test_cluster_allows_members_with_send_permission(env,jw):
    from tests.unit.test_routes_jobs_api import SRC,DST,DST2
    st=jw();c,_=create(env,[st.aid]);batch,_=run(env,c);rid=batch['items'][0]['id']
    assert env.client.post(f'/api/routes/{rid}/verify',headers=env.h).status_code == 202
    cmd=st.worker.poll()[0]
    targets=[{'index':i,'id':dst,'ok':True,'can_send':True,'can_manage':False} for i,dst in enumerate((DST,DST2))]
    assert st.worker.result(cmd['id'],result={'post':{'source_chat_id':SRC,'message_id':123,'targets':targets}}).status_code==204
    current=env.client.get('/api/routes/'+rid).json()
    assert all(t['can_send'] and t['error_code'] is None for t in current['link_config']['checks'])
    assert env.client.post(f'/api/routes/{rid}/start',headers=env.h).status_code==200
    assert env.client.get('/api/jobs').json()['total']==2


def test_cluster_random_spacing_is_persisted_and_enforced_after_completion(env,jw):
    from datetime import timedelta
    from sqlalchemy import select
    from app.models import ForwardJob
    from app.types import utcnow
    st=jw();c,_=create(env,[st.aid],delay_seconds=150,delay_max_seconds=180)
    batch,_=run(env,c);rid=batch['items'][0]['id'];verify(env,st,rid)
    assert env.client.post(f'/api/routes/{rid}/start',headers=env.h).status_code==200
    async def queued(db): return list((await db.execute(select(ForwardJob).where(ForwardJob.route_id==uuid.UUID(rid)).order_by(ForwardJob.available_at))).scalars())
    rows=run_db(env.settings,queued)
    assert all(150<=j.cooldown_seconds<=180 for j in rows)
    assert (rows[1].available_at-rows[0].available_at).total_seconds()==rows[0].cooldown_seconds
    first=st.worker.claim()[0];assert first['managed_targets_only'] is False
    async def finish(db,seconds):
        now=utcnow()
        for j in await queued(db):
            if str(j.id)==str(first['id']):
                j.status='succeeded';j.cooldown_seconds=180;j.finished_at=now-timedelta(seconds=seconds);j.claimed_at=j.finished_at
            else:j.available_at=now-timedelta(seconds=300)
    run_db(env.settings,lambda db:finish(db,170))
    assert st.worker.claim()==[]
    run_db(env.settings,lambda db:finish(db,190))
    assert len(st.worker.claim())==1


def test_cluster_shuffles_once_and_keeps_verification_and_queue_on_resume(env, jw, monkeypatch):
    from sqlalchemy import select
    from app.models import ForwardJob
    from tests.unit.test_routes_jobs_api import DST, DST2
    from app.services import jobs as jobsvc

    calls = []
    def reverse_destinations(destinations):
        calls.append(list(destinations))
        destinations.reverse()
    monkeypatch.setattr(jobsvc.random, 'shuffle', reverse_destinations)
    st = jw()
    cluster, _ = create(env, [st.aid], delay_seconds=150, delay_max_seconds=180)
    batch, _ = run(env, cluster)
    rid = batch['items'][0]['id']
    verify(env, st, rid)
    started = env.client.post(f'/api/routes/{rid}/start', headers=env.h)
    assert started.status_code == 200, started.text
    assert calls == [[DST, DST2]]
    assert started.json()['destination_chat_ids'] == [DST, DST2]

    async def queued(db):
        return list((await db.execute(select(ForwardJob).where(
            ForwardJob.route_id == uuid.UUID(rid)).order_by(ForwardJob.available_at))).scalars())
    before = run_db(env.settings, queued)
    assert [j.dest_chat_id for j in before] == [DST2, DST]
    assert len({j.dest_chat_id for j in before}) == 2
    assert all(150 <= j.cooldown_seconds <= 180 for j in before)
    for action in ('start', 'pause', 'resume'):
        response = env.client.post(f'/api/routes/{rid}/{action}', headers=env.h)
        assert response.status_code == 200, response.text
    after = run_db(env.settings, queued)
    assert [(j.id, j.dest_chat_id, j.available_at) for j in after] == [
        (j.id, j.dest_chat_id, j.available_at) for j in before]
    assert len(calls) == 1
