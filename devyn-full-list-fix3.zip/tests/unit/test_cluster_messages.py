import uuid
from tests.unit.test_accounts_api import env
from tests.unit.test_work_clusters import create
from tests.unit.test_multi_senders import setup


def test_message_schedule_validation_and_empty_content(env):
    aid=env.make_account(); cluster,_=create(env,[aid])
    bad=env.client.put(f"/api/work-clusters/{cluster['id']}/message",headers=env.h,
        json={'text':'','schedule_times':['09:00','09:00'],'timezone':'Asia/Ho_Chi_Minh','schedule_enabled':True})
    assert bad.status_code==422
    bad=env.client.put(f"/api/work-clusters/{cluster['id']}/message",headers=env.h,
        json={'text':'hello','schedule_times':['25:00'],'timezone':'Asia/Ho_Chi_Minh','schedule_enabled':True})
    assert bad.status_code==422
    good=env.client.put(f"/api/work-clusters/{cluster['id']}/message",headers=env.h,
        json={'text':'hello 😀','schedule_times':['18:30','09:00'],'timezone':'Asia/Ho_Chi_Minh','schedule_enabled':True})
    assert good.status_code==200,good.text
    assert good.json()['message_schedule_times']==['09:00','18:30']
    assert good.json()['message_schedule_enabled'] is True


def test_message_send_requires_ready_senders_and_valid_media(env):
    aid=env.make_account(); cluster,_=create(env,[aid],cluster_type='message')
    empty=env.client.post(f"/api/work-clusters/{cluster['id']}/message-runs",headers=env.h,json={'request_id':str(uuid.uuid4())})
    assert empty.status_code==422
    invalid=env.client.post(f"/api/work-clusters/{cluster['id']}/message-media",headers=env.h,
        files={'file':('bad.txt',b'not-image','image/jpeg')})
    assert invalid.status_code==422
    saved=env.client.put(f"/api/work-clusters/{cluster['id']}/message",headers=env.h,
        json={'text':'hello','schedule_times':[],'timezone':'Asia/Ho_Chi_Minh','schedule_enabled':False})
    assert saved.status_code==200
    unavailable=env.client.post(f"/api/work-clusters/{cluster['id']}/message-runs",headers=env.h,json={'request_id':str(uuid.uuid4())})
    assert unavailable.status_code==409 and unavailable.json()['error']['code']=='senders_unavailable'


def test_message_send_commands_are_randomized_encrypted_staggered_and_stoppable(env):
    worker,ids=setup(env,1)
    cluster,_=create(env,ids,targets_text='@target_one\n@target_two\n@target_three',delay_seconds=10,delay_max_seconds=20,cluster_type='message')
    env.client.put(f"/api/work-clusters/{cluster['id']}/message",headers=env.h,
        json={'text':'Hi there 😀','schedule_times':[],'timezone':'Asia/Ho_Chi_Minh','schedule_enabled':False})
    env.client.post(f'/api/accounts/{ids[0]}/start', headers=env.h)
    response=env.client.post(f"/api/work-clusters/{cluster['id']}/message-runs",headers=env.h,json={'request_id':str(uuid.uuid4())})
    assert response.status_code==201,response.text
    run=response.json(); commands=worker.poll()
    assert len(commands)==1
    assert all(c['type']=='send_message' and c['payload']['text']=='Hi there 😀' for c in commands)
    assert len({c['payload']['dest'] for c in commands})==1
    stopped=env.client.post(f"/api/work-clusters/{cluster['id']}/message-runs/{run['id']}/stop",headers=env.h)
    assert stopped.status_code==200


def test_message_clusters_are_separate_and_cannot_forward(env):
    aid=env.make_account()
    payload={'request_id':str(uuid.uuid4()),'name':'Message only','account_ids':[str(aid)],'targets_text':'@target_one','cluster_type':'message'}
    response=env.client.post('/api/work-clusters',headers=env.h,json=payload)
    assert response.status_code==201,response.text
    cluster=response.json()
    assert cluster['cluster_type']=='message'
    assert not env.client.get('/api/work-clusters?kind=forward',headers=env.h).json()['items']
    assert env.client.get('/api/work-clusters?kind=message',headers=env.h).json()['items'][0]['id']==cluster['id']
    response=env.client.post(f"/api/work-clusters/{cluster['id']}/runs",headers=env.h,json={'request_id':str(uuid.uuid4()),'revision':cluster['revision']})
    assert response.status_code==409
    assert response.json()['error']['code']=='message_cluster_route'


def test_loop_continues_after_pass_completes(env):
    """A loop-enabled message cluster starts pass 2 when pass 1 finishes."""
    from app.routers.work_clusters import continue_loop_sessions
    from tests.conftest import run_db
    w = env.make_worker()
    aid = env.make_account('LoopAcc', w)
    env.authorize(w, aid)
    env.client.post(f'/api/accounts/{aid}/start', headers=env.h)
    r = env.client.post('/api/work-clusters', headers=env.h, json={
        'request_id': str(uuid.uuid4()), 'name': 'Loop test', 'account_ids': [aid],
        'targets_text': '@group_one\n@group_two', 'mode': 'copy', 'cluster_type': 'message',
        'message_loop_enabled': True})
    assert r.status_code == 201, r.text
    cid = r.json()['id']
    saved = env.client.put(f'/api/work-clusters/{cid}/message', headers=env.h, json={
        'text': 'Hello loop', 'schedule_times': [], 'timezone': 'Asia/Ho_Chi_Minh',
        'schedule_enabled': False, 'loop_enabled': True})
    assert saved.status_code == 200, saved.text
    r2 = env.client.post(f'/api/work-clusters/{cid}/message-runs', headers=env.h, json={'request_id': str(uuid.uuid4())})
    assert r2.status_code == 201, r2.text
    assert r2.json()['loop_pass'] == 1
    c = env.client.get(f'/api/work-clusters/{cid}', headers=env.h).json()
    assert c['loop_active'] is True
    # Mark every command of pass 1 as finished so the pass counts as complete.
    from app.models import ClusterMessageRun, WorkerCommand
    from sqlalchemy import update as sa_update
    def finish_pass1(db):
        async def _do(s):
            run = await s.get(ClusterMessageRun, uuid.UUID(r2.json()['id']))
            await s.execute(sa_update(WorkerCommand).where(
                WorkerCommand.message_run_id == run.id).values(status='done'))
            run.completed_commands = run.total_commands
            run.status = 'completed'
            await s.flush()
        return _do(db)
    run_db(env.settings, finish_pass1)
    from app.crypto import build_secret_box
    box = build_secret_box(env.settings.session_encryption_key.get_secret_value(), env.settings.session_encryption_key_file)
    def run_continue():
        run_db(env.settings, lambda db: continue_loop_sessions(db, env.settings, box))
    run_continue()
    items = env.client.get(f'/api/work-clusters/{cid}/message-runs', headers=env.h).json()['items']
    assert len(items) >= 2, items
    passes = sorted(items, key=lambda x: x['loop_pass'])
    assert passes[0]['status'] in ('completed', 'completed_with_errors')
    assert passes[1]['loop_pass'] == 2 and passes[1]['status'] == 'queued'
    stop = env.client.post(f'/api/work-clusters/{cid}/loop/stop', headers=env.h)
    assert stop.status_code == 200
    assert env.client.get(f'/api/work-clusters/{cid}', headers=env.h).json()['loop_active'] is False

def test_loop_keeps_spinning_with_schedule_disabled(env):
    """User scenario: schedule OFF, loop ON, press Run once - every pass must spawn the next one."""
    from app.crypto import build_secret_box
    from app.models import ClusterMessageRun, WorkerCommand
    from app.routers.work_clusters import continue_loop_sessions
    from sqlalchemy import update as sa_update
    from tests.conftest import run_db
    w = env.make_worker()
    aid = env.make_account("LoopCard", w)
    env.authorize(w, aid)
    env.client.post(f"/api/accounts/{aid}/start", headers=env.h)
    r = env.client.post("/api/work-clusters", headers=env.h, json={
        "request_id": str(uuid.uuid4()), "name": "Loop card", "account_ids": [aid],
        "targets_text": "@group_one\n@group_two\n@group_three", "mode": "copy",
        "cluster_type": "message", "message_loop_enabled": True})
    assert r.status_code == 201, r.text
    cid = r.json()["id"]
    saved = env.client.put(f"/api/work-clusters/{cid}/message", headers=env.h, json={
        "text": "Loop body", "schedule_times": [], "timezone": "Asia/Ho_Chi_Minh",
        "schedule_enabled": False, "loop_enabled": True})
    assert saved.status_code == 200, saved.text
    started = env.client.post(f"/api/work-clusters/{cid}/start", headers=env.h, json={"request_id": str(uuid.uuid4())})
    assert started.status_code == 201, started.text
    box = build_secret_box(env.settings.session_encryption_key.get_secret_value(), env.settings.session_encryption_key_file)

    def finish_open_runs(s):
        async def _do(session):
            runs = (await session.execute(__import__("sqlalchemy").select(ClusterMessageRun).where(
                ClusterMessageRun.cluster_id == uuid.UUID(cid),
                ClusterMessageRun.status.in_(("queued", "running"))))).scalars().all()
            for run in runs:
                await session.execute(sa_update(WorkerCommand).where(
                    WorkerCommand.message_run_id == run.id).values(status="done"))
                run.completed_commands = run.total_commands
                run.status = "completed"
            await session.flush()
        return _do(s)

    passes = []
    for _ in range(4):
        run_db(env.settings, finish_open_runs)
        run_db(env.settings, lambda db: continue_loop_sessions(db, env.settings, box))
        items = env.client.get(f"/api/work-clusters/{cid}/message-runs", headers=env.h).json()["items"]
        passes = sorted((i["loop_pass"] for i in items))
    assert passes == [1, 2, 3, 4, 5], passes
    cluster = env.client.get(f"/api/work-clusters/{cid}", headers=env.h).json()
    assert cluster["loop_active"] is True
    assert cluster["running"] is True
