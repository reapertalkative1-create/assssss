"""Auto-join on not_joined: user-approved feature (account risk accepted by the user)."""
import asyncio
from types import SimpleNamespace
import telethon.types as tt
import telethon.functions as tf
from telethon import errors as terr
from worker.telegram_backend import BackendError, TelethonBackend


class Chat: pass
class Channel: pass


def _chat(**kw):
    e = Chat()
    e.left = False; e.kicked = False; e.broadcast = False; e.username = kw.get('username')
    return e


def test_autojoin_username_then_send(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)
    state = {'joined': False}
    joined = []
    sent = []

    class Client:
        async def get_entity(self, dest):
            if not state['joined']:
                raise ValueError('Cannot find any entity corresponding to "group"')
            return _chat(username='group')

        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=False, is_creator=False, is_admin=False,
                                   has_default_permissions=True, is_banned=False,
                                   participant=SimpleNamespace(left=False, banned_rights=None))

        async def send_message(self, entity, text, **kw):
            sent.append(text); return SimpleNamespace(id=4242)

        async def __call__(self, request):
            if isinstance(request, tf.channels.JoinChannelRequest):
                joined.append(request)
                state['joined'] = True
                return self
            raise AssertionError('unexpected request: %r' % (request,))

    backend = TelethonBackend(123, 'a'*32)
    handle = SimpleNamespace(client=Client())
    mid = asyncio.run(backend.send_message_payload(handle, '@group', {'text': 'hi'}))
    assert mid == 4242
    assert len(joined) == 1 and sent == ['hi']


def test_autojoin_invite_link_uses_import_invite(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)
    import_calls = []
    sent = []

    class InviteResult:
        chats = [_chat()]

    class Client:
        async def get_entity(self, dest):
            raise ValueError('no entity for invite link')

        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=False, is_creator=False, is_admin=False,
                                   has_default_permissions=True, is_banned=False,
                                   participant=SimpleNamespace(left=False, banned_rights=None))

        async def send_message(self, entity, text, **kw):
            sent.append(text); return SimpleNamespace(id=7)

        async def __call__(self, request):
            if isinstance(request, tf.messages.ImportChatInviteRequest):
                import_calls.append(request)
                return InviteResult()
            raise AssertionError('unexpected request: %r' % (request,))

    backend = TelethonBackend(123, 'a'*32)
    handle = SimpleNamespace(client=Client())
    mid = asyncio.run(backend.send_message_payload(handle, 'https://t.me/+AbCdEf123', {'text': 'yo'}))
    assert mid == 7
    assert len(import_calls) == 1
    assert import_calls[0].hash == 'AbCdEf123'
    assert sent == ['yo']


def test_floodwait_propagates_from_join(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)

    class Client:
        async def get_entity(self, dest):
            raise ValueError('missing')

        async def __call__(self, request):
            raise terr.FloodWaitError(request=None, capture=300)

    backend = TelethonBackend(123, 'a'*32)
    handle = SimpleNamespace(client=Client())
    try:
        asyncio.run(backend.send_message_payload(handle, '@group', {'text': 'x'}))
    except BackendError as exc:
        assert exc.code == 'flood_wait' and exc.retry_after == 300
    else:
        raise AssertionError('expected flood_wait to propagate')


def test_autojoin_failure_still_raises_not_joined(monkeypatch):
    monkeypatch.setattr(tt, 'Chat', Chat); monkeypatch.setattr(tt, 'Channel', Channel)

    class Client:
        async def get_entity(self, dest):
            raise ValueError('missing')

        async def __call__(self, request):
            return self

    backend = TelethonBackend(123, 'a'*32)
    handle = SimpleNamespace(client=Client())
    try:
        asyncio.run(backend.send_message_payload(handle, '@group', {'text': 'x'}))
    except BackendError as exc:
        assert exc.code == 'not_joined'
    else:
        raise AssertionError('expected not_joined')


def _perms():
    return SimpleNamespace(has_left=False, is_creator=False, is_admin=False,
                           has_default_permissions=True, is_banned=False,
                           post_messages=False,
                           participant=SimpleNamespace(left=False, banned_rights=None))


def test_autojoin_on_forward_mode(monkeypatch):
    """forward() must auto-join the destination chat before forwarding."""
    monkeypatch.setattr(tt, "Chat", Chat); monkeypatch.setattr(tt, "Channel", Channel)
    state = {"joined": False}
    joined, forwarded = [], []

    class Client:
        async def get_entity(self, dest):
            if not state["joined"]:
                raise ValueError("Cannot find any entity corresponding to the requested peer")
            return _chat(username="group")

        async def get_permissions(self, entity, me=None):
            return _perms()

        async def forward_messages(self, dest, message_id, from_peer=None):
            forwarded.append((dest, message_id, from_peer))
            return SimpleNamespace(id=99)

        async def __call__(self, request):
            if isinstance(request, tf.channels.JoinChannelRequest):
                joined.append(request)
                state["joined"] = True
                return self
            raise AssertionError("unexpected request: %r" % (request,))

    backend = TelethonBackend(123, "a" * 32)
    handle = SimpleNamespace(client=Client())
    mid = asyncio.run(backend.forward(handle, -100123, 55, "@group", "forward"))
    assert mid == 99
    assert len(joined) == 1
    assert forwarded == [("@group", 55, -100123)]


def test_autojoin_on_forward_mode_failure_raises_not_joined(monkeypatch):
    """If the join does not actually make the chat usable, forward must fail loudly."""
    monkeypatch.setattr(tt, "Chat", Chat); monkeypatch.setattr(tt, "Channel", Channel)
    forwarded = []

    class Client:
        async def get_entity(self, dest):
            raise ValueError("missing")

        async def get_permissions(self, entity, me=None):
            return SimpleNamespace(has_left=True)

        async def forward_messages(self, dest, message_id, from_peer=None):
            forwarded.append(dest)
            return SimpleNamespace(id=1)

        async def __call__(self, request):
            if isinstance(request, tf.channels.JoinChannelRequest):
                return self
            raise AssertionError("unexpected request: %r" % (request,))

    backend = TelethonBackend(123, "a" * 32)
    handle = SimpleNamespace(client=Client())
    try:
        asyncio.run(backend.forward(handle, -100123, 55, "@group", "forward"))
    except BackendError as exc:
        assert exc.code == "not_joined"
    else:
        raise AssertionError("expected not_joined")
    assert forwarded == []


def test_autojoin_on_copy_mode(monkeypatch):
    """copy mode (no forward header) must auto-join too, then resend the message."""
    monkeypatch.setattr(tt, "Chat", Chat); monkeypatch.setattr(tt, "Channel", Channel)
    state = {"joined": False}
    joined, sent = [], []

    class Client:
        async def get_entity(self, dest):
            if dest == -100123:
                return SimpleNamespace(noforwards=False)
            if not state["joined"]:
                raise ValueError("missing")
            return _chat(username="group")

        async def get_permissions(self, entity, me=None):
            return _perms()

        async def get_messages(self, source, ids=None):
            return SimpleNamespace(id=ids, empty=False, noforwards=False)

        async def send_message(self, entity, msg, **kw):
            sent.append((entity, msg.id))
            return SimpleNamespace(id=77)

        async def __call__(self, request):
            if isinstance(request, tf.channels.JoinChannelRequest):
                joined.append(request)
                state["joined"] = True
                return self
            raise AssertionError("unexpected request: %r" % (request,))

    backend = TelethonBackend(123, "a" * 32)
    handle = SimpleNamespace(client=Client())
    mid = asyncio.run(backend.forward(handle, -100123, 55, "@group", "copy"))
    assert mid == 77
    assert len(joined) == 1
    assert sent and sent[0][1] == 55
