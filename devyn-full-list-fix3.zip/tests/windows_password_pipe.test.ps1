﻿param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$PythonExe = 'python'
)
$ErrorActionPreference = 'Stop'
. (Join-Path $ProjectRoot 'scripts/windows.ps1') -NoBrowser
# Stand in for Docker with a real native process, so PowerShell actually encodes stdin.
function docker {
    [CmdletBinding(PositionalBinding=$false)]
    param([Parameter(ValueFromPipeline=$true)]$InputObject,
          [Parameter(ValueFromRemainingArguments=$true)][string[]]$Values)
    $InputObject | & $PythonExe @Values
}
$testPassword = '  Visible-ĐặcBiệt-9&|^%!"''\$🙂  '
$expected = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($testPassword))
$probe = @'
import base64, json, sys
raw = sys.stdin.buffer.read()
assert not raw.startswith(bytes([239,187,191])), "Unexpected UTF-8 BOM"
payload = json.loads(raw.decode("utf-8"))
expected = base64.b64decode(sys.argv[1]).decode("utf-8")
assert payload["password"] == expected and payload["password_confirm"] == expected, "Input changed"
print(json.dumps({"ok": True, "message": "Chữ có dấu"}, ensure_ascii=True))
'@
$payload = @{ username = 'test-admin'; password = $testPassword; password_confirm = $testPassword } | ConvertTo-Json -Compress
$result = Invoke-DockerJson -DockerArgs @('-c', $probe, $expected) -InputJson $payload
if ($result.ok -ne $true -or $result.message -cne 'Chữ có dấu') { throw 'Native UTF-8 JSON pipe failed.' }
Write-Host 'PASS: native stdin preserves Unicode, punctuation, case and spaces; no BOM; JSON response decoded.'
