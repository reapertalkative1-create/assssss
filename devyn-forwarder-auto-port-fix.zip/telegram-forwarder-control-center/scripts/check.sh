#!/usr/bin/env bash
# Runs every check that works without external services. Add TFCC_TEST_DATABASE_URL to also run the PostgreSQL variants.
set -euo pipefail
cd "$(dirname "$0")/.."
python -m pytest -m "not integration and not telegram_live"
(cd apps/web && npm run test && npm run build)
