"""Create local-development settings without overwriting existing configuration."""
import os
from pathlib import Path
import secrets
from cryptography.fernet import Fernet


def main():
    root = Path(__file__).resolve().parents[1]
    settings = '\n'.join([
        '# Local development only; keep this file private.',
        'TFCC_ENV=development',
        'TFCC_DATABASE_URL=sqlite+aiosqlite:///./data/tfcc-local.db',
        f'TFCC_SECRET_KEY={secrets.token_hex(32)}',
        f'TFCC_SESSION_ENCRYPTION_KEY={Fernet.generate_key().decode()}',
        'TFCC_COOKIE_SECURE=false',
        'TFCC_ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173',
        'TFCC_WORKER_CONTROL_PLANE_URL=http://localhost:8000',
        'TFCC_WORKER_CREDENTIAL=',
        '# Add real TFCC_WORKER_TELEGRAM_API_ID and TFCC_WORKER_TELEGRAM_API_HASH when ready.',
        '',
    ])
    try:
        fd = os.open(root/'.env', os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise SystemExit('.env already exists; kept unchanged.')
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        stream.write(settings)
    (root/'data').mkdir(exist_ok=True)
    print('Created local settings. Next: python -m alembic upgrade head')


if __name__ == '__main__':
    main()
