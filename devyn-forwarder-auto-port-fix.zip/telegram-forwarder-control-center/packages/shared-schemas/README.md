# shared-schemas
Machine-readable contracts shared by api / worker / web. Phase 1 holds the job state machine only;
API payload schemas are added from Phase 2 onwards.
