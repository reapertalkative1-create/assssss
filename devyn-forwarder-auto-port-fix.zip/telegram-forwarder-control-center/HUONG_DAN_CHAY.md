# Windows: cách được khuyến nghị

Để chạy trong môi trường riêng, dùng `setup.cmd` và `run.cmd`; xem [HUONG_DAN_WINDOWS.md](HUONG_DAN_WINDOWS.md). Phần sau là cách chạy thủ công cũ.

# Chạy bản khôi phục

Yêu cầu Python >=3.11 và Node.js >=18. Chạy các lệnh từ thư mục chứa README.md.

1. `python -m venv .venv`
2. Kích hoạt môi trường: Linux/macOS `source .venv/bin/activate`; Windows PowerShell `.venv\Scripts\Activate.ps1`; Windows CMD `.venv\Scripts\activate.bat`.
3. `python -m pip install -e "apps/api[dev]" -e "workers/telegram-worker[dev]"`
4. Với cài đặt mới: `python scripts/init_local.py`
5. `python -m alembic upgrade head`
6. `python -m app.cli create-admin admin` — nhập mật khẩu riêng, ít nhất 12 ký tự, không chứa tên đăng nhập.
7. Terminal thứ nhất: `python -m uvicorn app.main:app --app-dir apps/api --host 127.0.0.1 --port 8000`
8. Terminal thứ hai: `cd apps/web`, chạy `npm ci`, rồi `npm run dev -- --host 127.0.0.1`.
9. Mở http://127.0.0.1:5173 và đăng nhập.

Script local dùng SQLite và tự tạo khóa riêng, không ghi đè .env có sẵn. Nếu cập nhật cài đặt cũ, giữ nguyên .env, khóa mã hóa và database; không tạo khóa mới cho dữ liệu cũ.

Trong UI tạo worker và lưu credential. Thêm URL/credential vào .env trên máy worker:

```dotenv
TFCC_WORKER_CONTROL_PLANE_URL=http://localhost:8000
TFCC_WORKER_CREDENTIAL=credential-cua-ban
```

Điền giá trị kết nối thật. API ID/hash được nhập trên web cho từng tài khoản. Chạy worker từ thư mục gốc đã kích hoạt .venv:

```sh
python -m worker.main check-config
python -m worker.main run
```

Trong UI: Thêm tài khoản Telegram → chọn worker → nhập api_id/api_hash lấy tại https://my.telegram.org → đăng nhập OTP/2FA → bật tài khoản → tạo tuyến → verify → start. Máy worker ở xa cần HTTPS; không chuyển khóa mã hóa của API sang worker.

SQLite/Vite chỉ dùng cho local. Triển khai thực tế cần PostgreSQL, HTTPS, TFCC_ENV=production và cookie_secure=true. Chưa kiểm thử Telegram thật. At-least-once có thể gửi trùng nếu worker chết đúng lúc Telegram đã nhận tin nhưng API chưa nhận kết quả.

Kiểm thử: `python -m pytest -m "not integration and not telegram_live"`; trong apps/web chạy `npm test` và `npm run build`. Không đặt TFCC_TEST_DATABASE_URL trỏ vào database thật vì kiểm thử sẽ xóa/tạo lại bảng.

Bản này được khôi phục từ ZIP gốc và các thay đổi đã ghi trong cuộc trò chuyện; không phải bản sao bit-for-bit của ZIP trước đã mất. Bản đăng nhập web bổ sung migration 0005; chạy alembic upgrade head trước khi khởi động API mới.
