"""Pure template rendering and a conservative SpamBot description-step guard."""
import re
from worker.telegram_backend import BackendError


def render(template,name,phone,email):
    fields=re.findall(r'\{([^{}]+)\}',template)
    if any(f not in ('name','phone','email') for f in fields):raise BackendError('appeal_template_invalid')
    values={'name':name,'phone':phone or '', 'email':email or ''}
    if 'phone' in fields and not values['phone']:raise BackendError('appeal_phone_missing')
    if 'email' in fields and not values['email']:raise BackendError('appeal_email_missing')
    text=re.sub(r'\{(name|phone|email)\}',lambda m:values[m[1]],template).strip()
    if not 1<=len(text)<=4000:raise BackendError('appeal_text_too_long')
    return text


def ready_prompt(text):
    value=' '.join(text.casefold().split())
    return any(re.search(pattern,value) for pattern in (
        r'please write us (?:some )?details about your case',
        r'please (?:tell us|provide) (?:some |more )?(?:details|information).*about your case',
        r'please describe (?:your |the )?(?:case|problem|issue|reason)',
        r'расскажите.*подробнее.*(?:случа|огранич|почему)',
    ))


async def prepare(client,template,name,email='',phone_override=''):
    import hashlib
    from worker.spambot import peer_for
    me=await client.get_me()
    phone=phone_override or str(getattr(me,'phone','') or '')
    phone=('+'+phone.lstrip('+')) if phone else ''
    text=render(template,name,phone,email)
    peer=await peer_for(client)
    messages=await client.get_messages(peer,limit=5)
    latest=next((m for m in messages if not getattr(m,'out',False) and getattr(m,'sender_id',None)==peer.id),None)
    if latest is None or not ready_prompt(latest.raw_text or ''):raise BackendError('appeal_not_ready')
    return {'text':text,'expected_reply_id':latest.id,
            'expected_prompt_hash':hashlib.sha256((latest.raw_text or '').encode()).hexdigest()}
