"""Machine resource sampling. Only sent when the control plane allows it for this worker."""
try:
    import psutil
except ImportError:  # resource reporting is optional
    psutil = None


def collect_resources() -> dict | None:
    if psutil is None:
        return None
    try:
        return {
            "cpu_percent": round(float(psutil.cpu_percent(interval=None)), 1),
            "memory_percent": round(float(psutil.virtual_memory().percent), 1),
        }
    except Exception:
        return None
