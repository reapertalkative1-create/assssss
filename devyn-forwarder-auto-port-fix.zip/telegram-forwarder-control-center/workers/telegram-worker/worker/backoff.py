import random
from collections.abc import Callable


class Backoff:
    """Exponential backoff with full jitter: delay ~ U(0, min(cap, base * 2**attempt))."""

    def __init__(self, base: float = 1.0, cap: float = 60.0, rng: Callable[[], float] = random.random):
        if base <= 0 or cap < base:
            raise ValueError("require 0 < base <= cap")
        self.base, self.cap, self._rng = base, cap, rng
        self.attempt = 0

    def next(self) -> float:
        ceiling = min(self.cap, self.base * (2 ** self.attempt))
        self.attempt = min(self.attempt + 1, 32)
        return self._rng() * ceiling

    def reset(self) -> None:
        self.attempt = 0
