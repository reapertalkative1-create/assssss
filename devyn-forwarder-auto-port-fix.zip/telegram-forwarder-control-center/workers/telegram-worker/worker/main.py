"""Worker CLI:  tfcc-worker run | check-config | version"""
import argparse
import asyncio
import signal
import socket
import sys

from worker import __version__
from worker.accounts import AccountManager
from worker.client import ControlPlaneClient
from worker.forwarding import ForwardEngine
from worker.config import get_worker_settings
from worker.logging_setup import setup_logging
from worker.resources import collect_resources
from worker.runner import EXIT_CONFIG, Runner


def _missing(s) -> list[str]:
    required = {
        "TFCC_WORKER_CONTROL_PLANE_URL": s.control_plane_url,
        "TFCC_WORKER_CREDENTIAL": s.credential.get_secret_value(),
    }
    return [name for name, value in required.items() if not value]


def _install_signal_handlers(loop: asyncio.AbstractEventLoop, runner: Runner) -> None:
    def request_stop(*_):
        loop.call_soon_threadsafe(runner.stop)

    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):  # SIGBREAK exists on Windows only
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, request_stop)
            except (ValueError, OSError):
                pass


async def _run(s) -> int:
    client = ControlPlaneClient(s.control_plane_url, s.credential.get_secret_value())
    from worker.account_backend import AccountTelegramBackend
    backend = AccountTelegramBackend(client, s.telegram_api_id, s.telegram_api_hash.get_secret_value())
    manager = AccountManager(client, backend)
    engine = ForwardEngine(client, manager, backend)
    manager.listeners.append(engine)
    runner = Runner(client, platform=s.platform, version=__version__, hostname=s.hostname or socket.gethostname(),
                    resource_provider=collect_resources, accounts=manager, engine=engine)
    _install_signal_handlers(asyncio.get_running_loop(), runner)
    try:
        return await runner.run()
    finally:
        await client.aclose()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="tfcc-worker")
    parser.add_argument("command", choices=["run", "check-config", "version"])
    args = parser.parse_args(argv)

    if args.command == "version":
        print(__version__)
        return 0

    s = get_worker_settings()
    missing = _missing(s)
    if args.command == "check-config":
        print(f"platform={s.platform} name={s.name} version={__version__} telegram_api=per-account-web legacy_env={'configured' if s.telegram_configured else 'not configured'}")  # never print secrets
        if missing:
            print("missing: " + ", ".join(missing))
            return EXIT_CONFIG
        print("config ok")
        return 0

    setup_logging()
    if missing:
        print("missing: " + ", ".join(missing), file=sys.stderr)
        return EXIT_CONFIG
    return asyncio.run(_run(s))


if __name__ == "__main__":
    raise SystemExit(main())
