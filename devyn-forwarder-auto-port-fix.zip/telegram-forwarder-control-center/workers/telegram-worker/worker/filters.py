"""Message filters, evaluated on the worker. Message text never leaves the worker: the API only ever sees ids."""
from worker.telegram_backend import MessageFacts


def matches(filters: dict, m: MessageFacts) -> bool:
    if m.is_service:
        return False
    if m.outgoing and not filters.get("include_outgoing"):
        return False  # our own messages (including our copies) are ignored by default: prevents forwarding loops
    types = filters.get("content_types") or []
    if types and m.kind not in types:
        return False
    text = m.text.lower()
    include = filters.get("keywords_include") or []
    if include and not any(k in text for k in include):
        return False
    if any(k in text for k in (filters.get("keywords_exclude") or [])):
        return False
    return True
