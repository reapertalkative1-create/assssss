"""Shared fixtures. Every API test runs on SQLite; the same tests also run on PostgreSQL
when TFCC_TEST_DATABASE_URL is set (marked 'integration', skipped otherwise)."""
import asyncio
import os
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

import app.models  # noqa: F401
from app.config import Settings
from app.db import Base, make_engine, make_sessionmaker
from app.main import create_app
from app.models import AuditLog, Role, User
from app.security import hash_password
from app.types import utcnow

from cryptography.fernet import Fernet

TEST_KEY = Fernet.generate_key().decode()
PASSWORD = "Correct-Horse-Battery-9"
NEW_PASSWORD = "Another-Strong-Passphrase-7"


@pytest.fixture(
    params=[pytest.param("sqlite", id="sqlite"), pytest.param("postgres", id="postgres", marks=pytest.mark.integration)]
)
def database_url(request, tmp_path):
    if request.param == "sqlite":
        return f"sqlite+aiosqlite:///{tmp_path / 'test.db'}"
    url = os.environ.get("TFCC_TEST_DATABASE_URL")
    if not url:
        pytest.skip("TFCC_TEST_DATABASE_URL not set")
    return url


def run_db(settings: Settings, fn):
    """Run `async def fn(session)` against the test DB on a private engine/loop; commits afterwards."""

    async def _go():
        engine = make_engine(settings.database_url)
        try:
            async with make_sessionmaker(engine)() as s:
                result = await fn(s)
                await s.commit()
                return result
        finally:
            await engine.dispose()

    return asyncio.run(_go())


@pytest.fixture
def settings(database_url):
    async def _reset():
        engine = make_engine(database_url)
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
            await conn.run_sync(Base.metadata.create_all)
        await engine.dispose()

    asyncio.run(_reset())
    return Settings(
        env="development", database_url=database_url, secret_key="x" * 32, session_encryption_key=TEST_KEY,
        cookie_secure=False, login_lock_threshold=3, login_lock_base_seconds=60,
        login_ip_max_attempts=50, worker_sweep_interval_seconds=0, worker_auth_ip_max_attempts=50,
    )


@pytest.fixture
def client(settings):
    with TestClient(create_app(settings), base_url="http://testserver") as c:
        yield c


@pytest.fixture
def new_client(settings):
    """Factory for extra independent clients (separate cookie jars), e.g. two users at once."""
    stack = []

    def _make():
        c = TestClient(create_app(settings), base_url="http://testserver")
        c.__enter__()
        stack.append(c)
        return c

    yield _make
    for c in stack:
        c.__exit__(None, None, None)


@pytest.fixture
def seed_user(settings):
    def _seed(username="alice", role=Role.ADMIN, password=PASSWORD, active=True) -> str:
        async def _do(s):
            u = User(username=username, password_hash=hash_password(password), role=role, is_active=active)
            s.add(u)
            await s.flush()
            return str(u.id)

        return run_db(settings, _do)

    return _seed


@pytest.fixture
def login():
    def _login(client, username="alice", password=PASSWORD) -> dict:
        r = client.post("/api/auth/login", json={"username": username, "password": password})
        assert r.status_code == 200, r.text
        return {"X-CSRF-Token": r.json()["csrf_token"]}

    return _login


@pytest.fixture
def audit_rows(settings):
    def _rows(action=None):
        async def _do(s):
            stmt = select(AuditLog).order_by(AuditLog.id)
            if action:
                stmt = stmt.where(AuditLog.action == action)
            return [
                {"action": r.action, "actor": r.actor_username, "details": r.details, "ip": r.ip,
                 "request_id": r.request_id, "target_id": r.target_id}
                for r in (await s.execute(stmt)).scalars()
            ]

        return run_db(settings, _do)

    return _rows


@pytest.fixture
def age_session(settings):
    """Pretend a user's sessions were last used `seconds` ago."""

    def _age(seconds: int):
        from app.models import WebSession

        async def _do(s):
            for ws in (await s.execute(select(WebSession))).scalars():
                ws.last_seen_at = utcnow() - timedelta(seconds=seconds)

        run_db(settings, _do)

    return _age
