import pytest

from worker.filters import matches
from worker.telegram_backend import MessageFacts


def msg(text="", kind="text", outgoing=False, service=False):
    return MessageFacts(-100, 1, text, kind, outgoing, service)


@pytest.mark.parametrize("filters,message,expected", [
    ({}, msg("anything"), True),
    ({}, msg("", "photo"), True),                                              # no text at all is fine without keyword rules
    ({}, msg("hello", service=True), False),                                   # join/leave/pin notices are never forwarded
    ({}, msg("mine", outgoing=True), False),                                   # own messages ignored by default (loop guard)
    ({"include_outgoing": True}, msg("mine", outgoing=True), True),
    ({"content_types": ["photo", "video"]}, msg("x", "photo"), True),
    ({"content_types": ["photo", "video"]}, msg("x", "text"), False),
    ({"content_types": ["text"]}, msg("x", "sticker"), False),
    ({"keywords_include": ["sale", "giá rẻ"]}, msg("Big SALE today"), True),   # case-insensitive, any keyword
    ({"keywords_include": ["sale", "giá rẻ"]}, msg("Nhà GIÁ RẺ quận 7"), True),  # Vietnamese diacritics
    ({"keywords_include": ["sale"]}, msg("nothing here"), False),
    ({"keywords_include": ["sale"]}, msg("", "photo"), False),                 # a photo without caption cannot match
    ({"keywords_exclude": ["spam"]}, msg("this is SPAM"), False),
    ({"keywords_exclude": ["spam"]}, msg("clean"), True),
    ({"keywords_include": ["sale"], "keywords_exclude": ["spam"]}, msg("sale spam"), False),
    ({"keywords_include": ["sale"], "keywords_exclude": ["spam"], "content_types": ["text"]}, msg("sale now"), True),
    ({"keywords_include": ["sale"], "content_types": ["photo"]}, msg("sale now", "text"), False),
])
def test_filter_matrix(filters, message, expected):
    assert matches(filters, message) is expected
