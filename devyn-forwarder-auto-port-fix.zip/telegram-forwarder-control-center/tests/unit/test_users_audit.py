from app.models import Role
from tests.conftest import NEW_PASSWORD, PASSWORD


def test_operator_is_forbidden_from_admin_endpoints(client, seed_user, login):
    seed_user("op", role=Role.OPERATOR)
    h = login(client, "op")
    assert client.get("/api/users").status_code == 403
    assert client.post("/api/users", headers=h, json={"username": "x-user", "password": PASSWORD}).status_code == 403
    assert client.get("/api/audit").status_code == 403


def test_admin_creates_lists_and_searches_users(client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    r = client.post("/api/users", headers=h, json={"username": "Dave", "password": PASSWORD, "role": "operator"})
    assert r.status_code == 201
    assert r.json()["username"] == "dave" and "password" not in r.text
    assert client.post("/api/users", headers=h, json={"username": "dave", "password": PASSWORD}).status_code == 409
    assert client.post("/api/users", headers=h, json={"username": "eve-user", "password": "short"}).status_code == 422
    assert client.post("/api/users", headers=h, json={"username": "Bad Name!", "password": PASSWORD}).status_code == 422
    assert client.post("/api/users", headers=h, json={"username": "frank", "password": PASSWORD, "role": "root"}).status_code == 422

    page = client.get("/api/users", params={"page_size": 1}).json()
    assert page["total"] == 2 and len(page["items"]) == 1
    assert [u["username"] for u in client.get("/api/users", params={"q": "dav"}).json()["items"]] == ["dave"]
    assert client.get("/api/users", params={"page_size": 1000}).status_code == 422


def test_new_user_can_login_with_assigned_role(client, new_client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    client.post("/api/users", headers=h, json={"username": "dave", "password": PASSWORD, "role": "operator"})
    other = new_client()
    login(other, "dave")
    assert other.get("/api/users").status_code == 403


def test_admin_cannot_modify_self(client, seed_user, login):
    uid = seed_user("admin1")
    h = login(client, "admin1")
    for body in ({"role": "operator"}, {"is_active": False}, {"password": NEW_PASSWORD}):
        r = client.patch(f"/api/users/{uid}", headers=h, json=body)
        assert r.status_code == 409 and r.json()["error"]["code"] == "cannot_modify_self"
    assert client.patch(f"/api/users/{uid}", headers=h, json={"role": "admin"}).status_code == 200  # no-op allowed


def test_deactivation_revokes_target_sessions(client, new_client, seed_user, login):
    seed_user("admin1")
    target_id = seed_user("victim", role=Role.OPERATOR)
    h = login(client, "admin1")
    victim = new_client()
    login(victim, "victim")
    assert victim.get("/api/auth/me").status_code == 200
    assert client.patch(f"/api/users/{target_id}", headers=h, json={"is_active": False}).status_code == 200
    assert victim.get("/api/auth/me").status_code == 401
    assert client.post("/api/auth/login", json={"username": "victim", "password": PASSWORD}).status_code == 401


def test_admin_password_reset_and_unlock(client, new_client, seed_user, login):
    seed_user("admin1")
    target_id = seed_user("victim", role=Role.OPERATOR)
    h = login(client, "admin1")
    victim = new_client()
    login(victim, "victim")
    for _ in range(3):  # lock the account
        new_client().post("/api/auth/login", json={"username": "victim", "password": "wrong-wrong-1"})
    r = client.patch(f"/api/users/{target_id}", headers=h, json={"password": NEW_PASSWORD, "unlock": True})
    assert r.status_code == 200 and r.json()["locked_until"] is None
    assert victim.get("/api/auth/me").status_code == 401  # old sessions revoked
    assert client.patch(f"/api/users/{target_id}", headers=h, json={"password": "short"}).status_code == 422
    fresh = new_client()
    assert fresh.post("/api/auth/login", json={"username": "victim", "password": NEW_PASSWORD}).status_code == 200


def test_update_unknown_user_and_extra_fields(client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    assert client.patch("/api/users/00000000-0000-0000-0000-000000000000", headers=h, json={"is_active": True}).status_code == 404
    assert client.get("/api/users/not-a-uuid").status_code == 422
    uid = seed_user("zed", role=Role.OPERATOR)
    assert client.patch(f"/api/users/{uid}", headers=h, json={"password_hash": "x"}).status_code == 422


def test_audit_trail_records_sensitive_actions(client, seed_user, login, audit_rows):
    seed_user("admin1")
    h = login(client, "admin1")
    r = client.post("/api/users", headers=h, json={"username": "dave", "password": PASSWORD})
    uid = r.json()["id"]
    client.patch(f"/api/users/{uid}", headers=h, json={"role": "admin"})
    actions = [a["action"] for a in audit_rows()]
    assert actions == ["auth.login", "user.create", "user.update"]
    created = audit_rows("user.create")[0]
    assert created["actor"] == "admin1" and created["target_id"] == uid and created["request_id"]
    assert PASSWORD not in repr(audit_rows())

    api = client.get("/api/audit", params={"action": "user."}).json()
    assert api["total"] == 2 and api["items"][0]["action"] == "user.update"
    assert client.get("/api/audit", params={"actor": "admin1", "page_size": 1}).json()["total"] == 3
    assert client.get("/api/audit", params={"action": "auth.login"}).json()["total"] == 1


def test_audit_has_no_write_endpoints(client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    for m in ("post", "put", "patch", "delete"):
        assert getattr(client, m)("/api/audit", headers=h).status_code == 405
