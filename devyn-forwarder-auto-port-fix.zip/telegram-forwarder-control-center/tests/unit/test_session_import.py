import asyncio
import base64
import io
import os
import sqlite3
import zipfile
import pytest
from sqlalchemy import select
from app.models import Role, TelegramAccount
from app.services.session_import import convert_session, parse_uploads, ImportFormatError
from app.main import create_app
from tests.conftest import run_db
from tests.fakes import FakeBackend, FakeNetwork
from tests.unit.test_accounts_api import env, db_dump
from tests.unit.test_accounts_e2e import e2e, Admin, WorkerSide
from worker.account_backend import AccountTelegramBackend
from worker.telegram_backend import BackendError


def sqlite_session(key=None):
    key=key or os.urandom(256)
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE sessions(dc_id INTEGER, server_address TEXT, port INTEGER, auth_key BLOB)')
    db.execute('INSERT INTO sessions VALUES(2,?,?,?)',('149.154.167.51',443,key))
    raw=db.serialize();db.close()
    return raw,key


def archive(files):
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for name,raw in files:z.writestr(name,raw)
    return buf.getvalue()


def payload(wid, raw, name='example.session'):
    return {'worker_id':wid,'api_id':12345,'api_hash':'a'*32,
            'files':[{'filename':name,'content':base64.b64encode(raw).decode()}]}


def test_sqlite_conversion_compatible_with_telethon():
    from telethon.sessions import StringSession
    raw,key=sqlite_session()
    session,fingerprint=convert_session(raw)
    parsed=StringSession(session)
    assert parsed.auth_key.key==key and parsed.dc_id==2 and parsed.port==443
    assert key.hex() not in fingerprint
    assert session not in repr(parse_uploads([('file.session',raw)]))


def test_archive_of_100_sessions_and_limits():
    raw,_=sqlite_session()
    entries=parse_uploads([('hundred.zip',archive([(f'{i}.session',raw) for i in range(100)]))])
    assert len(entries)==100 and all(e.session for e in entries)
    with pytest.raises(ImportFormatError):
        parse_uploads([('too-many.zip',archive([(f'{i}.session',raw) for i in range(101)]))])
    assert parse_uploads([('bad.session',b'not sqlite')])[0].error
    with pytest.raises(ImportFormatError):parse_uploads([('bad.zip',b'not zip')])
    with pytest.raises(ImportFormatError):parse_uploads([('a.zip',archive([('secret.txt',b'x')]))])
    assert parse_uploads([('paths.zip',archive([('../../fake.session',raw)]))])[0].filename=='fake.session'


def test_import_api_encryption_dedup_and_access(env, new_client, seed_user, login):
    w=env.make_worker();raw,key=sqlite_session();session,_=convert_session(raw)
    r=env.client.post('/api/accounts/import-sessions',headers=env.h,json=payload(w.id,raw))
    assert r.status_code==202,r.text
    (item,)=r.json()['items'];aid=item['account_id']
    assert item['status']=='queued'
    account=env.client.get('/api/accounts/'+aid).json()
    assert account['auth_state']=='importing' and account['has_session'] and account['session_imported']
    assert env.client.post('/api/accounts/'+aid+'/start',headers=env.h).status_code==409
    assert session not in db_dump(env.settings)
    assert 'a'*32 not in db_dump(env.settings)
    assert env.client.post('/api/accounts/import-sessions',headers=env.h,json=payload(w.id,raw)).json()['items'][0]['status']=='duplicate'
    (cmd,)=w.poll()
    assert cmd['type']=='import_session' and not cmd['payload']
    status=env.client.post('/api/accounts/import-sessions/status',headers=env.h,json={'command_ids':[cmd['id']]})
    assert status.json()['items'][0]['status']=='delivered'
    w.result(cmd['id'],result={'state':'authorized','telegram_user_id':987,'username':'imported'})
    account=env.client.get('/api/accounts/'+aid).json()
    assert account['auth_state']=='authorized' and account['telegram_user_id']==987 and account['desired_state']=='stopped'
    assert session not in env.client.get('/api/audit').text
    assert env.client.post('/api/accounts/import-sessions',json=payload(w.id,raw)).status_code==403
    seed_user('op',role=Role.OPERATOR);op=new_client();h=login(op,'op')
    assert op.post('/api/accounts/import-sessions',headers=h,json=payload(w.id,raw)).status_code==403


def test_hundred_accounts_and_partial_bad_files(env):
    w=env.make_worker()
    files=[(f'{i}.session',sqlite_session()[0]) for i in range(100)]
    r=env.client.post('/api/accounts/import-sessions',headers=env.h,json=payload(w.id,archive(files),'sessions.zip'))
    assert r.status_code==202,r.text
    assert len(r.json()['items'])==100 and all(i['status']=='queued' for i in r.json()['items'])
    assert env.client.get('/api/accounts?page_size=100').json()['total']==100
    mixed=archive([('duplicate.session',files[0][1]),('bad.session',b'invalid')])
    r=env.client.post('/api/accounts/import-sessions',headers=env.h,json=payload(w.id,mixed,'mixed.zip'))
    assert [i['status'] for i in r.json()['items']]==['duplicate','error']


def test_failed_import_retry_and_flood_wait(env):
    w=env.make_worker();raw,_=sqlite_session()
    item=env.client.post('/api/accounts/import-sessions',headers=env.h,json=payload(w.id,raw)).json()['items'][0]
    (cmd,)=w.poll();w.result(cmd['id'],status='failed',error_code='network_error')
    aid=item['account_id']
    assert env.client.get('/api/accounts/'+aid).json()['auth_state']=='import_failed'
    retry=env.client.post(f'/api/accounts/{aid}/import-session/retry',headers=env.h)
    assert retry.status_code==202,retry.text
    again=env.client.post(f'/api/accounts/{aid}/import-session/retry',headers=env.h)
    assert again.json()['command_id']==retry.json()['command_id']
    (cmd,)=w.poll()
    assert w.http.post('/api/worker/v1/commands/'+cmd['id']+'/result',headers=w.h,
        json={'status':'failed','error_code':'flood_wait','retry_after':300}).status_code==204
    assert env.client.post(f'/api/accounts/{aid}/import-session/retry',headers=env.h).status_code==429


def test_real_worker_imports_session_without_otp(e2e):
    async def scenario():
        app=create_app(e2e);admin=Admin(app);await admin.login()
        net=FakeNetwork();w=await WorkerSide(app,admin,'import-worker',net).create()
        class NoOtpBackend(FakeBackend):
            async def send_code(self,phone):raise AssertionError('Import must not request OTP')
        backend=AccountTelegramBackend(w.client,factory=lambda api_id,api_hash:NoOtpBackend(net))
        w.manager._backend=backend
        try:
            raw,_=sqlite_session()
            r=await admin.post('/api/accounts/import-sessions',payload(w.id,raw))
            assert r.status_code==202,r.text
            item=r.json()['items'][0]
            cmd=await admin.finished(item['account_id'],item['command_id'])
            assert cmd['status']=='done',cmd
            account=await admin.account(item['account_id'])
            assert account['auth_state']=='authorized' and account['has_session'] and account['telegram_user_id']==111
        finally:
            await w.close();await w.client.aclose();await admin.http.aclose();await app.state.engine.dispose()
    asyncio.run(scenario())


def test_import_checks_are_bounded_to_three():
    from worker.accounts import AccountManager
    manager=AccountManager(None,object());active=peak=0
    async def check(aid):
        nonlocal active,peak
        active+=1;peak=max(active,peak)
        await asyncio.sleep(.005);active-=1
        return {'connection_state':'connected'}
    manager._check=check
    async def scenario():
        results=await asyncio.gather(*(manager._execute('import_session',str(i),{}) for i in range(100)))
        assert all(r['state']=='authorized' for r in results)
    asyncio.run(scenario())
    assert peak==3
