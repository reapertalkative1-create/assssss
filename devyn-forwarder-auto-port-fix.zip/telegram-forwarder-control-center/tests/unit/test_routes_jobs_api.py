import asyncio
import json
import uuid
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from sqlalchemy import select, update

from app.db import make_engine, make_sessionmaker
from app.models import AuditLog, ForwardJob, ForwardRoute, Role, RouteCheckpoint, TelegramAccount, Worker
from app.services import jobs as jobsvc
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import REG, W, db_dump, env  # noqa: F401  (env is a fixture)

SRC, SRC2 = -1001000000001, -1001000000002
DST, DST2 = -1002000000001, -1002000000002


class WJ(W):
    def enqueue(self, route_id, items=(), checkpoints=None):
        return self.http.post("/api/worker/v1/jobs/enqueue", headers=self.h, json={
            "route_id": route_id, "items": [{"source_chat_id": s, "message_id": m} for s, m in items],
            "checkpoints": checkpoints or {}})

    def claim(self, max_jobs=10):
        r = self.http.post("/api/worker/v1/jobs/claim", headers=self.h, json={"max_jobs": max_jobs, "wait_seconds": 0})
        assert r.status_code == 200, r.text
        return r.json()["jobs"]

    def start(self, jobs):
        return self.http.post("/api/worker/v1/jobs/start", headers=self.h,
                              json={"jobs": [{"id": j["id"], "epoch": j["epoch"]} for j in jobs]})

    def results(self, results):
        r = self.http.post("/api/worker/v1/jobs/results", headers=self.h, json={"results": results})
        assert r.status_code == 200, r.text
        return r.json()["outcomes"]

    def ok(self, job, dest_message_id=9001):
        return {"id": job["id"], "epoch": job["epoch"], "status": "succeeded", "dest_message_id": dest_message_id}

    def retry(self, job, code="network_error", retry_after=None):
        return {"id": job["id"], "epoch": job["epoch"], "status": "retry", "error_code": code, "retry_after": retry_after}

    def fail(self, job, code="destination_forbidden"):
        return {"id": job["id"], "epoch": job["epoch"], "status": "failed", "error_code": code}


@pytest.fixture
def jw(env):
    state = SimpleNamespace(worker=None, aid=None, epoch=None)

    def _worker():
        if state.worker is None:
            w = env.make_worker("wj")
            w.__class__ = WJ
            aid = env.make_account("acc-jobs", w)
            env.authorize(w, aid)
            assert env.client.post(f"/api/accounts/{aid}/start", headers=env.h).status_code == 200
            state.worker, state.aid, state.epoch = w, aid, w.lease(aid).json()["epoch"]
        return state

    return _worker


def make_route(env, st, name="r1", sources=(SRC,), dests=(DST, DST2), verify=True, start=True, **extra):
    body = {"name": name, "account_id": st.aid, "source_chat_ids": list(sources), "destination_chat_ids": list(dests), **extra}
    r = env.client.post("/api/routes", headers=env.h, json=body)
    assert r.status_code == 201, r.text
    rid = r.json()["id"]
    if verify:
        verify_route(env, st, rid)
    if start:
        assert env.client.post(f"/api/routes/{rid}/start", headers=env.h).status_code == 200, "route did not start"
    return rid


def verify_route(env, st, rid, can_send=True, drop=()):
    assert env.client.post(f"/api/routes/{rid}/verify", headers=env.h).status_code == 202
    (cmd,) = st.worker.poll()
    assert cmd["type"] == "verify_chats"
    chats = {str(c): {"ok": True, "can_send": can_send, "title": f"chat {c}"} for c in cmd["payload"]["chat_ids"] if c not in drop}
    assert st.worker.result(cmd["id"], result={"chats": chats}).status_code == 204
    return cmd


def jobs_in_db(env, **where):
    async def _do(s):
        stmt = select(ForwardJob)
        for k, v in where.items():
            stmt = stmt.where(getattr(ForwardJob, k) == v)
        return [(j.status, j.attempts, j.last_error_code, j.available_at, j.source_chat_id, j.message_id, j.dest_chat_id)
                for j in (await s.execute(stmt.order_by(ForwardJob.created_at))).scalars()]

    return run_db(env.settings, _do)


def mutate_jobs(env, **values):
    async def _do(s):
        await s.execute(update(ForwardJob).values(**values))

    run_db(env.settings, _do)


# ============================================================ routes
def test_route_crud_validation_and_rbac(env, jw, new_client, seed_user, login):
    st = jw()
    rid = make_route(env, st, verify=False, start=False)
    c = env.client
    assert c.post("/api/routes", headers=env.h, json={"name": "R1", "account_id": st.aid, "source_chat_ids": [SRC], "destination_chat_ids": [DST]}).status_code == 409
    bad = [{"source_chat_ids": [], "destination_chat_ids": [DST]}, {"source_chat_ids": [SRC, SRC], "destination_chat_ids": [DST]},
           {"source_chat_ids": [SRC], "destination_chat_ids": [SRC]}, {"source_chat_ids": [0], "destination_chat_ids": [DST]},
           {"source_chat_ids": [SRC], "destination_chat_ids": [DST], "priority": 10},
           {"source_chat_ids": [SRC], "destination_chat_ids": [DST], "rate_per_minute": 0},
           {"source_chat_ids": [SRC], "destination_chat_ids": [DST], "filters": {"keywords_include": [""]}},
           {"source_chat_ids": [SRC], "destination_chat_ids": [DST], "filters": {"content_types": ["gif"]}},
           {"source_chat_ids": [SRC], "destination_chat_ids": [DST], "mode": "teleport"}]
    for i, b in enumerate(bad):
        assert c.post("/api/routes", headers=env.h, json={"name": f"bad{i}", "account_id": st.aid, **b}).status_code == 422, b
    assert c.post("/api/routes", headers=env.h, json={"name": "ghost", "account_id": str(uuid.uuid4()),
                  "source_chat_ids": [SRC], "destination_chat_ids": [DST]}).status_code == 404

    r = c.patch(f"/api/routes/{rid}", headers=env.h, json={"filters": {"keywords_include": ["  Giá  Rẻ ", "giá rẻ"], "content_types": ["photo", "photo"]},
                                                          "priority": 2, "mode": "copy"})
    assert r.status_code == 200 and r.json()["filters"]["keywords_include"] == ["giá rẻ"] and r.json()["filters"]["content_types"] == ["photo"]
    assert r.json()["priority"] == 2 and r.json()["mode"] == "copy"

    seed_user("op", role=Role.OPERATOR)
    op = new_client()
    oh = login(op, "op")
    assert op.get("/api/routes").json()["total"] == 1 and op.get(f"/api/routes/{rid}").status_code == 200
    for method, path, body in [("post", "/api/routes", {"name": "x"}), ("patch", f"/api/routes/{rid}", {"priority": 3}),
                               ("post", f"/api/routes/{rid}/delete", {"confirm_name": "r1"})]:
        assert getattr(op, method)(path, headers=oh, json=body).status_code == 403, path
    assert new_client().get("/api/routes").status_code == 401
    assert c.get("/api/routes", params={"status": "active"}).json()["total"] == 0 and c.get("/api/routes", params={"q": "r"}).json()["total"] == 1


def test_start_requires_verified_access_to_every_chat(env, jw):
    st = jw()
    rid = make_route(env, st, verify=False, start=False)
    c = env.client
    assert c.post(f"/api/routes/{rid}/start", headers=env.h).json()["error"]["code"] == "route_not_verified"

    verify_route(env, st, rid, can_send=False)                       # cannot write to the destinations
    assert c.get(f"/api/routes/{rid}").json()["verified"] is False
    assert c.post(f"/api/routes/{rid}/start", headers=env.h).status_code == 409

    verify_route(env, st, rid, drop=(DST2,))                         # a chat is missing from the answer: ignored
    assert c.get(f"/api/routes/{rid}").json()["verified"] is False

    verify_route(env, st, rid)
    assert c.get(f"/api/routes/{rid}").json()["verified"] is True
    c.post(f"/api/accounts/{st.aid}/stop", headers=env.h)
    assert c.post(f"/api/routes/{rid}/start", headers=env.h).json()["error"]["code"] == "account_not_running"
    c.post(f"/api/accounts/{st.aid}/start", headers=env.h)
    assert c.post(f"/api/routes/{rid}/start", headers=env.h).json()["status"] == "active"


def test_changing_chats_needs_stop_and_forces_reverification(env, jw):
    st = jw()
    rid = make_route(env, st)
    c = env.client
    assert c.patch(f"/api/routes/{rid}", headers=env.h, json={"destination_chat_ids": [DST]}).json()["error"]["code"] == "route_must_be_stopped"
    c.post(f"/api/routes/{rid}/stop", headers=env.h)
    r = c.patch(f"/api/routes/{rid}", headers=env.h, json={"destination_chat_ids": [DST, -1002000000009]})
    assert r.status_code == 200 and r.json()["verified"] is False
    assert c.post(f"/api/routes/{rid}/start", headers=env.h).status_code == 409
    assert c.patch(f"/api/routes/{rid}", headers=env.h, json={"destination_chat_ids": [SRC]}).status_code == 422


def test_verification_for_outdated_chat_list_is_ignored(env, jw):
    st = jw()
    rid = make_route(env, st, verify=False, start=False)
    c = env.client
    c.post(f"/api/routes/{rid}/verify", headers=env.h)
    (cmd,) = st.worker.poll()
    c.patch(f"/api/routes/{rid}", headers=env.h, json={"destination_chat_ids": [DST, -1002000000009]})   # edited meanwhile
    st.worker.result(cmd["id"], result={"chats": {str(x): {"ok": True, "can_send": True} for x in cmd["payload"]["chat_ids"]}})
    assert c.get(f"/api/routes/{rid}").json()["verified"] is False


def test_route_state_transitions_are_idempotent(env, jw):
    st = jw()
    rid = make_route(env, st, start=False)
    c, h = env.client, env.h
    assert c.post(f"/api/routes/{rid}/pause", headers=h).json()["error"]["code"] == "route_not_active"
    assert c.post(f"/api/routes/{rid}/resume", headers=h).status_code == 409
    for _ in range(2):
        assert c.post(f"/api/routes/{rid}/start", headers=h).json()["status"] == "active"
    for _ in range(2):
        assert c.post(f"/api/routes/{rid}/pause", headers=h).json()["status"] == "paused"
    assert c.post(f"/api/routes/{rid}/resume", headers=h).json()["status"] == "active"
    for _ in range(2):
        assert c.post(f"/api/routes/{rid}/stop", headers=h).json()["status"] == "stopped"
    names = [i["action"] for i in c.get("/api/audit", params={"action": "route.", "page_size": 100}).json()["items"]]
    assert names.count("route.start") == 1 and names.count("route.pause") == 1 and names.count("route.stop") == 1


def test_loop_protection_for_include_outgoing(env, jw):
    st = jw()
    make_route(env, st, "a-to-b", sources=(SRC,), dests=(DST,))
    rid = make_route(env, st, "b-to-c", sources=(DST,), dests=(SRC2,), filters={"include_outgoing": True}, start=False)
    verify_route(env, st, rid)
    assert env.client.post(f"/api/routes/{rid}/start", headers=env.h).json()["error"]["code"] == "possible_loop"
    # the same chat graph is fine while nobody forwards outgoing messages
    env.client.patch(f"/api/routes/{rid}", headers=env.h, json={"filters": {"include_outgoing": False}})
    assert env.client.post(f"/api/routes/{rid}/start", headers=env.h).json()["status"] == "active"


def test_worker_receives_only_its_active_routes(env, jw):
    st = jw()
    rid = make_route(env, st)
    other = env.make_worker("other")
    paused = make_route(env, st, "paused-one", sources=(SRC2,), dests=(DST,))
    env.client.post(f"/api/routes/{paused}/pause", headers=env.h)
    st.worker.enqueue(rid, checkpoints={SRC: 500})
    hb = st.worker.http.post("/api/worker/v1/heartbeat", headers=st.worker.h, json={}).json()
    assert [r["route_id"] for r in hb["routes"]] == [rid]
    assert hb["routes"][0]["checkpoints"] == {str(SRC): 500} and hb["routes"][0]["destination_chat_ids"] == [DST, DST2]
    assert other.http.post("/api/worker/v1/heartbeat", headers=other.h, json={}).json()["routes"] == []
    reg = st.worker.http.post("/api/worker/v1/register", headers=st.worker.h, json=REG).json()
    assert [r["route_id"] for r in reg["routes"]] == [rid]


def test_delete_route_needs_confirmation_and_stopped_state(env, jw):
    st = jw()
    rid = make_route(env, st)
    st.worker.enqueue(rid, [(SRC, 1)])
    c, h = env.client, env.h
    assert c.post(f"/api/routes/{rid}/delete", headers=h, json={"confirm_name": "nope"}).status_code == 422
    assert c.post(f"/api/routes/{rid}/delete", headers=h, json={"confirm_name": "r1"}).json()["error"]["code"] == "route_must_be_stopped"
    c.post(f"/api/routes/{rid}/stop", headers=h)
    job = [j for j in [st.worker.claim()] if j]
    assert c.post(f"/api/routes/{rid}/delete", headers=h, json={"confirm_name": "r1"}).status_code == 200
    assert c.get(f"/api/routes/{rid}").status_code == 404
    assert jobs_in_db(env) == []


# ============================================================ enqueue / dedupe / checkpoints
def test_enqueue_fans_out_dedupes_and_tracks_checkpoints(env, jw):
    st = jw()
    rid = make_route(env, st, sources=(SRC, SRC2), dests=(DST, DST2))              # N sources x M destinations
    r = st.worker.enqueue(rid, [(SRC, 10), (SRC, 11), (SRC2, 7)]).json()
    assert r == {"created": 6, "duplicates": 0}
    again = st.worker.enqueue(rid, [(SRC, 10), (SRC, 12)]).json()
    assert again == {"created": 2, "duplicates": 2}                                 # same message is never queued twice
    assert len(jobs_in_db(env)) == 8
    d = env.client.get(f"/api/routes/{rid}").json()
    assert d["checkpoints"] == {str(SRC): 12, str(SRC2): 7} and d["stats"] == {"pending": 8}
    st.worker.enqueue(rid, checkpoints={SRC: 5})                                    # checkpoints only move forward
    assert env.client.get(f"/api/routes/{rid}").json()["checkpoints"][str(SRC)] == 12
    st.worker.enqueue(rid, checkpoints={SRC2: 900})                                 # checkpoint-only call (nothing matched)
    assert env.client.get(f"/api/routes/{rid}").json()["checkpoints"][str(SRC2)] == 900


def test_enqueue_is_strictly_validated(env, jw):
    st = jw()
    rid = make_route(env, st)
    other = env.make_worker("intruder")
    other.__class__ = WJ
    assert other.enqueue(rid, [(SRC, 1)]).status_code == 404                        # not this worker's route
    assert st.worker.enqueue(rid, [(SRC2, 1)]).json()["error"]["code"] == "invalid_source"
    assert st.worker.enqueue(rid, [(SRC, 0)]).status_code == 422
    env.client.post(f"/api/routes/{rid}/pause", headers=env.h)
    assert st.worker.enqueue(rid, [(SRC, 1)]).json()["error"]["code"] == "route_not_active"
    env.client.post(f"/api/routes/{rid}/resume", headers=env.h)

    async def expire(s):
        (await s.get(TelegramAccount, uuid.UUID(st.aid))).lease_expires_at = utcnow() - timedelta(seconds=1)

    run_db(env.settings, expire)
    assert st.worker.enqueue(rid, [(SRC, 1)]).json()["error"]["code"] == "lease_invalid"   # lost the session: cannot enqueue


# ============================================================ claim / start / results
def test_claim_orders_by_priority_and_never_hands_out_a_job_twice(env, jw):
    st = jw()
    low = make_route(env, st, "low", sources=(SRC,), dests=(DST,), priority=9)
    high = make_route(env, st, "high", sources=(SRC2,), dests=(DST2,), priority=1)
    st.worker.enqueue(low, [(SRC, i) for i in range(1, 4)])
    st.worker.enqueue(high, [(SRC2, i) for i in range(1, 4)])
    first = st.worker.claim(4)
    assert [j["route_id"] for j in first][:3] == [high] * 3 and len(first) == 4      # urgent route first
    second = st.worker.claim(10)
    assert len(second) == 2 and not ({j["id"] for j in first} & {j["id"] for j in second})
    assert st.worker.claim() == []
    assert all(j["epoch"] == 1 and j["attempt"] == 1 for j in first + second)


def test_claim_requires_lease_active_route_and_flood_free_account(env, jw):
    st = jw()
    rid = make_route(env, st)
    st.worker.enqueue(rid, [(SRC, 1)])
    stranger = env.make_worker("stranger")
    stranger.__class__ = WJ
    assert stranger.claim() == []                                                   # owns no account
    env.client.post(f"/api/routes/{rid}/pause", headers=env.h)
    assert st.worker.claim() == []                                                  # paused: nothing is handed out
    env.client.post(f"/api/routes/{rid}/resume", headers=env.h)

    async def expire(s):
        (await s.get(TelegramAccount, uuid.UUID(st.aid))).lease_expires_at = utcnow() - timedelta(seconds=1)

    run_db(env.settings, expire)
    assert st.worker.claim() == []                                                  # lease lost: must not send anything
    st.worker.lease(st.aid)
    assert len(st.worker.claim()) == 2


def test_concurrent_claims_are_disjoint(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), rate_per_minute=600)
    st.worker.enqueue(rid, [(SRC, i) for i in range(1, 41)])

    async def race():
        engine = make_engine(env.settings.database_url)
        sm = make_sessionmaker(engine)

        async def one():
            async with sm() as s:
                worker = await s.get(Worker, uuid.UUID(st.worker.id))
                jobs = await jobsvc.claim_jobs(s, worker, utcnow(), 20, env.settings)
                await s.commit()
                return [j["id"] for j in jobs]

        res = await asyncio.gather(one(), one(), one())
        await engine.dispose()
        return res

    a, b, c = asyncio.run(race())
    allids = a + b + c
    # Never a duplicate assignment. (Verified to FAIL on PostgreSQL if the status/epoch guards are removed from the
    # claim UPDATE; SQLite serialises writers so it cannot show that failure.) The per-minute caps are best-effort
    # under three simultaneous claims from the same worker, which the real worker never does (one claim loop).
    assert len(allids) == len(set(allids)) and len(allids) >= 20


def test_rate_limits_per_route_and_per_account(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), rate_per_minute=3)
    st.worker.enqueue(rid, [(SRC, i) for i in range(1, 11)])
    assert len(st.worker.claim(10)) == 3 and st.worker.claim(10) == []              # route budget used up for this minute
    mutate_jobs(env, claimed_at=utcnow() - timedelta(seconds=61))
    assert len(st.worker.claim(10)) == 3                                            # the window moved on

    s2 = env.settings.model_copy(update={"account_rate_per_minute": 2})
    env.settings = s2  # the app under test was created from the old settings; check the cap through the service
    async def cap():
        engine = make_engine(s2.database_url)
        async with make_sessionmaker(engine)() as s:
            worker = await s.get(Worker, uuid.UUID(st.worker.id))
            got = await jobsvc.claim_jobs(s, worker, utcnow(), 10, s2)
            await s.commit()
        await engine.dispose()
        return len(got)

    mutate_jobs(env, claimed_at=utcnow() - timedelta(seconds=500))
    assert asyncio.run(cap()) == 2                                                  # account-wide cap beats the route's 3/min


def test_full_job_lifecycle_and_fencing(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,))
    st.worker.enqueue(rid, [(SRC, 1), (SRC, 2)])
    j1, j2 = st.worker.claim()
    assert st.worker.results([st.worker.ok(j1)]) == [{"id": j1["id"], "outcome": "stale"}]      # must be started first
    r = st.worker.start([j1, j2]).json()
    assert set(r["started"]) == {j1["id"], j2["id"]} and r["lost"] == []
    assert st.worker.start([j1]).json()["lost"] == [j1["id"]]                       # cannot start twice
    assert st.worker.results([{**st.worker.ok(j1), "epoch": 99}]) == [{"id": j1["id"], "outcome": "stale"}]
    assert st.worker.results([st.worker.ok(j1, 777), st.worker.ok(j2)])[0]["outcome"] == "ok"
    assert st.worker.results([st.worker.ok(j1)])[0]["outcome"] == "stale"           # a duplicate report changes nothing
    assert {s for s, *_ in jobs_in_db(env)} == {"succeeded"}
    jobs = env.client.get("/api/jobs", params={"status": "succeeded"}).json()
    assert jobs["total"] == 2 and {j["result"]["dest_message_id"] for j in jobs["items"]} == {777, 9001}
    assert "message" not in json.dumps(jobs["items"][0]).replace("message_id", "")  # only ids, never message content


def test_start_returns_job_to_queue_when_route_was_paused(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,))
    st.worker.enqueue(rid, [(SRC, 1)])
    (j,) = st.worker.claim()
    env.client.post(f"/api/routes/{rid}/pause", headers=env.h)
    assert st.worker.start([j]).json()["lost"] == [j["id"]]
    assert jobs_in_db(env)[0][:2] == ("pending", 0)                                 # back in the queue, attempt refunded


def test_transient_errors_back_off_then_dead_letter(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), max_attempts=3)
    st.worker.enqueue(rid, [(SRC, 1)])
    for attempt in (1, 2, 3):
        (j,) = st.worker.claim()
        assert j["attempt"] == attempt
        st.worker.start([j])
        st.worker.results([st.worker.retry(j)])
        status, attempts, err, available_at, *_ = jobs_in_db(env)[0]
        if attempt < 3:
            assert status == "retry_wait" and err == "network_error"
            assert (available_at - utcnow()).total_seconds() > 0                    # exponential backoff, not immediate
            assert st.worker.claim() == []                                          # not before available_at
            mutate_jobs(env, available_at=utcnow() - timedelta(seconds=1))
    assert jobs_in_db(env)[0][:3] == ("dead_letter", 3, "network_error")            # bounded: never retried forever
    dl = env.client.get("/api/audit", params={"action": "job.dead_letter"}).json()["items"]
    assert len(dl) == 1 and dl[0]["details"]["attempts"] == 3
    assert st.worker.claim() == []


def test_permanent_failure_is_parked_until_an_operator_acts(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,))
    st.worker.enqueue(rid, [(SRC, 1), (SRC, 2)])
    j1, j2 = st.worker.claim()
    st.worker.start([j1, j2])
    st.worker.results([st.worker.fail(j1), st.worker.fail(j2, "forward_restricted")])
    assert {r[0] for r in jobs_in_db(env)} == {"failed"} and st.worker.claim() == []
    c, h = env.client, env.h
    jid = j1["id"]
    r = c.post(f"/api/jobs/{jid}/retry", headers=h).json()
    assert r["status"] == "pending" and r["attempts"] == 0
    assert c.post(f"/api/jobs/{jid}/retry", headers=h).status_code == 409           # no longer parked
    assert c.post(f"/api/jobs/{j2['id']}/cancel", headers=h).json()["status"] == "cancelled"
    assert c.post(f"/api/jobs/{j2['id']}/cancel", headers=h).json()["status"] == "cancelled"   # idempotent
    assert c.post(f"/api/jobs/{jid}/cancel", headers=h).status_code == 200
    assert c.post(f"/api/jobs/{uuid.uuid4()}/retry", headers=h).status_code == 404


def test_flood_wait_is_honoured_exactly_and_blocks_the_whole_account(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), rate_per_minute=600)
    st.worker.enqueue(rid, [(SRC, i) for i in range(1, 5)])
    j1, j2, j3, j4 = st.worker.claim()
    st.worker.start([j1, j2])
    before = utcnow()
    st.worker.results([st.worker.retry(j1, "flood_wait", retry_after=120)])
    status, attempts, err, available_at, *_ = [r for r in jobs_in_db(env, message_id=1)][0]
    assert status == "retry_wait" and attempts == 0 and err == "flood_wait"          # not counted as a failed attempt
    wait = (available_at - before).total_seconds()
    assert 120 <= wait <= 123                                                         # exactly what Telegram demanded (+1 s margin)

    async def blocked_until(s):
        return (await s.get(TelegramAccount, uuid.UUID(st.aid))).flood_wait_until

    assert 120 <= (run_db(env.settings, blocked_until) - before).total_seconds() <= 123
    st.worker.start([j3, j4])
    mutate_jobs(env, status="pending", available_at=utcnow())
    assert st.worker.claim() == []                                                    # nothing else may be sent meanwhile
    async def unblock(s):
        (await s.get(TelegramAccount, uuid.UUID(st.aid))).flood_wait_until = utcnow() - timedelta(seconds=1)

    run_db(env.settings, unblock)
    assert len(st.worker.claim()) >= 1


def test_slow_mode_delays_one_job_without_blocking_the_account(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), rate_per_minute=600)
    st.worker.enqueue(rid, [(SRC, 1), (SRC, 2)])
    j1, j2 = st.worker.claim()
    st.worker.start([j1, j2])
    st.worker.results([st.worker.retry(j1, "slow_mode", retry_after=30)])
    assert jobs_in_db(env, message_id=1)[0][:2] == ("retry_wait", 0)

    async def blocked_until(s):
        return (await s.get(TelegramAccount, uuid.UUID(st.aid))).flood_wait_until

    assert run_db(env.settings, blocked_until) is None


def test_abandoned_jobs_are_recovered_and_late_reports_are_rejected(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), max_attempts=2, rate_per_minute=600)
    st.worker.enqueue(rid, [(SRC, 1), (SRC, 2), (SRC, 3)])
    j1, j2, j3 = st.worker.claim()
    st.worker.start([j1, j2])                                                         # j3 stays "claimed" (never started)
    mutate_jobs(env, lease_expires_at=utcnow() - timedelta(seconds=1))

    async def sweep(s):
        return await jobsvc.recover_abandoned(s, utcnow(), env.settings)

    assert run_db(env.settings, sweep) == {"requeued": 1, "retried": 2, "dead_letter": 0}
    rows = {r[5]: r for r in jobs_in_db(env)}
    assert rows[3][:2] == ("pending", 0) and rows[1][0] == "retry_wait" and rows[1][2] == "lease_expired"
    assert st.worker.results([st.worker.ok(j1)]) == [{"id": j1["id"], "outcome": "stale"}]   # the old owner lost the job

    mutate_jobs(env, available_at=utcnow() - timedelta(seconds=1))
    again = st.worker.claim()
    assert {j["epoch"] for j in again} == {2}                                         # new fencing epoch
    st.worker.start([j for j in again if j["message_id"] == 1])
    mutate_jobs(env, lease_expires_at=utcnow() - timedelta(seconds=1))
    assert run_db(env.settings, sweep)["dead_letter"] == 1                            # attempts exhausted while abandoned
    assert any(r[0] == "dead_letter" for r in jobs_in_db(env))


def test_stop_can_cancel_the_pending_queue(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,))
    st.worker.enqueue(rid, [(SRC, i) for i in range(1, 6)])
    (j,) = st.worker.claim(1)
    r = env.client.post(f"/api/routes/{rid}/stop", headers=env.h, json={"cancel_pending": True}).json()
    assert r["status"] == "stopped" and r["stats"] == {"cancelled": 4, "claimed": 1}


def test_bulk_actions_metrics_and_listing(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,), rate_per_minute=600, max_attempts=1)
    st.worker.enqueue(rid, [(SRC, i) for i in range(1, 7)])
    jobs = st.worker.claim(6)
    st.worker.start(jobs)
    st.worker.results([st.worker.ok(jobs[0]), st.worker.fail(jobs[1]), st.worker.retry(jobs[2]), st.worker.retry(jobs[3])])
    st.worker.enqueue(rid, [(SRC, 7)])
    m = env.client.get("/api/queue/metrics").json()
    assert m["by_status"]["succeeded"] == 1 and m["by_status"]["failed"] == 1 and m["by_status"]["dead_letter"] == 2
    assert m["by_status"]["running"] == 2 and m["by_status"]["pending"] == 1
    assert m["needs_attention"] == 3 and m["succeeded_last_5m"] == 1 and m["oldest_pending_age_seconds"] >= 0

    assert env.client.post("/api/jobs/bulk", headers=env.h, json={"action": "retry", "status": "pending"}).status_code == 409
    assert env.client.post("/api/jobs/bulk", headers=env.h, json={"action": "retry", "status": "dead_letter", "limit": 1}).json() == {"affected": 1}
    assert env.client.post("/api/jobs/bulk", headers=env.h, json={"action": "cancel", "status": "failed"}).json() == {"affected": 1}
    assert env.client.get("/api/queue/metrics").json()["needs_attention"] == 1
    listing = env.client.get("/api/jobs", params={"route_id": rid, "page_size": 3}).json()
    assert listing["total"] == 7 and len(listing["items"]) == 3
    assert env.client.get("/api/jobs", params={"status": "bogus"}).status_code == 422
    assert env.client.get("/api/jobs", params={"status": "dead_letter"}).json()["total"] == 1


def test_deleting_an_account_removes_its_routes_and_jobs(env, jw):
    st = jw()
    rid = make_route(env, st)
    st.worker.enqueue(rid, [(SRC, 1)])
    env.client.post(f"/api/routes/{rid}/stop", headers=env.h)
    # the account has a stored session, so delete it the "forced" way (worker-side logout is covered elsewhere)
    r = env.client.post(f"/api/accounts/{st.aid}/delete", headers=env.h, json={"confirm_name": "acc-jobs", "force": True})
    assert r.json()["status"] == "deleted"

    async def left(s):
        return [len((await s.execute(select(m))).scalars().all()) for m in (ForwardRoute, ForwardJob, RouteCheckpoint)]

    assert run_db(env.settings, left) == [0, 0, 0]


# ============================================================ contract + pure functions
def test_state_machine_matches_the_shared_contract():
    data = json.loads((Path(__file__).resolve().parents[2] / "packages/shared-schemas/job_states.json").read_text())
    assert {k: set(v) for k, v in data["transitions"].items()} == jobsvc.TRANSITIONS
    assert set(data["states"]) == set(jobsvc.TRANSITIONS)
    assert all(data["transitions"][t] == [] for t in data["terminal"])
    assert all(data["transitions"][p] for p in data["parked"])                        # parked states can be requeued
    with pytest.raises(RuntimeError):
        jobsvc._guard("succeeded", "pending")
    with pytest.raises(RuntimeError):
        jobsvc._guard("pending", "running")                                           # must be claimed first


def test_backoff_is_exponential_capped_and_jittered():
    values = [jobsvc.backoff_seconds(a, 5, 900, rng=lambda: 0.5) for a in (1, 2, 3, 4, 10)]
    assert values == [5, 10, 20, 40, 900]
    lo, hi = jobsvc.backoff_seconds(3, 5, 900, rng=lambda: 0.0), jobsvc.backoff_seconds(3, 5, 900, rng=lambda: 1.0)
    assert (lo, hi) == pytest.approx((16.0, 24.0))                                     # +-20 %
