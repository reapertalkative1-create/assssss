import pytest

from app.config import Settings


def test_production_rejects_weak_secret():
    with pytest.raises(RuntimeError, match="TFCC_SECRET_KEY"):
        Settings(_env_file=None, env="production", secret_key="short", session_encryption_key="k").assert_production_ready()


def test_production_requires_encryption_key():
    with pytest.raises(RuntimeError, match="SESSION_ENCRYPTION_KEY"):
        Settings(_env_file=None, env="production", secret_key="x" * 32).assert_production_ready()


def test_production_rejects_wildcard_cors_and_insecure_cookie():
    with pytest.raises(RuntimeError) as e:
        Settings(_env_file=None, env="production", secret_key="x" * 32, session_encryption_key="k",
                 allowed_origins="*", cookie_secure=False).assert_production_ready()
    assert "COOKIE_SECURE" in str(e.value) and "ALLOWED_ORIGINS" in str(e.value)


def test_secrets_not_in_repr():
    s = Settings(_env_file=None, secret_key="supersecretvalue1234567890123456")
    assert "supersecretvalue" not in repr(s)


def test_cors_origins_parsing():
    assert Settings(_env_file=None, allowed_origins="https://a.com, https://b.com").cors_origins == ["https://a.com", "https://b.com"]
