import os

import pytest
from cryptography.fernet import Fernet

from app.crypto import CryptoError, SecretBox, build_secret_box, load_keys


def test_roundtrip_and_ciphertext_hides_plaintext():
    box = SecretBox([SecretBox.generate_key()])
    token = box.seal("session", "acc-1", "my-secret-session")
    assert "my-secret-session" not in token
    assert box.open("session", "acc-1", token) == "my-secret-session"


def test_ciphertext_is_bound_to_its_owner_and_purpose():
    box = SecretBox([SecretBox.generate_key()])
    token = box.seal("session", "acc-1", "x" * 30)
    with pytest.raises(CryptoError):
        box.open("session", "acc-2", token)      # copied onto another account's row
    with pytest.raises(CryptoError):
        box.open("command", "acc-1", token)      # replayed as another kind of record
    with pytest.raises(CryptoError):
        box.open("session", "acc-1", token[:-4] + "AAAA")  # tampered


def test_wrong_key_cannot_decrypt_and_error_leaks_nothing():
    a, b = SecretBox([SecretBox.generate_key()]), SecretBox([SecretBox.generate_key()])
    token = a.seal("session", "1", "plain-secret-value-123")
    with pytest.raises(CryptoError) as e:
        b.open("session", "1", token)
    assert "plain-secret" not in str(e.value) and token not in str(e.value)


def test_key_rotation_keeps_old_data_readable():
    old, new = SecretBox.generate_key(), SecretBox.generate_key()
    token = SecretBox([old]).seal("session", "1", "value-value-value-value")
    rotating = SecretBox([new, old])               # new key first = primary
    assert rotating.open("session", "1", token) == "value-value-value-value"
    assert not rotating.is_current(token)
    rotated = rotating.rotate(token)
    assert rotating.is_current(rotated)
    assert SecretBox([new]).open("session", "1", rotated) == "value-value-value-value"  # old key no longer needed


def test_invalid_keys_are_rejected():
    with pytest.raises(CryptoError):
        SecretBox(["not-a-fernet-key"])
    with pytest.raises(CryptoError):
        SecretBox([])
    assert build_secret_box("") is None


@pytest.mark.skipif(os.name != "posix", reason="POSIX permissions")
def test_key_file_must_not_be_readable_by_others(tmp_path):
    key = Fernet.generate_key().decode()
    f = tmp_path / "session.key"
    f.write_text(key + "\n")
    f.chmod(0o644)
    with pytest.raises(CryptoError, match="chmod 600"):
        load_keys("", str(f))
    f.chmod(0o600)
    assert load_keys("", str(f)) == [key]
    with pytest.raises(CryptoError):
        load_keys("", str(tmp_path / "missing.key"))


def test_multiple_keys_from_env_string():
    a, b = Fernet.generate_key().decode(), Fernet.generate_key().decode()
    assert load_keys(f"{a}, {b}") == [a, b]
