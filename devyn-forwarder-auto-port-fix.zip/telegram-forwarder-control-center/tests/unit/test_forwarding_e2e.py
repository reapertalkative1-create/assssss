"""Real API + database + worker client + AccountManager + ForwardEngine. Only Telegram is faked."""
import asyncio
import time
import uuid
from datetime import timedelta

import pytest
from sqlalchemy import select

from app.db import make_sessionmaker
from app.main import create_app
from app.models import AuditLog, ForwardJob, RouteCheckpoint, TelegramAccount
from app.types import utcnow
from tests.fakes import FakeNetwork
from tests.unit.test_accounts_e2e import Admin, WorkerSide, authorize, e2e  # noqa: F401  (e2e is a fixture)
from worker.forwarding import ForwardEngine
from worker.telegram_backend import BackendError, ChatInfo, MessageFacts

SRC, DST1, DST2 = -1001000000001, -1002000000001, -1002000000002


class FSide(WorkerSide):
    async def create(self, **engine_kw):
        await super().create()
        engine_kw.setdefault("send_interval", 0)
        engine_kw.setdefault("claim_wait", 0)
        self.engine = ForwardEngine(self.client, self.manager, self.backend, **engine_kw)
        self.manager.listeners.append(self.engine)
        return self

    async def beat(self):
        payload = {"accounts": self.manager.heartbeat_accounts()}
        sent = self.clock()
        hb = await self.client.heartbeat(payload)
        await self.manager.on_heartbeat(hb, sent)
        await self.engine.on_routes(hb.routes)
        while self.manager._tasks:
            await asyncio.gather(*list(self.manager._tasks), return_exceptions=True)
        return hb

    async def pump(self, rounds=1):
        """flush observed messages into the queue, then execute whatever can run"""
        done = 0
        for _ in range(rounds):
            await self.engine._flush()
            done += await self.engine.execute_once()
        return done


def msg(mid, text="hello", chat=SRC, kind="text", outgoing=False):
    return MessageFacts(chat, mid, text, kind, outgoing)


async def db(app, fn):
    async with make_sessionmaker(app.state.engine)() as s:
        out = await fn(s)
        await s.commit()
        return out


async def job_rows(app, route_id=None):
    async def _do(s):
        stmt = select(ForwardJob).order_by(ForwardJob.message_id, ForwardJob.dest_chat_id)
        rows = (await s.execute(stmt)).scalars().all()
        return [(j.message_id, j.dest_chat_id, j.status, j.attempts, j.last_error_code) for j in rows]

    return await db(app, _do)


async def setup(e2e_settings, **route_kw):
    """Admin + one worker with an authorized, running account and a verified, active route."""
    app = create_app(e2e_settings)
    admin = Admin(app)
    await admin.login()
    w = await FSide(app, admin, "w1", FakeNetwork(), command_wait=1).create()
    aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
    await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": w.id})
    await authorize(admin, aid)
    await admin.post(f"/api/accounts/{aid}/start")
    await w.beat()
    await w.beat()
    body = {"name": "r1", "account_id": aid, "source_chat_ids": [SRC], "destination_chat_ids": [DST1, DST2], **route_kw}
    rid = (await admin.post("/api/routes", body)).json()["id"]
    cid = (await admin.post(f"/api/routes/{rid}/verify")).json()["command_id"]
    assert (await admin.finished(aid, cid))["status"] == "done"          # the worker really checked the chats
    started = await admin.post(f"/api/routes/{rid}/start")
    assert started.status_code == 200, started.text
    return app, admin, w, aid, rid


async def finish(app, *sides):
    for w in sides:
        await w.close()
    await app.state.engine.dispose()


@pytest.fixture
def fast(e2e):
    return e2e.model_copy(update={"job_retry_base_seconds": 0.01, "job_retry_cap_seconds": 0.02})


def test_live_messages_are_filtered_queued_forwarded_and_deduplicated(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e, filters={"keywords_include": ["sale"]}, mode="copy")
        w.backend.latest[SRC] = 50
        await w.beat()                                                     # engine starts watching; old history is ignored
        for m in (msg(51, "SALE today"), msg(52, "unrelated"), msg(53, "big sale", kind="photo"), msg(54, "mine sale", outgoing=True)):
            w.backend.emit(m)
        done = await w.pump()
        first = (done, sorted(w.backend.forwarded), await job_rows(app))
        w.backend.emit(msg(51, "SALE today"))                             # the same message arrives again
        again = await w.pump()
        detail = (await admin.get(f"/api/routes/{rid}")).json()
        await finish(app, w)
        return first, again, w.backend.forwarded, detail

    (done, forwarded, rows), again, all_forwarded, detail = asyncio.run(scenario())
    assert done == 4 and forwarded == sorted([(SRC, 51, DST1, "copy"), (SRC, 51, DST2, "copy"), (SRC, 53, DST1, "copy"), (SRC, 53, DST2, "copy")])
    assert {r[2] for r in rows} == {"succeeded"} and len(rows) == 4
    assert again == 0 and len(all_forwarded) == 4                          # never forwarded twice
    assert detail["checkpoints"] == {str(SRC): 54} and detail["stats"] == {"succeeded": 4}


def test_missed_messages_are_caught_up_after_the_worker_was_away(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e)
        w.backend.latest[SRC] = 10
        await w.beat()
        w.backend.emit(msg(11))
        await w.pump()
        await w.manager._drop(aid, "test-outage")                          # connection lost
        for i in (12, 13, 14):                                             # arrive while nobody is watching
            w.backend.emit(msg(i))
        w.clock.t += 6
        await w.beat()                                                     # reconnects, catches up from the checkpoint
        await w.pump(2)
        rows = await job_rows(app)
        await finish(app, w)
        return w.backend.forwarded, rows

    forwarded, rows = asyncio.run(scenario())
    assert sorted({f[1] for f in forwarded}) == [11, 12, 13, 14]
    assert len(forwarded) == 8 and len(rows) == 8                          # each message once per destination


def test_pausing_stops_observation_and_resuming_catches_up(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e)
        w.backend.latest[SRC] = 10
        await w.beat()
        await admin.post(f"/api/routes/{rid}/pause")
        await w.beat()
        watchers_paused = len(w.backend.watchers)
        w.backend.emit(msg(11))
        await w.pump()
        forwarded_while_paused = len(w.backend.forwarded)
        await admin.post(f"/api/routes/{rid}/resume")
        await w.beat()
        await w.pump(2)
        await finish(app, w)
        return watchers_paused, forwarded_while_paused, w.backend.forwarded

    watchers_paused, while_paused, forwarded = asyncio.run(scenario())
    assert watchers_paused == 0 and while_paused == 0
    assert sorted(f[1] for f in forwarded) == [11, 11]                      # picked up exactly once after resume


def test_transient_failures_retry_with_backoff_then_dead_letter_then_manual_retry(fast):
    async def scenario():
        app, admin, w, aid, rid = await setup(fast, destination_chat_ids=[DST1], max_attempts=3)
        w.backend.latest[SRC] = 0
        await w.beat()
        w.backend.forward_error_for[1] = BackendError("network_error")
        w.backend.emit(msg(1))
        for _ in range(4):
            await w.pump()
            await asyncio.sleep(0.05)
        rows = await job_rows(app)
        audit = (await admin.get("/api/audit", action="job.dead_letter")).json()["items"]
        metrics = (await admin.get("/api/queue/metrics")).json()
        w.backend.forward_error_for.clear()                                # Telegram recovered
        retried = (await admin.post("/api/jobs/bulk", {"action": "retry", "status": "dead_letter"})).json()
        await w.pump()
        after = await job_rows(app)
        await finish(app, w)
        return rows, audit, metrics, retried, after, w.backend.forwarded

    rows, audit, metrics, retried, after, forwarded = asyncio.run(scenario())
    assert rows == [(1, DST1, "dead_letter", 3, "network_error")]           # exactly max_attempts tries, then parked
    assert len(audit) == 1 and metrics["needs_attention"] == 1
    assert retried == {"affected": 1} and after[0][2] == "succeeded" and forwarded == [(SRC, 1, DST1, "forward")]


def test_flood_wait_blocks_the_account_for_exactly_the_time_telegram_demands(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e, destination_chat_ids=[DST1])
        w.backend.latest[SRC] = 0
        await w.beat()
        w.backend.forward_script = [BackendError("flood_wait", 120)]
        w.backend.emit(msg(1))
        w.backend.emit(msg(2))
        t0 = utcnow()
        await w.pump()
        blocked = await db(app, lambda s: s.get(TelegramAccount, uuid.UUID(aid)))
        during = await w.pump(3)                                           # nothing else may be sent while blocked
        rows_blocked = await job_rows(app)

        async def release(s):
            (await s.get(TelegramAccount, uuid.UUID(aid))).flood_wait_until = utcnow() - timedelta(seconds=1)
            for j in (await s.execute(select(ForwardJob))).scalars():
                j.available_at = utcnow() - timedelta(seconds=1)

        await db(app, release)
        after = await w.pump(2)
        rows_after = await job_rows(app)
        await finish(app, w)
        return t0, blocked, during, rows_blocked, after, rows_after, w

    t0, blocked, during, rows_blocked, after, rows_after, w = asyncio.run(scenario())
    assert 120 <= (blocked.flood_wait_until - t0).total_seconds() <= 124
    assert during == 0 and [(r[2], r[3]) for r in rows_blocked] == [("retry_wait", 0), ("retry_wait", 0)]   # 2nd job NOT sent
    assert after == 2 and {r[2] for r in rows_after} == {"succeeded"} and len(w.backend.forwarded) == 2


def test_permanent_errors_fail_immediately_without_retrying(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e, destination_chat_ids=[DST1])
        w.backend.latest[SRC] = 0
        await w.beat()
        w.backend.forward_error_for[1] = BackendError("forward_restricted")
        w.backend.emit(msg(1))
        w.backend.emit(msg(2))
        await w.pump(3)
        rows = await job_rows(app)
        detail = (await admin.get(f"/api/routes/{rid}")).json()
        await finish(app, w)
        return rows, detail

    rows, detail = asyncio.run(scenario())
    assert rows == [(1, DST1, "failed", 1, "forward_restricted"), (2, DST1, "succeeded", 1, None)]
    assert detail["stats"] == {"failed": 1, "succeeded": 1}


def test_a_destination_the_account_cannot_write_to_blocks_the_route(e2e):
    async def scenario():
        app = create_app(e2e)
        admin = Admin(app)
        await admin.login()
        w = await FSide(app, admin, "w1", FakeNetwork(), command_wait=1).create()
        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": w.id})
        await authorize(admin, aid)
        await admin.post(f"/api/accounts/{aid}/start")
        await w.beat()
        await w.beat()
        w.backend.chats[DST2] = ChatInfo(True, False, "read-only channel")          # the account is not allowed to post there
        rid = (await admin.post("/api/routes", {"name": "r1", "account_id": aid, "source_chat_ids": [SRC],
                                                "destination_chat_ids": [DST1, DST2]})).json()["id"]
        cid = (await admin.post(f"/api/routes/{rid}/verify")).json()["command_id"]
        await admin.finished(aid, cid)
        start = await admin.post(f"/api/routes/{rid}/start")
        verification = (await admin.get(f"/api/routes/{rid}")).json()["verification"]
        await finish(app, w)
        return start, verification

    start, verification = asyncio.run(scenario())
    assert start.status_code == 409 and start.json()["error"]["code"] == "route_not_verified"
    assert verification[str(DST2)]["can_send"] is False and verification[str(DST1)]["can_send"] is True


def test_stopping_the_account_stops_forwarding_without_losing_the_queue(e2e):
    async def scenario():
        app, admin, w, aid, rid = await setup(e2e, destination_chat_ids=[DST1])
        w.backend.latest[SRC] = 0
        await w.beat()
        w.backend.emit(msg(1))
        await w.engine._flush()
        await admin.post(f"/api/accounts/{aid}/stop")
        await w.beat()                                                      # worker disconnects and releases the lease
        sent_while_stopped = await w.engine.execute_once() if w.manager.connected_accounts() else 0
        rows_stopped = await job_rows(app)
        await admin.post(f"/api/accounts/{aid}/start")
        await w.beat()
        await w.beat()
        await w.pump()
        rows_after = await job_rows(app)
        await finish(app, w)
        return sent_while_stopped, rows_stopped, rows_after

    sent, stopped, after = asyncio.run(scenario())
    assert sent == 0 and [r[2] for r in stopped] == ["pending"]             # queued, not lost, not sent
    assert [r[2] for r in after] == ["succeeded"]


def test_runner_drives_the_whole_pipeline_in_real_time(settings, seed_user):
    from tests.unit.test_accounts_e2e import ControlPlaneClient, FakeBackend, httpx
    from worker.accounts import AccountManager
    from worker.runner import Runner

    seed_user("admin1")
    s = settings.model_copy(update={"worker_heartbeat_interval_seconds": 1})

    async def scenario():
        app = create_app(s)
        admin = Admin(app)
        await admin.login()
        backend = FakeBackend(FakeNetwork())
        wk = (await admin.post("/api/workers", {"name": "w1", "platform": "linux"})).json()
        http = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")
        client = ControlPlaneClient("http://testserver", wk["credential"], http=http)
        manager = AccountManager(client, backend, command_wait=1)
        engine = ForwardEngine(client, manager, backend, send_interval=0, claim_wait=1, flush_interval=0.1)
        manager.listeners.append(engine)
        runner = Runner(client, platform="linux", version="0.5.0", hostname="h", accounts=manager, engine=engine)
        task = asyncio.create_task(runner.run())

        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": wk["id"]})
        await authorize(admin, aid)
        await admin.post(f"/api/accounts/{aid}/start")
        rid = (await admin.post("/api/routes", {"name": "r1", "account_id": aid, "source_chat_ids": [SRC],
                                                "destination_chat_ids": [DST1]})).json()["id"]
        cid = (await admin.post(f"/api/routes/{rid}/verify")).json()["command_id"]
        await admin.finished(aid, cid)
        backend.latest[SRC] = 100
        await admin.post(f"/api/routes/{rid}/start")

        deadline = time.monotonic() + 25
        while time.monotonic() < deadline and not backend.watchers:
            await asyncio.sleep(0.2)
        backend.emit(msg(101, "live message"))
        while time.monotonic() < deadline and not backend.forwarded:
            await asyncio.sleep(0.2)
        await asyncio.sleep(1.5)                                           # let the result reach the API
        rows = await job_rows(app)
        runner.stop()
        code = await asyncio.wait_for(task, 20)
        await app.state.engine.dispose()
        return rows, backend.forwarded, code

    rows, forwarded, code = asyncio.run(scenario())
    assert forwarded == [(SRC, 101, DST1, "forward")] and rows == [(101, DST1, "succeeded", 1, None)] and code == 0
