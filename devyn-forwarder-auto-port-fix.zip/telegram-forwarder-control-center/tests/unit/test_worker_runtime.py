import asyncio

import httpx
import pytest

from worker.backoff import Backoff
from worker.client import (
    AuthError, ControlPlaneClient, FatalError, HeartbeatInfo, RegisterInfo, TransientError,
)
from worker.runner import EXIT_AUTH, EXIT_FATAL, EXIT_OK, Runner

CRED = "tfw_" + "ab" * 16 + ".super-secret-part"


# ---------------- backoff ----------------
def test_backoff_exponential_capped_with_full_jitter():
    b = Backoff(base=1, cap=10, rng=lambda: 1.0)  # worst-case jitter
    assert [b.next() for _ in range(6)] == [1, 2, 4, 8, 10, 10]
    b.reset()
    assert b.next() == 1
    assert Backoff(base=1, cap=10, rng=lambda: 0.0).next() == 0.0


def test_backoff_jitter_stays_inside_bounds():
    b = Backoff(base=2, cap=30)
    for i in range(50):
        d = b.next()
        assert 0 <= d <= min(30, 2 * 2 ** i)
    with pytest.raises(ValueError):
        Backoff(base=0)


# ---------------- client error mapping ----------------
def _client(handler) -> ControlPlaneClient:
    http = httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url="https://panel.example.com")
    return ControlPlaneClient("https://panel.example.com", CRED, http=http)


def _run(coro):
    return asyncio.run(coro)


@pytest.mark.parametrize("status,body,exc,revoked", [
    (401, {"error": {"code": "invalid_credential"}}, AuthError, False),
    (403, {"error": {"code": "worker_revoked"}}, AuthError, True),
    (409, {"error": {"code": "platform_mismatch"}}, FatalError, None),
    (422, {"error": {"code": "validation_error"}}, FatalError, None),
    (429, {}, TransientError, None),
    (503, {}, TransientError, None),
])
def test_client_maps_http_errors(status, body, exc, revoked):
    c = _client(lambda req: httpx.Response(status, json=body))
    with pytest.raises(exc) as info:
        _run(c.heartbeat({}))
    if revoked is not None:
        assert info.value.revoked is revoked
    assert CRED not in str(info.value)


def test_network_error_is_transient_and_leaks_nothing():
    def boom(req):
        raise httpx.ConnectError("cannot connect to https://panel.example.com with " + req.headers["authorization"])

    with pytest.raises(TransientError) as info:
        _run(_client(boom).register("linux", "0.3.0", "h"))
    assert CRED not in str(info.value) and "panel.example.com" not in str(info.value)


def test_client_sends_bearer_and_parses_register():
    seen = {}

    def handler(req):
        seen["auth"], seen["path"] = req.headers["authorization"], req.url.path
        return httpx.Response(200, json={"worker_id": "w1", "name": "n", "heartbeat_interval_seconds": 15,
                                         "heartbeat_timeout_seconds": 60, "report_resources": False,
                                         "server_time": "2026-01-01T00:00:00Z"})

    info = _run(_client(handler).register("linux", "0.3.0", "h"))
    assert seen == {"auth": f"Bearer {CRED}", "path": "/api/worker/v1/register"}
    assert info.heartbeat_interval_seconds == 15 and info.report_resources is False


# ---------------- runner (scripted fake control plane) ----------------
class FakeClient:
    def __init__(self, register_script, heartbeat_script):
        self.register_script, self.heartbeat_script = list(register_script), list(heartbeat_script)
        self.registers, self.payloads = 0, []

    @staticmethod
    def _step(script):
        item = script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    async def register(self, platform, version, hostname):
        self.registers += 1
        return self._step(self.register_script)

    async def heartbeat(self, payload):
        self.payloads.append(payload)
        return self._step(self.heartbeat_script)


INFO = RegisterInfo("w1", "n", 15, 60, True)
HB = HeartbeatInfo(True)


def make_runner(client, stop_after_waits=None, **kw):
    waits = []
    runner = Runner(client, platform="linux", version="0.3.0", hostname="h",
                    backoff=Backoff(1, 60, rng=lambda: 1.0), **kw)

    async def wait(seconds):
        waits.append(seconds)
        if stop_after_waits is not None and len(waits) >= stop_after_waits:
            runner.stop()

    runner._wait = wait
    return runner, waits


def test_runner_reconnects_with_backoff_after_connection_loss():
    c = FakeClient([INFO, INFO], [HB, TransientError("ConnectError"), HB])
    runner, waits = make_runner(c, stop_after_waits=5)
    assert _run(runner.run()) == EXIT_OK
    assert c.registers == 2                      # re-registered after the outage (state resync)
    assert len(c.payloads) == 3                  # ok, lost, ok (after reconnect)
    assert waits == [15, 15, 1.0, 15, 15]        # interval, interval, backoff(1s), interval, interval(stop)


def test_runner_register_failures_back_off_exponentially_then_recover():
    err = TransientError("503")
    c = FakeClient([err, err, err, INFO], [HB])
    runner, waits = make_runner(c, stop_after_waits=5)
    _run(runner.run())
    assert waits[:3] == [1.0, 2.0, 4.0] and waits[3] == 15
    assert runner._backoff.attempt == 0          # reset after a successful registration


def test_runner_stops_permanently_when_credential_is_rejected_or_revoked():
    for exc in (AuthError("x", revoked=True), AuthError("x", revoked=False)):
        c = FakeClient([INFO], [exc])
        runner, _ = make_runner(c, stop_after_waits=50)
        assert _run(runner.run()) == EXIT_AUTH and not runner.connected
    c = FakeClient([AuthError("x")], [])
    assert _run(make_runner(c, 50)[0].run()) == EXIT_AUTH
    assert c.registers == 1                       # no retry storm


def test_runner_fatal_error_exits_without_retrying():
    c = FakeClient([FatalError("http 409: platform_mismatch")], [])
    runner, waits = make_runner(c, 50)
    assert _run(runner.run()) == EXIT_FATAL and waits == []


def test_resources_only_sent_while_server_allows_it():
    c = FakeClient([INFO], [HB, HeartbeatInfo(False), HeartbeatInfo(False)])
    runner, _ = make_runner(c, stop_after_waits=4, resource_provider=lambda: {"cpu_percent": 5.0, "memory_percent": 6.0})
    _run(runner.run())
    assert [("resources" in p) for p in c.payloads] == [True, True, False]


def test_health_provider_is_reported():
    c = FakeClient([INFO], [HB])
    runner, _ = make_runner(c, stop_after_waits=2, health_provider=lambda: ("degraded", "telegram flood wait", 3))
    _run(runner.run())
    assert c.payloads[0] == {"health": "degraded", "degraded_reason": "telegram flood wait", "running_jobs": 3}


def test_graceful_stop_before_first_connect():
    runner, _ = make_runner(FakeClient([], []))
    runner.stop()
    assert _run(runner.run()) == EXIT_OK


# ---------------- end-to-end against the real API + database ----------------
class FlakyTransport(httpx.AsyncBaseTransport):
    """Delegates to the real ASGI app but fails selected request numbers like a dropped network."""

    def __init__(self, inner, fail_on):
        self.inner, self.fail_on, self.n = inner, set(fail_on), 0

    async def handle_async_request(self, request):
        self.n += 1
        if self.n in self.fail_on:
            raise httpx.ConnectError("network down")
        return await self.inner.handle_async_request(request)


@pytest.fixture
def seeded_worker(settings):
    from app.services.workers import create_worker
    from tests.conftest import run_db

    async def _seed(s):
        w, cred = create_worker(s, "e2e-worker", "linux", None)
        await s.flush()
        return str(w.id), cred

    return run_db(settings, _seed)


def _e2e(settings, cred, fail_on=(), stop_after_waits=5, revoke_before=None):
    from app.main import create_app

    async def go():
        app = create_app(settings)
        transport = FlakyTransport(httpx.ASGITransport(app=app), fail_on)
        http = httpx.AsyncClient(transport=transport, base_url="http://testserver")
        client = ControlPlaneClient("http://testserver", cred, http=http)
        runner = Runner(client, platform="linux", version="0.3.0", hostname="e2e-host",
                        backoff=Backoff(0.001, 0.002), health_provider=lambda: ("ok", None, 4),
                        resource_provider=lambda: {"cpu_percent": 7.0, "memory_percent": 8.0})
        waited = []

        async def wait(seconds):
            waited.append(seconds)
            await asyncio.sleep(0)
            if len(waited) >= stop_after_waits:
                runner.stop()

        runner._wait = wait
        try:
            code = await runner.run()
        finally:
            await http.aclose()
            await app.state.engine.dispose()
        return code

    return asyncio.run(go())


def test_e2e_worker_registers_and_heartbeats(settings, seeded_worker, audit_rows):
    from app.models import Worker
    from tests.conftest import run_db
    import uuid

    wid, cred = seeded_worker
    assert _e2e(settings, cred) == EXIT_OK

    async def read(s):
        w = await s.get(Worker, uuid.UUID(wid))
        return w.status, w.version, w.hostname, w.running_jobs, w.cpu_percent

    assert run_db(settings, read) == ("online", "0.3.0", "e2e-host", 4, 7.0)
    assert len(audit_rows("worker.register")) == 1


def test_e2e_worker_reconnects_after_network_outage(settings, seeded_worker, audit_rows):
    wid, cred = seeded_worker
    # requests: 1 register, 2 heartbeat, 3 heartbeat (dropped), 4 register, 5 heartbeat ...
    assert _e2e(settings, cred, fail_on=(3,), stop_after_waits=7) == EXIT_OK
    assert len(audit_rows("worker.register")) == 2


def test_e2e_revoked_worker_exits_with_auth_code(settings, seeded_worker):
    from app.models import Worker
    from app.services.workers import revoke
    from tests.conftest import run_db
    import uuid

    wid, cred = seeded_worker

    async def do_revoke(s):
        revoke(await s.get(Worker, uuid.UUID(wid)))

    run_db(settings, do_revoke)
    assert _e2e(settings, cred) == EXIT_AUTH
