import json
from pathlib import Path

import pytest

from worker.config import WorkerSettings, detect_platform, get_worker_settings
from worker.main import main


def test_rejects_plain_http_remote():
    with pytest.raises(ValueError):
        WorkerSettings(control_plane_url="http://example.com")


def test_accepts_https_and_localhost():
    assert WorkerSettings(control_plane_url="https://panel.example.com/").control_plane_url == "https://panel.example.com"
    WorkerSettings(control_plane_url="http://localhost:8000")


def test_platform_detection(monkeypatch):
    monkeypatch.setattr("sys.platform", "win32")
    assert detect_platform() == "windows"
    monkeypatch.setattr("sys.platform", "linux")
    assert detect_platform() == "linux"


def test_credential_never_printed(monkeypatch, capsys):
    monkeypatch.setenv("TFCC_WORKER_CONTROL_PLANE_URL", "https://panel.example.com")
    monkeypatch.setenv("TFCC_WORKER_ID", "w1")
    monkeypatch.setenv("TFCC_WORKER_CREDENTIAL", "TOPSECRETCRED")
    get_worker_settings.cache_clear()
    try:
        assert main(["check-config"]) == 0
        assert "TOPSECRETCRED" not in capsys.readouterr().out
    finally:
        get_worker_settings.cache_clear()


def test_missing_config_returns_error(monkeypatch, capsys):
    for k in ("CONTROL_PLANE_URL", "ID", "CREDENTIAL"):
        monkeypatch.delenv(f"TFCC_WORKER_{k}", raising=False)
    monkeypatch.chdir("/tmp")
    get_worker_settings.cache_clear()
    try:
        assert main(["check-config"]) == 1
        assert "missing" in capsys.readouterr().out
    finally:
        get_worker_settings.cache_clear()


def test_job_state_machine_is_consistent():
    data = json.loads((Path(__file__).parents[2] / "packages/shared-schemas/job_states.json").read_text())
    states = set(data["states"])
    assert set(data["transitions"]) == states
    for dsts in data["transitions"].values():
        assert set(dsts) <= states
    for t in data["terminal"]:
        assert data["transitions"][t] == []


def test_cli_version_and_missing_config(monkeypatch, capsys):
    for k in ("CONTROL_PLANE_URL", "ID", "CREDENTIAL"):
        monkeypatch.delenv(f"TFCC_WORKER_{k}", raising=False)
    monkeypatch.chdir("/tmp")
    get_worker_settings.cache_clear()
    try:
        assert main(["version"]) == 0
        assert main(["run"]) == 1  # refuses to start without a control-plane URL and credential
        assert "TFCC_WORKER_CREDENTIAL" in capsys.readouterr().err
    finally:
        get_worker_settings.cache_clear()


def test_worker_id_is_not_required(monkeypatch, capsys):
    monkeypatch.setenv("TFCC_WORKER_CONTROL_PLANE_URL", "https://panel.example.com")
    monkeypatch.setenv("TFCC_WORKER_CREDENTIAL", "tfw_x.y")
    monkeypatch.delenv("TFCC_WORKER_ID", raising=False)
    get_worker_settings.cache_clear()
    try:
        assert main(["check-config"]) == 0
    finally:
        get_worker_settings.cache_clear()
