import asyncio
import logging

import pytest

from worker.accounts import AccountManager
from worker.client import Assignment, ConflictError, HeartbeatInfo, RegisterInfo, SessionData, TransientError
from worker.telegram_backend import BackendError
from tests.fakes import CODE_OK, PW_OK, SESSION, FakeBackend, FakeClient, FakeNetwork

AID = "11111111-1111-1111-1111-111111111111"


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


def build(backend="default", ttl=60.0, **kw):
    clock = Clock()
    client = FakeClient(ttl)
    backend = FakeBackend() if backend == "default" else backend
    return AccountManager(client, backend, clock=clock, command_wait=0, **kw), client, backend, clock


async def settle(mgr):
    while mgr._tasks:
        await asyncio.gather(*list(mgr._tasks), return_exceptions=True)


def cmd(type, payload=None, cid="c1"):
    return {"id": cid, "type": type, "account_id": AID, "payload": payload}


def running(*ids):
    return tuple(Assignment(i, "running") for i in ids)


def hb(accounts=(), lost=(), ttl=60.0):
    return HeartbeatInfo(True, ttl, tuple(accounts), tuple(lost))


def run(coro):
    return asyncio.run(coro)


# ---------------------------------------------------------------- login flow
def test_login_flow_with_code(caplog):
    async def go():
        mgr, client, backend, _ = build()
        caplog.set_level(logging.DEBUG)
        await mgr._run_command(cmd("send_code", {"phone": "+84901234567"}, "c1"))
        await mgr._run_command(cmd("sign_in_code", {"code": "00000"}, "c2"))      # wrong code: attempt stays alive
        await mgr._run_command(cmd("sign_in_code", {"code": CODE_OK}, "c3"))
        return client, backend

    client, backend = run(go())
    r = {c[0]: c for c in client.results}
    assert r["c1"][1:3] == ("done", {"state": "awaiting_code"})
    assert r["c2"][1] == "failed" and r["c2"][3] == "code_invalid"
    assert r["c3"][1] == "done" and r["c3"][2] == {"state": "authorized", "telegram_user_id": 111, "username": "alice_tg"}
    assert client.uploads == [(AID, 1, SESSION, None)] and client.released == [(AID, 1)]   # session saved under a lease, then released
    assert backend.disconnects                                                              # login socket closed
    blob = caplog.text + " ".join(repr(r.__dict__) for r in caplog.records)   # message AND structured extras
    for secret in (CODE_OK, "+84901234567", "901234567", SESSION):
        assert secret not in blob


def test_login_with_two_factor_password(caplog):
    async def go():
        mgr, client, _, _ = build(FakeBackend(two_factor=True))
        caplog.set_level(logging.DEBUG)
        await mgr._run_command(cmd("send_code", {"phone": "+84901234567"}, "c1"))
        await mgr._run_command(cmd("sign_in_code", {"code": CODE_OK}, "c2"))
        await mgr._run_command(cmd("sign_in_password", {"password": "wrong"}, "c3"))
        await mgr._run_command(cmd("sign_in_password", {"password": PW_OK}, "c4"))
        return client

    client = run(go())
    r = {c[0]: c for c in client.results}
    assert r["c2"][2] == {"state": "awaiting_password"}
    assert r["c3"][3] == "password_invalid"
    assert r["c4"][1] == "done" and r["c4"][2]["state"] == "authorized"
    blob = caplog.text + " ".join(repr(r.__dict__) for r in caplog.records)
    assert PW_OK not in blob and "wrong" not in blob


def test_login_errors_are_reported_as_codes():
    async def go():
        mgr, client, backend, _ = build()
        await mgr._run_command(cmd("sign_in_code", {"code": CODE_OK}, "lost"))              # worker restarted mid-login
        backend.send_code_error = BackendError("flood_wait", 37)
        await mgr._run_command(cmd("send_code", {"phone": "+84901234567"}, "flood"))
        backend.send_code_error = None
        await mgr._run_command(cmd("send_code", {"phone": "+84901234567"}, "ok"))
        backend.send_code_error = BackendError("phone_invalid")
        await mgr._run_command(cmd("send_code", {"phone": "+1"}, "badphone"))
        await mgr._run_command(cmd("sign_in_code", {"code": CODE_OK}, "after"))              # attempt was dropped
        return client

    r = {c[0]: c for c in run(go()).results}
    assert r["lost"][3] == "login_session_lost"
    assert r["flood"][3:5] == ("flood_wait", 37)                                             # exact wait from Telegram
    assert r["badphone"][3] == "phone_invalid" and r["after"][3] == "login_session_lost"


def test_without_telegram_credentials_and_with_lease_held():
    async def go():
        mgr, client, *_ = build(backend=None)
        await mgr._run_command(cmd("send_code", {"phone": "+84901234567"}, "a"))
        mgr2, client2, *_ = build()
        await mgr2._run_command(cmd("send_code", {"phone": "+84901234567"}, "b"))
        client2.lease_held_by_other.add(AID)
        await mgr2._run_command(cmd("sign_in_code", {"code": CODE_OK}, "c"))
        return client, client2

    c1, c2 = run(go())
    assert c1.results[0][3] == "telegram_api_not_configured"
    assert {r[0]: r for r in c2.results}["c"][3] == "lease_held" and c2.uploads == []


# ---------------------------------------------------------------- running accounts + fencing
async def start_account(mgr, client, backend, clock, session=SESSION):
    client.sessions[AID] = SessionData(session, 3)
    await mgr.on_heartbeat(hb(running(AID)), clock())
    await settle(mgr)


def test_start_connects_and_reports_with_epoch():
    async def go():
        mgr, client, backend, clock = build()
        await start_account(mgr, client, backend, clock)
        return mgr.heartbeat_accounts(), backend, client

    reports, backend, client = run(go())
    assert reports == [{"account_id": AID, "epoch": 1, "state": "connected", "error_code": None}]
    assert backend.connects == 1 and client.acquired == [AID]


def test_self_fencing_when_lease_cannot_be_renewed():
    async def go():
        mgr, client, backend, clock = build(ttl=60.0)
        await start_account(mgr, client, backend, clock)
        handle_active = lambda: bool(mgr._active)  # noqa: E731
        clock.t += 47                                   # still inside 80% of the 60 s TTL (deadline = +48 s)
        await mgr.enforce_deadlines()
        before = handle_active()
        clock.t += 2                                    # past the deadline, no renewal happened (control plane unreachable)
        await mgr.enforce_deadlines()
        return before, handle_active(), backend, client

    before, after, backend, client = run(go())
    assert before is True and after is False
    assert backend.disconnects and not backend.net.open_by_session.get(SESSION)               # socket really closed
    assert client.uploads == [] and client.released == []                                      # must not touch the session after fencing


def test_heartbeat_renewal_extends_deadline_only_for_reported_epochs():
    async def go():
        mgr, client, backend, clock = build(ttl=60.0)
        await start_account(mgr, client, backend, clock)
        clock.t += 30
        reports = mgr.heartbeat_accounts()                # heartbeat built and sent at t+30
        sent = clock.t
        clock.t += 10
        await mgr.on_heartbeat(hb(running(AID)), sent)    # response arrives at t+40: lease renewed from the send time
        clock.t += 30                                     # t+70: would be past the original deadline (t+48)
        await mgr.enforce_deadlines()
        alive_after_renewal = bool(mgr._active)
        # an account started after the heartbeat was built is NOT covered by that heartbeat's renewal
        mgr2, client2, backend2, clock2 = build(ttl=60.0)
        mgr2._reported = {}
        await start_account(mgr2, client2, backend2, clock2)
        first_deadline = mgr2._active[AID].deadline
        await mgr2.on_heartbeat(hb(running(AID)), clock2.t + 30)
        return alive_after_renewal, reports, first_deadline, mgr2._active[AID].deadline

    alive, reports, d1, d2 = run(go())
    assert alive is True and reports[0]["epoch"] == 1
    assert d1 == d2


def test_deadline_is_earlier_than_server_lease_expiry():
    mgr, *_ = build(ttl=60.0)
    assert mgr._margin * 60.0 < 60.0                      # worker stops using the session before the server may re-lease it


def test_lost_lease_drops_immediately_without_touching_session():
    async def go():
        mgr, client, backend, clock = build()
        await start_account(mgr, client, backend, clock)
        first = mgr._active[AID].handle
        mgr.heartbeat_accounts()
        await mgr.on_heartbeat(hb([], lost=[AID]), clock.t)             # reassigned elsewhere: no longer in our list
        reassigned_away = AID not in mgr._active
        # Still assigned but the lease was lost (e.g. it expired): drop at once, then take a NEW lease the normal way.
        mgr2, client2, backend2, clock2 = build()
        await start_account(mgr2, client2, backend2, clock2)
        old = mgr2._active[AID]
        mgr2.heartbeat_accounts()
        await mgr2.on_heartbeat(hb(running(AID), lost=[AID]), clock2.t)
        await settle(mgr2)
        return reassigned_away, first, client, mgr2, old, client2

    away, first, client, mgr2, old, client2 = run(go())
    assert away and first.connected is False
    assert client.uploads == [] and client.released == []               # never touches the session/lease after losing it
    assert old.handle.connected is False
    assert mgr2._active[AID].epoch == 2 and client2.acquired == [AID, AID]   # fresh lease, fresh fencing epoch


def test_desired_stopped_stops_gracefully_and_saves_changed_session():
    async def go():
        mgr, client, backend, clock = build()
        backend.session_after_use = SESSION + "-refreshed"        # Telethon changed its auth data while connected
        await start_account(mgr, client, backend, clock)
        await mgr.on_heartbeat(hb([Assignment(AID, "stopped")]), clock.t)
        await settle(mgr)
        return mgr, client, backend

    mgr, client, backend = run(go())
    assert AID not in mgr._active
    assert client.uploads == [(AID, 1, SESSION + "-refreshed", 3)]          # optimistic version check
    assert client.released == [(AID, 1)] and backend.disconnects


def test_start_failures_back_off_with_exact_flood_wait_and_report_errors():
    async def go():
        mgr, client, backend, clock = build()
        client.sessions[AID] = SessionData(SESSION, 1)
        backend.connect_error = BackendError("flood_wait", 120)
        await mgr.on_heartbeat(hb(running(AID)), clock.t)
        await settle(mgr)
        first = (backend.connects, mgr.heartbeat_accounts())
        clock.t += 60
        await mgr.on_heartbeat(hb(running(AID)), clock.t)           # still inside Telegram's 120 s: must not retry
        await settle(mgr)
        during = client.acquired.copy()
        clock.t += 61
        backend.connect_error = None
        await mgr.on_heartbeat(hb(running(AID)), clock.t)
        await settle(mgr)
        return first, during, client.acquired.copy(), mgr.heartbeat_accounts(), client.released

    first, during, after, reports, released = run(go())
    assert first[1] == [{"account_id": AID, "epoch": 0, "state": "error", "error_code": "flood_wait"}]
    assert len(during) == 1 and len(after) == 2                                    # waited the full 120 s, then retried
    assert reports[0]["state"] == "connected" and released == [(AID, 1)]          # failed attempt released its lease


def test_dead_session_is_reported_and_lease_released():
    async def go():
        mgr, client, backend, clock = build()
        backend.dead_sessions.add(SESSION)
        await start_account(mgr, client, backend, clock)
        return mgr.heartbeat_accounts(), client.released

    reports, released = run(go())
    assert reports[0]["error_code"] == "auth_key_unregistered" and released == [(AID, 1)]


def test_lease_held_by_previous_owner_is_not_an_error():
    async def go():
        mgr, client, backend, clock = build()
        client.lease_held_by_other.add(AID)
        await start_account(mgr, client, backend, clock)
        return mgr.heartbeat_accounts(), backend.connects

    reports, connects = run(go())
    assert reports == [] and connects == 0                                          # waits quietly for release/expiry


def test_lost_connection_is_detected_and_retried_later():
    async def go():
        mgr, client, backend, clock = build()
        await start_account(mgr, client, backend, clock)
        mgr._active[AID].handle.connected = False
        await mgr.enforce_deadlines()
        return mgr.heartbeat_accounts(), AID in mgr._active

    reports, active = run(go())
    assert active is False and reports[0]["error_code"] == "connection_lost"


# ---------------------------------------------------------------- check / logout / shutdown
def test_check_connection_never_opens_a_second_connection():
    async def go():
        mgr, client, backend, clock = build()
        await start_account(mgr, client, backend, clock)
        await mgr._run_command(cmd("check_connection", cid="chk"))
        return client, backend

    client, backend = run(go())
    assert {r[0]: r for r in client.results}["chk"][2] == {"connection_state": "connected"}
    assert backend.connects == 1                                                    # the running connection was reused


def test_check_connection_when_idle_connects_then_releases():
    async def go():
        mgr, client, backend, _ = build()
        client.sessions[AID] = SessionData(SESSION, 1)
        await mgr._run_command(cmd("check_connection", cid="chk"))
        return client, backend

    client, backend = run(go())
    r = client.results[0]
    assert r[1] == "done" and r[2]["connection_state"] == "connected" and r[2]["telegram_user_id"] == 111
    assert client.released == [(AID, 1)] and backend.disconnects and not backend.net.open_by_session[SESSION]


def test_logout_revokes_on_telegram_and_tolerates_dead_or_missing_sessions():
    async def go():
        mgr, client, backend, _ = build()
        client.sessions[AID] = SessionData(SESSION, 1)
        await mgr._run_command(cmd("logout", cid="a"))
        backend.dead_sessions.add(SESSION)
        await mgr._run_command(cmd("logout", cid="b"))
        client.sessions.clear()
        await mgr._run_command(cmd("logout", cid="c"))
        return client, backend

    client, backend = run(go())
    assert [r[1] for r in client.results] == ["done", "done", "done"]
    assert len(backend.logged_out) == 1                                              # only the live session needed revoking


def test_shutdown_saves_session_releases_lease_and_closes():
    async def go():
        mgr, client, backend, clock = build()
        backend.session_after_use = SESSION + "-2"
        await start_account(mgr, client, backend, clock)
        await mgr.shutdown()
        return mgr, client, backend

    mgr, client, backend = run(go())
    assert not mgr._active and client.uploads and client.released == [(AID, 1)] and backend.disconnects


def test_command_loop_executes_commands_and_survives_poll_errors():
    async def go():
        mgr, client, backend, _ = build()
        stop = asyncio.Event()
        client.poll_error = TransientError("ConnectError")
        task = asyncio.create_task(mgr.command_loop(stop))
        await asyncio.sleep(0.05)
        client.poll_error = None
        client.commands = [cmd("send_code", {"phone": "+84901234567"}, "c1")]
        for _ in range(60):
            await asyncio.sleep(0.1)
            if client.results:
                break
        stop.set()
        await asyncio.wait_for(task, 5)
        return client

    client = run(go())
    assert client.results and client.results[0][:2] == ("c1", "done")


# ---------------------------------------------------------------- the real Telethon adapter (offline checks only)
def test_telethon_error_mapping_and_client_setup():
    from telethon import errors
    from worker.telegram_backend import TelethonBackend, map_error

    flood = map_error(errors.FloodWaitError(request=None, capture=37))
    assert (flood.code, flood.retry_after) == ("flood_wait", 37)
    for exc, code in [(errors.PhoneCodeInvalidError(request=None), "code_invalid"),
                      (errors.PhoneCodeExpiredError(request=None), "code_expired"),
                      (errors.PasswordHashInvalidError(request=None), "password_invalid"),
                      (errors.AuthKeyUnregisteredError(request=None), "auth_key_unregistered"),
                      (errors.UserDeactivatedBanError(request=None), "user_deactivated"),
                      (errors.PhoneNumberInvalidError(request=None), "phone_invalid"),
                      (ConnectionResetError(), "network_error"), (ValueError("secret text"), "telegram_error")]:
        assert map_error(exc).code == code
    assert "secret text" not in str(map_error(ValueError("secret text")))

    client = TelethonBackend(12345, "0123456789abcdef0123456789abcdef")._new_client("")
    assert client.flood_sleep_threshold == 0          # FloodWait is surfaced, never slept through silently
    assert client.session.save() == ""                # in-memory StringSession: no session file on disk
