"""Real API + real database + real worker client/manager; only Telegram is faked."""
import asyncio
import time
import uuid
from datetime import timedelta

import httpx
import pytest
from sqlalchemy import select

from app.db import make_sessionmaker
from app.main import create_app
from app.models import TelegramAccount
from app.types import utcnow
from tests.conftest import PASSWORD, run_db
from tests.fakes import CODE_OK, SESSION, FakeBackend, FakeNetwork
from tests.unit.test_accounts_api import db_dump
from worker.accounts import AccountManager
from worker.client import ControlPlaneClient
from worker.runner import EXIT_OK, Runner

PHONE = "+84901234567"


class Clock:
    def __init__(self):
        self.t = 5000.0

    def __call__(self):
        return self.t


class Admin:
    def __init__(self, app):
        self.http = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")
        self.h = {}

    async def login(self):
        r = await self.http.post("/api/auth/login", json={"username": "admin1", "password": PASSWORD})
        assert r.status_code == 200, r.text
        self.h = {"X-CSRF-Token": r.json()["csrf_token"]}

    async def post(self, path, body=None):
        return await self.http.post(path, json=body, headers=self.h)

    async def put(self, path, body):
        return await self.http.put(path, json=body, headers=self.h)

    async def get(self, path, **params):
        return await self.http.get(path, params=params)

    async def account(self, aid):
        return (await self.get(f"/api/accounts/{aid}")).json()

    async def finished(self, aid, cid):
        r = await self.get(f"/api/accounts/{aid}/commands/{cid}", wait_seconds=15)
        assert r.json()["status"] in ("done", "failed"), r.text
        return r.json()


class WorkerSide:
    def __init__(self, app, admin, name, network, clock=None, command_wait=1):
        self.app, self.admin, self.name = app, admin, name
        self.backend, self.clock = FakeBackend(network), clock or Clock()
        self.client = self.manager = self.id = None
        self.command_wait = command_wait

    async def create(self):
        wk = (await self.admin.post("/api/workers", {"name": self.name, "platform": "linux"})).json()
        self.id = wk["id"]
        http = httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app), base_url="http://testserver")
        self.client = ControlPlaneClient("http://testserver", wk["credential"], http=http)
        self.manager = AccountManager(self.client, self.backend, clock=self.clock, command_wait=self.command_wait)
        info = await self.client.register("linux", "0.4.0", "host")
        await self.manager.on_register(info, self.clock())
        self.stop = asyncio.Event()
        self.cmd_task = asyncio.create_task(self.manager.command_loop(self.stop))
        return self

    async def beat(self):
        payload = {"accounts": self.manager.heartbeat_accounts()}
        sent = self.clock()
        hb = await self.client.heartbeat(payload)
        await self.manager.on_heartbeat(hb, sent)
        while self.manager._tasks:
            await asyncio.gather(*list(self.manager._tasks), return_exceptions=True)
        return hb

    async def close(self):
        self.stop.set()
        await asyncio.wait_for(self.cmd_task, 10)


async def authorize(admin, aid):
    cid = (await admin.post(f"/api/accounts/{aid}/login/start", {"phone": PHONE})).json()["command_id"]
    assert (await admin.finished(aid, cid))["status"] == "done"
    cid = (await admin.post(f"/api/accounts/{aid}/login/code", {"code": CODE_OK})).json()["command_id"]
    assert (await admin.finished(aid, cid))["status"] == "done"
    assert (await admin.account(aid))["auth_state"] == "authorized"


async def expire_lease(app, aid):
    async with make_sessionmaker(app.state.engine)() as s:
        (await s.get(TelegramAccount, uuid.UUID(aid))).lease_expires_at = utcnow() - timedelta(seconds=1)
        await s.commit()


@pytest.fixture
def e2e(settings, seed_user):
    seed_user("admin1")
    return settings


def test_account_lifecycle_login_run_stop_delete(e2e):
    async def scenario():
        app = create_app(e2e)
        admin = Admin(app)
        await admin.login()
        net = FakeNetwork()
        w = await WorkerSide(app, admin, "w1", net).create()
        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": w.id})

        await authorize(admin, aid)
        seen = {"after_login": await admin.account(aid)}
        assert (await admin.post(f"/api/accounts/{aid}/start")).json()["desired_state"] == "running"
        await w.beat()                         # worker sees the assignment, takes the lease, connects
        await w.beat()                         # reports "connected" and renews the lease
        seen["running"] = await admin.account(aid)
        await admin.post(f"/api/accounts/{aid}/stop")
        await w.beat()                         # worker stops gracefully and releases the lease
        seen["stopped"] = await admin.account(aid)

        d = (await admin.post(f"/api/accounts/{aid}/delete", {"confirm_name": "acc"})).json()
        assert d["status"] == "logout_requested"
        gone = time.monotonic() + 15
        while time.monotonic() < gone:                       # the account disappears once Telegram confirmed the logout
            seen["deleted_status"] = (await admin.get(f"/api/accounts/{aid}")).status_code
            if seen["deleted_status"] == 404:
                break
            await asyncio.sleep(0.3)
        seen["command_after_delete"] = (await admin.get(f"/api/accounts/{aid}/commands/{d['command_id']}")).status_code
        audit = (await admin.get("/api/audit", page_size=100)).text
        await w.close()
        await app.state.engine.dispose()
        return seen, w, net, audit

    seen, w, net, audit = asyncio.run(scenario())
    assert seen["after_login"]["has_session"] and seen["after_login"]["telegram_user_id"] == 111
    assert seen["running"]["connection_state"] == "connected" and seen["running"]["owner_worker_id"] == w.id
    assert seen["stopped"]["connection_state"] == "disconnected" and seen["stopped"]["owner_worker_id"] is None
    assert seen["deleted_status"] == 404 and seen["command_after_delete"] == 404 and len(w.backend.logged_out) == 1       # session terminated on Telegram, then purged
    assert net.max_simultaneous == 1
    everything = db_dump(e2e) + audit
    for secret in (CODE_OK, "901234567", SESSION):
        assert secret not in everything


def test_handover_between_workers_never_shares_a_session(e2e):
    async def scenario():
        app = create_app(e2e)
        admin = Admin(app)
        await admin.login()
        net = FakeNetwork()                                   # raises max_simultaneous if one auth key is open twice
        a = await WorkerSide(app, admin, "wa", net).create()
        b = await WorkerSide(app, admin, "wb", net).create()
        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": a.id})
        await authorize(admin, aid)
        await admin.post(f"/api/accounts/{aid}/start")
        await a.beat()
        await a.beat()
        assert (await admin.account(aid))["owner_worker_id"] == a.id

        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": b.id})
        await b.beat()                                        # B wants it, but A still owns the lease
        b_connects_while_a_owns = b.backend.connects
        owner_during = (await admin.account(aid))["owner_worker_id"]

        hb = await a.beat()                                   # A is told it lost the lease and drops it at once
        a_dropped = aid in hb.lost_leases and not a.manager._active

        b.clock.t += 6                                        # B's retry cooldown passes, A's lease has NOT expired yet
        await b.beat()
        still_blocked = b.backend.connects
        await expire_lease(app, aid)                          # A never released: the lease simply times out
        b.clock.t += 6
        await b.beat()
        final = await admin.account(aid)
        stale_upload = await a.client._http.put(  # a late write from the old owner must be impossible
            f"/api/worker/v1/accounts/{aid}/session", headers=a.client._headers,
            json={"epoch": 1, "session": "x" * 40, "expected_version": None})
        await a.close(); await b.close()
        await app.state.engine.dispose()
        return b_connects_while_a_owns, owner_during, a_dropped, still_blocked, final, stale_upload.status_code, net, b

    first, owner_during, a_dropped, blocked, final, stale, net, b = asyncio.run(scenario())
    assert first == 0 and owner_during is not None and a_dropped
    assert blocked == 0                                       # B stayed out until the lease really expired
    assert final["owner_worker_id"] == b.id and final["connection_state"] == "connected"
    assert stale in (404, 409)
    assert net.max_simultaneous == 1                          # at no moment were two workers connected with the session


def test_dead_session_marks_account_invalid_end_to_end(e2e):
    async def scenario():
        app = create_app(e2e)
        admin = Admin(app)
        await admin.login()
        w = await WorkerSide(app, admin, "w1", FakeNetwork()).create()
        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": w.id})
        await authorize(admin, aid)
        w.backend.dead_sessions.add(SESSION)                  # Telegram revoked it (user terminated the session)
        await admin.post(f"/api/accounts/{aid}/start")
        await w.beat()                                        # connect fails -> error reported
        await w.beat()
        acc = await admin.account(aid)
        w.clock.t += 100
        await w.beat()
        await w.close()
        await app.state.engine.dispose()
        return acc, w

    acc, w = asyncio.run(scenario())
    assert acc["auth_state"] == "invalid" and acc["desired_state"] == "stopped"
    assert w.backend.connects == 0 and w.manager._errors == {}      # stopped retrying once the API invalidated it


def test_runner_keeps_account_connected_and_shuts_down_cleanly(settings, seed_user):
    seed_user("admin1")
    s = settings.model_copy(update={"worker_heartbeat_interval_seconds": 1})

    async def scenario():
        app = create_app(s)
        admin = Admin(app)
        await admin.login()
        net = FakeNetwork()
        backend = FakeBackend(net)
        wk = (await admin.post("/api/workers", {"name": "w1", "platform": "linux"})).json()
        http = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")
        client = ControlPlaneClient("http://testserver", wk["credential"], http=http)
        manager = AccountManager(client, backend, command_wait=1)
        runner = Runner(client, platform="linux", version="0.4.0", hostname="h", accounts=manager)
        task = asyncio.create_task(runner.run())

        aid = (await admin.post("/api/accounts", {"name": "acc"})).json()["id"]
        await admin.put(f"/api/accounts/{aid}/assignment", {"worker_id": wk["id"]})
        await authorize(admin, aid)
        await admin.post(f"/api/accounts/{aid}/start")
        connected, deadline = None, time.monotonic() + 20
        while time.monotonic() < deadline:
            connected = await admin.account(aid)
            if connected["connection_state"] == "connected":
                break
            await asyncio.sleep(0.5)
        runner.stop()
        code = await asyncio.wait_for(task, 20)
        after = await admin.account(aid)
        await app.state.engine.dispose()
        return connected, code, after, backend, net

    connected, code, after, backend, net = asyncio.run(scenario())
    assert connected["connection_state"] == "connected" and connected["owner_worker_id"]
    assert code == EXIT_OK
    assert after["owner_worker_id"] is None and after["connection_state"] == "disconnected"   # lease released on shutdown
    assert backend.disconnects and net.max_simultaneous == 1
