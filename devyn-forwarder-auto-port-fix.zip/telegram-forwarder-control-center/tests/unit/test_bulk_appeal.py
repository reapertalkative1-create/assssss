import asyncio,uuid,json
from types import SimpleNamespace
from sqlalchemy import select
import pytest
from app.models import AccountBulkJob as J,AccountBulkItem as I,TelegramAccount,WorkerCommand,Role
from app.crypto import SecretBox
from tests.conftest import run_db
from tests.unit.test_accounts_api import env,db_dump
from tests.unit.test_account_bulk import process
from worker.appeal_template import render,ready_prompt,prepare
from worker.telegram_backend import BackendError
TEMPLATE='Hello {name}. Phone Number: {phone}. Email Address: {email}. Please review.'
PHONE='+15551234567'


def create(env,n=2):
    w=env.make_worker();ids=[env.make_account(f'SS-{i}',w) for i in range(n)]
    async def valid(db):
        for aid in ids:
            a=await db.get(TelegramAccount,uuid.UUID(aid));a.auth_state='authorized';a.session_ciphertext=SecretBox([env.settings.session_encryption_key.get_secret_value()]).seal('session',str(a.id),'fake-test-session');a.session_version=1
    run_db(env.settings,valid)
    r=env.client.post('/api/account-appeals',headers=env.h,json={'account_ids':ids,'template':TEMPLATE,
        'email':'common@example.com','profiles':{'SS-1':{'email':'private@example.com'}}})
    assert r.status_code==202,r.text
    return w,ids,r.json()['id']


def finish_prepare(env,w,jid):
    process(env)
    commands=w.poll();assert commands and all(c['type']=='appeal_prepare' for c in commands)
    for cmd in commands:
        payload=cmd['payload']
        assert 'template' in payload
        preview=render(payload['template'],payload['name'],PHONE,payload['email'])
        w.result(cmd['id'],result={'connection_state':'connected','appeal_preview':{'text':preview,'expected_reply_id':101,'expected_prompt_hash':'a'*64}})
    process(env)
    return env.client.get('/api/account-appeals/'+jid).json()


def test_template_one_pass_and_missing_email():
    assert render('{name} {phone} {email}','SS-{email}',PHONE,'a@example.com')=='SS-{email} '+PHONE+' a@example.com'
    with pytest.raises(BackendError):render('{email}','SS',PHONE,'')
    with pytest.raises(BackendError):render('{unknown}','SS',PHONE,'a@example.com')
    assert ready_prompt('Please write us some details about your case. Why do you think your account was limited?')
    assert not ready_prompt('Good news, no limits are currently applied to your account.')


def test_worker_reads_real_phone_for_preview_without_sending():
    class Client:
        sent=[]
        async def get_me(self):return SimpleNamespace(phone=PHONE.lstrip('+'))
        async def get_entity(self,name):return SimpleNamespace(id=178220800,bot=True,username='SpamBot')
        async def get_messages(self,peer,limit):return [SimpleNamespace(id=101,sender_id=peer.id,out=False,raw_text='Please write us some details about your case.')]
    result=asyncio.run(prepare(Client(),TEMPLATE,'SS','person@example.com'))
    assert PHONE in result['text'] and result['expected_reply_id']==101 and not Client.sent


def test_prepare_preview_then_explicit_confirm_and_send_once(env):
    w,ids,jid=create(env)
    preview=finish_prepare(env,w,jid)
    assert preview['status']=='preview' and preview['counts']['prepared']==2
    assert not w.poll()  # Preparing and preview never enqueue a send.
    bodies=[i['text'] for i in preview['items']]
    assert any('SS-0' in t and 'common@example.com' in t for t in bodies)
    assert any('SS-1' in t and 'private@example.com' in t for t in bodies)
    async def dump(db):
        values=[]
        for model in (J,I,WorkerCommand):
            values.extend(repr(row.__dict__) for row in (await db.execute(select(model))).scalars())
        return '\n'.join(values)
    data=run_db(env.settings,dump)
    assert PHONE not in data and 'private@example.com' not in data and TEMPLATE not in data
    body={'review_token':preview['review_token'],'facts_confirmed':False}
    assert env.client.post('/api/account-appeals/'+jid+'/confirm',headers=env.h,json=body).status_code==422
    body['facts_confirmed']=True
    assert env.client.post('/api/account-appeals/'+jid+'/confirm',headers=env.h,json=body).status_code==202
    assert env.client.post('/api/account-appeals/'+jid+'/confirm',headers=env.h,json=body).status_code==202
    process(env)
    commands=w.poll();assert len(commands)==2 and all(c['type']=='spam_reply' for c in commands)
    for cmd in commands:
        assert cmd['payload']['text'] in bodies and cmd['payload']['expected_prompt_hash']=='a'*64
        w.result(cmd['id'],result={'connection_state':'connected','spam_report':{'status':'unknown','delivery':'sent','text':'Request received','message_id':102,'buttons':[]}})
    process(env)
    result=env.client.get('/api/account-appeals/'+jid).json()
    assert result['status']=='done' and result['counts']['done']==2 and not w.poll()
    assert all(i['text'] is None for i in result['items'])
    assert PHONE not in env.client.get('/api/audit').text
    assert env.client.post('/api/account-bulk/'+jid+'/retry',headers=env.h).status_code==409


def test_cancel_preview_wipes_private_drafts(env):
    w,ids,jid=create(env,1);preview=finish_prepare(env,w,jid)
    assert env.client.post('/api/account-bulk/'+jid+'/cancel',headers=env.h).status_code==200
    process(env)
    result=env.client.get('/api/account-appeals/'+jid).json()
    assert result['status']=='cancelled' and not w.poll() and result['items'][0]['text'] is None
    async def wiped(db):
        j=await db.get(J,uuid.UUID(jid));i=(await db.execute(select(I).where(I.job_id==j.id))).scalars().one()
        return j.settings_ciphertext,i.payload_ciphertext
    assert run_db(env.settings,wiped)==(None,None)


def test_missing_email_stale_preview_and_rbac(env,new_client,seed_user,login):
    w,ids,jid=create(env,1)
    assert env.client.post('/api/account-appeals/'+jid+'/confirm',headers=env.h,json={'review_token':'0'*64,'facts_confirmed':True}).status_code==409
    assert env.client.post('/api/account-appeals',headers=env.h,json={'account_ids':ids,'template':'{email}'}).status_code==422
    seed_user('op',role=Role.OPERATOR);op=new_client();h=login(op,'op')
    assert op.get('/api/account-appeals/'+jid).status_code==403
    assert op.post('/api/account-appeals',headers=h,json={'account_ids':ids,'template':'test'}).status_code==403
    assert env.client.post('/api/account-appeals',json={'account_ids':ids,'template':'test'}).status_code==403


def test_draft_key_rotation(env):
    from app.cli import verify_keys,rotate_keys
    w,ids,jid=create(env,1);finish_prepare(env,w,jid)
    old=env.settings.session_encryption_key.get_secret_value();new=SecretBox.generate_key()
    assert asyncio.run(verify_keys(env.settings.database_url,SecretBox([old])))['appeal_drafts_ok']==2
    assert asyncio.run(rotate_keys(env.settings.database_url,SecretBox([new,old])))['appeal_drafts']==2
    assert asyncio.run(verify_keys(env.settings.database_url,SecretBox([new])))['appeal_drafts_ok']==2
