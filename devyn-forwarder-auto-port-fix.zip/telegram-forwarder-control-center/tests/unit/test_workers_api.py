import asyncio
import logging
import time
import uuid
from datetime import timedelta

import pytest
from sqlalchemy import select

from app.models import Role, Worker
from app.services.workers import mark_stale_offline
from app.types import utcnow
from tests.conftest import run_db


@pytest.fixture
def admin(client, seed_user, login):
    seed_user("admin1")
    return login(client, "admin1")


@pytest.fixture
def create_worker(client, admin):
    def _create(name="vps-linux-01", platform="linux") -> dict:
        r = client.post("/api/workers", headers=admin, json={"name": name, "platform": platform})
        assert r.status_code == 201, r.text
        return r.json()

    return _create


def bearer(cred: str) -> dict:
    return {"Authorization": f"Bearer {cred}"}


@pytest.fixture
def worker_client(new_client):
    return new_client()  # separate cookie jar: behaves like a real remote worker


REG = {"platform": "linux", "version": "0.3.0", "hostname": "box1"}


@pytest.fixture
def mutate_worker(settings):
    def _m(worker_id, **fields):
        async def _do(s):
            w = await s.get(Worker, uuid.UUID(worker_id))
            for k, v in fields.items():
                setattr(w, k, v)

        run_db(settings, _do)

    return _m


def test_credential_is_shown_once_and_only_hash_stored(client, admin, create_worker, settings):
    w = create_worker()
    cred = w["credential"]
    assert cred.startswith("tfw_") and w["status"] == "offline"
    assert "credential" not in client.get(f"/api/workers/{w['id']}").json()
    assert cred not in client.get("/api/workers").text

    async def stored(s):
        row = (await s.execute(select(Worker))).scalar_one()
        return row.credential_hash, row.previous_credential_hash

    h, prev = run_db(settings, stored)
    assert h != cred and len(h) == 64 and prev is None


def test_rbac_for_worker_management(client, new_client, seed_user, login, create_worker):  # noqa: E501
    w = create_worker()
    seed_user("op", role=Role.OPERATOR)
    op = new_client()
    h = login(op, "op")
    assert op.get("/api/workers").status_code == 200
    assert op.get(f"/api/workers/{w['id']}").status_code == 200
    assert w["credential"] not in op.get("/api/workers").text
    for method, path, body in [
        ("post", "/api/workers", {"name": "x-worker", "platform": "linux"}),
        ("patch", f"/api/workers/{w['id']}", {"name": "renamed"}),
        ("post", f"/api/workers/{w['id']}/rotate-credential", None),
        ("post", f"/api/workers/{w['id']}/revoke", None),
    ]:
        assert getattr(op, method)(path, headers=h, json=body).status_code == 403, path
    anon = new_client()
    assert anon.get("/api/workers").status_code == 401


def test_create_validation_and_unique_names(client, admin, create_worker):
    create_worker("Alpha-1")
    assert client.post("/api/workers", headers=admin, json={"name": "alpha-1", "platform": "windows"}).status_code == 409
    assert client.post("/api/workers", headers=admin, json={"name": "  ", "platform": "linux"}).status_code == 422
    assert client.post("/api/workers", headers=admin, json={"name": "ok", "platform": "macos"}).status_code == 422
    other = create_worker("beta")
    r = client.patch(f"/api/workers/{other['id']}", headers=admin, json={"name": "ALPHA-1"})
    assert r.status_code == 409


def test_register_and_heartbeat_make_worker_online(client, admin, create_worker, worker_client, audit_rows):
    w = create_worker()
    h = bearer(w["credential"])
    r = worker_client.post("/api/worker/v1/register", headers=h, json=REG)
    assert r.status_code == 200
    body = r.json()
    assert body["worker_id"] == w["id"] and body["heartbeat_interval_seconds"] > 0 and body["report_resources"] is True

    hb = worker_client.post("/api/worker/v1/heartbeat", headers=h,
                            json={"running_jobs": 2, "resources": {"cpu_percent": 12.5, "memory_percent": 40}})
    assert hb.status_code == 200 and hb.json()["status"] == "ok"

    d = client.get(f"/api/workers/{w['id']}").json()
    assert d["status"] == "online" and d["version"] == "0.3.0" and d["hostname"] == "box1"
    assert d["running_jobs"] == 2 and d["cpu_percent"] == 12.5 and d["memory_percent"] == 40
    actions = [a["action"] for a in audit_rows()]
    assert "worker.register" in actions and actions.count("worker.online") == 1
    assert w["credential"] not in repr(audit_rows())


def test_platform_mismatch_is_rejected(client, create_worker, worker_client):
    w = create_worker(platform="windows")
    r = worker_client.post("/api/worker/v1/register", headers=bearer(w["credential"]), json=REG)
    assert r.status_code == 409 and r.json()["error"]["code"] == "platform_mismatch"


def test_bad_credentials_all_look_the_same(client, create_worker, worker_client, caplog):
    w = create_worker()
    secret = w["credential"].split(".", 1)[1]
    forged_id = "tfw_" + uuid.uuid4().hex + "." + secret
    attempts = [
        {}, {"Authorization": "Basic abc"}, {"Authorization": "Bearer"}, bearer("garbage"),
        bearer(w["credential"] + "x"), bearer(forged_id), bearer("tfw_" + "z" * 32 + ".abc"),
    ]
    caplog.set_level(logging.DEBUG)
    results = [worker_client.post("/api/worker/v1/heartbeat", headers=h, json={}) for h in attempts]
    assert {r.status_code for r in results} == {401}
    assert len({repr(r.json()["error"]) for r in results}) == 1
    assert secret not in caplog.text


def test_worker_auth_ip_rate_limit(settings, create_worker, new_client):
    from fastapi.testclient import TestClient
    from app.main import create_app

    w = create_worker()
    s = settings.model_copy(update={"worker_auth_ip_max_attempts": 3})
    with TestClient(create_app(s), base_url="http://testserver") as c:
        for _ in range(3):
            assert c.post("/api/worker/v1/heartbeat", headers=bearer("garbage"), json={}).status_code == 401
        assert c.post("/api/worker/v1/heartbeat", headers=bearer(w["credential"]), json={}).status_code == 429


def test_web_session_and_worker_credentials_are_not_interchangeable(client, admin, create_worker, worker_client):
    w = create_worker()
    assert client.post("/api/worker/v1/heartbeat", headers={"X-CSRF-Token": admin["X-CSRF-Token"]}, json={}).status_code == 401
    assert worker_client.get("/api/workers", headers=bearer(w["credential"])).status_code == 401
    assert worker_client.get("/api/users", headers=bearer(w["credential"])).status_code == 401


def test_revocation_is_immediate_and_idempotent(client, admin, create_worker, worker_client, audit_rows):
    w = create_worker()
    h = bearer(w["credential"])
    assert worker_client.post("/api/worker/v1/register", headers=h, json=REG).status_code == 200
    assert client.post(f"/api/workers/{w['id']}/revoke", headers=admin).json()["status"] == "revoked"
    assert client.post(f"/api/workers/{w['id']}/revoke", headers=admin).status_code == 200
    r = worker_client.post("/api/worker/v1/heartbeat", headers=h, json={})
    assert r.status_code == 403 and r.json()["error"]["code"] == "worker_revoked"
    assert client.post(f"/api/workers/{w['id']}/rotate-credential", headers=admin).status_code == 409
    assert len(audit_rows("worker.revoke")) == 1


def test_rotation_grace_period(client, admin, create_worker, worker_client, mutate_worker):
    w = create_worker()
    old = bearer(w["credential"])
    r = client.post(f"/api/workers/{w['id']}/rotate-credential", headers=admin, json={"grace_seconds": 300})
    new = bearer(r.json()["credential"])
    assert r.json()["credential"] != w["credential"]
    assert worker_client.post("/api/worker/v1/heartbeat", headers=new, json={}).status_code == 200
    assert worker_client.post("/api/worker/v1/heartbeat", headers=old, json={}).status_code == 200  # within grace
    mutate_worker(w["id"], previous_valid_until=utcnow() - timedelta(seconds=1))
    assert worker_client.post("/api/worker/v1/heartbeat", headers=old, json={}).status_code == 401
    assert worker_client.post("/api/worker/v1/heartbeat", headers=new, json={}).status_code == 200


def test_rotation_without_grace_invalidates_old_immediately(client, admin, create_worker, worker_client):
    w = create_worker()
    old = bearer(w["credential"])
    r = client.post(f"/api/workers/{w['id']}/rotate-credential", headers=admin, json={"grace_seconds": 0})
    assert worker_client.post("/api/worker/v1/heartbeat", headers=old, json={}).status_code == 401
    assert worker_client.post("/api/worker/v1/heartbeat", headers=bearer(r.json()["credential"]), json={}).status_code == 200
    assert client.post(f"/api/workers/{w['id']}/rotate-credential", headers=admin, json={"grace_seconds": 99999}).status_code == 422


def test_stale_heartbeat_reads_as_offline_and_filters_work(client, admin, create_worker, worker_client, mutate_worker):
    a, b, c = create_worker("w-a"), create_worker("w-b"), create_worker("w-c")
    for w in (a, b):
        worker_client.post("/api/worker/v1/register", headers=bearer(w["credential"]), json=REG)
    worker_client.post("/api/worker/v1/heartbeat", headers=bearer(b["credential"]),
                       json={"health": "degraded", "degraded_reason": "disk almost full"})
    ids = lambda st: sorted(i["name"] for i in client.get("/api/workers", params={"status": st}).json()["items"])  # noqa: E731
    assert ids("online") == ["w-a"] and ids("degraded") == ["w-b"] and ids("offline") == ["w-c"]
    assert client.get(f"/api/workers/{b['id']}").json()["degraded_reason"] == "disk almost full"

    mutate_worker(a["id"], last_heartbeat_at=utcnow() - timedelta(seconds=120))
    assert client.get(f"/api/workers/{a['id']}").json()["status"] == "offline"  # computed, no sweeper needed
    assert ids("offline") == ["w-a", "w-c"]

    worker_client.post("/api/worker/v1/heartbeat", headers=bearer(b["credential"]), json={"health": "ok"})
    assert client.get(f"/api/workers/{b['id']}").json()["degraded_reason"] is None
    assert client.get("/api/workers", params={"status": "bogus"}).status_code == 422
    assert client.get("/api/workers", params={"q": "w-"}).json()["total"] == 3
    assert client.get("/api/workers", params={"platform": "windows"}).json()["total"] == 0


def test_resource_reporting_can_be_disabled(client, admin, create_worker, worker_client):
    w = create_worker()
    h = bearer(w["credential"])
    worker_client.post("/api/worker/v1/register", headers=h, json=REG)
    worker_client.post("/api/worker/v1/heartbeat", headers=h, json={"resources": {"cpu_percent": 50, "memory_percent": 60}})
    client.patch(f"/api/workers/{w['id']}", headers=admin, json={"resource_reporting_enabled": False})
    d = client.get(f"/api/workers/{w['id']}").json()
    assert d["cpu_percent"] is None and d["memory_percent"] is None
    r = worker_client.post("/api/worker/v1/heartbeat", headers=h, json={"resources": {"cpu_percent": 99, "memory_percent": 99}})
    assert r.json()["report_resources"] is False
    assert client.get(f"/api/workers/{w['id']}").json()["cpu_percent"] is None
    assert worker_client.post("/api/worker/v1/heartbeat", headers=h, json={"resources": {"cpu_percent": 101}}).status_code == 422


def test_offline_detector_emits_one_event_and_worker_recovers(client, admin, create_worker, worker_client,
                                                              mutate_worker, settings, audit_rows):
    w = create_worker()
    h = bearer(w["credential"])
    worker_client.post("/api/worker/v1/register", headers=h, json=REG)
    mutate_worker(w["id"], last_heartbeat_at=utcnow() - timedelta(seconds=300))

    async def sweep(s):
        return await mark_stale_offline(s, utcnow(), settings.heartbeat_timeout_seconds)

    assert run_db(settings, sweep) == [w["id"]]
    assert run_db(settings, sweep) == []  # already offline: no duplicate alert
    assert len(audit_rows("worker.offline")) == 1

    worker_client.post("/api/worker/v1/heartbeat", headers=h, json={})
    assert client.get(f"/api/workers/{w['id']}").json()["status"] == "online"
    assert len(audit_rows("worker.online")) == 2  # first registration + recovery


def test_background_sweeper_runs_inside_the_app(settings, seed_user, login, mutate_worker):
    from fastapi.testclient import TestClient
    from app.main import create_app

    seed_user("admin1")
    s = settings.model_copy(update={"worker_sweep_interval_seconds": 0.2})
    with TestClient(create_app(s), base_url="http://testserver") as c:
        h = login(c, "admin1")
        w = c.post("/api/workers", headers=h, json={"name": "bg", "platform": "linux"}).json()
        c.post("/api/worker/v1/register", headers=bearer(w["credential"]), json=REG)
        mutate_worker(w["id"], last_heartbeat_at=utcnow() - timedelta(seconds=300))

        async def stored_status(sess):
            return (await sess.get(Worker, uuid.UUID(w["id"]))).status

        deadline = time.time() + 10
        while time.time() < deadline and run_db(s, stored_status) != "offline":
            time.sleep(0.3)
        assert run_db(s, stored_status) == "offline"


def test_missing_worker_returns_404(client, admin):
    ghost = "00000000-0000-0000-0000-000000000000"
    assert client.get(f"/api/workers/{ghost}").status_code == 404
    assert client.post(f"/api/workers/{ghost}/revoke", headers=admin).status_code == 404
