import asyncio
import pytest
from app.models import Role
from tests.unit.test_accounts_api import env, db_dump
from tests.unit.test_accounts_e2e import e2e, Admin, WorkerSide, authorize
from tests.fakes import CODE_OK, PW_OK, FakeNetwork, FakeBackend
from app.main import create_app
from worker.account_backend import AccountTelegramBackend

HASH = 'abcdef0123456789abcdef0123456789'


def test_web_credentials_encrypted_and_worker_scoped(env, new_client, seed_user, login):
    w, other = env.make_worker(), env.make_worker('other')
    r = env.client.post('/api/accounts', headers=env.h,
                        json={'name':'Web account','worker_id':w.id,'api_id':12345,'api_hash':HASH})
    assert r.status_code == 201, r.text
    aid = r.json()['id']
    assert r.json()['telegram_api_configured'] is True
    assert HASH not in r.text
    path = f'/api/worker/v1/accounts/{aid}/telegram-api/fetch'
    assert other.http.post(path, headers=other.h).status_code == 404
    fetched = w.http.post(path, headers=w.h)
    assert fetched.status_code == 200 and fetched.json() == {'api_id':12345,'api_hash':HASH}
    assert 'no-store' in fetched.headers['cache-control']
    assert HASH not in db_dump(env.settings)
    assert HASH not in env.client.get('/api/accounts').text
    assert HASH not in env.client.get('/api/audit').text
    seed_user('op', role=Role.OPERATOR)
    op = new_client(); h = login(op, 'op')
    config = {'api_id':22222,'api_hash':HASH}
    assert op.put(f'/api/accounts/{aid}/telegram-api', headers=h, json=config).status_code == 403
    assert env.client.put(f'/api/accounts/{aid}/telegram-api', json=config).status_code == 403
    assert env.client.put(f'/api/accounts/{aid}/telegram-api', headers=env.h, json=config).status_code == 200
    assert w.http.post(path, headers=w.h).json()['api_id'] == 22222
    env.client.post(f'/api/accounts/{aid}/login/start',headers=env.h,json={'phone':'+84901234567'})
    (cmd,) = w.poll(); w.result(cmd['id'], result={'state':'awaiting_code'})
    assert env.client.put(f'/api/accounts/{aid}/telegram-api', headers=env.h,json=config).status_code == 409


@pytest.mark.parametrize('config', [ {'api_id':0,'api_hash':HASH}, {'api_id':1}, {'api_hash':HASH}, {'api_id':1,'api_hash':'invalid-sensitive-hash'} ])
def test_bad_web_credentials_rejected_without_echo(env, config):
    r = env.client.post('/api/accounts',headers=env.h,json={'name':'bad',**config})
    assert r.status_code == 422
    assert HASH not in r.text and 'invalid-sensitive-hash' not in r.text


def test_web_config_full_login_without_worker_environment(e2e):
    async def scenario():
        app = create_app(e2e); admin = Admin(app); await admin.login()
        net = FakeNetwork(); w = await WorkerSide(app,admin,'web-worker',net).create()
        used = []
        def factory(api_id, api_hash):
            used.append((api_id,api_hash))
            return FakeBackend(net, two_factor=api_id == 2)
        backend = AccountTelegramBackend(w.client, factory=factory)
        w.backend = backend; w.manager._backend = backend
        try:
            accounts=[]
            for i in (1,2):
                r=await admin.post('/api/accounts',{'name':f'Web {i}','worker_id':w.id,'api_id':i,'api_hash':str(i)*32})
                assert r.status_code == 201, r.text
                aid=r.json()['id']; accounts.append(aid)
                if i == 1:
                    await authorize(admin,aid)
                else:
                    base = f'/api/accounts/{aid}'
                    for suffix, body in [('start', {'phone':'+84901234567'}), ('code', {'code':CODE_OK})]:
                        r = await admin.post(base + '/login/' + suffix, body)
                        assert (await admin.finished(aid,r.json()['command_id']))['status'] == 'done'
                    assert (await admin.account(aid))['auth_state'] == 'awaiting_password'
                    r = await admin.post(base + '/login/password', {'password':PW_OK})
                    assert (await admin.finished(aid,r.json()['command_id']))['status'] == 'done'
                    assert (await admin.account(aid))['auth_state'] == 'authorized'
            assert used == [(1,'1'*32),(2,'2'*32)]
            for aid in accounts:
                assert (await admin.account(aid))['has_session']
        finally:
            await w.close(); await w.client.aclose(); await admin.http.aclose()
            await app.state.engine.dispose()
    asyncio.run(scenario())


def test_parallel_handles_keep_own_api_credentials_and_legacy_fallback():
    from types import SimpleNamespace
    from worker.client import NotFoundError
    from worker.telegram_backend import BackendError
    class Client:
        async def fetch_telegram_api(self, aid):
            if aid == 'old':
                raise NotFoundError('telegram_api_not_configured')
            return SimpleNamespace(api_id=int(aid), api_hash=aid*32)
    class Backend:
        def __init__(self, api_id, api_hash):
            self.pair=(api_id,api_hash)
        async def send_code(self, phone):
            await asyncio.sleep(0)
            return object()
        async def sign_in_code(self, raw, code):
            return self.pair
    async def scenario():
        backend=AccountTelegramBackend(Client(),factory=Backend)
        first, second=await asyncio.gather(backend.send_code_for('1','+1'),backend.send_code_for('2','+2'))
        assert await backend.sign_in_code(first,'12345') == (1,'1'*32)
        assert await backend.sign_in_code(second,'12345') == (2,'2'*32)
        with pytest.raises(BackendError):
            await backend.send_code_for('old','+1')
        legacy=AccountTelegramBackend(Client(),99,'b'*32,factory=Backend)
        handle=await legacy.send_code_for('old','+1')
        assert await legacy.sign_in_code(handle,'12345') == (99,'b'*32)
    asyncio.run(scenario())
