from app.ratelimit import SlidingWindowLimiter
from app.security import (
    hash_password, hash_token, needs_rehash, new_token, validate_password_policy, verify_password,
)


def test_argon2id_roundtrip():
    h = hash_password("Correct-Horse-Battery-9")
    assert h.startswith("$argon2id$")
    assert verify_password(h, "Correct-Horse-Battery-9")
    assert not verify_password(h, "wrong")
    assert not verify_password("not-a-hash", "x")
    assert not needs_rehash(h)


def test_password_policy():
    assert validate_password_policy("short") is not None
    assert validate_password_policy("aaaaaaaaaaaaaaaa") is not None
    assert validate_password_policy("my-alice-passphrase-1", "alice") is not None
    assert validate_password_policy("x" * 200) is not None
    assert validate_password_policy("Correct-Horse-Battery-9", "alice") is None


def test_tokens_are_unique_and_stored_hashed():
    a, b = new_token(), new_token()
    assert a != b and len(a) >= 40
    assert hash_token(a) != a and len(hash_token(a)) == 64


def test_sliding_window_limiter():
    now = [0.0]
    lim = SlidingWindowLimiter(3, 10, clock=lambda: now[0])
    for _ in range(3):
        assert not lim.is_limited("ip")
        lim.record("ip")
    assert lim.is_limited("ip")
    assert not lim.is_limited("other")
    now[0] = 11
    assert not lim.is_limited("ip")
    lim.record("ip")
    lim.reset("ip")
    assert not lim.is_limited("ip")
