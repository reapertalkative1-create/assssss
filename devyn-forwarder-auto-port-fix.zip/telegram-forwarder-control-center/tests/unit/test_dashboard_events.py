import pytest
from starlette.websockets import WebSocketDisconnect

from app.models import Role
from tests.conftest import NEW_PASSWORD, PASSWORD, TEST_KEY
from tests.unit.test_routes_jobs_api import DST, DST2, SRC, WJ, env, jw, make_route  # noqa: F401  (fixtures)

COOKIE = "tfcc_session"


def cookie_header(client) -> dict:
    return {"cookie": f"{COOKIE}={client.cookies.get(COOKIE)}"}


def drain_until(ws, predicate, limit=12):
    """Read messages until one event satisfies `predicate`; returns (that event, every event seen)."""
    seen = []
    for _ in range(limit):
        msg = ws.receive_json()
        for e in msg.get("events", []):
            seen.append(e)
            if predicate(e):
                return e, seen
    raise AssertionError(f"event not received; saw {[e['action'] for e in seen]}")


# ------------------------------------------------------------------ websocket
def test_websocket_requires_a_valid_session_and_same_origin(client, seed_user, login):
    seed_user("admin1")
    with pytest.raises(WebSocketDisconnect) as e:
        with client.websocket_connect("/api/ws/events"):
            pass
    assert e.value.code == 4401                                              # no cookie

    login(client, "admin1")
    ok = {**cookie_header(client), "origin": "http://testserver", "host": "testserver"}
    with client.websocket_connect("/api/ws/events", headers=ok) as ws:
        assert ws.receive_json()["type"] == "hello"
    evil = {**cookie_header(client), "origin": "https://evil.example", "host": "testserver"}
    with pytest.raises(WebSocketDisconnect) as e:
        with client.websocket_connect("/api/ws/events", headers=evil):       # cross-site WebSocket hijacking attempt
            pass
    assert e.value.code == 1008
    forged = {"cookie": f"{COOKIE}=not-a-real-session"}
    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/api/ws/events", headers=forged):
            pass


def test_hello_has_history_then_live_events_arrive(client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    client.post("/api/workers", headers=h, json={"name": "before", "platform": "linux"})
    with client.websocket_connect("/api/ws/events", headers=cookie_header(client)) as ws:
        hello = ws.receive_json()
        assert hello["type"] == "hello" and hello["cursor"]["audit"] > 0 and hello["role"] == "admin"
        assert [e["action"] for e in hello["events"]][-2:] == ["auth.login", "worker.create"]
        client.post("/api/accounts", headers=h, json={"name": "live-one"})
        ev, _ = drain_until(ws, lambda e: e["action"] == "account.create")
        assert ev["level"] == "info" and ev["actor"] == "admin1" and ev["details"] == {"name": "live-one"}


def test_reconnect_with_a_cursor_resumes_without_gaps_or_repeats(client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    with client.websocket_connect("/api/ws/events", headers=cookie_header(client)) as ws:
        cursor = ws.receive_json()["cursor"]
    client.post("/api/accounts", headers=h, json={"name": "while-offline-1"})     # happens while the browser was disconnected
    client.post("/api/accounts", headers=h, json={"name": "while-offline-2"})
    url = f"/api/ws/events?audit={cursor['audit']}&job={cursor['job']}"
    with client.websocket_connect(url, headers=cookie_header(client)) as ws:
        hello = ws.receive_json()
        assert hello["events"] == []                                              # history is NOT replayed
        _, seen = drain_until(ws, lambda e: e["details"] == {"name": "while-offline-2"})
        assert [e["details"]["name"] for e in seen] == ["while-offline-1", "while-offline-2"]


def test_operators_only_receive_operational_events(client, new_client, seed_user, login):
    seed_user("admin1")
    seed_user("op", role=Role.OPERATOR)
    h = login(client, "admin1")
    op = new_client()
    login(op, "op")
    with op.websocket_connect("/api/ws/events", headers=cookie_header(op)) as ws:
        hello = ws.receive_json()
        assert hello["role"] == "operator" and all(not e["action"].startswith(("auth.", "user.")) for e in hello["events"])
        client.post("/api/users", headers=h, json={"username": "newbie", "password": PASSWORD})     # admin-only information
        client.post("/api/workers", headers=h, json={"name": "visible", "platform": "linux"})
        ev, seen = drain_until(ws, lambda e: e["action"] == "worker.create")
        assert all(not e["action"].startswith(("auth.", "user.")) for e in seen)


def test_finished_jobs_appear_in_the_stream_without_message_content(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST,))
    with env.client.websocket_connect("/api/ws/events", headers=cookie_header(env.client)) as ws:
        ws.receive_json()
        st.worker.enqueue(rid, [(SRC, 1)])
        (j,) = st.worker.claim()
        st.worker.start([j])
        st.worker.results([st.worker.fail(j, "forward_restricted")])
        ev, _ = drain_until(ws, lambda e: e["action"] == "job.failed")
        assert ev["level"] == "error" and ev["details"]["error"] == "forward_restricted" and ev["kind"] == "job"
        assert set(ev["details"]) == {"route_id", "attempts", "max_attempts", "error"}      # ids/counters only


def test_revoked_session_is_disconnected(client, new_client, seed_user, login, monkeypatch):
    from app.routers import ws as ws_module

    monkeypatch.setattr(ws_module, "REVALIDATE_SECONDS", 0.5)
    monkeypatch.setattr(ws_module, "POLL_SECONDS", 0.2)
    seed_user("admin1")
    h = login(client, "admin1")
    other = new_client()
    other_h = login(other, "admin1")                                            # second browser, same user
    with other.websocket_connect("/api/ws/events", headers=cookie_header(other)) as ws:
        ws.receive_json()
        assert client.post("/api/auth/change-password", headers=h,
                           json={"current_password": PASSWORD, "new_password": NEW_PASSWORD}).status_code == 204   # revokes `other`
        with pytest.raises(WebSocketDisconnect) as e:
            for _ in range(20):
                ws.receive_json()
        assert e.value.code == 4401


# ------------------------------------------------------------------ REST: dashboard and system
def test_dashboard_summary_counts_everything(env, jw):
    st = jw()
    rid = make_route(env, st, dests=(DST, DST2))
    st.worker.heartbeat([])
    st.worker.http.post("/api/worker/v1/heartbeat", headers=st.worker.h,
                        json={"running_jobs": 1, "resources": {"cpu_percent": 12.5, "memory_percent": 40}})
    st.worker.enqueue(rid, [(SRC, 1), (SRC, 2)])
    jobs = st.worker.claim()
    st.worker.start(jobs)
    st.worker.results([st.worker.ok(jobs[0]), st.worker.ok(jobs[1]), st.worker.fail(jobs[2]), st.worker.retry(jobs[3])])
    env.make_worker("sleeper", register=False)

    d = env.client.get("/api/dashboard/summary").json()
    assert d["workers"] == {"online": 1, "offline": 1, "degraded": 0, "revoked": 0}
    assert d["accounts"]["total"] == 1 and d["accounts"]["authorized"] == 1 and d["accounts"]["running"] == 1
    assert d["routes"]["active"] == 1
    assert d["jobs"]["by_status"]["succeeded"] == 2 and d["jobs"]["by_status"]["failed"] == 1 and d["jobs"]["by_status"]["retry_wait"] == 1
    assert d["jobs"]["last_24h"] == {"succeeded": 2, "failed": 1}
    assert len(d["jobs"]["series"]) == 24 and sum(s["succeeded"] for s in d["jobs"]["series"]) == 2
    by_name = {r["name"]: r for r in d["resources"]}
    assert by_name["wj"]["cpu_percent"] == 12.5 and by_name["wj"]["memory_percent"] == 40 and by_name["sleeper"]["cpu_percent"] is None
    assert d["recent_events"] and "server_time" in d


def test_dashboard_is_available_to_operators_but_system_info_is_admin_only(env, new_client, seed_user, login):
    seed_user("op", role=Role.OPERATOR)
    op = new_client()
    login(op, "op")
    assert op.get("/api/dashboard/summary").status_code == 200
    assert all(not e["action"].startswith(("auth.", "user.")) for e in op.get("/api/events/recent").json()["events"])
    assert op.get("/api/system/info").status_code == 403
    assert new_client().get("/api/dashboard/summary").status_code == 401


def test_system_info_exposes_no_secrets(env):
    r = env.client.get("/api/system/info")
    assert r.status_code == 200
    body = r.json()
    assert body["database_ok"] is True and body["encryption"] == {"configured": True, "keys": 1}
    assert body["settings"]["account_lease_ttl_seconds"] == env.settings.account_lease_ttl_seconds
    assert TEST_KEY not in r.text and env.settings.secret_key.get_secret_value() not in r.text and "database_url" not in r.text


def test_logout_other_sessions_keeps_the_current_one(client, new_client, seed_user, login):
    seed_user("admin1")
    h = login(client, "admin1")
    others = [new_client() for _ in range(2)]
    for o in others:
        login(o, "admin1")
    assert client.post("/api/auth/logout-others", headers=h).json() == {"revoked": 2}
    assert client.get("/api/auth/me").status_code == 200
    assert all(o.get("/api/auth/me").status_code == 401 for o in others)
    assert client.post("/api/auth/logout-others", headers=h).json() == {"revoked": 0}
