import asyncio

import pytest

from worker.client import ConflictError, RouteConfig, TransientError
from worker.forwarding import ENQUEUE_CHUNK, ForwardEngine
from worker.telegram_backend import BackendError, MessageFacts
from tests.fakes import FakeBackend, FakeHandle

AID, SRC, DST = "acc-1", -1001, -2001


class StubManager:
    def __init__(self):
        self.handle = FakeHandle("s")
        self.live = True
        self.errors = []

    def handle_for(self, aid):
        return self.handle if self.live and aid == AID else None

    def connected_accounts(self):
        return [AID] if self.live else []

    async def report_error(self, aid, code):
        self.errors.append((aid, code))
        self.live = False


class StubClient:
    def __init__(self):
        self.enqueues, self.results_posted = [], []
        self.enqueue_error = None
        self.jobs, self.started_filter = [], None
        self.results_error = None

    async def enqueue(self, route_id, items, checkpoints):
        if self.enqueue_error:
            err = self.enqueue_error(len(self.enqueues)) if callable(self.enqueue_error) else self.enqueue_error
            if err:
                raise err
        self.enqueues.append((route_id, list(items), dict(checkpoints)))
        return len(items), 0

    async def claim_jobs(self, max_jobs, wait_seconds):
        jobs, self.jobs = self.jobs[:max_jobs], self.jobs[max_jobs:]
        return jobs

    async def start_jobs(self, jobs):
        ids = {str(j["id"]) for j in jobs}
        lost = set(self.started_filter or ())
        return ids - lost, lost & ids

    async def post_job_results(self, results):
        if self.results_error:
            raise self.results_error
        self.results_posted.append(list(results))
        return []


def route(rid="r1", sources=(SRC,), filters=None, checkpoints=None, mode="forward"):
    return RouteConfig(rid, AID, "route", tuple(sources), (DST,), mode, filters or {}, "v1", dict(checkpoints or {}))


def facts(mid, text="hello", kind="text", outgoing=False, chat=SRC):
    return MessageFacts(chat, mid, text, kind, outgoing)


def build(**kw):
    backend, client, mgr = FakeBackend(), StubClient(), StubManager()
    kw.setdefault("send_interval", 0)
    kw.setdefault("claim_wait", 0)
    return ForwardEngine(client, mgr, backend, **kw), client, backend, mgr


def run(coro):
    return asyncio.run(coro)


def test_first_start_begins_from_now_and_forwards_no_history():
    async def go():
        eng, client, backend, mgr = build()
        backend.history[SRC] = [facts(i) for i in range(1, 51)]
        await eng.on_routes([route()])
        return client, eng

    client, eng = run(go())
    assert client.enqueues == [("r1", [], {SRC: 50})]                  # checkpoint only: old messages are NOT forwarded
    assert eng._buffer == [] and eng.routes["r1"].checkpoints == {SRC: 50}


def test_live_messages_are_filtered_buffered_and_checkpointed():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route(filters={"keywords_include": ["sale"]})])
        client.enqueues.clear()
        backend.emit(facts(101, "Big SALE"))
        backend.emit(facts(102, "unrelated"))
        backend.emit(facts(103, "sale again", outgoing=True))          # own message: filtered out
        backend.emit(facts(104, "sale", chat=-999))                    # not a source of any route
        backend.emit(facts(105, "SALE!"))
        await eng._flush()
        return client

    client = run(go())
    assert client.enqueues == [("r1", [(SRC, 101), (SRC, 105)], {SRC: 105})]   # checkpoint covers filtered-out ids too


def test_catch_up_from_checkpoint_after_downtime():
    async def go():
        eng, client, backend, mgr = build(max_backfill=2)
        backend.history[SRC] = [facts(i, "sale" if i % 2 else "other") for i in range(1, 8)]
        await eng.on_routes([route(filters={"keywords_include": ["sale"]}, checkpoints={SRC: 3})])
        await eng._flush()
        return client, eng

    client, eng = run(go())
    items = [i for _, its, _ in client.enqueues for i in its]
    assert items == [(SRC, 5), (SRC, 7)]                               # 4..7 re-examined, only matches queued, in order
    assert max(cp[SRC] for _, _, cp in client.enqueues) == 7           # paged through in rounds of 2


def test_failed_flush_keeps_messages_and_does_not_advance_the_checkpoint():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route()])
        client.enqueues.clear()
        for i in (12, 11, 13):                                         # arrive out of order
            backend.emit(facts(i))
        client.enqueue_error = TransientError("ConnectError")
        await eng._flush()
        kept = [(e.message_id) for e in eng._buffer]
        cp_after_failure = dict(eng.routes["r1"].checkpoints)
        client.enqueue_error = None
        await eng._flush()
        return kept, cp_after_failure, client, eng

    kept, cp, client, eng = run(go())
    assert sorted(kept) == [11, 12, 13] and cp == {SRC: 0}
    assert client.enqueues == [("r1", [(SRC, 11), (SRC, 12), (SRC, 13)], {SRC: 13})]   # retried, ascending order
    assert eng._buffer == []


def test_chunking_never_lets_a_checkpoint_jump_over_unsent_messages():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route(checkpoints={SRC: 0})])
        client.enqueues.clear()
        for i in range(1, ENQUEUE_CHUNK * 2 + 51):
            backend.emit(facts(i))
        client.enqueue_error = lambda n: TransientError("x") if n >= 1 else None   # second chunk fails
        await eng._flush()
        return client, eng

    client, eng = run(go())
    assert len(client.enqueues) == 1 and client.enqueues[0][2] == {SRC: ENQUEUE_CHUNK}   # only what was accepted
    assert eng.routes["r1"].checkpoints[SRC] == ENQUEUE_CHUNK
    assert sorted(e.message_id for e in eng._buffer) == list(range(ENQUEUE_CHUNK + 1, ENQUEUE_CHUNK * 2 + 51))


def test_rejected_enqueue_keeps_entries_without_crashing():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route(checkpoints={SRC: 5})])
        backend.emit(facts(6))
        client.enqueue_error = ConflictError("route_not_active")
        await eng._flush()
        return eng

    eng = run(go())
    assert [e.message_id for e in eng._buffer] == [6] and eng.routes["r1"].checkpoints[SRC] == 5


def test_route_changes_update_watchers_and_keep_local_progress():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route(checkpoints={SRC: 5})])
        backend.emit(facts(6))
        await eng._flush()
        watched_1 = [c for _, c, _ in backend.watchers.values()]
        await eng.on_routes([route(sources=(SRC, -1002), checkpoints={SRC: 1})])      # server still reports an older checkpoint
        watched_2 = [c for _, c, _ in backend.watchers.values()]
        cp = dict(eng.routes["r1"].checkpoints)
        backend.emit(facts(7))
        await eng.on_routes([])                                                      # route paused/stopped
        return watched_1, watched_2, cp, backend.watchers, eng._buffer

    w1, w2, cp, watchers, buf = run(go())
    assert w1 == [{SRC}] and w2 == [{SRC, -1002}]
    assert cp[SRC] == 6                                                              # progress is never moved backwards
    assert watchers == {} and buf == []                                              # nothing is observed for inactive routes


def test_messages_are_ignored_while_the_account_is_disconnected():
    async def go():
        eng, client, backend, mgr = build()
        await eng.on_routes([route(checkpoints={SRC: 0})])
        await eng.on_account_dropped(AID)
        mgr.live = False
        mgr.handle.connected = False
        backend.emit(facts(1))
        return eng

    assert run(go())._buffer == []


# ------------------------------------------------------------------ executing jobs
def job(mid=1, jid="j1", mode="forward"):
    return {"id": jid, "epoch": 1, "route_id": "r1", "account_id": AID, "source_chat_id": SRC, "message_id": mid,
            "dest_chat_id": DST, "mode": mode, "attempt": 1, "max_attempts": 5}


@pytest.mark.parametrize("error,expected_status,expected_code,retry_after", [
    (None, "succeeded", None, None),
    (BackendError("destination_forbidden"), "failed", "destination_forbidden", None),
    (BackendError("forward_restricted"), "failed", "forward_restricted", None),
    (BackendError("message_not_found"), "failed", "message_not_found", None),
    (BackendError("flood_wait", 37), "retry", "flood_wait", 37),                      # exact wait is passed on, not slept
    (BackendError("slow_mode", 20), "retry", "slow_mode", 20),
    (BackendError("network_error"), "retry", "network_error", None),
    (BackendError("telegram_error"), "retry", "telegram_error", None),
])
def test_job_outcome_classification(error, expected_status, expected_code, retry_after):
    async def go():
        eng, client, backend, mgr = build()
        if error:
            backend.forward_script = [error]
        return await eng._run_job(job()), backend

    result, backend = run(go())
    assert result["status"] == expected_status and result.get("error_code") == expected_code
    assert result.get("retry_after") == retry_after
    if expected_status == "succeeded":
        assert result["dest_message_id"] and backend.forwarded == [(SRC, 1, DST, "forward")]


def test_job_is_not_sent_when_the_account_is_no_longer_owned():
    async def go():
        eng, client, backend, mgr = build()
        mgr.live = False                                                          # fenced meanwhile
        return await eng._run_job(job()), backend

    result, backend = run(go())
    assert result["status"] == "retry" and result["error_code"] == "account_not_connected" and backend.forwarded == []


def test_dead_session_during_forwarding_is_reported_to_the_manager():
    async def go():
        eng, client, backend, mgr = build()
        backend.forward_script = [BackendError("auth_key_unregistered")]
        return await eng._run_job(job()), mgr

    result, mgr = run(go())
    assert result["error_code"] == "auth_key_unregistered" and mgr.errors == [(AID, "auth_key_unregistered")]


def test_execute_once_sends_only_started_jobs_and_reports_once():
    async def go():
        eng, client, backend, mgr = build()
        client.jobs = [job(1, "j1"), job(2, "j2"), job(3, "j3")]
        client.started_filter = {"j2"}                                            # the server took j2 back (route paused)
        n = await eng.execute_once()
        return n, client, backend

    n, client, backend = run(go())
    assert n == 2 and [f[1] for f in backend.forwarded] == [1, 3]
    assert len(client.results_posted) == 1 and [r["id"] for r in client.results_posted[0]] == ["j1", "j3"]


def test_finished_sends_are_not_forgotten_when_the_report_fails():
    async def go():
        eng, client, backend, mgr = build()
        client.jobs = [job(1, "j1")]
        client.results_error = TransientError("ConnectError")
        await eng.execute_once()
        kept = list(eng._unsent)
        client.results_error = None
        await eng.execute_once()                                                  # nothing new to claim: resends the report
        return kept, client, backend

    kept, client, backend = run(go())
    assert [r["id"] for r in kept] == ["j1"] and len(backend.forwarded) == 1       # sent once, reported later
    assert [r["id"] for r in client.results_posted[0]] == ["j1"]


def test_run_loops_stop_cleanly():
    async def go():
        eng, client, backend, mgr = build(flush_interval=0.01)
        stop = asyncio.Event()
        task = asyncio.create_task(eng.run(stop))
        await asyncio.sleep(0.1)
        stop.set()
        await asyncio.wait_for(task, 5)

    run(go())


def test_flood_wait_stops_the_rest_of_the_batch_for_that_account():
    async def go():
        eng, client, backend, mgr = build()
        backend.forward_script = [BackendError("flood_wait", 90)]
        client.jobs = [job(1, "j1"), job(2, "j2"), job(3, "j3")]
        await eng.execute_once()
        return client, backend

    client, backend = run(go())
    assert backend.forwarded == []                                                     # nothing sent after the demand
    results = {r["id"]: r for r in client.results_posted[0]}
    assert {r["error_code"] for r in results.values()} == {"flood_wait"}
    assert results["j1"]["retry_after"] == 90 and 89 <= results["j2"]["retry_after"] <= 91
