import pytest

from app.models import Role
from tests.conftest import NEW_PASSWORD, PASSWORD


def test_login_me_logout_flow(client, seed_user, login):
    seed_user("alice")
    headers = login(client)
    me = client.get("/api/auth/me")
    assert me.status_code == 200 and me.json()["user"]["username"] == "alice"
    assert "password" not in me.text
    assert client.post("/api/auth/logout", headers=headers).status_code == 204
    assert client.get("/api/auth/me").status_code == 401


def test_cookie_flags_secure_mode(settings, seed_user):
    from fastapi.testclient import TestClient
    from app.main import create_app

    seed_user("alice")
    secure = settings.model_copy(update={"cookie_secure": True})
    with TestClient(create_app(secure), base_url="https://testserver") as c:
        r = c.post("/api/auth/login", json={"username": "alice", "password": PASSWORD})
        cookie = r.headers["set-cookie"].lower()
        assert "httponly" in cookie and "secure" in cookie and "samesite=lax" in cookie


def test_unknown_user_and_wrong_password_look_identical(client, seed_user):
    seed_user("alice")
    a = client.post("/api/auth/login", json={"username": "alice", "password": "nope-nope-nope"})
    b = client.post("/api/auth/login", json={"username": "ghost", "password": "nope-nope-nope"})
    assert a.status_code == b.status_code == 401
    assert a.json()["error"] == b.json()["error"]


def test_username_is_case_insensitive(client, seed_user):
    seed_user("alice")
    assert client.post("/api/auth/login", json={"username": " ALICE ", "password": PASSWORD}).status_code == 200


def test_lockout_after_repeated_failures_blocks_even_correct_password(client, seed_user, audit_rows):
    seed_user("alice")
    for _ in range(3):
        assert client.post("/api/auth/login", json={"username": "alice", "password": "wrong-wrong-1"}).status_code == 401
    r = client.post("/api/auth/login", json={"username": "alice", "password": PASSWORD})
    assert r.status_code == 401  # locked: indistinguishable from a wrong password
    assert audit_rows("auth.account_locked")
    assert audit_rows("auth.login_blocked")


def test_lock_expires_and_success_resets_counter(client, seed_user, settings):
    from app.models import User
    from app.types import utcnow
    from tests.conftest import run_db
    from datetime import timedelta
    from sqlalchemy import select

    seed_user("alice")
    for _ in range(3):
        client.post("/api/auth/login", json={"username": "alice", "password": "wrong-wrong-1"})

    async def expire(s):
        u = (await s.execute(select(User))).scalar_one()
        u.locked_until = utcnow() - timedelta(seconds=1)

    run_db(settings, expire)
    assert client.post("/api/auth/login", json={"username": "alice", "password": PASSWORD}).status_code == 200

    async def counter(s):
        return (await s.execute(select(User))).scalar_one().failed_login_count

    assert run_db(settings, counter) == 0


def test_inactive_user_cannot_login(client, seed_user):
    seed_user("bob", active=False)
    assert client.post("/api/auth/login", json={"username": "bob", "password": PASSWORD}).status_code == 401


def test_ip_rate_limit_returns_429(settings, seed_user):
    from fastapi.testclient import TestClient
    from app.main import create_app

    seed_user("alice")
    s = settings.model_copy(update={"login_ip_max_attempts": 3, "login_lock_threshold": 100})
    with TestClient(create_app(s), base_url="http://testserver") as c:
        for _ in range(3):
            assert c.post("/api/auth/login", json={"username": "ghost", "password": "x" * 12}).status_code == 401
        assert c.post("/api/auth/login", json={"username": "alice", "password": PASSWORD}).status_code == 429


def test_csrf_required_for_state_changes(client, seed_user, login):
    seed_user("alice")
    login(client)
    assert client.post("/api/auth/logout").status_code == 403
    assert client.post("/api/auth/logout", headers={"X-CSRF-Token": "wrong"}).status_code == 403


def test_idle_session_expires(client, seed_user, login, age_session):
    seed_user("alice")
    login(client)
    age_session(client.app.state.settings.session_idle_seconds + 5)
    assert client.get("/api/auth/me").status_code == 401


def test_endpoints_require_authentication(client):
    for method, path in [("get", "/api/auth/me"), ("get", "/api/users"), ("get", "/api/audit"), ("post", "/api/users")]:
        assert getattr(client, method)(path).status_code == 401, path


def test_change_password(client, new_client, seed_user, login):
    seed_user("alice")
    h1 = login(client)
    other = new_client()
    login(other)  # second session for same user

    bad = client.post("/api/auth/change-password", headers=h1, json={"current_password": "wrong-wrong-1", "new_password": NEW_PASSWORD})
    assert bad.status_code == 400
    weak = client.post("/api/auth/change-password", headers=h1, json={"current_password": PASSWORD, "new_password": "short"})
    assert weak.status_code == 422
    ok = client.post("/api/auth/change-password", headers=h1, json={"current_password": PASSWORD, "new_password": NEW_PASSWORD})
    assert ok.status_code == 204

    assert client.get("/api/auth/me").status_code == 200       # current session kept
    assert other.get("/api/auth/me").status_code == 401        # other sessions revoked
    assert client.post("/api/auth/login", json={"username": "alice", "password": PASSWORD}).status_code == 401
    assert client.post("/api/auth/login", json={"username": "alice", "password": NEW_PASSWORD}).status_code == 200


def test_validation_errors_do_not_echo_input(client):
    r = client.post("/api/auth/login", json={"username": "alice", "password": "S3cret-" * 100})
    assert r.status_code == 422
    assert "S3cret" not in r.text
    assert r.json()["error"]["code"] == "validation_error"


def test_passwords_never_reach_audit_log(client, seed_user, audit_rows):
    seed_user("alice")
    client.post("/api/auth/login", json={"username": "alice", "password": "Leaky-Password-123"})
    client.post("/api/auth/login", json={"username": "ghost", "password": "Leaky-Password-123"})
    assert "Leaky-Password" not in repr(audit_rows())


def test_response_headers(client):
    r = client.get("/health/live", headers={"X-Request-ID": "abc-12345678"})
    assert r.headers["x-request-id"] == "abc-12345678"
    assert r.headers["x-content-type-options"] == "nosniff"
    bad = client.get("/health/live", headers={"X-Request-ID": "bad id!!"})
    assert bad.headers["x-request-id"] != "bad id!!"


@pytest.mark.parametrize("role", [Role.ADMIN, Role.OPERATOR])
def test_me_reports_role(client, seed_user, login, role):
    seed_user("carol", role=role)
    login(client, "carol")
    assert client.get("/api/auth/me").json()["user"]["role"] == role.value
