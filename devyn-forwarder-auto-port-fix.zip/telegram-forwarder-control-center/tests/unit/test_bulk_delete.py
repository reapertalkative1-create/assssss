import uuid
from sqlalchemy import select,func
from app.models import TelegramAccount as A,ForwardRoute,ForwardJob,RouteCheckpoint,WorkerCommand,Role
from app.services import accounts as svc
from app.crypto import SecretBox
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_account_bulk import seed,process


def test_bulk_delete_filtered_snapshot_excludes_unchecked_more_than_100(env):
    ids=seed(env,251)
    async def mark(db):
        for a in (await db.execute(select(A).where(A.id!=uuid.UUID(ids[-1])))).scalars():a.health_status='dead'
    run_db(env.settings,mark)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'delete','all_matching':True,
        'filters':{'health_status':'dead'},'exclude_ids':[ids[0]]})
    assert r.status_code==202,r.text
    assert r.json()['total']==249
    process(env,4)
    j=env.client.get('/api/account-bulk/'+r.json()['id']).json()
    assert j['status']=='done' and j['counts']['done']==249
    remaining=env.client.get('/api/accounts').json()
    assert remaining['total']==2 and {a['id'] for a in remaining['items']}=={ids[0],ids[-1]}
    assert env.client.get('/api/accounts/'+ids[1]).status_code==404


def test_bulk_delete_cleans_related_data_and_preserves_other_accounts(env):
    victim=env.make_account('Delete me');keep=env.make_account('Keep me')
    async def related(db):
        route=ForwardRoute(name='victim route',name_key='victim route',account_id=uuid.UUID(victim),
            source_chat_ids=[-1001],destination_chat_ids=[-1002])
        db.add(route);await db.flush()
        db.add(RouteCheckpoint(route_id=route.id,source_chat_id=-1001,last_message_id=10))
        db.add(ForwardJob(route_id=route.id,account_id=uuid.UUID(victim),source_chat_id=-1001,
            message_id=10,dest_chat_id=-1002,idempotency_key='delete-test-job'))
        db.add(ForwardRoute(name='keep route',name_key='keep route',account_id=uuid.UUID(keep),
            source_chat_ids=[-1003],destination_chat_ids=[-1004]))
    run_db(env.settings,related)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'delete','account_ids':[victim]})
    assert r.status_code==202,r.text
    process(env)
    async def counts(db):
        return [(await db.execute(select(func.count()).select_from(m))).scalar_one() for m in (ForwardRoute,ForwardJob,RouteCheckpoint)]
    assert run_db(env.settings,counts)==[1,0,0]
    assert env.client.get('/api/accounts/'+keep).status_code==200
    assert env.client.get('/api/accounts/'+victim).status_code==404


def test_running_account_drains_and_pending_commands_are_cancelled(env):
    w=env.make_worker();aid=env.make_account('Active',w)
    epoch=w.lease(aid).json()['epoch']
    async def pending(db):
        svc.create_command(db,SecretBox([env.settings.session_encryption_key.get_secret_value()]),
            worker_id=uuid.UUID(w.id),account_id=uuid.UUID(aid),type='spam_reply',payload={'text':'delete-test-private'},
            ttl=600,created_by=None,now=utcnow())
    run_db(env.settings,pending)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'delete','account_ids':[aid]})
    process(env)
    j=env.client.get('/api/account-bulk/'+r.json()['id']).json()
    assert j['counts']['draining']==1
    a=env.client.get('/api/accounts/'+aid).json();assert a['pending_deletion'] and a['desired_state']=='stopped'
    assert not w.poll() and w.lease(aid).status_code==409
    async def expired(db):
        cmd=(await db.execute(select(WorkerCommand).where(WorkerCommand.account_id==uuid.UUID(aid)))).scalars().one()
        return cmd.status,cmd.payload_ciphertext
    assert run_db(env.settings,expired)==('expired',None)
    # Stopping further scheduling does not undo deletion already begun.
    env.client.post('/api/account-bulk/'+r.json()['id']+'/cancel',headers=env.h)
    assert w.release(aid,epoch).status_code==204
    process(env)
    assert env.client.get('/api/accounts/'+aid).status_code==404
    assert not w.poll()  # No Telegram logout request is created by bulk removal.


def test_bulk_delete_rbac_and_csrf(env,new_client,seed_user,login):
    aid=env.make_account()
    seed_user('op',role=Role.OPERATOR);op=new_client();h=login(op,'op')
    body={'action':'delete','account_ids':[aid]}
    assert op.post('/api/account-bulk',headers=h,json=body).status_code==403
    assert env.client.post('/api/account-bulk',json=body).status_code==403
    assert env.client.get('/api/accounts/'+aid).status_code==200


def test_single_delete_logout_keeps_its_authorized_lease_path(env):
    w=env.make_worker();aid=env.make_account('Legacy logout',w)
    env.client.put('/api/accounts/'+aid+'/telegram-api',headers=env.h,json={'api_id':12345,'api_hash':'a'*32})
    env.authorize(w,aid)
    r=env.client.post('/api/accounts/'+aid+'/delete',headers=env.h,
        json={'confirm_name':'Legacy logout','telegram_logout':True,'force':False})
    assert r.status_code==200,r.text
    (cmd,)=w.poll();assert cmd['type']=='logout'
    ep=w.lease(aid);assert ep.status_code==200,ep.text
    assert w.http.post(f'/api/worker/v1/accounts/{aid}/telegram-api/fetch',headers=w.h).status_code==200
    w.release(aid,ep.json()['epoch']);w.result(cmd['id'],result={})
    assert env.client.get('/api/accounts/'+aid).status_code==404
