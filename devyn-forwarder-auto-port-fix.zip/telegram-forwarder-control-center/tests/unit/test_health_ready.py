from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def test_ready_ok(client):
    r = client.get("/health/ready")
    assert r.status_code == 200 and r.json()["database"] == "up"


def test_ready_degraded_hides_error_details(tmp_path):
    s = Settings(env="development", database_url="sqlite+aiosqlite:////nonexistent-dir/x/y.db")
    with TestClient(create_app(s)) as c:
        r = c.get("/health/ready")
    assert r.status_code == 503
    assert r.json() == {"status": "degraded", "database": "down"}
