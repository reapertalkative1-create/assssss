import asyncio
import uuid
from datetime import timedelta
import pytest
from sqlalchemy import select, func
from app.models import TelegramAccount as A, AccountBulkJob, AccountBulkItem, WorkerCommand, Role
from app.services.account_bulk import tick
from app.services.accounts import apply_result
from app.crypto import SecretBox
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env


def process(env, n=1):
    async def run(db):
        for _ in range(n):await tick(db,env.settings,SecretBox([env.settings.session_encryption_key.get_secret_value()]))
    run_db(env.settings,run)


def seed(env,n=250,worker=None):
    async def run(db):
        ids=[]
        for i in range(n):
            a=A(name=f'Bulk {i}',name_key=f'bulk {i}',auth_state='authorized',desired_state='running',
                assigned_worker_id=uuid.UUID(worker.id) if worker else None,session_ciphertext='encrypted-test-placeholder',session_version=1)
            db.add(a);await db.flush();ids.append(str(a.id))
        return ids
    return run_db(env.settings,run)


def test_snapshot_stop_more_than_100_and_restart(env):
    ids=seed(env,251)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True})
    assert r.status_code==202,r.text
    job=r.json();assert job['total']==251
    process(env)
    state=env.client.get('/api/account-bulk/'+job['id']).json()
    assert state['counts']['done']==100 and state['counts']['pending']==151
    # New transactions emulate a restarted scheduler; the target is persisted.
    seed(env,1) if False else None
    process(env,3)
    state=env.client.get('/api/account-bulk/'+job['id']).json()
    assert state['status']=='done' and state['counts']['done']==251
    assert env.client.get('/api/accounts?desired_state=stopped').json()['total']==251


def test_filters_manual_frozen_and_clear_does_not_override_telegram(env):
    ids=seed(env,3)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'mark_frozen','account_ids':[ids[0]]});process(env)
    frozen=env.client.get('/api/accounts?health_status=frozen').json()
    assert frozen['total']==1 and frozen['items'][0]['health_source']=='manual'
    assert frozen['items'][0]['desired_state']=='stopped'
    summary=env.client.get('/api/accounts/summary').json()
    assert summary['health']['frozen']==1
    env.client.post('/api/account-bulk',headers=env.h,json={'action':'clear_mark','account_ids':[ids[0]]});process(env)
    assert env.client.get('/api/accounts?health_status=frozen').json()['total']==0
    env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True,'filters':{'q':'Bulk 1'}});process(env)
    assert env.client.get('/api/accounts?desired_state=stopped').json()['total']==2


def test_check_backpressure_and_per_item_errors(env):
    w=env.make_worker();ids=seed(env,125,w)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'check','all_matching':True});assert r.status_code==202,r.text
    jid=r.json()['id'];process(env)
    state=env.client.get('/api/account-bulk/'+jid).json()
    assert state['counts']['queued']==30 and state['counts']['pending']==95
    # Consume commands and report actual classified errors.
    while True:
        cmds=w.poll()
        if not cmds:break
        for cmd in cmds:w.result(cmd['id'],status='failed',error_code='network_error')
    process(env)
    state=env.client.get('/api/account-bulk/'+jid+'?status=error').json()
    assert state['counts']['error']==30 and state['items_total']==30
    assert env.client.get('/api/accounts?health_status=error').json()['total']==30
    retry=env.client.post('/api/account-bulk/'+jid+'/retry',headers=env.h)
    assert retry.status_code==202 and retry.json()['total']==30


def test_cancel_unqueued_snapshot_and_rbac(env,new_client,seed_user,login):
    seed(env,151)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True});jid=r.json()['id']
    process(env)
    cancel=env.client.post('/api/account-bulk/'+jid+'/cancel',headers=env.h);assert cancel.status_code==200
    process(env)
    state=env.client.get('/api/account-bulk/'+jid).json()
    assert state['status']=='cancelled' and state['counts']['cancelled']==51
    seed_user('op',role=Role.OPERATOR);op=new_client();h=login(op,'op')
    assert op.post('/api/account-bulk',headers=h,json={'action':'stop','all_matching':True}).status_code==403
    assert env.client.post('/api/account-bulk',json={'action':'stop','all_matching':True}).status_code==403
    assert env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop'}).status_code==422


@pytest.mark.parametrize('code,expected',[('network_error','error'),('auth_key_unregistered','dead'),('account_frozen','frozen'),('flood_wait','waiting')])
def test_health_classification_not_all_errors_are_dead(env,code,expected):
    w=env.make_worker();aid=env.make_account(worker=w)
    async def run(db):
        a=await db.get(A,uuid.UUID(aid));a.auth_state='authorized';a.desired_state='running'
        cmd=WorkerCommand(worker_id=w.id,account_id=aid,type='check_connection',expires_at=utcnow()+timedelta(seconds=60))
        # UUIDs are coerced here to match SQLAlchemy native UUID columns.
        cmd.worker_id=uuid.UUID(w.id);cmd.account_id=uuid.UUID(aid)
        db.add(cmd);await db.flush()
        await apply_result(db,cmd,a,'failed',None,code,60 if code=='flood_wait' else None,utcnow())
    run_db(env.settings,run)
    a=env.client.get('/api/accounts/'+aid).json()
    assert a['health_status']==expected
    if expected=='waiting':assert a['flood_wait_until']
    if expected=='error':assert a['auth_state']=='authorized'


def test_frozen_rpc_mapping():
    from worker.telegram_backend import map_error
    class Frozen(Exception):message='FROZEN_METHOD_INVALID'
    assert map_error(Frozen()).code=='account_frozen'


def test_heartbeat_can_renew_more_than_200_accounts(env):
    w=env.make_worker();ids=seed(env,251,w)
    async def lease_all(db):
        for a in (await db.execute(select(A))).scalars():
            a.lease_worker_id=uuid.UUID(w.id);a.lease_epoch=1;a.lease_expires_at=utcnow()+timedelta(seconds=60)
    run_db(env.settings,lease_all)
    r=w.heartbeat([{'account_id':aid,'epoch':1,'state':'connected'} for aid in ids])
    assert r.status_code==200,r.text
    assert not r.json()['lost_leases'] and len(r.json()['accounts'])==251


def test_select_all_can_exclude_individual_accounts(env):
    ids=seed(env,3)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'stop','all_matching':True,'exclude_ids':[ids[0]]})
    assert r.status_code==202 and r.json()['total']==2
    process(env)
    assert env.client.get('/api/accounts/'+ids[0]).json()['desired_state']=='running'
    assert env.client.get('/api/accounts?desired_state=stopped').json()['total']==2


def test_bulk_start_refills_slots_without_waiting_for_next_heartbeat():
    from types import SimpleNamespace
    from worker.accounts import AccountManager
    manager=AccountManager(None,object());active=peak=0;seen=[]
    async def start(aid):
        nonlocal active,peak
        active+=1;peak=max(peak,active)
        await asyncio.sleep(.002)
        manager._active[aid]=SimpleNamespace(epoch=1)
        seen.append(aid);active-=1
    manager._start=start
    async def scenario():
        assignments=[SimpleNamespace(account_id=str(i),desired_state='running') for i in range(25)]
        await manager._apply(60,assignments,[],0)
        while manager._tasks:await asyncio.gather(*list(manager._tasks))
    asyncio.run(scenario())
    assert len(seen)==25 and peak==3 and not manager._starting
