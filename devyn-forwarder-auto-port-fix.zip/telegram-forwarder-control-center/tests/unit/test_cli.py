import asyncio

import pytest
from sqlalchemy import select

from app.cli import create_admin
from app.db import make_engine, make_sessionmaker
from app.models import AuditLog, Role, User
from tests.conftest import PASSWORD


def test_create_admin_cli(settings, client, login):
    asyncio.run(create_admin(settings.database_url, "Root-Admin", PASSWORD))
    h = login(client, "root-admin")
    assert client.get("/api/auth/me").json()["user"]["role"] == "admin"
    assert h


def test_create_admin_rejects_weak_and_duplicate(settings):
    with pytest.raises(SystemExit):
        asyncio.run(create_admin(settings.database_url, "adminx", "short"))
    asyncio.run(create_admin(settings.database_url, "adminx", PASSWORD))
    with pytest.raises(SystemExit):
        asyncio.run(create_admin(settings.database_url, "adminx", PASSWORD))

    async def check():
        engine = make_engine(settings.database_url)
        async with make_sessionmaker(engine)() as s:
            users = (await s.execute(select(User))).scalars().all()
            logs = (await s.execute(select(AuditLog))).scalars().all()
        await engine.dispose()
        return users, logs

    users, logs = asyncio.run(check())
    assert len(users) == 1 and users[0].role == Role.ADMIN and users[0].password_hash != PASSWORD
    assert [l.actor_username for l in logs] == ["cli"]
