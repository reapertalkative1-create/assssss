import asyncio
import uuid
from datetime import timedelta
from types import SimpleNamespace

import pytest
from sqlalchemy import select

from app.models import AuditLog, Role, TelegramAccount, Worker, WorkerCommand
from app.services import accounts as svc
from app.types import utcnow
from tests.conftest import run_db

PHONE, PHONE_TAIL = "+84901234567", "901234567"
CODE, PW = "48213", "My-2FA-Secret-pw"
SESSION = "1BVtsOHUBu9w8aB4cpNHsecretsessionmarker0123456789"
REG = {"platform": "linux", "version": "0.4.0", "hostname": "box"}


class W:
    """Acts like a remote worker, speaking the real HTTP protocol."""

    def __init__(self, http, cred, wid):
        self.http, self.id, self.h = http, wid, {"Authorization": f"Bearer {cred}"}

    def poll(self, wait=0):
        r = self.http.post("/api/worker/v1/commands/poll", headers=self.h, json={"wait_seconds": wait})
        assert r.status_code == 200, r.text
        return r.json()["commands"]

    def result(self, cid, status="done", result=None, error_code=None):
        return self.http.post(f"/api/worker/v1/commands/{cid}/result", headers=self.h,
                              json={"status": status, "result": result, "error_code": error_code})

    def lease(self, aid):
        return self.http.post(f"/api/worker/v1/accounts/{aid}/lease", headers=self.h)

    def release(self, aid, epoch):
        return self.http.post(f"/api/worker/v1/accounts/{aid}/lease/release", headers=self.h, json={"epoch": epoch})

    def fetch(self, aid, epoch):
        return self.http.post(f"/api/worker/v1/accounts/{aid}/session/fetch", headers=self.h, json={"epoch": epoch})

    def upload(self, aid, epoch, session=SESSION, expected_version=None):
        return self.http.put(f"/api/worker/v1/accounts/{aid}/session", headers=self.h,
                             json={"epoch": epoch, "session": session, "expected_version": expected_version})

    def heartbeat(self, accounts=()):
        return self.http.post("/api/worker/v1/heartbeat", headers=self.h, json={"accounts": list(accounts)})


@pytest.fixture
def env(client, seed_user, login, new_client, settings):
    seed_user("admin1")
    h = login(client, "admin1")

    def make_worker(name="w1", platform="linux", register=True) -> W:
        r = client.post("/api/workers", headers=h, json={"name": name, "platform": platform})
        assert r.status_code == 201, r.text
        w = W(new_client(), r.json()["credential"], r.json()["id"])
        if register:
            assert w.http.post("/api/worker/v1/register", headers=w.h, json={**REG, "platform": platform}).status_code == 200
        return w

    def make_account(name="acc1", worker: W | None = None) -> str:
        r = client.post("/api/accounts", headers=h, json={"name": name})
        assert r.status_code == 201, r.text
        if worker:
            assert client.put(f"/api/accounts/{r.json()['id']}/assignment", headers=h, json={"worker_id": worker.id}).status_code == 200
        return r.json()["id"]

    def authorize(w: W, aid: str):
        """Drive the real login flow end to end as admin + worker; returns the final lease epoch used."""
        c = client
        r = c.post(f"/api/accounts/{aid}/login/start", headers=h, json={"phone": PHONE})
        assert r.status_code == 202, r.text
        (cmd,) = w.poll()
        w.result(cmd["id"], result={"state": "awaiting_code"})
        assert c.post(f"/api/accounts/{aid}/login/code", headers=h, json={"code": CODE}).status_code == 202
        (cmd,) = w.poll()
        ep = w.lease(aid).json()["epoch"]
        assert w.upload(aid, ep, expected_version=0).status_code == 200
        w.release(aid, ep)
        assert w.result(cmd["id"], result={"state": "authorized", "telegram_user_id": 777, "username": "alice_tg"}).status_code == 204
        return ep

    return SimpleNamespace(client=client, h=h, make_worker=make_worker, make_account=make_account, authorize=authorize, settings=settings)


def db_dump(settings) -> str:
    async def _do(s):
        parts = []
        for model in (AuditLog, WorkerCommand, TelegramAccount):
            for row in (await s.execute(select(model))).scalars():
                parts.append(repr({c.name: getattr(row, c.name) for c in model.__table__.columns}))
        return "\n".join(parts)

    return run_db(settings, _do)


# ------------------------------------------------------------------ basics / RBAC
def test_account_crud_and_rbac(env, new_client, seed_user, login):
    aid = env.make_account("Sales One")
    assert env.client.post("/api/accounts", headers=env.h, json={"name": "sales one"}).status_code == 409
    assert env.client.post("/api/accounts", headers=env.h, json={"name": "  "}).status_code == 422
    r = env.client.patch(f"/api/accounts/{aid}", headers=env.h, json={"name": "Sales 1"})
    assert r.json()["name"] == "Sales 1" and r.json()["auth_state"] == "unauthenticated" and r.json()["has_session"] is False

    seed_user("op", role=Role.OPERATOR)
    op = new_client()
    oh = login(op, "op")
    assert op.get("/api/accounts").json()["total"] == 1 and op.get(f"/api/accounts/{aid}").status_code == 200
    for method, path, body in [("post", "/api/accounts", {"name": "x"}), ("patch", f"/api/accounts/{aid}", {"name": "y"}),
                               ("put", f"/api/accounts/{aid}/assignment", {"worker_id": None}),
                               ("post", f"/api/accounts/{aid}/login/start", {"phone": PHONE}),
                               ("post", f"/api/accounts/{aid}/delete", {"confirm_name": "Sales 1"})]:
        assert getattr(op, method)(path, headers=oh, json=body).status_code == 403, path
    assert new_client().get("/api/accounts").status_code == 401
    assert env.client.get("/api/accounts", params={"q": "sales"}).json()["total"] == 1
    assert env.client.get("/api/accounts", params={"auth_state": "authorized"}).json()["total"] == 0


def test_assignment_rules(env):
    w = env.make_worker()
    aid = env.make_account()
    ghost = str(uuid.uuid4())
    assert env.client.put(f"/api/accounts/{aid}/assignment", headers=env.h, json={"worker_id": ghost}).status_code == 404
    r = env.client.put(f"/api/accounts/{aid}/assignment", headers=env.h, json={"worker_id": w.id})
    assert r.json()["assigned_worker_name"] == "w1"
    env.client.post(f"/api/workers/{w.id}/revoke", headers=env.h)
    other = env.make_account("acc2")
    assert env.client.put(f"/api/accounts/{other}/assignment", headers=env.h, json={"worker_id": w.id}).status_code == 409


# ------------------------------------------------------------------ login flow with OTP / 2FA
def test_full_login_flow_never_exposes_or_persists_secrets(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    c, h = env.client, env.h

    r = c.post(f"/api/accounts/{aid}/login/start", headers=h, json={"phone": PHONE})
    assert r.status_code == 202
    assert c.get(f"/api/accounts/{aid}").json()["phone_masked"] not in (None, PHONE)
    assert PHONE_TAIL not in db_dump(env.settings) and PHONE_TAIL not in c.get(f"/api/accounts/{aid}").text  # payload encrypted
    (cmd,) = w.poll()
    assert cmd["type"] == "send_code" and cmd["payload"] == {"phone": PHONE}
    assert w.poll() == []                                                   # delivered exactly once
    async def stored_payloads(s):
        return [(c.status, c.payload_ciphertext) for c in (await s.execute(select(WorkerCommand))).scalars()]

    assert run_db(env.settings, stored_payloads) == [("delivered", None)]   # the encrypted phone is wiped on delivery
    assert w.result(cmd["id"], result={"state": "awaiting_code"}).status_code == 204
    assert c.get(f"/api/accounts/{aid}").json()["auth_state"] == "awaiting_code"

    assert c.post(f"/api/accounts/{aid}/login/password", headers=h, json={"password": PW}).status_code == 409  # wrong step
    assert c.post(f"/api/accounts/{aid}/login/code", headers=h, json={"code": CODE}).status_code == 202
    (cmd,) = w.poll()
    assert cmd["type"] == "sign_in_code" and cmd["payload"] == {"code": CODE}
    w.result(cmd["id"], result={"state": "awaiting_password"})
    assert c.get(f"/api/accounts/{aid}").json()["auth_state"] == "awaiting_password"

    assert c.post(f"/api/accounts/{aid}/login/password", headers=h, json={"password": PW}).status_code == 202
    (cmd,) = w.poll()
    ep = w.lease(aid).json()["epoch"]
    assert w.upload(aid, ep, expected_version=0).json() == {"version": 1}
    assert w.result(cmd["id"], result={"state": "authorized", "telegram_user_id": 777, "username": "alice_tg"}).status_code == 204

    acc = c.get(f"/api/accounts/{aid}").json()
    assert acc["auth_state"] == "authorized" and acc["telegram_user_id"] == 777 and acc["has_session"] is True
    everything = db_dump(env.settings) + c.get(f"/api/accounts/{aid}").text + c.get("/api/audit", params={"page_size": 100}).text
    for secret in (CODE, PW, PHONE_TAIL, SESSION):
        assert secret not in everything, f"{secret!r} leaked"          # DB rows, API responses, audit trail
    got = w.fetch(aid, ep).json()
    assert got == {"session": SESSION, "version": 1}                    # only the lease holder can read it back

    async def raw(s):
        return (await s.execute(select(TelegramAccount.session_ciphertext))).scalar_one()

    assert SESSION not in run_db(env.settings, raw)                     # stored encrypted


def test_failed_login_steps(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    c, h = env.client, env.h
    assert c.post(f"/api/accounts/{aid}/login/start", headers=h, json={"phone": "abc"}).status_code == 422
    r = c.post(f"/api/accounts/{aid}/login/start", headers=h, json={"phone": PHONE})
    (cmd,) = w.poll()
    w.result(cmd["id"], "done", {"state": "awaiting_code"})
    bad = c.post(f"/api/accounts/{aid}/login/code", headers=h, json={"code": "12ab"})
    assert bad.status_code == 422 and "12ab" not in bad.text

    c.post(f"/api/accounts/{aid}/login/code", headers=h, json={"code": "11111"})
    (cmd,) = w.poll()
    w.result(cmd["id"], "failed", error_code="code_invalid")
    assert c.get(f"/api/accounts/{aid}").json()["auth_state"] == "awaiting_code"       # may retry
    cm = c.get(f"/api/accounts/{aid}/commands/{cmd['id']}").json()
    assert cm["status"] == "failed" and cm["error_code"] == "code_invalid"

    c.post(f"/api/accounts/{aid}/login/code", headers=h, json={"code": "22222"})
    (cmd,) = w.poll()
    w.result(cmd["id"], "failed", error_code="code_expired")
    assert c.get(f"/api/accounts/{aid}").json()["auth_state"] == "unauthenticated"     # start over


def test_login_needs_online_worker_and_encryption_key(env, settings, new_client, seed_user):
    aid = env.make_account()
    assert env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE}).json()["error"]["code"] == "no_worker_assigned"
    w = env.make_worker("lazy", register=False)
    env.client.put(f"/api/accounts/{aid}/assignment", headers=env.h, json={"worker_id": w.id})
    r = env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE})
    assert r.status_code == 409 and r.json()["error"]["code"] == "worker_unavailable"


def test_without_encryption_key_account_features_answer_503(settings, seed_user, login):
    from fastapi.testclient import TestClient
    from app.main import create_app

    seed_user("admin1")
    from pydantic import SecretStr

    s = settings.model_copy(update={"session_encryption_key": SecretStr("")})
    with TestClient(create_app(s), base_url="http://testserver") as c:
        h = login(c, "admin1")
        wk = c.post("/api/workers", headers=h, json={"name": "w", "platform": "linux"}).json()
        aid = c.post("/api/accounts", headers=h, json={"name": "a"}).json()["id"]
        c.post("/api/worker/v1/register", headers={"Authorization": f"Bearer {wk['credential']}"}, json=REG)
        c.put(f"/api/accounts/{aid}/assignment", headers=h, json={"worker_id": wk["id"]})
        r = c.post(f"/api/accounts/{aid}/login/start", headers=h, json={"phone": PHONE})
        assert r.status_code == 503 and r.json()["error"]["code"] == "encryption_not_configured"


# ------------------------------------------------------------------ leases = one owner at a time
def test_lease_is_exclusive_and_fenced(env):
    a, b = env.make_worker("wa"), env.make_worker("wb")
    aid = env.make_account(worker=a)
    assert b.lease(aid).status_code == 404                              # not assigned to B
    ep1 = a.lease(aid).json()["epoch"]
    ep2 = a.lease(aid).json()["epoch"]
    assert ep2 > ep1
    assert a.upload(aid, ep1).status_code == 409                        # stale epoch is fenced out
    assert a.fetch(aid, ep1).status_code == 409

    env.client.put(f"/api/accounts/{aid}/assignment", headers=env.h, json={"worker_id": b.id})
    r = b.lease(aid)
    assert r.status_code == 409 and r.json()["error"]["code"] == "lease_held"   # A still owns it until release/expiry
    assert a.lease(aid).status_code == 404                              # A is no longer assigned, cannot re-take it
    assert a.upload(aid, ep2).status_code == 404

    renewal = a.heartbeat([{"account_id": aid, "epoch": ep2, "state": "connected"}]).json()
    assert aid in renewal["lost_leases"]                                # A is told to drop it immediately

    async def expire(s):
        (await s.get(TelegramAccount, uuid.UUID(aid))).lease_expires_at = utcnow() - timedelta(seconds=1)

    run_db(env.settings, expire)
    ep3 = b.lease(aid).json()["epoch"]
    assert ep3 > ep2
    assert a.upload(aid, ep2).status_code in (404, 409)                 # the old owner can never write again


def test_release_frees_the_lease_for_the_new_worker(env):
    a, b = env.make_worker("wa"), env.make_worker("wb")
    aid = env.make_account(worker=a)
    ep = a.lease(aid).json()["epoch"]
    env.client.put(f"/api/accounts/{aid}/assignment", headers=env.h, json={"worker_id": b.id})
    assert a.release(aid, ep).status_code == 204
    assert a.release(aid, ep).status_code == 204                        # idempotent
    assert b.lease(aid).status_code == 200


def test_concurrent_acquires_never_share_an_epoch(env):
    from app.db import make_engine, make_sessionmaker

    a = env.make_worker("wa")
    aid = uuid.UUID(env.make_account(worker=a))
    wid = uuid.UUID(a.id)

    async def race():
        engine = make_engine(env.settings.database_url)
        sm = make_sessionmaker(engine)

        async def one():
            async with sm() as s:
                ep = await svc.acquire_lease(s, aid, wid, 60, utcnow())
                await s.commit()
                return ep

        eps = await asyncio.gather(*[one() for _ in range(8)])
        await engine.dispose()
        return eps

    eps = [e for e in asyncio.run(race()) if e is not None]
    assert len(eps) == len(set(eps)) and eps                            # atomic: no duplicated fencing tokens


def test_heartbeat_renews_lease_and_reports_state(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.authorize(w, aid)
    env.client.post(f"/api/accounts/{aid}/start", headers=env.h)
    ep = w.lease(aid).json()["epoch"]

    r = w.heartbeat([{"account_id": aid, "epoch": ep, "state": "connected"}]).json()
    assert r["lost_leases"] == [] and r["lease_ttl_seconds"] == env.settings.account_lease_ttl_seconds
    assert [x["account_id"] for x in r["accounts"]] == [aid] and r["accounts"][0]["desired_state"] == "running"
    acc = env.client.get(f"/api/accounts/{aid}").json()
    assert acc["connection_state"] == "connected" and acc["owner_worker_id"] == w.id and acc["last_active_at"]

    assert aid in w.heartbeat([{"account_id": aid, "epoch": ep + 5, "state": "connected"}]).json()["lost_leases"]
    env.client.post(f"/api/accounts/{aid}/stop", headers=env.h)
    r = w.heartbeat([{"account_id": aid, "epoch": ep, "state": "connected"}]).json()
    assert r["lost_leases"] == [] and r["accounts"][0]["desired_state"] == "stopped"   # keeps the lease to stop gracefully
    assert env.client.get(f"/api/accounts/{aid}").json()["connection_state"] == "disconnected"


def test_connection_state_is_disconnected_once_lease_expires(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.authorize(w, aid)
    env.client.post(f"/api/accounts/{aid}/start", headers=env.h)
    ep = w.lease(aid).json()["epoch"]
    w.heartbeat([{"account_id": aid, "epoch": ep, "state": "connected"}])
    assert env.client.get(f"/api/accounts/{aid}").json()["connection_state"] == "connected"

    async def expire(s):
        (await s.get(TelegramAccount, uuid.UUID(aid))).lease_expires_at = utcnow() - timedelta(seconds=1)

    run_db(env.settings, expire)
    assert env.client.get(f"/api/accounts/{aid}").json()["connection_state"] == "disconnected"


def test_dead_session_report_invalidates_account(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.authorize(w, aid)
    env.client.post(f"/api/accounts/{aid}/start", headers=env.h)
    ep = w.lease(aid).json()["epoch"]
    r = w.heartbeat([{"account_id": aid, "epoch": ep, "state": "error", "error_code": "auth_key_unregistered"}]).json()
    assert aid in r["lost_leases"]
    acc = env.client.get(f"/api/accounts/{aid}").json()
    assert acc["auth_state"] == "invalid" and acc["desired_state"] == "stopped"
    assert env.client.post(f"/api/accounts/{aid}/start", headers=env.h).status_code == 409
    # an invalid account can log in again
    assert env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE}).status_code == 202


def test_start_stop_are_idempotent_and_need_authorization(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    assert env.client.post(f"/api/accounts/{aid}/start", headers=env.h).status_code == 409   # not authorized yet
    env.authorize(w, aid)
    for _ in range(2):
        assert env.client.post(f"/api/accounts/{aid}/start", headers=env.h).json()["desired_state"] == "running"
    for _ in range(2):
        assert env.client.post(f"/api/accounts/{aid}/stop", headers=env.h).json()["desired_state"] == "stopped"
    actions = [r.json() for r in [env.client.get("/api/audit", params={"page_size": 100})]][0]["items"]
    names = [a["action"] for a in actions]
    assert names.count("account.start") == 1 and names.count("account.stop") == 1


def test_register_returns_assignments_for_authorized_accounts_only(env):
    w = env.make_worker()
    ok, not_yet = env.make_account("ok", w), env.make_account("not-yet", w)
    env.authorize(w, ok)
    r = w.http.post("/api/worker/v1/register", headers=w.h, json=REG).json()
    assert [a["account_id"] for a in r["accounts"]] == [ok]
    assert r["lease_ttl_seconds"] > 0 and not_yet not in str(r)


# ------------------------------------------------------------------ session endpoints
def test_session_endpoints_require_lease_and_check_versions(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    assert w.upload(aid, 1).status_code == 409                          # no lease yet
    ep = w.lease(aid).json()["epoch"]
    assert w.fetch(aid, ep).status_code == 404                          # leased but nothing stored
    assert w.upload(aid, ep, expected_version=0).json() == {"version": 1}
    assert w.upload(aid, ep, session=SESSION + "-2", expected_version=0).status_code == 409   # stale writer
    assert w.upload(aid, ep, session=SESSION + "-2", expected_version=1).json() == {"version": 2}
    assert w.upload(aid, ep, session="short").status_code == 422
    other = env.make_worker("other")
    assert other.fetch(aid, ep).status_code == 404
    audit = env.client.get("/api/audit", params={"action": "account.session_", "page_size": 100}).text
    assert SESSION not in audit and "account.session_fetched" not in audit
    w.fetch(aid, ep)
    assert "account.session_fetched" in env.client.get("/api/audit", params={"action": "account.session_fetched"}).text


# ------------------------------------------------------------------ commands: results, expiry
def test_result_handling_is_strict_and_whitelisted(env):
    a, b = env.make_worker("wa"), env.make_worker("wb")
    aid = env.make_account(worker=a)
    env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE})
    cid = [c for c in env.client.get(f"/api/audit", params={"action": "account.login_start"}).json()["items"]][0]["details"]["command_id"]
    assert a.result(cid).status_code == 409                             # not delivered yet
    (cmd,) = a.poll()
    assert b.result(cmd["id"]).status_code == 404                       # another worker's command
    r = a.result(cmd["id"], result={"state": "awaiting_code", "session": "LEAKED-SESSION", "x": 1})
    assert r.status_code == 204 and a.result(cmd["id"]).status_code == 204            # idempotent retry
    assert a.result(cmd["id"], "failed", error_code="x").status_code == 409
    stored = env.client.get(f"/api/accounts/{aid}/commands/{cmd['id']}").json()
    assert stored["result"] == {"state": "awaiting_code"} and "LEAKED" not in db_dump(env.settings)


def test_authorized_requires_stored_session(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE})
    (cmd,) = w.poll()
    w.result(cmd["id"], result={"state": "awaiting_code"})
    env.client.post(f"/api/accounts/{aid}/login/code", headers=env.h, json={"code": CODE})
    (cmd,) = w.poll()
    w.result(cmd["id"], result={"state": "authorized", "telegram_user_id": 1})       # worker never uploaded a session
    assert env.client.get(f"/api/accounts/{aid}").json()["auth_state"] == "awaiting_code"
    assert env.client.get(f"/api/accounts/{aid}/commands/{cmd['id']}").json()["error_code"] == "session_not_uploaded"


def test_unfetched_commands_expire_and_their_payload_is_wiped(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE})

    async def age(s):
        for c in (await s.execute(select(WorkerCommand))).scalars():
            c.expires_at = utcnow() - timedelta(seconds=1)

    run_db(env.settings, age)
    assert w.poll() == []                                               # expired commands are never delivered

    async def sweep(s):
        n = await svc.expire_commands(s, utcnow())
        rows = (await s.execute(select(WorkerCommand))).scalars().all()
        return n, [(c.status, c.payload_ciphertext) for c in rows]

    n, rows = run_db(env.settings, sweep)
    assert n == 1 and rows == [("expired", None)]


def test_new_login_supersedes_the_previous_attempt(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE})
    env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": "+84907654321"})
    cmds = w.poll()
    assert len(cmds) == 1 and cmds[0]["payload"] == {"phone": "+84907654321"}


def test_command_wait_returns_when_still_pending(env):
    w = env.make_worker()
    aid = env.make_account(worker=w)
    cid = env.client.post(f"/api/accounts/{aid}/login/start", headers=env.h, json={"phone": PHONE}).json()["command_id"]
    r = env.client.get(f"/api/accounts/{aid}/commands/{cid}", params={"wait_seconds": 1})
    assert r.status_code == 200 and r.json()["status"] == "pending"
    assert env.client.get(f"/api/accounts/{aid}/commands/{uuid.uuid4()}").status_code == 404


# ------------------------------------------------------------------ deletion needs explicit confirmation
def test_delete_requires_confirmation_and_handles_session_explicitly(env):
    w = env.make_worker()
    plain = env.make_account("no-session")
    assert env.client.post(f"/api/accounts/{plain}/delete", headers=env.h, json={"confirm_name": "wrong"}).status_code == 422
    r = env.client.post(f"/api/accounts/{plain}/delete", headers=env.h, json={"confirm_name": "no-session"})
    assert r.json() == {"status": "deleted", "telegram_session_revoked": None, "command_id": None}

    aid = env.make_account("with-session", w)
    env.authorize(w, aid)
    r = env.client.post(f"/api/accounts/{aid}/delete", headers=env.h, json={"confirm_name": "with-session"})
    assert r.json()["status"] == "logout_requested"
    assert env.client.get(f"/api/accounts/{aid}").json()["pending_deletion"] is True
    assert env.client.post(f"/api/accounts/{aid}/start", headers=env.h).status_code == 409
    (cmd,) = w.poll()
    assert cmd["type"] == "logout"
    assert w.result(cmd["id"]).status_code == 204
    assert env.client.get(f"/api/accounts/{aid}").status_code == 404    # purged only after Telegram confirmed logout
    deleted = [i for i in env.client.get("/api/audit", params={"action": "account.delete"}).json()["items"]]
    assert deleted and deleted[0]["details"]["revoked_on_telegram"] is True
    assert SESSION not in db_dump(env.settings)


def test_failed_logout_keeps_account_and_force_delete_is_explicit(env):
    w = env.make_worker()
    aid = env.make_account("stuck", w)
    env.authorize(w, aid)
    env.client.post(f"/api/accounts/{aid}/delete", headers=env.h, json={"confirm_name": "stuck"})
    (cmd,) = w.poll()
    w.result(cmd["id"], "failed", error_code="network_error")
    assert env.client.get(f"/api/accounts/{aid}").status_code == 200    # nothing was destroyed
    r = env.client.post(f"/api/accounts/{aid}/delete", headers=env.h, json={"confirm_name": "stuck", "force": True})
    assert r.json() == {"status": "deleted", "telegram_session_revoked": False, "command_id": None}
    audit = env.client.get("/api/audit", params={"action": "account.delete"}).json()["items"][0]["details"]
    assert audit["forced"] is True and audit["revoked_on_telegram"] is False


def test_delete_with_logout_needs_an_online_worker(env):
    w = env.make_worker()
    aid = env.make_account("offline-one", w)
    env.authorize(w, aid)
    env.client.post(f"/api/workers/{w.id}/revoke", headers=env.h)
    r = env.client.post(f"/api/accounts/{aid}/delete", headers=env.h, json={"confirm_name": "offline-one"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "worker_unavailable"
    assert env.client.get(f"/api/accounts/{aid}").status_code == 200


# ------------------------------------------------------------------ key CLI
def test_key_cli_verify_and_rotate(env):
    from app.cli import rotate_keys, verify_keys
    from app.crypto import SecretBox
    from tests.conftest import TEST_KEY

    w = env.make_worker()
    aid = env.make_account(worker=w)
    env.authorize(w, aid)
    url = env.settings.database_url
    assert env.client.put(f'/api/accounts/{aid}/telegram-api', headers=env.h,
                          json={'api_id':12345,'api_hash':'a'*32}).status_code == 200
    old_box = SecretBox([TEST_KEY])
    assert asyncio.run(verify_keys(url, old_box))["sessions_ok"] == 1
    assert asyncio.run(verify_keys(url, SecretBox([SecretBox.generate_key()])))["sessions_failed"] == 1

    new_key = SecretBox.generate_key()
    both = SecretBox([new_key, TEST_KEY])
    assert asyncio.run(verify_keys(url, both))["sessions_on_old_key"] == 1
    rotated = asyncio.run(rotate_keys(url, both))
    assert rotated["sessions"] == 1 and rotated["api_configs"] == 1
    assert asyncio.run(verify_keys(url, SecretBox([new_key])))["api_configs_ok"] == 1
    assert asyncio.run(verify_keys(url, SecretBox([new_key])))["sessions_ok"] == 1   # old key can be retired
    assert asyncio.run(rotate_keys(url, both))["sessions"] == 0


def test_audit_sanitizer_drops_secret_looking_keys_but_keeps_flags():
    from app.audit import _clean

    cleaned = _clean({"password": "x", "new_password": "x", "token": "x", "session": "x", "otp_code": "x", "credential": "x",
                      "secret_key": "x", "hash": "x", "version": 2, "revoked_on_telegram": True, "name": "acc"})
    assert cleaned == {"version": 2, "revoked_on_telegram": True, "name": "acc"}
    assert _clean(None) is None and _clean({}) is None
