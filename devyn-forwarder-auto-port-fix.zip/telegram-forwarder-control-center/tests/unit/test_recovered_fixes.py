import asyncio

import pytest

from worker.client import FatalError, TransientError
from worker.config import WorkerSettings
from tests.unit.test_forward_engine import build, facts, route, job, SRC, AID
from tests.unit.test_routes_jobs_api import env, jw, make_route, SRC2, DST, DST2


@pytest.mark.parametrize('count', [6, 50])
def test_fanout_respects_api_limit(count):
    async def go():
        engine, client, backend, _ = build()
        config = route(checkpoints={SRC: 0})
        config.destinations = tuple(-3000-i for i in range(count))
        await engine.on_routes([config])
        original = client.enqueue

        async def enqueue(rid, items, checkpoints):
            if len(items)*count > 1000:
                raise FatalError('http 422')
            return await original(rid, items, checkpoints)

        client.enqueue = enqueue
        for i in range(1, 201):
            backend.emit(facts(i))
        await engine._flush()
        assert [mid for _, items, _ in client.enqueues for _, mid in items] == list(range(1, 201))
        assert config.checkpoints[SRC] == 200 and not engine._buffer
    asyncio.run(go())


def test_history_continues_and_live_updates_cannot_skip_history():
    async def go():
        engine, client, backend, _ = build(max_backfill=2, backfill_rounds=2)
        backend.history[SRC] = [facts(i) for i in range(1, 7)]
        original = backend.history_since

        async def history(handle, src, cp, limit):
            if cp == 0:
                backend.emit(facts(7))
                await engine._flush()
                assert not client.enqueues
            return await original(handle, src, cp, limit)

        backend.history_since = history
        await engine.on_routes([route(checkpoints={SRC: 0})])
        await engine._flush()
        assert engine.routes['r1'].checkpoints[SRC] == 4
        assert ('r1', SRC) not in engine._synced
        await engine.on_routes([route(checkpoints={SRC: 4})])
        await engine._flush()
        assert [mid for _, items, _ in client.enqueues for _, mid in items] == list(range(1, 8))
        assert not engine._deferred_live
    asyncio.run(go())


def test_failed_enqueue_preserves_every_route():
    async def go():
        engine, client, backend, _ = build()
        await engine.on_routes([route(checkpoints={SRC:0}), route('r2', checkpoints={SRC:0})])
        backend.emit(facts(1))
        client.enqueue_error = FatalError('http 422')
        await engine._flush()
        assert len(engine._buffer) == 2
        client.enqueue_error = None
        await engine._flush()
        assert not engine._buffer
        assert all(r.checkpoints[SRC] == 1 for r in engine.routes.values())
    asyncio.run(go())


def test_results_are_chunked_and_backpressure_preserves_pending_results():
    async def go():
        engine, client, backend, _ = build()
        original = client.post_job_results

        async def report(results):
            assert len(results) <= 50
            return await original(results)

        client.post_job_results = report
        client.results_error = TransientError('offline')
        pending = [{'id':str(i)} for i in range(1100)]
        await engine._report(pending)
        client.jobs = [job()]
        with pytest.raises(TransientError, match='results_pending'):
            await engine.execute_once()
        assert engine._unsent == pending and not backend.forwarded
        client.results_error = None
        await engine.execute_once()
        assert not engine._unsent and len(backend.forwarded) == 1
        assert [r for batch in client.results_posted[:-1] for r in batch] == pending
    asyncio.run(go())


def test_cancellation_keeps_completed_send_results():
    async def go():
        engine, client, backend, _ = build()
        client.jobs = [job(1,'j1'),job(2,'j2')]
        original = backend.forward
        second = asyncio.Event()

        async def forward(handle, source, mid, dest, mode):
            if mid == 2:
                second.set()
                await asyncio.Event().wait()
            return await original(handle, source, mid, dest, mode)

        backend.forward = forward
        task = asyncio.create_task(engine.execute_once())
        await second.wait()
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        await engine.shutdown()
        assert [r['id'] for batch in client.results_posted for r in batch] == ['j1']
    asyncio.run(go())


@pytest.mark.parametrize('url', ['http://localhost.evil.example','http://localhost@evil.example',
    'http://localhost:8000@evil.example','https://user:pass@panel.example.com','https://panel.example.com:99999'])
def test_url_validation_rejects_remote_http_and_userinfo(url):
    with pytest.raises(ValueError):
        WorkerSettings(control_plane_url=url, _env_file=None)


@pytest.mark.parametrize('url',['http://localhost:8000','http://127.0.0.1:8000','http://[::1]:8000'])
def test_loopback_http_is_valid(url):
    assert WorkerSettings(control_plane_url=url,_env_file=None).control_plane_url == url


def test_saturated_route_cannot_starve_other_routes(env,jw):
    st=jw()
    busy=make_route(env,st,'busy',dests=(DST,),priority=1,rate_per_minute=1)
    other=make_route(env,st,'other',sources=(SRC2,),dests=(DST2,),priority=9)
    from tests.unit.test_routes_jobs_api import SRC as API_SRC
    st.worker.enqueue(busy,[(API_SRC,i) for i in range(1,101)])
    st.worker.enqueue(other,[(SRC2,1)])
    assert [j['route_id'] for j in st.worker.claim()] == [busy]
    assert [j['route_id'] for j in st.worker.claim()] == [other]


def test_live_filter_edit_checks_loop_guard(env,jw):
    from tests.unit.test_routes_jobs_api import SRC as API_SRC
    st=jw()
    make_route(env,st,'a-b',sources=(API_SRC,),dests=(DST,))
    rid=make_route(env,st,'b-a',sources=(DST,),dests=(API_SRC,))
    result=env.client.patch(f'/api/routes/{rid}',headers=env.h,json={'filters':{'include_outgoing':True}})
    assert result.status_code == 409
    assert result.json()['error']['code'] == 'possible_loop'
    assert env.client.get(f'/api/routes/{rid}').json()['filters']['include_outgoing'] is False


def test_runner_waits_before_shutdown():
    from worker.runner import Runner, EXIT_OK
    async def go():
        ready=asyncio.Event()
        cleaned=[]
        async def background(name):
            try:
                if name=='engine': ready.set()
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(0)
                cleaned.append(name)
        class Accounts:
            async def command_loop(self,stop): await background('commands')
            async def fencing_loop(self,stop): await background('fencing')
            async def shutdown(self): assert set(cleaned)=={'commands','fencing','engine'}
        class Engine:
            async def run(self,stop): await background('engine')
            async def shutdown(self): assert set(cleaned)=={'commands','fencing','engine'}
        runner=Runner(None,platform='linux',version='test',hostname=None,accounts=Accounts(),engine=Engine())
        async def loop():
            await ready.wait()
            return EXIT_OK
        runner._run_loop=loop
        assert await runner.run()==EXIT_OK
    asyncio.run(go())


@pytest.mark.parametrize('method,arg',[('connect','test-session'),('send_code','+12025550123')])
def test_telegram_cancel_propagates(method,arg):
    from worker.telegram_backend import TelethonBackend
    async def go():
        ready,closed=asyncio.Event(),asyncio.Event()
        class Client:
            async def connect(self):
                ready.set()
                await asyncio.Event().wait()
            async def disconnect(self): closed.set()
        backend=TelethonBackend(123,'test-hash')
        backend._new_client=lambda *args:Client()
        task=asyncio.create_task(getattr(backend,method)(arg))
        await ready.wait()
        task.cancel()
        with pytest.raises(asyncio.CancelledError): await task
        assert closed.is_set()
    asyncio.run(go())


def test_role_change_closes_existing_websocket(client,new_client,seed_user,login,monkeypatch):
    from app.routers import ws as module
    from starlette.websockets import WebSocketDisconnect
    monkeypatch.setattr(module,'REVALIDATE_SECONDS',0.1)
    monkeypatch.setattr(module,'POLL_SECONDS',0.05)
    seed_user('admin1')
    uid=seed_user('admin2')
    headers=login(client,'admin1')
    other=new_client()
    login(other,'admin2')
    with other.websocket_connect('/api/ws/events',headers={'cookie':f'tfcc_session={other.cookies.get("tfcc_session")}'}) as stream:
        assert stream.receive_json()['role']=='admin'
        assert client.patch(f'/api/users/{uid}',headers=headers,json={'role':'operator'}).status_code==200
        with pytest.raises(WebSocketDisconnect) as exc:
            for _ in range(20): stream.receive_json()
        assert exc.value.code==4401


def test_login_commits_before_sending_headers(settings,seed_user):
    import httpx
    from http.cookies import SimpleCookie
    from sqlalchemy import select
    from app.main import create_app
    from app.models import WebSession
    from app.security import hash_token
    from tests.conftest import PASSWORD
    seed_user('alice')
    async def go():
        app=create_app(settings)
        checked=[]
        async def wrapped(scope,receive,send):
            async def observe(message):
                if message['type']=='http.response.start' and message['status']==200:
                    cookie=SimpleCookie(dict(message['headers'])[b'set-cookie'].decode())
                    async with app.state.sessionmaker() as db:
                        result=await db.execute(select(WebSession).where(WebSession.token_hash==hash_token(cookie['tfcc_session'].value)))
                        assert result.scalar_one_or_none() is not None
                        checked.append(True)
                await send(message)
            await app(scope,receive,observe)
        try:
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=wrapped),base_url='http://testserver') as c:
                assert (await c.post('/api/auth/login',json={'username':'alice','password':PASSWORD})).status_code==200
            assert checked==[True]
        finally:
            await app.state.engine.dispose()
    asyncio.run(go())
