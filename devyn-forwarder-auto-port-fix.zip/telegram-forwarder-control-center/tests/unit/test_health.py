from cryptography.fernet import Fernet
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def test_live_returns_ok():
    client = TestClient(create_app(Settings(env="development")))
    r = client.get("/health/live")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_docs_disabled_in_production():
    s = Settings(env="production", secret_key="x" * 32, session_encryption_key=Fernet.generate_key().decode(), cookie_secure=True)
    client = TestClient(create_app(s))
    assert client.get("/docs").status_code == 404
    assert client.get("/openapi.json").status_code == 404
