import uuid
from datetime import timedelta
from sqlalchemy import select
from app.models import AccountBulkJob, AccountBulkItem, WorkerCommand, Role
from app.types import utcnow
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_spambot import seeded_report


def test_list_and_detail_include_bot_reply_but_not_for_operators(env,new_client,seed_user,login):
    w,aid,report=seeded_report(env)
    for url in ['/api/accounts',f'/api/accounts/{aid}']:
        r=env.client.get(url);assert r.status_code==200,r.text
        data=r.json();a=data['items'][0] if 'items' in data else data
        assert a['spam_response']==report['report']['text']
        assert a['row_operations'][0]['action']=='spam_check'
        assert 'payload_ciphertext' not in r.text and 'report_token' not in r.text
    seed_user('row-operator',role=Role.OPERATOR);op=new_client();login(op,'row-operator')
    for url in ['/api/accounts',f'/api/accounts/{aid}']:
        r=op.get(url);assert r.status_code==200
        assert 'PRIVATE-BOT-REPLY' not in r.text
        data=r.json();a=data['items'][0] if 'items' in data else data
        assert a['spam_response'] is None


def test_active_work_is_not_hidden_by_newer_finished_history(env):
    w=env.make_worker();aid=env.make_account(worker=w);now=utcnow()
    async def seed(db):
        active=AccountBulkJob(action='bulk_appeal',status='preview',created_at=now-timedelta(days=1));db.add(active);await db.flush()
        db.add(AccountBulkItem(job_id=active.id,account_id=uuid.UUID(aid),status='prepared'))
        for i in range(8):
            job=AccountBulkJob(action='check',status='done',created_at=now+timedelta(seconds=i));db.add(job);await db.flush()
            db.add(AccountBulkItem(job_id=job.id,account_id=uuid.UUID(aid),status='error',error_code='network_error'))
        return str(active.id)
    job_id=run_db(env.settings,seed)
    a=env.client.get('/api/accounts/'+aid).json()
    ops=a['row_operations'];assert len(ops)==5
    assert ops[0]['id']==job_id and ops[0]['status']=='prepared'
    assert ops[0]['job_status']=='preview'
    assert all(o['error_code']=='network_error' for o in ops[1:])


def test_linked_worker_command_is_not_duplicated_and_errors_are_inline(env):
    w=env.make_worker();aid=env.make_account(worker=w)
    r=env.client.post('/api/account-bulk',headers=env.h,json={'action':'spam_check','account_ids':[aid]})
    job_id=r.json()['id']
    async def seed(db):
        cmd=WorkerCommand(worker_id=uuid.UUID(w.id),account_id=uuid.UUID(aid),type='spam_check',status='done',expires_at=utcnow()+timedelta(minutes=1),result={'spam_error':'account_frozen'})
        db.add(cmd);await db.flush()
        item=await db.get(AccountBulkItem,(uuid.UUID(job_id),uuid.UUID(aid)))
        item.command_id=cmd.id;item.status='error';item.error_code='account_frozen'
    run_db(env.settings,seed)
    a=env.client.get('/api/accounts/'+aid).json()
    assert len(a['row_operations'])==1
    assert a['row_operations'][0]['error_code']=='account_frozen'


def test_direct_spambot_partial_failure_is_not_reported_as_success(env):
    w=env.make_worker();aid=env.make_account(worker=w)
    async def seed(db):
        db.add(WorkerCommand(worker_id=uuid.UUID(w.id),account_id=uuid.UUID(aid),type='spam_check',status='done',expires_at=utcnow()+timedelta(minutes=1),result={'spam_error':'network_error'}))
    run_db(env.settings,seed)
    op=env.client.get('/api/accounts/'+aid).json()['row_operations'][0]
    assert op['status']=='error' and op['error_code']=='network_error'
