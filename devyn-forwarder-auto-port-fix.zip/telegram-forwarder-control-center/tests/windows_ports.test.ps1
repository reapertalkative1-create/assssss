param([string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$root = Join-Path ([IO.Path]::GetTempPath()) ('devyn ports ' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $root)
$oldPort = $env:TFCC_HTTP_PORT
function Assert-True { param($Value, [string]$Message); if (-not $Value) { throw $Message } }
try {
    . (Join-Path $ProjectRoot 'scripts/windows.ps1') -NoBrowser
    $script:ConfigFile = Join-Path $root '.env.docker'
    New-DockerConfig
    $config = Read-DockerConfig
    $originalSettings = Read-DockerConfig
    $script:PortRecords = @()
    function docker {
        param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Values)
        $global:LASTEXITCODE = 0
        if ($Values[0] -eq 'ps') { return 'test-container' }
        if ($Values[0] -eq 'inspect') {
            return '{"80/tcp":[{"HostIp":"127.0.0.1","HostPort":"8787"}]}|{"com.docker.compose.project":"other-install","com.docker.compose.service":"web"}'
        }
    }
    $records = @(Get-DockerPortOwners)
    Assert-True ($records.Count -eq 1 -and $records[0].Port -eq 8787 -and $records[0].Project -eq 'other-install') 'Docker binding parsing failed.'
    $realProbe = (Get-Item Function:Test-LocalPortFree).ScriptBlock
    function Get-DockerPortOwners { return $script:PortRecords }

    # Exercise a real occupied loopback socket, then verify persistent settings.
    $listener = New-Object Net.Sockets.TcpListener ([Net.IPAddress]::Loopback), 0
    $listener.ExclusiveAddressUse = $true; $listener.Start()
    try {
        $busy = $listener.LocalEndpoint.Port
        $config['TFCC_HTTP_PORT'] = [string]$busy
        Write-DockerSettings -Values @{TFCC_HTTP_PORT=[string]$busy}
        Select-HttpPort -Config $config
        Assert-True ([int]$config['TFCC_HTTP_PORT'] -ne $busy) 'Occupied real socket was reused.'
        Assert-True ((Read-DockerConfig)['TFCC_HTTP_PORT'] -eq $config['TFCC_HTTP_PORT']) 'Selected port was not saved.'
        Assert-True ($env:TFCC_HTTP_PORT -eq $config['TFCC_HTTP_PORT']) 'Compose environment disagrees with config.'
    } finally { $listener.Stop() }
    foreach ($key in @('TFCC_COMPOSE_PROJECT','TFCC_DB_PASSWORD','TFCC_SECRET_KEY','TFCC_SESSION_ENCRYPTION_KEY','TFCC_WORKER_CREDENTIAL')) {
        Assert-True ((Read-DockerConfig)[$key] -eq $originalSettings[$key]) "Port selection changed $key."
    }
    function Test-LocalPortFree { param([int]$Port); return $true }
    $config['TFCC_HTTP_PORT'] = '8787'
    $script:PortRecords = @([pscustomobject]@{Port=8787;Project='different-project';Service='web'})
    Select-HttpPort -Config $config
    Assert-True ($config['TFCC_HTTP_PORT'] -eq '8788') 'Another Docker project was not respected.'

    # Own running web listener should retain the same URL on every run.
    $config['TFCC_HTTP_PORT'] = '8787'
    $script:PortRecords = @([pscustomobject]@{Port=8787;Project=$config['TFCC_COMPOSE_PROJECT'];Service='web'})
    function Test-LocalPortFree { param([int]$Port); throw 'Own running web must not require a free socket.' }
    Select-HttpPort -Config $config
    Assert-True ($config['TFCC_HTTP_PORT'] -eq '8787') 'Own web port unexpectedly changed.'

    # Reserved/denied local ports must also be skipped, including upper bound wrap.
    $script:PortRecords = @()
    function Test-LocalPortFree { param([int]$Port); return $Port -ne 65535 }
    $config['TFCC_HTTP_PORT'] = '65535'; Select-HttpPort -Config $config
    Assert-True ($config['TFCC_HTTP_PORT'] -eq '1024') 'Port scan overflowed 65535.'
    function Test-LocalPortFree { param([int]$Port); return $false }
    $failed=$false;try { Select-HttpPort -Config $config } catch { $failed=$true }
    Assert-True $failed 'Exhausted port scan did not fail clearly.'

    # Classify actual captured Docker output rather than retrying unrelated failures.
    $script:FailureMessage = 'Bind for 127.0.0.1:8787 failed: port is already allocated'
    function docker {
        param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Values)
        $global:LASTEXITCODE = 1; return $script:FailureMessage
    }
    $classified=$false
    try { Invoke-Docker -DockerArgs @('compose','up') -DetectPortConflict } catch { $classified=$_.Exception.Data.Contains('PortConflict') }
    Assert-True $classified 'Port allocation failure not classified.'
    $script:FailureMessage='dependency failed to start: API unhealthy';$classified=$true
    try { Invoke-Docker -DockerArgs @('compose','up') -DetectPortConflict } catch { $classified=$_.Exception.Data.Contains('PortConflict') }
    Assert-True (-not $classified) 'Unrelated Docker failure misclassified as port conflict.'

    function Test-LocalPortFree { param([int]$Port); return $true }
    $script:WebStarts=0; $script:PortFailures=1; $script:Unrelated=$false
    function Invoke-Docker {
        param([string[]]$DockerArgs,[int[]]$AllowedCodes=@(0),[switch]$DetectPortConflict)
        if ($DockerArgs -contains 'up' -and $DockerArgs -contains 'web') {
            $script:WebStarts++
            if ($script:Unrelated) { throw 'API unhealthy' }
            if ($script:WebStarts -le $script:PortFailures) {
                $e=New-Object InvalidOperationException 'port conflict';$e.Data['PortConflict']=$true;throw $e
            }
        }
        return 0
    }
    function Connect-LocalWorker { param([hashtable]$Config);return [pscustomobject]@{id='test-worker';previous_registered=$null} }
    function Invoke-DockerJson { param([string[]]$DockerArgs,[string]$InputJson);return [pscustomobject]@{name='test-worker'} }
    $config['TFCC_HTTP_PORT']='8787'
    Start-Application -Config $config
    Assert-True ($script:WebStarts -eq 2 -and $config['TFCC_HTTP_PORT'] -eq '8788') 'Race retry did not switch port and recover.'
    $script:WebStarts=0;$script:Unrelated=$true;$failed=$false
    try { Start-Application -Config $config } catch { $failed=$true }
    Assert-True ($failed -and $script:WebStarts -eq 1) 'Non-port startup error was retried.'
    $script:WebStarts=0;$script:Unrelated=$false;$script:PortFailures=9;$failed=$false
    try { Start-Application -Config $config } catch { $failed=$true }
    Assert-True ($failed -and $script:WebStarts -eq 3) 'Port retry must stop after three startup attempts.'
    Write-Host 'PASS: Docker bindings, real socket conflict, settings/keys preservation, own listener reuse, unavailable ports, wrap/exhaustion, conflict classification, race recovery and bounded retries.'
} finally {
    $env:TFCC_HTTP_PORT=$oldPort
    Remove-Item -LiteralPath $root -Recurse -Force
}
