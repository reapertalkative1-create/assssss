"""In-memory stand-ins used instead of Telegram and of the control plane in unit tests."""
from dataclasses import dataclass

from worker.client import ConflictError, NotFoundError, SessionData
from worker.telegram_backend import BackendError, ChatInfo, MessageFacts, SignInResult, UserInfo

SESSION = "1BVtsOHUBu9w8aB4cpNHfakesessionmarker-0123456789abcdef"
CODE_OK, PW_OK = "12345", "tg-2fa-password"


@dataclass(eq=False)
class FakeHandle:
    session: str
    connected: bool = True


class FakeNetwork:
    """Mimics Telegram's rule that one auth key must not be used from two places at once."""

    def __init__(self):
        self.open_by_session: dict[str, int] = {}
        self.max_simultaneous = 0

    def opened(self, session: str) -> None:
        self.open_by_session[session] = self.open_by_session.get(session, 0) + 1
        self.max_simultaneous = max(self.max_simultaneous, self.open_by_session[session])

    def closed(self, session: str) -> None:
        self.open_by_session[session] = max(0, self.open_by_session.get(session, 0) - 1)


class FakeBackend:
    def __init__(self, network: FakeNetwork | None = None, two_factor: bool = False):
        self.net = network or FakeNetwork()
        self.two_factor = two_factor
        self.send_code_error: BackendError | None = None
        self.connect_error: BackendError | None = None
        self.dead_sessions: set[str] = set()
        self.connects = 0
        self.disconnects: list[FakeHandle] = []
        self.logged_out: list[FakeHandle] = []
        self.session_after_use: str | None = None  # simulate Telethon refreshing its auth data
        # --- chats / history / forwarding ---
        self.chats: dict[int, ChatInfo] = {}
        self.history: dict[int, list[MessageFacts]] = {}
        self.latest: dict[int, int] = {}
        self.forward_script: list = []           # items popped per forward(): a BackendError is raised, anything else = ok
        self.forward_error_for: dict[int, BackendError] = {}   # message_id -> error (every time)
        self.forwarded: list[tuple] = []
        self.watchers: dict[object, tuple] = {}
        self.primed = 0

    async def send_code(self, phone):
        if self.send_code_error:
            raise self.send_code_error
        return FakeHandle(SESSION)

    async def sign_in_code(self, handle, code):
        if code != CODE_OK:
            raise BackendError("code_invalid")
        return SignInResult("password_needed") if self.two_factor else SignInResult("authorized", UserInfo(111, "alice_tg"))

    async def sign_in_password(self, handle, password):
        if password != PW_OK:
            raise BackendError("password_invalid")
        return UserInfo(111, "alice_tg")

    def session_string(self, handle):
        return handle.session

    async def connect(self, session):
        if self.connect_error:
            raise self.connect_error
        if session in self.dead_sessions:
            raise BackendError("auth_key_unregistered")
        self.connects += 1
        self.net.opened(session)
        h = FakeHandle(self.session_after_use or session)
        h.origin = session
        return h, UserInfo(111, "alice_tg")

    def is_connected(self, handle):
        return handle.connected

    async def disconnect(self, handle):
        if handle.connected:
            handle.connected = False
            self.net.closed(getattr(handle, "origin", handle.session))
        self.disconnects.append(handle)

    async def log_out(self, handle):
        self.logged_out.append(handle)

    async def prime(self, handle):
        self.primed += 1

    async def resolve_chats(self, handle, chat_ids):
        return {c: self.chats.get(c, ChatInfo(True, True, f"chat {c}")) for c in chat_ids}

    async def latest_message_id(self, handle, chat_id):
        if chat_id in self.latest:
            return self.latest[chat_id]
        return max((m.message_id for m in self.history.get(chat_id, [])), default=0)

    async def history_since(self, handle, chat_id, min_id, limit):
        msgs = sorted((m for m in self.history.get(chat_id, []) if m.message_id > min_id), key=lambda m: m.message_id)
        return msgs[:limit]

    def watch(self, handle, chat_ids, callback):
        token = object()
        self.watchers[token] = (handle, set(chat_ids), callback)
        return token

    def unwatch(self, handle, token):
        self.watchers.pop(token, None)

    def emit(self, facts):
        """A live message arrives in Telegram (also appended to history, like the real thing)."""
        self.history.setdefault(facts.chat_id, []).append(facts)
        for handle, chats, cb in list(self.watchers.values()):
            if facts.chat_id in chats and handle.connected:
                cb(facts)

    async def forward(self, handle, source, message_id, dest, mode):
        if self.forward_script:
            item = self.forward_script.pop(0)
            if isinstance(item, BackendError):
                raise item
        if message_id in self.forward_error_for:
            raise self.forward_error_for[message_id]
        self.forwarded.append((source, message_id, dest, mode))
        return 5000 + len(self.forwarded)


class FakeClient:
    """Control-plane client with in-memory leases, scriptable by the test."""

    def __init__(self, ttl: float = 60.0):
        self.ttl, self.epoch = ttl, 0
        self.lease_held_by_other: set[str] = set()
        self.sessions: dict[str, SessionData] = {}
        self.commands: list[dict] = []
        self.results: list[tuple] = []
        self.uploads: list[tuple] = []
        self.released: list[tuple] = []
        self.acquired: list[str] = []
        self.poll_error: Exception | None = None

    async def poll_commands(self, wait_seconds):
        if self.poll_error:
            raise self.poll_error
        cmds, self.commands = self.commands, []
        return cmds

    async def post_command_result(self, cid, status, result=None, error_code=None, retry_after=None):
        self.results.append((cid, status, result, error_code, retry_after))

    async def acquire_lease(self, aid):
        if aid in self.lease_held_by_other:
            raise ConflictError("lease_held")
        self.epoch += 1
        self.acquired.append(aid)
        return self.epoch, self.ttl

    async def release_lease(self, aid, epoch):
        self.released.append((aid, epoch))

    async def fetch_session(self, aid, epoch):
        if aid not in self.sessions:
            raise NotFoundError("no_session")
        return self.sessions[aid]

    async def upload_session(self, aid, epoch, session, expected_version):
        self.uploads.append((aid, epoch, session, expected_version))
        version = (expected_version or 0) + 1
        self.sessions[aid] = SessionData(session, version)
        return version
