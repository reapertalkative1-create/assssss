@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows.ps1" -Mode Setup
set "result=%errorlevel%"
if not "%result%"=="0" (
    echo.
    echo Setup failed. Read the message above, then run setup.cmd again.
)
echo.
pause
exit /b %result%
