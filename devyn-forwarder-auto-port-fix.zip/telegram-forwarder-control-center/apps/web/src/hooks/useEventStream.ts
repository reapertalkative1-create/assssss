import { useEffect, useRef, useState } from "react";
import type { EventItem } from "../api/types";
import { EventStream, type StreamState } from "../lib/eventStream";

export function useEventStream(onEvents: (events: EventItem[], initial: boolean) => void, onAuthLost: () => void, enabled = true): StreamState {
  const [state, setState] = useState<StreamState>("connecting");
  const cb = useRef({ onEvents, onAuthLost });
  cb.current = { onEvents, onAuthLost };
  useEffect(() => {
    if (!enabled) return;
    const stream = new EventStream({
      onEvents: (e, initial) => cb.current.onEvents(e, initial), onState: setState, onAuthLost: () => cb.current.onAuthLost(),
    });
    stream.start();
    return () => stream.stop();
  }, [enabled]);
  return state;
}
