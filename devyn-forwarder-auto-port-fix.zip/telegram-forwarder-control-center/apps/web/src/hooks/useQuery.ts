import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError } from "../api/client";

interface Options { interval?: number; enabled?: boolean }
export interface QueryState<T> { data: T | undefined; error: ApiError | undefined; loading: boolean; refreshing: boolean; reload: () => void }

/** Loads data, keeps the previous result while refreshing (no flicker), optionally polls while the tab is visible. */
export function useQuery<T>(fetcher: (signal: AbortSignal) => Promise<T>, deps: unknown[], opts: Options = {}): QueryState<T> {
  const { interval, enabled = true } = opts;
  const [data, setData] = useState<T>();
  const [error, setError] = useState<ApiError>();
  const [loading, setLoading] = useState(enabled);
  const [refreshing, setRefreshing] = useState(false);
  const [tick, setTick] = useState(0);
  const fetchRef = useRef(fetcher);
  fetchRef.current = fetcher;
  const hasData = useRef(false);

  useEffect(() => {
    if (!enabled) return;
    const ctl = new AbortController();
    if (hasData.current) setRefreshing(true); else setLoading(true);
    fetchRef.current(ctl.signal)
      .then((d) => { setData(d); setError(undefined); hasData.current = true; })
      .catch((e: unknown) => { if ((e as Error).name !== "AbortError") setError(e instanceof ApiError ? e : new ApiError(0, "unknown", "Đã xảy ra lỗi không xác định.")); })
      .finally(() => { if (!ctl.signal.aborted) { setLoading(false); setRefreshing(false); } });
    return () => ctl.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick, enabled]);

  useEffect(() => {
    if (!interval || !enabled) return;
    const id = window.setInterval(() => { if (document.visibilityState === "visible") setTick((t) => t + 1); }, interval);
    return () => clearInterval(id);
  }, [interval, enabled]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { data, error, loading, refreshing, reload };
}

export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => { const id = window.setTimeout(() => setV(value), ms); return () => clearTimeout(id); }, [value, ms]);
  return v;
}
