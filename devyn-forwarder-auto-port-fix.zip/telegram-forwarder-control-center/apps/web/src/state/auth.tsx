import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, setCsrfToken, setUnauthorizedHandler } from "../api/client";
import type { SessionInfo, User } from "../api/types";
import { useToast } from "./toast";

interface AuthApi {
  user: User | null;
  checking: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
}
const Ctx = createContext<AuthApi | null>(null);
export const useAuth = () => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside AuthProvider");
  return v;
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [checking, setChecking] = useState(true);
  const toast = useToast();

  useEffect(() => {
    setUnauthorizedHandler(() => {
      setUser((u) => {
        if (u) toast.error("Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.");
        return null;
      });
      setCsrfToken("");
    });
    api.get<SessionInfo>("/api/auth/me")
      .then((s) => { setCsrfToken(s.csrf_token); setUser(s.user); })
      .catch(() => setUser(null))
      .finally(() => setChecking(false));
    return () => setUnauthorizedHandler(null);
  }, [toast]);

  const login = useCallback(async (username: string, password: string) => {
    const s = await api.post<SessionInfo>("/api/auth/login", { username, password });
    setCsrfToken(s.csrf_token);
    setUser(s.user);
  }, []);

  const logout = useCallback(async () => {
    try { await api.post("/api/auth/logout"); } finally { setCsrfToken(""); setUser(null); }
  }, []);

  const value = useMemo<AuthApi>(() => ({ user, checking, login, logout, isAdmin: user?.role === "admin" }), [user, checking, login, logout]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
