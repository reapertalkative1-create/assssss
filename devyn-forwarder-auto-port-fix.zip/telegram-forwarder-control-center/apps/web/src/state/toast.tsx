import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

interface Toast { id: number; kind: "ok" | "error"; text: string }
interface ToastApi { success: (text: string) => void; error: (text: string) => void }
const Ctx = createContext<ToastApi>({ success: () => {}, error: () => {} });
export const useToast = () => useContext(Ctx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const next = useRef(1);
  const timers = useRef<number[]>([]);
  const push = useCallback((kind: Toast["kind"], text: string) => {
    const id = next.current++;
    setItems((cur) => [...cur.slice(-3), { id, kind, text }]);
    timers.current.push(window.setTimeout(() => setItems((cur) => cur.filter((t) => t.id !== id)), kind === "error" ? 8000 : 4500));
  }, []);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const api = useMemo<ToastApi>(() => ({ success: (t) => push("ok", t), error: (t) => push("error", t) }), [push]);
  return (
    <Ctx.Provider value={api}>
      {children}
      <div className="toasts" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`toast ${t.kind === "error" ? "error" : ""}`} role={t.kind === "error" ? "alert" : "status"}>
            <span>{t.text}</span>
            <button className="btn ghost sm" aria-label="Đóng thông báo" onClick={() => setItems((c) => c.filter((x) => x.id !== t.id))}>✕</button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
