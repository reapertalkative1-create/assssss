export type Theme = "auto" | "light" | "dark";
const KEY = "tfcc.theme";

export function getTheme(): Theme {
  try {
    const v = localStorage.getItem(KEY);
    return v === "light" || v === "dark" ? v : "auto";
  } catch { return "auto"; }
}
export function applyTheme(theme: Theme): void {
  if (theme === "auto") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.setAttribute("data-theme", theme);
}
export function setTheme(theme: Theme): void {
  try { theme === "auto" ? localStorage.removeItem(KEY) : localStorage.setItem(KEY, theme); } catch { /* private mode: keep for this tab only */ }
  applyTheme(theme);
  window.dispatchEvent(new Event("devyn-theme-change"));
}
