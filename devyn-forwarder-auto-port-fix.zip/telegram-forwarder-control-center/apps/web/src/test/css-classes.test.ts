import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const root = join(__dirname, "..");
const walk = (dir: string): string[] => readdirSync(dir).flatMap((f) => {
  const p = join(dir, f);
  return statSync(p).isDirectory() ? walk(p) : p.endsWith(".tsx") && !p.includes(".test.") ? [p] : [];
});

describe("stylesheet", () => {
  it("defines every CSS class the components use (no typos, nothing silently unstyled)", () => {
    const css = readFileSync(join(root, "styles.css"), "utf8");
    const defined = new Set([...css.matchAll(/\.([a-zA-Z][\w-]*)/g)].map((m) => m[1]));
    const used = new Map<string, string>();
    for (const file of walk(root)) {
      const src = readFileSync(file, "utf8");
      const found = [...src.matchAll(/className="([^"]+)"/g)].map((m) => m[1])
        .concat([...src.matchAll(/className=\{`([^`]+)`\}/g)].map((m) => m[1].replace(/\$\{[^}]*\}/g, " ")));
      for (const group of found) for (const cls of group.split(/\s+/).filter(Boolean)) if (!used.has(cls)) used.set(cls, file.replace(root, ""));
    }
    const dynamic = new Set(["ok", "warn", "bad", "idle"]);   // tone names are composed at runtime and are defined with .pill/.stage/.alert
    const missing = [...used].filter(([c]) => !defined.has(c) && !dynamic.has(c));
    expect(missing).toEqual([]);
  });
});
