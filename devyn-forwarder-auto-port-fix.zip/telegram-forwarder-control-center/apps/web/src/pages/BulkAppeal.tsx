import {useState} from 'react';
import {api,ApiError} from '../api/client';
import {useQuery} from '../hooks/useQuery';
import {Modal} from '../components/Modal';
import {Alert,Check,TextArea,TextField} from '../components/ui';
import {Pagination} from '../components/DataTable';
import {errorLabel} from '../lib/labels';
import type {Account} from '../api/types';
import {SpamPanel} from './SpamPanel';
export type AppealSelection={all_matching:boolean;account_ids:string[];exclude_ids:string[];filters:Record<string,string|undefined>};
export const appealTemplate=`Hello {name}, I am using my Telegram account on the desktop application, but I was blocked from chatting in public groups and I believe this was a mistake. I never spam messages to the group. Please check my account.\n\nMy information:\nPhone Number: {phone}\nEmail Address: {email}\n\nThank you very much!`;
type Item={account_id:string;name:string;status:string;error_code:string|null;text:string|null};
type Draft={id:string;status:string;total:number;counts:Record<string,number>;review_token:string|null;items:Item[];items_total:number};
export function BulkAppeal({selection,jobId,onClose}:{selection?:AppealSelection;jobId?:string;onClose:()=>void}){
  const [id,setId]=useState(jobId),[template,setTemplate]=useState(appealTemplate),[email,setEmail]=useState(''),[profiles,setProfiles]=useState('');
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[facts,setFacts]=useState(false);
  const [page,setPage]=useState(1),[status,setStatus]=useState('');
  const [account,setAccount]=useState<Account>();
  const draft=useQuery(signal=>api.get<Draft>(`/api/account-appeals/${id}`,{page,status:status||undefined},signal),[id,page,status],{enabled:!!id,interval:3000});
  async function prepare(){
    setBusy(true);setError('');
    try{
      const mapping:Record<string,{email?:string;phone?:string}>={};
      for(const line of profiles.split(/\r?\n/).filter(x=>x.trim())){
        const parts=line.split(',').map(x=>x.trim());
        if(parts.length<2||parts.length>3||!parts[0])throw Error('Mỗi dòng cần: tên SS hoặc ID,email[,số điện thoại].');
        mapping[parts[0]]={...(parts[1]?{email:parts[1]}:{}),...(parts[2]?{phone:parts[2]}:{})};
      }
      const result=await api.post<{id:string}>('/api/account-appeals',{...selection,template,email:email.trim()||undefined,profiles:mapping});
      setId(result.id);setProfiles('');setEmail('');
    }catch(e){setError(e instanceof ApiError?e.message:e instanceof Error?e.message:'Không chuẩn bị được.');}
    finally{setBusy(false);}
  }
  async function send(){
    if(!draft.data?.review_token||!facts)return;setBusy(true);setError('');
    try{await api.post(`/api/account-appeals/${id}/confirm`,{review_token:draft.data.review_token,facts_confirmed:facts});setFacts(false);draft.reload();}
    catch(e){setError(e instanceof ApiError?e.message:'Không xếp hàng được.');}finally{setBusy(false);}
  }
  async function cancel(){setBusy(true);try{await api.post(`/api/account-bulk/${id}/cancel`);draft.reload();}catch(e){setError(e instanceof ApiError?e.message:'Không hủy được.');}finally{setBusy(false);}}
  async function openAccount(aid:string){try{setAccount(await api.get<Account>(`/api/accounts/${aid}`));}catch(e){setError(e instanceof ApiError?e.message:'Không mở được.');}}
  return <Modal title='Kháng nghị hàng loạt theo mẫu' onClose={onClose} dismissible={!busy} footer={<><button className='btn' disabled={busy} onClick={onClose}>Đóng</button>{!id&&<button className='btn primary' disabled={busy||!template.trim()} onClick={()=>void prepare()}>{busy?'Đang tạo…':'Chuẩn bị bản xem trước'}</button>}{id&&draft.data?.status==='preview'&&<button className='btn primary' disabled={busy||!facts||!draft.data.counts.prepared} onClick={()=>void send()}>Xác nhận gửi {draft.data.counts.prepared??0} kháng nghị</button>}</>}>
    {!id?<>
      <p>Mẫu gửi tới @SpamBot cho các tài khoản đã chọn. Bước chuẩn bị chỉ đọc thông tin và tạo bản xem trước, chưa gửi kháng nghị.</p>
      <TextArea label='Mẫu kháng nghị' value={template} onChange={e=>setTemplate(e.target.value)} rows={10} maxLength={3500} hint='Biến hỗ trợ: {name} = tên SS trong ứng dụng, {phone} = số đọc từ session, {email} = email bạn cung cấp.'/>
      <TextField label='Email liên hệ chung' type='email' value={email} onChange={e=>setEmail(e.target.value)} hint='Telegram không cung cấp đầy đủ email qua session. Nhập email thực tế, hoặc khai báo email riêng ở dưới. Có thể bỏ dòng Email khỏi mẫu nếu không sử dụng.'/>
      <TextArea label='Email / số điện thoại riêng từng SS (tùy chọn)' value={profiles} onChange={e=>setProfiles(e.target.value)} rows={4} hint='Mỗi dòng: tên hiển thị hoặc ID,email[,số điện thoại]. Giá trị riêng ưu tiên hơn email chung. Số điện thoại để trống sẽ đọc từ session.'/>
      <Alert>Chỉnh lại mẫu cho đúng sự việc của từng tài khoản, đặc biệt câu “I never spam messages”. Mỗi bản gửi được hiển thị để bạn kiểm tra trước khi xác nhận.</Alert>
    </>:<>
      <p role='status'>Tổng {draft.data?.total??0} · Sẵn sàng {draft.data?.counts.prepared??0} · Đã gửi {draft.data?.counts.done??0} · Lỗi {draft.data?.counts.error??0} · Đang xử lý {(draft.data?.counts.pending??0)+(draft.data?.counts.pending_send??0)+(draft.data?.counts.queued??0)}</p>
      {draft.data?.status==='preparing'&&<Alert>Đang đọc số từ session và kiểm tra bước hội thoại SpamBot. Chưa gửi mẫu.</Alert>}
      <select className='select' aria-label='Lọc bản kháng nghị' value={status} onChange={e=>{setStatus(e.target.value);setPage(1);}}><option value=''>Tất cả</option><option value='prepared'>Sẵn sàng xem trước</option><option value='error'>Chỉ lỗi</option><option value='done'>Đã gửi tin</option><option value='queued'>Đang xử lý</option></select>
      {draft.data?.items.map(item=><section className='card' key={item.account_id}><strong>{item.name}</strong><div className='hint'>{({prepared:'Sẵn sàng — chưa gửi',pending:'Đang chờ',queued:'Worker xử lý',pending_send:'Đã duyệt, chờ gửi',done:'Đã gửi tin tới SpamBot',error:'Chưa gửi/xác nhận được',cancelled:'Đã hủy'} as Record<string,string>)[item.status]??item.status}</div>
        {item.text&&<p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{item.text}</p>}
        {item.error_code&&<Alert tone='warn'>{errorLabel(item.error_code)}</Alert>}
        <button className='btn sm' onClick={()=>void openAccount(item.account_id)}>Mở hội thoại SpamBot</button>
      </section>)}
      {draft.data&&<Pagination page={page} pageSize={20} total={draft.data.items_total} onPage={setPage}/>}
      {draft.data?.status==='preview'&&<Check label='Tôi đã kiểm tra mẫu, thông tin và xác nhận nội dung đúng với tất cả tài khoản sẵn sàng gửi' checked={facts} onChange={e=>setFacts(e.target.checked)}/>}
      {draft.data&&['preparing','preview','running'].includes(draft.data.status)&&<button className='btn danger' disabled={busy} onClick={()=>void cancel()}>Hủy phần chưa gửi</button>}
      <p className='hint'>Tài khoản chưa ở bước SpamBot yêu cầu mô tả sẽ được báo lỗi. Mở hội thoại để hoàn tất đúng các bước rồi tạo bản xem trước mới. Lệnh gửi chỉ chạy một lần; kết quả xét duyệt do Telegram phản hồi. Đóng cửa sổ vẫn giữ tác vụ, có thể mở lại bằng nút Xem / duyệt kháng nghị ngay trên dòng session.</p>
    </>}
    {(error||draft.error)&&<Alert tone='bad'>{error||draft.error?.message}</Alert>}
    {account&&<SpamPanel a={account} onClose={()=>setAccount(undefined)}/>}
  </Modal>;
}
