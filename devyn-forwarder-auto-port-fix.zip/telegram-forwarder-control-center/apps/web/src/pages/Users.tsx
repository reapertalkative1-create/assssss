import { useState } from "react";
import { api, ApiError } from "../api/client";
import type { Page, Role, User } from "../api/types";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { Alert, Check, EmptyState, PageHead, Pill, SelectField, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtAgo, fmtDateTime } from "../lib/format";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";

const roleLabel: Record<Role, string> = { admin: "Quản trị viên", operator: "Vận hành viên" };
const isLocked = (u: User) => !!u.locked_until && new Date(u.locked_until) > new Date();

export function UsersPage() {
  const { user: me } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<{ kind: "create" } | { kind: "edit"; u: User } | null>(null);
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<User>>("/api/users", { q: search, page, page_size: 20 }, signal), [search, page], { interval: 15000 });
  const cols: Column<User>[] = [
    { key: "u", header: "Tên đăng nhập", cell: (u) => <><strong>{u.username}</strong>{u.id === me?.id && <span className="muted small"> (bạn)</span>}</> },
    { key: "r", header: "Vai trò", cell: (u) => roleLabel[u.role] },
    { key: "s", header: "Trạng thái", cell: (u) => !u.is_active ? <Pill tone="idle">Đã khóa</Pill> : isLocked(u) ? <Pill tone="warn">Tạm khóa do đăng nhập sai</Pill> : <Pill tone="ok">Hoạt động</Pill> },
    { key: "l", header: "Đăng nhập gần nhất", cell: (u) => <span title={fmtDateTime(u.last_login_at)}>{fmtAgo(u.last_login_at)}</span> },
    { key: "c", header: "Tạo lúc", cell: (u) => fmtDateTime(u.created_at) },
    { key: "a", header: "", align: "right", cell: (u) => <div className="actions"><button className="btn sm" onClick={() => setDialog({ kind: "edit", u })}>Sửa</button></div> },
  ];
  return (
    <div className="stack">
      <PageHead title="Người dùng" actions={<button className="btn primary" onClick={() => setDialog({ kind: "create" })}>Thêm người dùng</button>}>
        Quản trị viên làm được mọi việc. Vận hành viên xem được toàn bộ và bật/tắt tài khoản, tuyến, tác vụ nhưng không tạo hay xóa.
      </PageHead>
      <div className="toolbar"><input className="input" placeholder="Tìm theo tên…" aria-label="Tìm người dùng" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} /></div>
      <DataTable caption="Danh sách người dùng" columns={cols} rows={list.data?.items} rowKey={(u) => u.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title="Không có người dùng phù hợp">Thử đổi từ khóa tìm kiếm.</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={20} total={list.data.total} onPage={setPage} />}
      {dialog?.kind === "create" && <CreateUser onClose={() => setDialog(null)} onDone={() => { setDialog(null); toast.success("Đã tạo người dùng."); list.reload(); }} />}
      {dialog?.kind === "edit" && <EditUser u={dialog.u} self={dialog.u.id === me?.id} onClose={() => setDialog(null)} onDone={() => { setDialog(null); toast.success("Đã cập nhật người dùng."); list.reload(); }} />}
    </div>
  );
}

function pwProblem(pw: string, username: string): string | undefined {
  if (pw.length < 12) return "Mật khẩu cần ít nhất 12 ký tự.";
  if (username && pw.toLowerCase().includes(username.toLowerCase())) return "Mật khẩu không được chứa tên đăng nhập.";
  return undefined;
}

function CreateUser({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("operator");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  async function go() {
    const e: Record<string, string> = {};
    if (!/^[a-z0-9][a-z0-9_.-]{2,31}$/.test(username.trim().toLowerCase())) e.username = "3–32 ký tự: chữ thường, số, “_”, “.”, “-”.";
    const p = pwProblem(password, username.trim()); if (p) e.password = p;
    setErrors(e); if (Object.keys(e).length) return;
    setBusy(true); setError(undefined);
    try { await api.post("/api/users", { username: username.trim(), password, role }); onDone(); }
    catch (err) { setErrors(fieldErrors(err)); setError(err instanceof ApiError ? err.message : "Không tạo được người dùng."); setBusy(false); }
  }
  return (
    <Modal title="Thêm người dùng" onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy}>Tạo người dùng</button></>}>
      <TextField label="Tên đăng nhập" value={username} onChange={(e) => setUsername(e.target.value)} error={errors.username} autoComplete="off" autoCapitalize="none" spellCheck={false} />
      <TextField label="Mật khẩu ban đầu" type="password" value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password} autoComplete="new-password" hint="Ít nhất 12 ký tự. Hãy đưa mật khẩu cho người đó qua kênh an toàn." />
      <SelectField label="Vai trò" value={role} onChange={(e) => setRole(e.target.value as Role)}>
        <option value="operator">Vận hành viên</option><option value="admin">Quản trị viên</option>
      </SelectField>
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}

function EditUser({ u, self, onClose, onDone }: { u: User; self: boolean; onClose: () => void; onDone: () => void }) {
  const [role, setRole] = useState<Role>(u.role);
  const [active, setActive] = useState(u.is_active);
  const [password, setPassword] = useState("");
  const [unlock, setUnlock] = useState(false);
  const [error, setError] = useState<string>();
  const [pwErr, setPwErr] = useState<string>();
  const [busy, setBusy] = useState(false);
  async function go() {
    const body: Record<string, unknown> = {};
    if (role !== u.role) body.role = role;
    if (active !== u.is_active) body.is_active = active;
    if (password) { const p = pwProblem(password, u.username); if (p) { setPwErr(p); return; } body.password = password; }
    if (unlock) body.unlock = true;
    if (!Object.keys(body).length) { onClose(); return; }
    setBusy(true); setError(undefined); setPwErr(undefined);
    try { await api.patch(`/api/users/${u.id}`, body); onDone(); }
    catch (e) { setPwErr(fieldErrors(e).password); setError(e instanceof ApiError ? e.message : "Không lưu được."); setBusy(false); }
  }
  return (
    <Modal title={`Sửa người dùng ${u.username}`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy}>Lưu thay đổi</button></>}>
      {self && <Alert>Bạn không thể tự đổi vai trò, tự khóa hay đặt lại mật khẩu của chính mình ở đây. Dùng Cài đặt để đổi mật khẩu.</Alert>}
      <SelectField label="Vai trò" value={role} onChange={(e) => setRole(e.target.value as Role)} disabled={self}>
        <option value="operator">Vận hành viên</option><option value="admin">Quản trị viên</option>
      </SelectField>
      <Check checked={active} onChange={(e) => setActive(e.target.checked)} disabled={self} label="Cho phép đăng nhập" hint="Bỏ chọn sẽ đăng xuất người này khỏi mọi thiết bị ngay lập tức." />
      <TextField label="Đặt lại mật khẩu (tùy chọn)" type="password" value={password} onChange={(e) => setPassword(e.target.value)} disabled={self} autoComplete="new-password" error={pwErr}
        hint="Để trống nếu không đổi. Đặt lại sẽ đăng xuất mọi phiên của người này." />
      {isLocked(u) && <Check checked={unlock} onChange={(e) => setUnlock(e.target.checked)} label="Mở khóa tạm thời do đăng nhập sai" />}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
