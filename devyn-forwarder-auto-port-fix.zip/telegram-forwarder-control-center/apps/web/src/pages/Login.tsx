import { useState, type FormEvent } from "react";
import { ApiError } from "../api/client";
import { Alert, TextField } from "../components/ui";
import { Brand } from "../components/Brand";
import { Icon } from "../components/icons";
import { useAuth } from "../state/auth";

export function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [showPassword,setShowPassword]=useState(false);
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ username?: string; password?: string }>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const next = {
      username: username.trim() ? undefined : "Nhập tên đăng nhập.",
      password: password ? undefined : "Nhập mật khẩu.",
    };
    setErrors(next);
    if (next.username || next.password) return;
    setBusy(true);
    setError(undefined);
    try {
      await login(username.trim(), password);
    } catch (err) {
      setPassword("");
      setError(err instanceof ApiError ? (err.status === 429 ? "Quá nhiều lần thử. Hãy chờ vài phút rồi thử lại." : err.message) : "Đăng nhập thất bại.");
      setBusy(false);
    }
  }

  return (
    <div className="login">
      <section className="login-story">
        <Brand/>
        <div className="login-story-content"><span className="eyebrow">TELEGRAM OPERATIONS, SIMPLIFIED</span><h2>Mọi kết nối.<br/>Trong tầm kiểm soát.</h2><p>Một không gian để quản lý session, điều phối chuyển tiếp và theo dõi toàn bộ hoạt động Telegram của bạn.</p>
          <div className="login-flow" aria-hidden="true"><span><Icon name="accounts" size={26}/></span><i/><span><Icon name="logo" size={32}/></span><i/><span><Icon name="routes" size={26}/></span></div>
          <div className="login-benefits"><div><Icon name="accounts"/><span>Session tập trung<small>Nhập, kiểm tra và quản lý hàng loạt.</small></span></div><div><Icon name="routes"/><span>Điều phối liền mạch<small>Tuyến chuyển tiếp và hàng đợi trong cùng một nơi.</small></span></div><div><Icon name="shield"/><span>Thông tin được bảo vệ<small>Session và dữ liệu nhạy cảm được lưu mã hóa.</small></span></div></div>
        </div><span className="login-story-foot">DEVYN FORWARDER · YOUR TELEGRAM WORKSPACE</span>
      </section>
      <div className="login-form-area"><div className="login-mobile-brand"><Brand/></div><form className="panel login-card" onSubmit={(e) => void submit(e)} noValidate>
        <div className="login-form-heading"><span className="eyebrow">CHÀO MỪNG TRỞ LẠI</span><h1>Đăng nhập</h1><p>Tiếp tục điều hành không gian làm việc của bạn.</p></div>
        <div className="panel-body">
          {error && <Alert tone="bad">{error}</Alert>}
          <TextField label="Tên đăng nhập" value={username} onChange={(e) => setUsername(e.target.value)} error={errors.username}
            autoComplete="username" autoCapitalize="none" spellCheck={false} autoFocus />
          <div className="password-wrap"><TextField label="Mật khẩu" type={showPassword?'text':'password'} value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password}
            autoComplete="current-password" /><button className="btn ghost icon-button" type="button" aria-label={showPassword?'Ẩn mật khẩu':'Hiện mật khẩu'} onClick={()=>setShowPassword(v=>!v)}><Icon name="eye"/></button></div>
          <button className="btn primary login-submit" type="submit" disabled={busy}>{busy ? "Đang đăng nhập…" : "Đăng nhập"}<Icon name="arrow" size={18}/></button>
          <p className="hint">Quên mật khẩu? Nhờ quản trị viên đặt lại trong mục Người dùng.</p>
        </div>
      </form><p className="login-caption">DEVYN FORWARDER <span>Quản lý tập trung. Vận hành chủ động.</span></p></div>
    </div>
  );
}
