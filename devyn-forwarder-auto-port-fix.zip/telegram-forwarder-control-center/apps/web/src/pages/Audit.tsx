import { useState } from "react";
import { api } from "../api/client";
import type { AuditEntry, Page } from "../api/types";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { EmptyState, PageHead } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtDateTime } from "../lib/format";
import { actionLabel } from "../lib/labels";

const groups: [string, string][] = [["", "Mọi hành động"], ["auth.", "Đăng nhập & phiên"], ["user.", "Người dùng"], ["worker.", "Worker"], ["account.", "Tài khoản Telegram"], ["route.", "Tuyến"], ["job.", "Tác vụ"], ["keys.", "Khóa mã hóa"]];

export function AuditPage() {
  const [group, setGroup] = useState("");
  const [actor, setActor] = useState("");
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState<AuditEntry | null>(null);
  const actorQ = useDebounced(actor.trim().toLowerCase());
  const list = useQuery((signal) => api.get<Page<AuditEntry>>("/api/audit", { action: group, actor: actorQ, page, page_size: 50 }, signal), [group, actorQ, page]);
  const cols: Column<AuditEntry>[] = [
    { key: "t", header: "Thời gian", cell: (a) => <span className="nowrap">{fmtDateTime(a.occurred_at)}</span> },
    { key: "who", header: "Người thực hiện", cell: (a) => a.actor_username ?? <span className="muted">—</span> },
    { key: "a", header: "Hành động", cell: (a) => <>{actionLabel(a.action)}<div className="muted small mono">{a.action}</div></> },
    { key: "target", header: "Đối tượng", cell: (a) => a.target_type ? <span className="small">{a.target_type}<div className="mono muted">{a.target_id?.slice(0, 8)}</div></span> : "—" },
    { key: "ip", header: "IP", cell: (a) => <span className="mono">{a.ip ?? "—"}</span> },
    { key: "d", header: "", align: "right", cell: (a) => <button className="btn sm" onClick={() => setDetail(a)}>Chi tiết</button> },
  ];
  return (
    <div className="stack">
      <PageHead title="Nhật ký kiểm toán">Mọi hành động nhạy cảm đều được ghi lại và không thể sửa hay xóa. Mật khẩu, mã xác nhận, phiên Telegram và credential không bao giờ được ghi.</PageHead>
      <div className="toolbar">
        <select className="select" aria-label="Lọc nhóm hành động" value={group} onChange={(e) => { setGroup(e.target.value); setPage(1); }}>{groups.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
        <input className="input" placeholder="Người thực hiện…" aria-label="Lọc theo người thực hiện" value={actor} onChange={(e) => { setActor(e.target.value); setPage(1); }} />
      </div>
      <DataTable caption="Nhật ký kiểm toán" columns={cols} rows={list.data?.items} rowKey={(a) => String(a.id)} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title="Không có bản ghi phù hợp">Thử đổi bộ lọc.</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={50} total={list.data.total} onPage={setPage} />}
      {detail && (
        <Modal title={actionLabel(detail.action)} onClose={() => setDetail(null)} footer={<button className="btn primary" onClick={() => setDetail(null)}>Đóng</button>}>
          <dl className="kv">
            <dt>Thời gian</dt><dd>{fmtDateTime(detail.occurred_at)}</dd><dt>Người thực hiện</dt><dd>{detail.actor_username ?? "—"}</dd>
            <dt>Mã hành động</dt><dd className="mono">{detail.action}</dd><dt>Đối tượng</dt><dd className="mono">{detail.target_type ?? "—"} {detail.target_id ?? ""}</dd>
            <dt>Địa chỉ IP</dt><dd className="mono">{detail.ip ?? "—"}</dd><dt>Mã yêu cầu</dt><dd className="mono">{detail.request_id ?? "—"}</dd>
          </dl>
          <pre className="json">{JSON.stringify(detail.details ?? {}, null, 2)}</pre>
        </Modal>)}
    </div>
  );
}
