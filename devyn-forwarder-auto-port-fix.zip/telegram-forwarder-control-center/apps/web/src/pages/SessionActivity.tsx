import {useState} from 'react';
import type {Account} from '../api/types';
import {api,ApiError} from '../api/client';
import {Pill} from '../components/ui';
import {fmtAgo} from '../lib/format';
import {errorLabel} from '../lib/labels';
import {useToast} from '../state/toast';
import {bulkActions} from './AccountBulk';

const statuses:Record<string,string>={pending:'Đang chờ',queued:'Worker đang xử lý',delivered:'Worker đã nhận',draining:'Đang dừng phiên để xóa',prepared:'Chờ duyệt kháng nghị',pending_send:'Đã duyệt, chờ gửi',done:'Hoàn tất',error:'Thất bại',failed:'Thất bại',expired:'Hết hạn',cancelled:'Đã hủy'};
const commands:Record<string,string>={check_connection:'Kiểm tra session',import_session:'Nhập / kiểm tra session',spam_check:'Check spam / đóng băng',spam_read:'Đọc phản hồi SpamBot',spam_reply:'Tương tác SpamBot',appeal_prepare:'Chuẩn bị kháng nghị',send_code:'Gửi mã đăng nhập',sign_in_code:'Xác nhận mã đăng nhập',sign_in_password:'Xác nhận 2FA',verify_chats:'Kiểm tra quyền nhóm',logout:'Đăng xuất session'};
export function SessionActivity({a,isAdmin,onReload,onAppeal}:{a:Account;isAdmin:boolean;onReload:()=>void;onAppeal:(id:string)=>void}){
  const [busy,setBusy]=useState<string>();const toast=useToast();
  async function cancel(id:string){
    setBusy(id);
    try{await api.post(`/api/account-bulk/${id}/cancel`);toast.success('Đã dừng xếp hàng cho cả đợt. Lệnh worker đã nhận có thể vẫn hoàn tất.');onReload();}
    catch(e){toast.error(e instanceof ApiError?e.message:'Không dừng được.');}finally{setBusy(undefined);}
  }
  return <div className="ss-activity stack tight">
    {a.pending_deletion&&<Pill tone="warn">Đang chờ dừng phiên và xóa</Pill>}
    {!a.row_operations?.length&&<span className="hint">Chưa có thao tác kiểm tra.</span>}
    {a.row_operations?.map(op=>{
      const failed=['error','failed','expired'].includes(op.status);
      const active=['pending','queued','delivered','draining','prepared','pending_send'].includes(op.status);
      const appeal=op.kind==='bulk'&&op.action==='bulk_appeal';
      return <section className="ss-operation" key={`${op.kind}-${op.id}`}>
        <strong>{(op.kind==='bulk'?bulkActions[op.action]:commands[op.action])??op.action}</strong>
        <div><Pill tone={failed?'bad':op.status==='done'?'ok':active?'warn':'idle'}>{statuses[op.status]??op.status}</Pill></div>
        {op.error_code&&<p className="ss-operation-error">{errorLabel(op.error_code)}</p>}
        {op.action==='spam_check'&&op.status==='done'&&<p className="hint">Đã check — xem kết quả spam và session trên dòng này.</p>}
        <div className="hint" title={new Date(op.updated_at).toLocaleString()}>{fmtAgo(op.updated_at)}</div>
        {isAdmin&&appeal&&<button className="btn sm" onClick={()=>onAppeal(op.id)}>Xem / duyệt kháng nghị</button>}
        {isAdmin&&op.kind==='bulk'&&active&&['running','preparing','preview'].includes(op.job_status??'')&&<div><button className="btn sm danger" disabled={!!busy} onClick={()=>void cancel(op.id)}>Dừng cả đợt</button><p className="hint">Áp dụng cho mọi SS cùng đợt này.</p></div>}
      </section>;
    })}
    <div className="hint">Hoạt động gần nhất: {fmtAgo(a.last_active_at)}</div>
  </div>;
}
