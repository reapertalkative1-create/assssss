import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api, ApiError } from "../api/client";
import type { Job, JobStatus, Page, QueueMetrics, Route } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { EmptyState, PageHead, Pill } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { fmtAgo, fmtDateTime, fmtDuration, fmtNumber } from "../lib/format";
import { errorLabel, jobStatus } from "../lib/labels";
import { useToast } from "../state/toast";

type Bulk = { action: "retry" | "cancel"; status: "dead_letter" | "failed"; count: number };

export function JobsPage() {
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const status = params.get("status") ?? "";
  const routeId = params.get("route") ?? "";
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState<string>();
  const [bulk, setBulk] = useState<Bulk | null>(null);
  const setFilter = (key: string, value: string) => { const n = new URLSearchParams(params); value ? n.set(key, value) : n.delete(key); setParams(n); setPage(1); };

  const metrics = useQuery((signal) => api.get<QueueMetrics>("/api/queue/metrics", undefined, signal), [], { interval: 5000 });
  const routes = useQuery((signal) => api.get<Page<Route>>("/api/routes", { page_size: 100 }, signal), []);
  const jobs = useQuery((signal) => api.get<Page<Job>>("/api/jobs", { status, route_id: routeId, page, page_size: 25 }, signal), [status, routeId, page], { interval: 5000 });
  const routeName = new Map(routes.data?.items.map((r) => [r.id, r.name]));
  const m = metrics.data;

  async function one(j: Job, action: "retry" | "cancel") {
    setBusy(j.id);
    try { await api.post(`/api/jobs/${j.id}/${action}`); toast.success(action === "retry" ? "Đã đưa tác vụ về hàng đợi." : "Đã hủy tác vụ."); jobs.reload(); metrics.reload(); }
    catch (e) { toast.error(e instanceof ApiError ? e.message : "Thao tác thất bại."); }
    finally { setBusy(undefined); }
  }
  const cols: Column<Job>[] = [
    { key: "created", header: "Tạo lúc", cell: (j) => <span title={fmtDateTime(j.created_at)}>{fmtAgo(j.created_at)}</span> },
    { key: "route", header: "Tuyến", cell: (j) => routeName.get(j.route_id) ?? <span className="muted">đã xóa</span> },
    { key: "chat", header: "Nguồn → đích", cell: (j) => <span className="mono small">{j.source_chat_id} #{j.message_id} → {j.dest_chat_id}</span> },
    { key: "status", header: "Trạng thái", cell: (j) => <Pill tone={jobStatus[j.status].tone}>{jobStatus[j.status].label}</Pill> },
    { key: "attempts", header: "Lần thử", cell: (j) => `${j.attempts}/${j.max_attempts}`, align: "right" },
    { key: "error", header: "Lý do / kế tiếp", cell: (j) => j.last_error_code ? <>{errorLabel(j.last_error_code)}{(j.status === "retry_wait") && <div className="muted small">Thử lại {fmtAgo(j.available_at) === "vừa xong" ? "ngay" : `lúc ${fmtDateTime(j.available_at)}`}</div>}</> : <span className="muted">—</span> },
    { key: "actions", header: "", align: "right", cell: (j) => (
      <div className="actions">
        {(j.status === "failed" || j.status === "dead_letter") && <button className="btn sm primary" disabled={busy === j.id} onClick={() => void one(j, "retry")}>Thử lại</button>}
        {["pending", "retry_wait", "failed", "dead_letter"].includes(j.status) && <button className="btn sm" disabled={busy === j.id} onClick={() => void one(j, "cancel")}>Hủy</button>}
      </div>) },
  ];
  const tile = (label: string, value: number, key?: JobStatus | "attention", tone?: "bad" | "warn") => (
    <button key={label} className="btn" style={{ flexDirection: "column", alignItems: "flex-start", minWidth: 128, padding: "8px 14px", height: "auto", borderColor: status === key ? "var(--accent)" : undefined }}
      onClick={() => key && key !== "attention" && setFilter("status", status === key ? "" : key)} aria-pressed={status === key}>
      <span className="muted small">{label}</span>
      <strong style={{ fontSize: 20, color: tone && value ? `var(--${tone})` : undefined }}>{fmtNumber(value)}</strong>
    </button>);
  return (
    <div className="stack">
      <PageHead title="Hàng đợi tác vụ">Mỗi tin nhắn gửi tới mỗi đích là một tác vụ. Lỗi tạm thời được thử lại có giới hạn; hết số lần thử, tác vụ chờ bạn xử lý ở đây.</PageHead>
      <div className="row" aria-label="Thống kê hàng đợi">
        {m ? <>
          {tile("Chờ xử lý", (m.by_status.pending ?? 0) + (m.by_status.claimed ?? 0), "pending")}
          {tile("Đang chạy", m.by_status.running ?? 0, "running")}
          {tile("Chờ thử lại", m.by_status.retry_wait ?? 0, "retry_wait", "warn")}
          {tile("Thất bại", m.by_status.failed ?? 0, "failed", "bad")}
          {tile("Hàng chờ lỗi", m.by_status.dead_letter ?? 0, "dead_letter", "bad")}
          {tile("Thành công (5 phút)", m.succeeded_last_5m)}
        </> : <span className="muted">Đang tải thống kê…</span>}
        {m?.oldest_pending_age_seconds != null && <span className="muted small">Tác vụ chờ lâu nhất: {fmtDuration(m.oldest_pending_age_seconds)}</span>}
      </div>
      <div className="toolbar">
        <select className="select" aria-label="Lọc trạng thái" value={status} onChange={(e) => setFilter("status", e.target.value)}>
          <option value="">Mọi trạng thái</option>
          {(Object.keys(jobStatus) as JobStatus[]).map((s) => <option key={s} value={s}>{jobStatus[s].label}</option>)}
        </select>
        <select className="select" aria-label="Lọc theo tuyến" value={routeId} onChange={(e) => setFilter("route", e.target.value)}>
          <option value="">Mọi tuyến</option>
          {routes.data?.items.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
        </select>
        {m && (m.by_status.dead_letter ?? 0) > 0 && <button className="btn" onClick={() => setBulk({ action: "retry", status: "dead_letter", count: m.by_status.dead_letter })}>Thử lại hàng chờ lỗi ({m.by_status.dead_letter})</button>}
        {m && (m.by_status.failed ?? 0) > 0 && <button className="btn" onClick={() => setBulk({ action: "cancel", status: "failed", count: m.by_status.failed })}>Hủy tác vụ thất bại ({m.by_status.failed})</button>}
      </div>
      <DataTable caption="Danh sách tác vụ chuyển tiếp" columns={cols} rows={jobs.data?.items} rowKey={(j) => j.id} loading={jobs.loading} error={jobs.error} onRetry={jobs.reload}
        empty={<EmptyState title={status || routeId ? "Không có tác vụ phù hợp" : "Hàng đợi đang trống"}>{status || routeId ? "Thử bỏ bớt bộ lọc." : "Tác vụ xuất hiện khi có tin nhắn mới ở chat nguồn của một tuyến đang chạy."}</EmptyState>} />
      {jobs.data && <Pagination page={page} pageSize={25} total={jobs.data.total} onPage={setPage} />}
      {bulk && (
        <ConfirmDialog title={bulk.action === "retry" ? "Thử lại hàng chờ lỗi?" : "Hủy các tác vụ thất bại?"} confirmLabel={bulk.action === "retry" ? "Thử lại" : "Hủy tác vụ"} danger={bulk.action === "cancel"} onClose={() => setBulk(null)}
          onConfirm={async () => { const r = await api.post<{ affected: number }>("/api/jobs/bulk", { action: bulk.action, status: bulk.status, route_id: routeId || undefined, limit: 1000 }); toast.success(`Đã xử lý ${r.affected} tác vụ.`); jobs.reload(); metrics.reload(); }}>
          <p>{bulk.action === "retry" ? `Tối đa 1000 tác vụ ${routeId ? "của tuyến đang chọn " : ""}sẽ về hàng đợi và được gửi lại.` : "Các tác vụ này sẽ không bao giờ được gửi nữa."}</p>
          {bulk.action === "retry" && <p className="muted">Nếu nguyên nhân lỗi chưa hết (ví dụ chưa có quyền gửi vào chat đích), chúng sẽ lại thất bại.</p>}
        </ConfirmDialog>)}
    </div>
  );
}
