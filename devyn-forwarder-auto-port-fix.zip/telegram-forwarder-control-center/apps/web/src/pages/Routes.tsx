import { useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiError } from "../api/client";
import type { Account, CommandAccepted, ContentType, Page, Route, RouteInput } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { Alert, Check, EmptyState, PageHead, Pill, SelectField, TextArea, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtDateTime, parseChatIds, splitLines } from "../lib/format";
import { authState, contentTypes, errorLabel, routeStatus } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";
import { waitForCommand } from "./Accounts";

type Dialog = { kind: "form"; route?: Route } | { kind: "detail"; route: Route } | { kind: "delete"; route: Route };
const ALL_TYPES = Object.keys(contentTypes) as ContentType[];

export function RoutesPage() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busy, setBusy] = useState<string>();
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<Route>>("/api/routes", { q: search, status, page, page_size: 20 }, signal), [search, status, page], { interval: 5000 });

  async function act(r: Route, action: "start" | "pause" | "resume" | "stop", done: string) {
    setBusy(r.id);
    try { await api.post(`/api/routes/${r.id}/${action}`); toast.success(done); list.reload(); }
    catch (e) { toast.error(e instanceof ApiError ? e.message : "Thao tác thất bại."); }
    finally { setBusy(undefined); }
  }
  async function verify(r: Route) {
    setBusy(r.id);
    try {
      const acc = await api.post<CommandAccepted>(`/api/routes/${r.id}/verify`);
      const cmd = await waitForCommand(r.account_id, acc.command_id, undefined, 3);
      if (cmd.status === "done") toast.success("Đã kiểm tra quyền truy cập. Xem kết quả trong Chi tiết.");
      else toast.error(cmd.status === "expired" ? "Worker không phản hồi kịp." : errorLabel(cmd.error_code, cmd.retry_after) || "Xác minh thất bại.");
      list.reload();
    } catch (e) { toast.error(e instanceof ApiError ? e.message : "Xác minh thất bại."); }
    finally { setBusy(undefined); }
  }

  const cols: Column<Route>[] = [
    { key: "name", header: "Tuyến", cell: (r) => <><strong>{r.name}</strong><div className="muted small">{r.account_name ?? "—"} · {r.mode === "copy" ? "Sao chép nội dung" : "Chuyển tiếp gốc"}</div></> },
    { key: "status", header: "Trạng thái", cell: (r) => <div className="stack tight"><Pill tone={routeStatus[r.status].tone}>{routeStatus[r.status].label}</Pill>
      <Pill tone={r.verified ? "ok" : "warn"}>{r.verified ? "Đã xác minh" : "Chưa xác minh"}</Pill></div> },
    { key: "chats", header: "Nguồn → đích", cell: (r) => `${r.source_chat_ids.length} nguồn → ${r.destination_chat_ids.length} đích` },
    { key: "stats", header: "Tác vụ", cell: (r) => {
      const s = r.stats, wait = (s.pending ?? 0) + (s.retry_wait ?? 0) + (s.claimed ?? 0) + (s.running ?? 0), bad = (s.failed ?? 0) + (s.dead_letter ?? 0);
      return <span className="small">{s.succeeded ?? 0} xong · {wait} chờ · <span style={bad ? { color: "var(--bad)", fontWeight: 600 } : undefined}>{bad} lỗi</span></span>;
    } },
    { key: "actions", header: "", align: "right", cell: (r) => (
      <div className="actions">
        {r.status === "stopped" && <button className="btn sm primary" disabled={busy === r.id || !r.verified} title={r.verified ? "" : "Cần xác minh quyền truy cập trước"} onClick={() => void act(r, "start", "Đã bật tuyến.")}>Bật</button>}
        {r.status === "active" && <button className="btn sm" disabled={busy === r.id} onClick={() => void act(r, "pause", "Đã tạm dừng tuyến.")}>Tạm dừng</button>}
        {r.status === "paused" && <button className="btn sm primary" disabled={busy === r.id} onClick={() => void act(r, "resume", "Đã tiếp tục tuyến.")}>Tiếp tục</button>}
        {r.status !== "stopped" && <button className="btn sm" disabled={busy === r.id} onClick={() => void act(r, "stop", "Đã dừng tuyến.")}>Dừng</button>}
        <button className="btn sm" disabled={busy === r.id} onClick={() => void verify(r)}>Xác minh</button>
        <button className="btn sm" onClick={() => setDialog({ kind: "detail", route: r })}>Chi tiết</button>
        {isAdmin && <button className="btn sm" onClick={() => setDialog({ kind: "form", route: r })}>Sửa</button>}
        {isAdmin && <button className="btn sm danger" onClick={() => setDialog({ kind: "delete", route: r })}>Xóa</button>}
      </div>) },
  ];
  const saved = (msg: string) => { setDialog(null); toast.success(msg); list.reload(); };
  return (
    <div className="stack">
      <PageHead title="Tuyến chuyển tiếp" actions={isAdmin && <button className="btn primary" onClick={() => setDialog({ kind: "form" })}>Tạo tuyến</button>}>
        Một tuyến lấy tin từ các chat nguồn của một tài khoản và gửi sang các chat đích. Chỉ chạy được sau khi xác minh tài khoản đọc được mọi nguồn và gửi được mọi đích.
      </PageHead>
      <div className="toolbar">
        <input className="input" placeholder="Tìm theo tên…" aria-label="Tìm tuyến" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className="select" aria-label="Lọc trạng thái" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">Mọi trạng thái</option>
          {Object.entries(routeStatus).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </div>
      <DataTable caption="Danh sách tuyến chuyển tiếp" columns={cols} rows={list.data?.items} rowKey={(r) => r.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title={search || status ? "Không có tuyến phù hợp" : "Chưa có tuyến nào"}
          action={isAdmin && !search && !status ? <button className="btn primary" onClick={() => setDialog({ kind: "form" })}>Tạo tuyến đầu tiên</button> : undefined}>
          {search || status ? "Thử bỏ bớt bộ lọc." : "Cần có một tài khoản Telegram đã xác thực và đang bật."}</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={20} total={list.data.total} onPage={setPage} />}

      {dialog?.kind === "form" && <RouteForm route={dialog.route} onClose={() => setDialog(null)} onSaved={() => saved(dialog.route ? "Đã lưu tuyến." : "Đã tạo tuyến. Hãy xác minh rồi bật tuyến.")} />}
      {dialog?.kind === "detail" && <RouteDetail route={dialog.route} onClose={() => setDialog(null)} />}
      {dialog?.kind === "delete" && (
        <ConfirmDialog title={`Xóa tuyến ${dialog.route.name}?`} confirmLabel="Xóa tuyến" danger requireText={dialog.route.name} onClose={() => setDialog(null)}
          onConfirm={async () => { await api.post(`/api/routes/${dialog.route.id}/delete`, { confirm_name: dialog.route.name }); toast.success("Đã xóa tuyến."); list.reload(); }}>
          <p>Toàn bộ tác vụ của tuyến này (kể cả tác vụ đã xong) và điểm đánh dấu tiến độ sẽ bị xóa. Tuyến phải đang ở trạng thái <strong>Đã dừng</strong>.</p>
        </ConfirmDialog>)}
    </div>
  );
}

function RouteDetail({ route: r, onClose }: { route: Route; onClose: () => void }) {
  const chats = [...r.source_chat_ids.map((id) => ({ id, role: "Nguồn" })), ...r.destination_chat_ids.map((id) => ({ id, role: "Đích" }))];
  const f = r.filters;
  return (
    <Modal wide title={`Chi tiết tuyến ${r.name}`} onClose={onClose} footer={<><Link className="btn" to={`/jobs?route=${r.id}`}>Xem tác vụ của tuyến</Link><button className="btn primary" onClick={onClose}>Đóng</button></>}>
      <dl className="kv">
        <dt>Tài khoản</dt><dd>{r.account_name ?? "—"}</dd>
        <dt>Chế độ</dt><dd>{r.mode === "copy" ? "Sao chép nội dung (không kèm “chuyển tiếp từ”)" : "Chuyển tiếp gốc"}</dd>
        <dt>Ưu tiên / tốc độ</dt><dd>Mức {r.priority} (1 là khẩn nhất) · tối đa {r.rate_per_minute} tin/phút · thử lại tối đa {r.max_attempts} lần</dd>
        <dt>Bộ lọc</dt><dd>
          {f.content_types.length ? `Loại: ${f.content_types.map((t) => contentTypes[t]).join(", ")}. ` : "Mọi loại nội dung. "}
          {f.keywords_include.length ? `Phải chứa một trong: ${f.keywords_include.join(", ")}. ` : ""}
          {f.keywords_exclude.length ? `Loại trừ: ${f.keywords_exclude.join(", ")}. ` : ""}
          {f.include_outgoing ? "Gồm cả tin do chính tài khoản gửi." : "Bỏ qua tin do chính tài khoản gửi."}</dd>
        <dt>Xác minh</dt><dd>{r.verified_at ? `${r.verified ? "Đạt" : "Chưa đạt"} lúc ${fmtDateTime(r.verified_at)}` : "Chưa xác minh"}</dd>
      </dl>
      <table className="table">
        <thead><tr><th scope="col">Chat</th><th scope="col">Vai trò</th><th scope="col">Tên</th><th scope="col">Quyền</th><th scope="col">Đã xử lý đến tin</th></tr></thead>
        <tbody>{chats.map((c) => {
          const v = r.verification?.[String(c.id)];
          const ok = !v ? null : c.role === "Nguồn" ? v.ok : v.ok && v.can_send;
          return (
            <tr key={`${c.role}${c.id}`}>
              <td className="mono">{c.id}</td><td>{c.role}</td><td>{v?.title ?? "—"}</td>
              <td>{ok === null ? <Pill tone="idle">Chưa kiểm tra</Pill> : ok ? <Pill tone="ok">{c.role === "Nguồn" ? "Đọc được" : "Gửi được"}</Pill> : <Pill tone="bad">{v?.ok ? "Không được gửi" : "Không truy cập được"}</Pill>}</td>
              <td className="mono">{c.role === "Nguồn" ? (r.checkpoints[String(c.id)] ?? "—") : ""}</td>
            </tr>);
        })}</tbody>
      </table>
    </Modal>
  );
}

export function RouteForm({ route, onClose, onSaved }: { route?: Route; onClose: () => void; onSaved: () => void }) {
  const editing = !!route;
  const accounts = useQuery((signal) => api.get<Page<Account>>("/api/accounts", { page_size: 100 }, signal), [], { enabled: !editing });
  const [name, setName] = useState(route?.name ?? "");
  const [accountId, setAccountId] = useState(route?.account_id ?? "");
  const [sources, setSources] = useState((route?.source_chat_ids ?? []).join("\n"));
  const [dests, setDests] = useState((route?.destination_chat_ids ?? []).join("\n"));
  const [mode, setMode] = useState<"forward" | "copy">(route?.mode ?? "forward");
  const [types, setTypes] = useState<ContentType[]>(route?.filters.content_types ?? []);
  const [include, setInclude] = useState((route?.filters.keywords_include ?? []).join("\n"));
  const [exclude, setExclude] = useState((route?.filters.keywords_exclude ?? []).join("\n"));
  const [outgoing, setOutgoing] = useState(route?.filters.include_outgoing ?? false);
  const [priority, setPriority] = useState(String(route?.priority ?? 5));
  const [rate, setRate] = useState(String(route?.rate_per_minute ?? 20));
  const [attempts, setAttempts] = useState(String(route?.max_attempts ?? 5));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const chatsLocked = editing && route.status !== "stopped";

  function validate(): RouteInput | null {
    const e: Record<string, string> = {};
    const src = parseChatIds(sources), dst = parseChatIds(dests);
    if (!name.trim()) e.name = "Nhập tên tuyến.";
    if (!editing && !accountId) e.account_id = "Chọn tài khoản.";
    for (const [key, p, label] of [["source_chat_ids", src, "nguồn"], ["destination_chat_ids", dst, "đích"]] as const) {
      if (p.invalid.length) e[key] = `Chat id không hợp lệ: ${p.invalid.slice(0, 3).join(", ")}. Dùng số nguyên như -1001234567890.`;
      else if (p.duplicates.length) e[key] = `Bị trùng: ${p.duplicates.slice(0, 3).join(", ")}.`;
      else if (p.ids.length === 0) e[key] = `Cần ít nhất một chat ${label}.`;
      else if (p.ids.length > 50) e[key] = "Tối đa 50 chat.";
    }
    if (!e.source_chat_ids && !e.destination_chat_ids && src.ids.some((i) => dst.ids.includes(i))) e.destination_chat_ids = "Một chat không thể vừa là nguồn vừa là đích.";
    const num = (v: string, lo: number, hi: number) => /^\d+$/.test(v) && Number(v) >= lo && Number(v) <= hi;
    if (!num(priority, 1, 9)) e.priority = "Từ 1 đến 9.";
    if (!num(rate, 1, 600)) e.rate_per_minute = "Từ 1 đến 600.";
    if (!num(attempts, 1, 10)) e.max_attempts = "Từ 1 đến 10.";
    const kwInc = splitLines(include), kwExc = splitLines(exclude);
    if ([...kwInc, ...kwExc].some((k) => k.length > 100)) e.keywords = "Mỗi từ khóa tối đa 100 ký tự.";
    setErrors(e);
    if (Object.keys(e).length) return null;
    return { name: name.trim(), account_id: accountId || undefined, source_chat_ids: src.ids, destination_chat_ids: dst.ids, mode,
      filters: { keywords_include: kwInc, keywords_exclude: kwExc, content_types: types, include_outgoing: outgoing },
      priority: Number(priority), rate_per_minute: Number(rate), max_attempts: Number(attempts) };
  }
  async function submit() {
    const body = validate();
    if (!body) return;
    setBusy(true); setError(undefined);
    try {
      if (editing) {
        const { account_id: _ignored, ...rest } = body;
        void _ignored;
        await api.patch(`/api/routes/${route.id}`, chatsLocked ? { ...rest, source_chat_ids: undefined, destination_chat_ids: undefined } : rest);
      } else await api.post("/api/routes", body);
      onSaved();
    } catch (e) { setErrors((cur) => ({ ...cur, ...fieldErrors(e) })); setError(e instanceof ApiError ? e.message : "Không lưu được tuyến."); setBusy(false); }
  }
  const toggle = (t: ContentType) => setTypes((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]));
  return (
    <Modal wide title={editing ? `Sửa tuyến ${route.name}` : "Tạo tuyến chuyển tiếp"} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void submit()} disabled={busy}>{busy ? "Đang lưu…" : editing ? "Lưu thay đổi" : "Tạo tuyến"}</button></>}>
      <div className="form-grid">
        <TextField label="Tên tuyến" value={name} onChange={(e) => setName(e.target.value)} error={errors.name} maxLength={64} />
        {editing ? <TextField label="Tài khoản" value={route.account_name ?? ""} disabled hint="Không đổi được tài khoản của tuyến." readOnly /> : (
          <SelectField label="Tài khoản Telegram" value={accountId} onChange={(e) => setAccountId(e.target.value)} error={errors.account_id}>
            <option value="">Chọn tài khoản…</option>
            {accounts.data?.items.map((a) => <option key={a.id} value={a.id}>{a.name} — {authState[a.auth_state].label}</option>)}
          </SelectField>)}
        <TextArea label="Chat nguồn" rows={4} value={sources} onChange={(e) => setSources(e.target.value)} error={errors.source_chat_ids} disabled={chatsLocked}
          hint={chatsLocked ? "Hãy dừng tuyến để sửa nguồn/đích." : "Mỗi dòng một chat id. Nhóm/kênh có dạng -100…"} spellCheck={false} />
        <TextArea label="Chat đích" rows={4} value={dests} onChange={(e) => setDests(e.target.value)} error={errors.destination_chat_ids} disabled={chatsLocked}
          hint={chatsLocked ? "Hãy dừng tuyến để sửa nguồn/đích." : "Mỗi dòng một chat id. Đổi nguồn/đích sẽ cần xác minh lại."} spellCheck={false} />
        <div className="field span-2">
          <span className="label" id="mode-label">Cách gửi</span>
          <div className="seg" role="group" aria-labelledby="mode-label">
            <button type="button" aria-pressed={mode === "forward"} onClick={() => setMode("forward")}>Chuyển tiếp gốc</button>
            <button type="button" aria-pressed={mode === "copy"} onClick={() => setMode("copy")}>Sao chép nội dung</button>
          </div>
          <span className="hint">{mode === "forward" ? "Giữ nhãn “chuyển tiếp từ”. Không dùng được với chat bật bảo vệ nội dung." : "Gửi lại nội dung như tin mới, không có nhãn nguồn. Cũng bị chặn ở chat bật bảo vệ nội dung."}</span>
        </div>
        <fieldset className="field span-2" style={{ border: 0, padding: 0, margin: 0 }}>
          <legend className="label">Chỉ chuyển các loại nội dung (để trống = tất cả)</legend>
          <div className="row" style={{ gap: 16 }}>{ALL_TYPES.map((t) => <Check key={t} checked={types.includes(t)} onChange={() => toggle(t)} label={contentTypes[t]} />)}</div>
        </fieldset>
        <TextArea label="Phải chứa một trong các từ khóa" rows={3} value={include} onChange={(e) => setInclude(e.target.value)} error={errors.keywords} hint="Mỗi dòng một từ khóa, không phân biệt hoa thường. Để trống = không yêu cầu." />
        <TextArea label="Loại trừ nếu chứa từ khóa" rows={3} value={exclude} onChange={(e) => setExclude(e.target.value)} hint="Tin chứa bất kỳ từ khóa nào ở đây sẽ bị bỏ qua." />
        <div className="span-2"><Check checked={outgoing} onChange={(e) => setOutgoing(e.target.checked)} label="Cũng chuyển tin do chính tài khoản này gửi" hint="Mặc định tắt để tránh vòng lặp (tin hệ thống vừa gửi bị chuyển lại)." /></div>
        <TextField label="Mức ưu tiên (1–9)" type="number" min={1} max={9} value={priority} onChange={(e) => setPriority(e.target.value)} error={errors.priority} hint="1 được xử lý trước 9." />
        <TextField label="Tối đa tin mỗi phút" type="number" min={1} max={600} value={rate} onChange={(e) => setRate(e.target.value)} error={errors.rate_per_minute} />
        <TextField label="Số lần thử tối đa" type="number" min={1} max={10} value={attempts} onChange={(e) => setAttempts(e.target.value)} error={errors.max_attempts} hint="Hết số lần này, tác vụ vào hàng chờ lỗi để bạn xử lý." />
      </div>
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
