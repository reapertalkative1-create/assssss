import { useState } from "react";
import { api, ApiError } from "../api/client";
import type { Page, Worker, WorkerCreated, WorkerStatus } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { SecretDialog } from "../components/SecretDialog";
import { Alert, Check, EmptyState, Meter, PageHead, Pill, SelectField, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtAgo } from "../lib/format";
import { workerStatus } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";

type Dialog =
  | { kind: "create" } | { kind: "edit"; w: Worker } | { kind: "rotate"; w: Worker } | { kind: "revoke"; w: Worker }
  | { kind: "secret"; title: string; secret: string; intro: string };

export function WorkersPage() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<Worker>>("/api/workers", { q: search, status, page, page_size: 20 }, signal), [search, status, page], { interval: 5000 });

  const cols: Column<Worker>[] = [
    { key: "name", header: "Worker", cell: (w) => <><strong>{w.name}</strong><div className="muted small">{w.platform === "windows" ? "Windows" : "Linux"}{w.hostname && ` · ${w.hostname}`}</div></> },
    { key: "status", header: "Trạng thái", cell: (w) => <><Pill tone={workerStatus[w.status].tone}>{workerStatus[w.status].label}</Pill>{w.degraded_reason && <div className="muted small">{w.degraded_reason}</div>}</> },
    { key: "hb", header: "Heartbeat", cell: (w) => <span title={w.last_ip ?? ""}>{fmtAgo(w.last_heartbeat_at)}</span> },
    { key: "ver", header: "Phiên bản", cell: (w) => w.version ?? "—" },
    { key: "cpu", header: "CPU", cell: (w) => w.resource_reporting_enabled ? <Meter value={w.status === "offline" ? null : w.cpu_percent} /> : <span className="muted small">Đã tắt báo cáo</span> },
    { key: "mem", header: "RAM", cell: (w) => w.resource_reporting_enabled ? <Meter value={w.status === "offline" ? null : w.memory_percent} /> : <span className="muted small">—</span> },
    { key: "jobs", header: "Tác vụ", cell: (w) => w.running_jobs, align: "right" },
    ...(isAdmin ? [{
      key: "actions", header: "", align: "right" as const, cell: (w: Worker) => w.status === "revoked" ? <span className="muted small">Đã thu hồi</span> : (
        <div className="actions">
          <button className="btn sm" onClick={() => setDialog({ kind: "edit", w })}>Sửa</button>
          <button className="btn sm" onClick={() => setDialog({ kind: "rotate", w })}>Xoay credential</button>
          <button className="btn sm danger" onClick={() => setDialog({ kind: "revoke", w })}>Thu hồi</button>
        </div>),
    }] : []),
  ];

  const done = (msg: string) => { toast.success(msg); list.reload(); };
  return (
    <div className="stack">
      <PageHead title="Worker & máy chủ" actions={isAdmin && <button className="btn primary" onClick={() => setDialog({ kind: "create" })}>Thêm worker</button>}>
        Worker là tiến trình chạy trên máy Linux hoặc Windows, tự kết nối ra máy chủ này. Đóng trình duyệt không làm worker dừng.
      </PageHead>
      <div className="toolbar">
        <input className="input" placeholder="Tìm theo tên…" aria-label="Tìm worker" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className="select" aria-label="Lọc trạng thái" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">Mọi trạng thái</option>
          {(Object.keys(workerStatus) as WorkerStatus[]).map((s) => <option key={s} value={s}>{workerStatus[s].label}</option>)}
        </select>
      </div>
      <DataTable caption="Danh sách worker" columns={cols} rows={list.data?.items} rowKey={(w) => w.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title={search || status ? "Không có worker phù hợp" : "Chưa có worker nào"}
          action={isAdmin && !search && !status ? <button className="btn primary" onClick={() => setDialog({ kind: "create" })}>Thêm worker đầu tiên</button> : undefined}>
          {search || status ? "Thử bỏ bớt bộ lọc." : "Tạo worker, rồi dán credential vào máy sẽ chạy worker."}</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={20} total={list.data.total} onPage={setPage} />}

      {dialog?.kind === "create" && <CreateWorker onClose={() => setDialog(null)} onCreated={(w) => { list.reload(); setDialog({ kind: "secret", title: `Credential của ${w.name}`, secret: w.credential, intro: "Credential chỉ hiển thị một lần. Máy chủ chỉ lưu bản băm nên không thể xem lại. Nếu mất, hãy xoay credential." }); }} />}
      {dialog?.kind === "edit" && <EditWorker w={dialog.w} onClose={() => setDialog(null)} onSaved={() => { setDialog(null); done("Đã cập nhật worker."); }} />}
      {dialog?.kind === "rotate" && <RotateWorker w={dialog.w} onClose={() => setDialog(null)} onRotated={(w) => { list.reload(); setDialog({ kind: "secret", title: `Credential mới của ${w.name}`, secret: w.credential, intro: "Hãy cập nhật credential mới vào máy worker. Credential cũ vẫn dùng được trong thời gian ân hạn đã chọn." }); }} />}
      {dialog?.kind === "revoke" && (
        <ConfirmDialog title={`Thu hồi worker ${dialog.w.name}?`} confirmLabel="Thu hồi" danger requireText={dialog.w.name} onClose={() => setDialog(null)}
          onConfirm={async () => { await api.post(`/api/workers/${dialog.w.id}/revoke`); done("Đã thu hồi worker."); }}>
          <p>Worker sẽ bị ngắt ngay ở lần kết nối kế tiếp và <strong>không thể khôi phục</strong>. Muốn dùng lại máy này, hãy tạo worker mới.</p>
          <p className="muted">Tài khoản Telegram đang gán cho worker này sẽ dừng hoạt động cho tới khi bạn gán sang worker khác.</p>
        </ConfirmDialog>)}
      {dialog?.kind === "secret" && <SecretDialog title={dialog.title} secret={dialog.secret} envName="TFCC_WORKER_CREDENTIAL" intro={dialog.intro} onClose={() => setDialog(null)} />}
    </div>
  );
}

function CreateWorker({ onClose, onCreated }: { onClose: () => void; onCreated: (w: WorkerCreated) => void }) {
  const [name, setName] = useState("");
  const [platform, setPlatform] = useState<"linux" | "windows">("linux");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  async function submit() {
    if (!name.trim()) { setFields({ name: "Nhập tên worker." }); return; }
    setBusy(true); setErr(undefined); setFields({});
    try { onCreated(await api.post<WorkerCreated>("/api/workers", { name, platform })); }
    catch (e) { setFields(fieldErrors(e)); setErr(e instanceof ApiError ? e.message : "Không tạo được worker."); setBusy(false); }
  }
  return (
    <Modal title="Thêm worker" onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void submit()} disabled={busy}>{busy ? "Đang tạo…" : "Tạo worker"}</button></>}>
      <TextField label="Tên worker" hint="Ví dụ: vps-hanoi-01" value={name} onChange={(e) => setName(e.target.value)} error={fields.name} maxLength={64} />
      <SelectField label="Hệ điều hành của máy chạy worker" value={platform} onChange={(e) => setPlatform(e.target.value as "linux" | "windows")} hint="Credential chỉ dùng được trên đúng hệ điều hành này.">
        <option value="linux">Linux</option><option value="windows">Windows</option>
      </SelectField>
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

function EditWorker({ w, onClose, onSaved }: { w: Worker; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(w.name);
  const [reporting, setReporting] = useState(w.resource_reporting_enabled);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  async function submit() {
    setBusy(true); setErr(undefined);
    try { await api.patch(`/api/workers/${w.id}`, { name, resource_reporting_enabled: reporting }); onSaved(); }
    catch (e) { setErr(e instanceof ApiError ? e.message : "Không lưu được."); setBusy(false); }
  }
  return (
    <Modal title={`Sửa worker ${w.name}`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void submit()} disabled={busy || !name.trim()}>Lưu thay đổi</button></>}>
      <TextField label="Tên worker" value={name} onChange={(e) => setName(e.target.value)} maxLength={64} />
      <Check checked={reporting} onChange={(e) => setReporting(e.target.checked)} label="Cho phép worker báo cáo CPU và RAM" hint="Tắt thì worker ngừng gửi và máy chủ xóa số liệu đã có." />
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

function RotateWorker({ w, onClose, onRotated }: { w: Worker; onClose: () => void; onRotated: (w: WorkerCreated) => void }) {
  const [grace, setGrace] = useState("600");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const n = Number(grace);
  const invalid = !Number.isInteger(n) || n < 0 || n > 3600;
  async function submit() {
    setBusy(true); setErr(undefined);
    try { onRotated(await api.post<WorkerCreated>(`/api/workers/${w.id}/rotate-credential`, { grace_seconds: n })); }
    catch (e) { setErr(e instanceof ApiError ? e.message : "Không xoay được credential."); setBusy(false); }
  }
  return (
    <Modal title={`Xoay credential của ${w.name}`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void submit()} disabled={busy || invalid}>Tạo credential mới</button></>}>
      <TextField label="Thời gian ân hạn (giây)" type="number" min={0} max={3600} value={grace} onChange={(e) => setGrace(e.target.value)}
        error={invalid ? "Nhập số nguyên từ 0 đến 3600." : undefined}
        hint="Credential cũ vẫn dùng được trong khoảng này để bạn kịp cập nhật máy worker. Nhập 0 để vô hiệu hóa ngay." />
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}
