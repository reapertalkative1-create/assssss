import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { EventItem, Level } from "../api/types";
import { EventList } from "../components/EventList";
import { EmptyState, PageHead, Pill } from "../components/ui";
import { useEventStream } from "../hooks/useEventStream";
import { describeEvent } from "../lib/events";
import { levelLabel } from "../lib/labels";
import { useAuth } from "../state/auth";

const MAX = 500;

export function LogsPage() {
  const { logout } = useAuth();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [fresh, setFresh] = useState<Set<string>>(new Set());
  const [paused, setPaused] = useState(false);
  const [held, setHeld] = useState<EventItem[]>([]);
  const [level, setLevel] = useState<"" | Level>("");
  const [kind, setKind] = useState("");
  const [text, setText] = useState("");
  const box = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;

  const merge = useCallback((incoming: EventItem[], markFresh: boolean) => {
    setEvents((cur) => {
      const seen = new Set(cur.map((e) => e.key));
      const add = incoming.filter((e) => !seen.has(e.key));
      if (!add.length) return cur;
      if (markFresh) { setFresh(new Set(add.map((e) => e.key))); window.setTimeout(() => setFresh(new Set()), 1800); }
      return [...cur, ...add].slice(-MAX);
    });
  }, []);
  const onEvents = useCallback((incoming: EventItem[], initial: boolean) => {
    if (pausedRef.current && !initial) setHeld((h) => [...h, ...incoming].slice(-MAX));
    else merge(incoming, !initial);
  }, [merge]);
  const state = useEventStream(onEvents, () => { void logout(); });

  const shown = useMemo(() => {
    const needle = text.trim().toLowerCase();
    return events.filter((e) => (!level || e.level === level) && (!kind || e.kind === kind) &&
      (!needle || `${describeEvent(e).title} ${describeEvent(e).meta} ${e.action}`.toLowerCase().includes(needle)));
  }, [events, level, kind, text]);

  useEffect(() => { const el = box.current; if (el && stick.current) el.scrollTop = el.scrollHeight; }, [shown]);
  const resume = () => { merge(held, true); setHeld([]); setPaused(false); };

  const conn = state === "open" ? { tone: "ok" as const, label: "Đang nhận trực tiếp" } : state === "closed" ? { tone: "idle" as const, label: "Đã ngắt" } : { tone: "warn" as const, label: state === "connecting" ? "Đang kết nối…" : "Mất kết nối, đang thử lại…" };
  return (
    <div className="stack">
      <PageHead title="Nhật ký trực tiếp" actions={<span className="conn" role="status"><Pill tone={conn.tone}>{conn.label}</Pill></span>}>
        Sự kiện vận hành xuất hiện ngay khi xảy ra: worker, tài khoản, tuyến và kết quả tác vụ. Nội dung tin nhắn không bao giờ có ở đây.
      </PageHead>
      <div className="toolbar">
        <select className="select" aria-label="Lọc mức độ" value={level} onChange={(e) => setLevel(e.target.value as "" | Level)}>
          <option value="">Mọi mức độ</option>{(Object.keys(levelLabel) as Level[]).map((l) => <option key={l} value={l}>{levelLabel[l]}</option>)}
        </select>
        <select className="select" aria-label="Lọc nguồn" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">Mọi nguồn</option><option value="audit">Thao tác & hệ thống</option><option value="job">Kết quả tác vụ</option>
        </select>
        <input className="input" placeholder="Tìm trong nhật ký…" aria-label="Tìm trong nhật ký" value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn" onClick={() => (paused ? resume() : setPaused(true))}>{paused ? `Tiếp tục${held.length ? ` (${held.length} mới)` : ""}` : "Tạm dừng cuộn"}</button>
        <button className="btn" onClick={() => { setEvents([]); setHeld([]); }}>Xóa màn hình</button>
      </div>
      <div className="panel">
        <div className="logbox" ref={box} onScroll={(e) => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40; }} aria-live="off">
          {shown.length === 0 ? <EmptyState title={events.length ? "Không có sự kiện khớp bộ lọc" : "Chưa có sự kiện nào"}>{events.length ? "Thử bỏ bớt bộ lọc." : "Sự kiện mới sẽ hiện tại đây."}</EmptyState> : <EventList events={shown} fresh={fresh} />}
        </div>
      </div>
      <p className="muted small">Hiển thị tối đa {MAX} sự kiện gần nhất. Khi mất kết nối, trang tự nối lại và lấy tiếp từ sự kiện cuối, không bỏ sót và không lặp.</p>
    </div>
  );
}
