import type { ReactNode } from "react";
import type { ApiError } from "../api/client";
import { ErrorState, Skeleton } from "./ui";

export interface Column<T> { key: string; header: string; cell: (row: T) => ReactNode; align?: "right"; width?: string }
interface Props<T> {
  columns: Column<T>[]; rows: T[] | undefined; rowKey: (row: T) => string; loading: boolean; error?: ApiError; onRetry?: () => void;
  empty: ReactNode; caption: string;
}

export function DataTable<T>({ columns, rows, rowKey, loading, error, onRetry, empty, caption }: Props<T>) {
  if (error && !rows) return <div className="table-wrap"><ErrorState error={error} onRetry={onRetry} /></div>;
  return (
    <div className="table-wrap">
      <div className="table-heading"><strong>{caption}</strong><span>{loading?'Đang tải dữ liệu…':rows?`${rows.length} dòng trên trang`:''}</span></div>
      <table className="table">
        <caption className="sr-only">{caption}</caption>
        <thead><tr>{columns.map((c) => <th key={c.key} scope="col" className={c.align === "right" ? "right" : ""} style={{ width: c.width }}>{c.header}</th>)}</tr></thead>
        <tbody>
          {loading && !rows && Array.from({ length: 5 }, (_, i) => (
            <tr key={i}>{columns.map((c) => <td key={c.key}><Skeleton width={c.align === "right" ? "50%" : "80%"} /></td>)}</tr>
          ))}
          {rows?.map((r) => (
            <tr key={rowKey(r)}>{columns.map((c) => <td key={c.key} className={c.align === "right" ? "right" : ""}>{c.cell(r)}</td>)}</tr>
          ))}
        </tbody>
      </table>
      {rows && rows.length === 0 && <div>{empty}</div>}
      {error && rows && <div className="alert bad" role="alert" style={{ margin: 12 }}>Không cập nhật được: {error.message}</div>}
    </div>
  );
}

export function Pagination({ page, pageSize, total, onPage }: { page: number; pageSize: number; total: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (total <= pageSize) return total ? <div className="pager"><span>{total} mục</span></div> : null;
  return (
    <nav className="pager" aria-label="Phân trang">
      <span>{(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} / {total}</span>
      <span className="row">
        <button className="btn sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>Trước</button>
        <span aria-current="page">Trang {page}/{pages}</span>
        <button className="btn sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>Sau</button>
      </span>
    </nav>
  );
}
