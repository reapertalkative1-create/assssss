import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {Brand} from "./Brand";
import {setTheme} from "../state/theme";
import { useAuth } from "../state/auth";
import { ErrorBoundary } from "./ErrorBoundary";
import { Icon, type IconName } from "./icons";

const nav: { to: string; label: string; icon: IconName; admin?: boolean; group?: string }[] = [
  { to: "/", label: "Tổng quan", icon: "dashboard" },
  { to: "/accounts", label: "Tài khoản Telegram", icon: "accounts", group: "ĐIỀU HÀNH" },
  { to: "/routes", label: "Tuyến chuyển tiếp", icon: "routes" },
  { to: "/jobs", label: "Hàng đợi tác vụ", icon: "jobs" },
  { to: "/logs", label: "Nhật ký trực tiếp", icon: "logs" },
  { to: "/workers", label: "Worker & máy chủ", icon: "workers", group: "QUẢN TRỊ" },
  { to: "/users", label: "Người dùng", icon: "users", admin: true },
  { to: "/audit", label: "Nhật ký kiểm toán", icon: "audit", admin: true },
  { to: "/settings", label: "Cài đặt", icon: "settings" },
];

export function Layout() {
  const { user, logout, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  useEffect(()=>{if(!open)return;const close=(e:KeyboardEvent)=>{if(e.key==='Escape')setOpen(false);};window.addEventListener('keydown',close);return()=>window.removeEventListener('keydown',close);},[open]);
  const current=nav.find(n=>n.to===loc.pathname)?.label??'Không gian làm việc';
  function toggleTheme(){const dark=document.documentElement.dataset.theme==='dark'||(!document.documentElement.dataset.theme&&window.matchMedia('(prefers-color-scheme: dark)').matches);setTheme(dark?'light':'dark');}
  let lastGroup = "";
  return (
    <div className="app">
      <aside className={`rail ${open ? "open" : ""}`} aria-label="Điều hướng chính">
        <Link className="brand-link" to="/" aria-label="DEVYN FORWARDER — Tổng quan"><Brand/></Link>
        <button className="btn ghost rail-close" aria-label="Đóng menu" onClick={()=>setOpen(false)}><Icon name="close"/></button>
        <div className="workspace-badge"><span className="workspace-symbol">D</span><span>Không gian làm việc<small>Telegram workspace</small></span><Icon name="chevron" size={14}/></div>
        <div className="nav-group">KHÔNG GIAN LÀM VIỆC</div>
        <nav className="nav">
          {nav.filter((n) => !n.admin || isAdmin).map((n) => {
            const heading = n.group && n.group !== lastGroup ? n.group : null;
            if (n.group) lastGroup = n.group;
            return (
              <div key={n.to}>
                {heading && <div className="nav-group">{heading}</div>}
                <NavLink to={n.to} end={n.to === "/"}><Icon name={n.icon} /> {n.label}</NavLink>
              </div>
            );
          })}
        </nav>
        <div className="rail-foot">
          <div className="user-profile"><span className="avatar">{user?.username.slice(0,2).toUpperCase()}</span><div><strong>{user?.username}</strong><div className="small">{isAdmin ? "Quản trị viên" : "Vận hành viên"}</div></div></div>
          <button className="btn sm" onClick={() => void logout()}><Icon name="logout" size={16} /> Đăng xuất</button>
        </div>
      </aside>
      {open && <button className="rail-shade" aria-label="Đóng menu điều hướng" onClick={()=>setOpen(false)}/>}
      <div className="workspace">
        <header className="topbar">
          <div className="row"><button className="btn ghost menu-toggle" aria-label="Mở menu" aria-expanded={open} onClick={()=>setOpen(true)}><Icon name="menu"/></button><div className="breadcrumbs"><span>DEVYN FORWARDER</span><Icon name="chevron" size={12}/><strong>{current}</strong></div></div>
          <div className="topbar-actions"><span className="workspace-label">WORKSPACE</span><button className="btn ghost icon-button" onClick={toggleTheme} aria-label="Đổi giao diện sáng/tối"><Icon name="sun"/></button><span className="avatar topbar-avatar" title={user?.username}>{user?.username.slice(0,2).toUpperCase()}</span></div>
        </header>
        <main className="main" id="main"><ErrorBoundary resetKey={loc.pathname}><Outlet /></ErrorBoundary></main>
        <footer className="workspace-footer"><span>DEVYN FORWARDER</span><span>Không gian điều phối Telegram</span></footer>
      </div>
    </div>
  );
}
