import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { ApiError } from "../api/client";
import { ConfirmDialog } from "./ConfirmDialog";
import { DataTable, Pagination } from "./DataTable";
import { ErrorBoundary } from "./ErrorBoundary";
import { Modal } from "./Modal";
import { SecretDialog } from "./SecretDialog";
import { ToastProvider } from "../state/toast";

describe("ConfirmDialog", () => {
  it("keeps the dangerous button disabled until the exact text is typed", async () => {
    const user = userEvent.setup();
    render(<ConfirmDialog title="Xóa" confirmLabel="Xóa ngay" danger requireText="acc-1" onConfirm={async () => {}} onClose={() => {}}>nội dung</ConfirmDialog>);
    const btn = screen.getByRole("button", { name: "Xóa ngay" });
    expect(btn).toBeDisabled();
    await user.type(screen.getByLabelText(/Gõ “acc-1”/), "acc-");
    expect(btn).toBeDisabled();
    await user.type(screen.getByLabelText(/Gõ “acc-1”/), "1");
    expect(btn).toBeEnabled();
  });

  it("closes only after the server confirmed, and shows a failure inside the dialog", async () => {
    const user = userEvent.setup();
    const onClose = vi.fn();
    const onConfirm = vi.fn().mockRejectedValueOnce(new ApiError(409, "route_must_be_stopped", "Hãy dừng tuyến trước khi xóa.")).mockResolvedValueOnce(undefined);
    render(<ConfirmDialog title="Xóa" confirmLabel="Xóa" onConfirm={onConfirm} onClose={onClose}>x</ConfirmDialog>);
    await user.click(screen.getByRole("button", { name: "Xóa" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Hãy dừng tuyến trước khi xóa.");
    expect(onClose).not.toHaveBeenCalled();                    // no success feedback before the backend agreed
    await user.click(screen.getByRole("button", { name: "Xóa" }));
    await waitFor(() => expect(onClose).toHaveBeenCalledTimes(1));
  });
});

describe("Modal", () => {
  it("is an accessible dialog that closes on Escape and moves focus inside", async () => {
    const user = userEvent.setup();
    const onClose = vi.fn();
    render(<Modal title="Tiêu đề" onClose={onClose}><input aria-label="ô nhập" /></Modal>);
    const dialog = screen.getByRole("dialog", { name: "Tiêu đề" });
    expect(dialog).toHaveAttribute("aria-modal", "true");
    expect(screen.getByLabelText("ô nhập")).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(onClose).toHaveBeenCalled();
  });

  it("cannot be dismissed while busy", async () => {
    const user = userEvent.setup();
    const onClose = vi.fn();
    render(<Modal title="Đang làm" onClose={onClose} dismissible={false}><input aria-label="x" /></Modal>);
    await user.keyboard("{Escape}");
    expect(onClose).not.toHaveBeenCalled();
    expect(screen.queryByRole("button", { name: "Đóng" })).toBeNull();
  });
});

describe("SecretDialog", () => {
  it("shows the secret once and cannot be closed until the person confirms they saved it", async () => {
    const user = userEvent.setup();
    const onClose = vi.fn();
    render(<ToastProvider><SecretDialog title="Credential" secret="tfw_abc.SECRET" envName="TFCC_WORKER_CREDENTIAL" intro="Chỉ hiển thị một lần." onClose={onClose} /></ToastProvider>);
    expect(screen.getByTestId("secret")).toHaveTextContent("TFCC_WORKER_CREDENTIAL=tfw_abc.SECRET");
    expect(screen.getByRole("button", { name: "Xong" })).toBeDisabled();
    await user.keyboard("{Escape}");
    expect(onClose).not.toHaveBeenCalled();
    await user.click(screen.getByLabelText(/Tôi đã lưu credential/));
    await user.click(screen.getByRole("button", { name: "Xong" }));
    expect(onClose).toHaveBeenCalled();
  });
});

describe("ErrorBoundary", () => {
  it("shows a fallback instead of a blank screen", () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    const Boom = () => { throw new Error("secret detail must not be shown"); };
    render(<ErrorBoundary><Boom /></ErrorBoundary>);
    expect(screen.getByRole("alert")).toHaveTextContent("Trang này gặp lỗi hiển thị");
    expect(screen.queryByText(/secret detail/)).toBeNull();
    spy.mockRestore();
  });
});

describe("DataTable and Pagination", () => {
  const cols = [{ key: "n", header: "Tên", cell: (r: { n: string }) => r.n }];
  it("shows skeleton rows while loading, the empty state, and a retryable error", async () => {
    const user = userEvent.setup();
    const { rerender, container } = render(<DataTable caption="c" columns={cols} rows={undefined} rowKey={(r) => r.n} loading error={undefined} empty={<p>trống</p>} />);
    expect(container.querySelectorAll(".skeleton").length).toBeGreaterThan(0);
    rerender(<DataTable caption="c" columns={cols} rows={[]} rowKey={(r) => r.n} loading={false} empty={<p>Không có gì</p>} />);
    expect(screen.getByText("Không có gì")).toBeInTheDocument();
    const retry = vi.fn();
    rerender(<DataTable caption="c" columns={cols} rows={undefined} rowKey={(r) => r.n} loading={false} error={new ApiError(500, "x", "Máy chủ lỗi")} onRetry={retry} empty={null} />);
    await user.click(screen.getByRole("button", { name: "Thử lại" }));
    expect(retry).toHaveBeenCalled();
    expect(screen.getByRole("alert")).toHaveTextContent("Máy chủ lỗi");
  });

  it("keeps showing old rows with a warning when a refresh fails", () => {
    render(<DataTable caption="c" columns={cols} rows={[{ n: "dòng 1" }]} rowKey={(r) => r.n} loading={false} error={new ApiError(0, "network", "Mất mạng")} empty={null} />);
    expect(screen.getByText("dòng 1")).toBeInTheDocument();
    expect(screen.getByRole("alert")).toHaveTextContent("Mất mạng");
  });

  it("paginates", async () => {
    const user = userEvent.setup();
    const onPage = vi.fn();
    render(<Pagination page={2} pageSize={20} total={65} onPage={onPage} />);
    expect(screen.getByText("21–40 / 65")).toBeInTheDocument();
    await user.click(screen.getByRole("button", { name: "Sau" }));
    expect(onPage).toHaveBeenCalledWith(3);
    await user.click(screen.getByRole("button", { name: "Trước" }));
    expect(onPage).toHaveBeenCalledWith(1);
  });
});
