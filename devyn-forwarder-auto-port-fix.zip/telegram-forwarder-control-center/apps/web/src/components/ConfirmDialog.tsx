import { useState, type ReactNode } from "react";
import { ApiError } from "../api/client";
import { Modal } from "./Modal";
import { Alert, TextField } from "./ui";

interface Props {
  title: string;
  children: ReactNode;
  confirmLabel: string;
  danger?: boolean;
  /** For dangerous actions: the person must retype this text before the button works. */
  requireText?: string;
  onConfirm: () => Promise<void>;
  onClose: () => void;
}

/** The dialog only closes after the server confirmed. A failure stays visible inside it. */
export function ConfirmDialog({ title, children, confirmLabel, danger, requireText, onConfirm, onClose }: Props) {
  const [typed, setTyped] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const blocked = requireText !== undefined && typed !== requireText;

  async function run() {
    setBusy(true);
    setError(undefined);
    try { await onConfirm(); onClose(); }
    catch (e) { setError(e instanceof ApiError ? e.message : "Thao tác thất bại."); setBusy(false); }
  }
  return (
    <Modal title={title} onClose={onClose} dismissible={!busy}
      footer={<>
        <button className="btn" onClick={onClose} disabled={busy}>Hủy</button>
        <button className={`btn ${danger ? "danger solid" : "primary"}`} onClick={run} disabled={busy || blocked}>{busy ? "Đang xử lý…" : confirmLabel}</button>
      </>}>
      <div className="stack tight">{children}</div>
      {requireText !== undefined && (
        <TextField label={`Gõ “${requireText}” để xác nhận`} value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off" spellCheck={false} />
      )}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
