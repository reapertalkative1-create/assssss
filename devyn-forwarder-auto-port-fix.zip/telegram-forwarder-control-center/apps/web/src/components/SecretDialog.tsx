import { useState } from "react";
import { Modal } from "./Modal";
import { Alert, Check } from "./ui";
import { Icon } from "./icons";
import { useToast } from "../state/toast";

/** Shows a secret exactly once. The dialog cannot be closed until the person confirms they stored it. */
export function SecretDialog({ title, secret, envName, intro, onClose }: { title: string; secret: string; envName: string; intro: string; onClose: () => void }) {
  const [saved, setSaved] = useState(false);
  const toast = useToast();
  const snippet = `TFCC_WORKER_CONTROL_PLANE_URL=${location.origin}\n${envName}=${secret}`;
  async function copy() {
    try { await navigator.clipboard.writeText(snippet); toast.success("Đã sao chép cấu hình vào clipboard."); }
    catch { toast.error("Không sao chép tự động được. Hãy bôi đen và sao chép thủ công."); }
  }
  return (
    <Modal title={title} onClose={onClose} dismissible={false}
      footer={<button className="btn primary" disabled={!saved} onClick={onClose}>Xong</button>}>
      <Alert tone="warn">{intro}</Alert>
      <div className="secret" data-testid="secret">{snippet}</div>
      <div className="row"><button className="btn" onClick={() => void copy()}><Icon name="copy" size={16} /> Sao chép</button></div>
      <Check checked={saved} onChange={(e) => setSaved(e.target.checked)} label="Tôi đã lưu credential ở nơi an toàn" />
    </Modal>
  );
}
