import { Component, type ErrorInfo, type ReactNode } from "react";

interface State { failed: boolean }

/** A crash in one page must not blank the whole console. The error itself is logged without any user data. */
export class ErrorBoundary extends Component<{ children: ReactNode; resetKey?: string }, State> {
  state: State = { failed: false };
  static getDerivedStateFromError(): State { return { failed: true }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error("ui_crash", error.name, info.componentStack?.split("\n")[1]?.trim()); }
  componentDidUpdate(prev: { resetKey?: string }) { if (this.state.failed && prev.resetKey !== this.props.resetKey) this.setState({ failed: false }); }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="empty" role="alert">
        <h3>Trang này gặp lỗi hiển thị</h3>
        <p>Các trang khác vẫn hoạt động bình thường. Tải lại trang để thử lần nữa.</p>
        <button className="btn primary" onClick={() => location.reload()}>Tải lại trang</button>
      </div>
    );
  }
}
