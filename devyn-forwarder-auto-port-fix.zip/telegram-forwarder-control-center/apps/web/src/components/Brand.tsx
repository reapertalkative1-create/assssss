export function Brand(){
  return <span className="brand"><span className="brand-mark" aria-hidden="true"><svg viewBox="0 0 32 32" fill="none"><path d="M8 7h7a9 9 0 0 1 0 18H8V7Z" stroke="currentColor" strokeWidth="3"/><path d="m14 12 5 4-5 4" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg></span><span className="brand-copy"><strong>DEVYN FORWARDER</strong><small>Trung tâm điều phối</small></span></span>;
}
