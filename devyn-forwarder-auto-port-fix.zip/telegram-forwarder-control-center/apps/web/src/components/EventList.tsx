import type { EventItem } from "../api/types";
import { describeEvent } from "../lib/events";
import { fmtTime } from "../lib/format";
import { levelLabel, levelTone } from "../lib/labels";
import { Pill } from "./ui";

export function EventList({ events, fresh }: { events: EventItem[]; fresh?: Set<string> }) {
  return (
    <ul className="events">
      {events.map((e) => {
        const d = describeEvent(e);
        return (
          <li key={e.key} className={`event ${fresh?.has(e.key) ? "fresh" : ""}`}>
            <time className="time" dateTime={e.ts}>{fmtTime(e.ts)}</time>
            <Pill tone={levelTone[e.level]}>{levelLabel[e.level]}</Pill>
            <div className="what">{d.title}{d.meta && <div className="meta">{d.meta}</div>}</div>
          </li>
        );
      })}
    </ul>
  );
}
