const dtf = new Intl.DateTimeFormat("vi-VN", { dateStyle: "short", timeStyle: "medium", hour12: false });
const tf = new Intl.DateTimeFormat("vi-VN", { timeStyle: "medium", hour12: false });

export const fmtDateTime = (iso?: string | null) => (iso ? dtf.format(new Date(iso)) : "—");
export const fmtTime = (iso?: string | null) => (iso ? tf.format(new Date(iso)) : "—");

/** "5 giây trước", "3 phút trước"… `now` is injectable for tests. */
export function fmtAgo(iso?: string | null, now: number = Date.now()): string {
  if (!iso) return "chưa bao giờ";
  const s = Math.max(0, Math.round((now - new Date(iso).getTime()) / 1000));
  if (s < 5) return "vừa xong";
  if (s < 60) return `${s} giây trước`;
  if (s < 3600) return `${Math.floor(s / 60)} phút trước`;
  if (s < 86400) return `${Math.floor(s / 3600)} giờ trước`;
  return `${Math.floor(s / 86400)} ngày trước`;
}

export function fmtDuration(seconds: number | null | undefined): string {
  if (seconds == null) return "—";
  if (seconds < 60) return `${Math.round(seconds)} giây`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} phút`;
  return `${(seconds / 3600).toFixed(1)} giờ`;
}

export const fmtPercent = (v: number | null | undefined) => (v == null ? "—" : `${Math.round(v)}%`);
export const fmtNumber = (n: number) => new Intl.NumberFormat("vi-VN").format(n);

/** Parses "-1001, -1002\n-1003" into unique integers; returns the bad tokens too so the form can say what is wrong. */
export function parseChatIds(text: string): { ids: number[]; invalid: string[]; duplicates: number[] } {
  const ids: number[] = [], invalid: string[] = [], duplicates: number[] = [];
  for (const tok of text.split(/[\s,;]+/).filter(Boolean)) {
    if (!/^-?\d{1,16}$/.test(tok) || Number(tok) === 0) { invalid.push(tok); continue; }
    const n = Number(tok);
    if (ids.includes(n)) duplicates.push(n); else ids.push(n);
  }
  return { ids, invalid, duplicates };
}

export const splitLines = (text: string) => text.split("\n").map((s) => s.trim()).filter(Boolean);
