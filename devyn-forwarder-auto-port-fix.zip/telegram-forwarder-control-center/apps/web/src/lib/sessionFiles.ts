/** Read ZIP central directory and one member at a time; never load the full archive. */
export type SessionFile = {name:string; bytes?:Uint8Array; error?:string};
const maxFile=1024*1024;
const number64=(v:DataView,p:number)=>{const n=Number(v.getBigUint64(p,true));if(!Number.isSafeInteger(n))throw Error("ZIP quá lớn cho trình duyệt.");return n;};
async function read(file:Blob,start:number,size:number){if(start<0||size<0||start+size>file.size)throw Error("ZIP bị hỏng.");const blob=file.slice(start,start+size);
  const buffer=typeof blob.arrayBuffer==='function'?await blob.arrayBuffer():await new Promise<ArrayBuffer>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result as ArrayBuffer);r.onerror=()=>reject(Error('Không đọc được file.'));r.readAsArrayBuffer(blob);});
  return new Uint8Array(buffer);}
const crcTable=Array.from({length:256},(_,i)=>{let c=i;for(let j=0;j<8;j++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc32(data:Uint8Array){let c=0xffffffff;for(const b of data)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
async function inflate(data:Uint8Array,expected:number){
  const reader=new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw")).getReader();
  const out=new Uint8Array(expected);let pos=0;
  try{while(true){const {value,done}=await reader.read();if(done)break;if(pos+value.length>expected)throw Error("Session giải nén quá lớn.");out.set(value,pos);pos+=value.length;}}
  finally{await reader.cancel().catch(()=>{});}
  if(pos!==expected)throw Error("ZIP bị thiếu dữ liệu.");return out;
}
async function* zipSessions(file:File):AsyncGenerator<SessionFile>{
  const tail=await read(file,Math.max(0,file.size-65557),Math.min(file.size,65557));
  const view=new DataView(tail.buffer);let end=-1;
  for(let p=tail.length-22;p>=0;p--)if(view.getUint32(p,true)===0x06054b50&&p+22+view.getUint16(p+20,true)===tail.length){end=p;break;}
  if(end<0)throw Error("Không đọc được ZIP. Hãy dùng ZIP chuẩn, không đặt mật khẩu.");
  if(view.getUint16(end+4,true)||view.getUint16(end+6,true))throw Error("Không hỗ trợ ZIP nhiều phần.");
  let count=view.getUint16(end+10,true),offset=view.getUint32(end+16,true);
  if(count===65535||offset===0xffffffff){
    const absolute=file.size-tail.length+end;
    const loc=new DataView((await read(file,absolute-20,20)).buffer);
    if(loc.getUint32(0,true)!==0x07064b50)throw Error("ZIP64 bị hỏng.");
    const rec=new DataView((await read(file,number64(loc,8),56)).buffer);
    if(rec.getUint32(0,true)!==0x06064b50||rec.getUint32(16,true)||rec.getUint32(20,true))throw Error("ZIP64 không được hỗ trợ.");
    count=number64(rec,32);offset=number64(rec,48);
  }
  for(let i=0;i<count;i++){
    const h=new DataView((await read(file,offset,46)).buffer);
    if(h.getUint32(0,true)!==0x02014b50)throw Error("Danh mục ZIP bị hỏng.");
    const flags=h.getUint16(8,true),method=h.getUint16(10,true),crc=h.getUint32(16,true);
    let compressed=h.getUint32(20,true),size=h.getUint32(24,true),local=h.getUint32(42,true);
    const n=h.getUint16(28,true),extra=h.getUint16(30,true),comment=h.getUint16(32,true);
    const meta=await read(file,offset+46,n+extra);const path=new TextDecoder().decode(meta.slice(0,n));
    offset+=46+n+extra+comment;
    if(!/\.session$/i.test(path))continue;
    const name=path.replace(/\\/g,"/").split("/").pop()!.slice(0,160);
    try{
      for(let p=n;p+4<=meta.length;){const x=new DataView(meta.buffer,meta.byteOffset+p);const len=x.getUint16(2,true);if(p+4+len>meta.length)throw Error("ZIP extra field lỗi.");if(x.getUint16(0,true)===1){let q=4;if(size===0xffffffff){size=number64(x,q);q+=8;}if(compressed===0xffffffff){compressed=number64(x,q);q+=8;}if(local===0xffffffff)local=number64(x,q);}p+=4+len;}
      if(flags&1)throw Error("ZIP có mật khẩu.");
      if(size>maxFile||compressed>maxFile*2)throw Error("Session lớn hơn 1 MiB.");
      if(method!==0&&method!==8)throw Error("Chỉ hỗ trợ ZIP Store/Deflate.");
      const lh=new DataView((await read(file,local,30)).buffer);
      if(lh.getUint32(0,true)!==0x04034b50)throw Error("ZIP bị hỏng.");
      const raw=await read(file,local+30+lh.getUint16(26,true)+lh.getUint16(28,true),compressed);
      const bytes=method===0?raw:await inflate(raw,size);
      if(bytes.length!==size||crc32(bytes)!==crc)throw Error("ZIP sai CRC hoặc bị hỏng.");
      yield {name,bytes};
    }catch(e){yield {name,error:e instanceof Error?e.message:"Không đọc được session."};}
  }
}
export async function* sessionFiles(files:File[]):AsyncGenerator<SessionFile>{
  for(const file of files){
    if(/\.zip$/i.test(file.name)){yield* zipSessions(file);continue;}
    if(!/\.session$/i.test(file.name)){yield {name:file.name,error:"Chỉ hỗ trợ Telethon .session hoặc ZIP."};continue;}
    if(file.size>maxFile){yield {name:file.name,error:"Session lớn hơn 1 MiB."};continue;}
    yield {name:file.name,bytes:await read(file,0,file.size)};
  }
}
export function toBase64(bytes:Uint8Array){let value="";for(let i=0;i<bytes.length;i+=8192)value+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(value);}
