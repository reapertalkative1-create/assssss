import { describe, expect, it, vi } from "vitest";
import type { EventItem } from "../api/types";
import { EventStream, backoffMs, type SocketLike, type StreamState } from "./eventStream";

class FakeSocket implements SocketLike {
  onopen: SocketLike["onopen"] = null; onmessage: SocketLike["onmessage"] = null; onclose: SocketLike["onclose"] = null; onerror: SocketLike["onerror"] = null;
  closed: number | undefined;
  constructor(public url: string) {}
  close(code?: number) { this.closed = code; }
  open() { this.onopen?.({}); }
  send(msg: unknown) { this.onmessage?.({ data: JSON.stringify(msg) }); }
  drop(code = 1006) { this.onclose?.({ code }); }
}
const ev = (key: string): EventItem => ({ key, ts: "2026-01-01T00:00:00Z", kind: "audit", action: "route.start", level: "info", actor: null, target_type: null, target_id: null, details: null });

function setup() {
  const sockets: FakeSocket[] = [];
  const timers: { fn: () => void; ms: number }[] = [];
  const states: StreamState[] = [];
  const got: [string[], boolean][] = [];
  const authLost = vi.fn();
  const stream = new EventStream({
    onEvents: (e, initial) => got.push([e.map((x) => x.key), initial]), onState: (s) => states.push(s), onAuthLost: authLost,
    makeSocket: (url) => { const s = new FakeSocket(url); sockets.push(s); return s; }, url: () => "ws://x/api/ws/events", random: () => 1,
    setTimer: (fn, ms) => { timers.push({ fn, ms }); return timers.length; }, clearTimer: () => {},
  });
  return { stream, sockets, timers, states, got, authLost };
}

describe("EventStream", () => {
  it("delivers history then live events and goes open", () => {
    const t = setup();
    t.stream.start();
    t.sockets[0].open();
    t.sockets[0].send({ type: "hello", events: [ev("a1")], cursor: { audit: 1, job: "2026-01-01T00:00:00+00:00" } });
    t.sockets[0].send({ type: "events", events: [ev("a2")], cursor: { audit: 2, job: "2026-01-01T00:00:00+00:00" } });
    t.sockets[0].send({ type: "ping", cursor: { audit: 2, job: "2026-01-01T00:00:00+00:00" } });
    expect(t.got).toEqual([[["a1"], true], [["a2"], false]]);
    expect(t.states).toEqual(["connecting", "open"]);
  });

  it("reconnects with backoff and resumes from the last cursor (no gaps, no replays)", () => {
    const t = setup();
    t.stream.start();
    t.sockets[0].open();
    t.sockets[0].send({ type: "events", events: [ev("a5")], cursor: { audit: 5, job: "2026-01-01T00:00:07+00:00" } });
    t.sockets[0].drop(1006);
    expect(t.states.at(-1)).toBe("reconnecting");
    expect(t.timers[0].ms).toBe(1000);                       // first retry after 1 s (random=1 → full ceiling)
    t.timers[0].fn();
    expect(t.sockets[1].url).toBe("ws://x/api/ws/events?audit=5&job=2026-01-01T00%3A00%3A07%2B00%3A00");
    t.sockets[1].drop(1006);                                  // fails again before opening: delay grows
    expect(t.timers[1].ms).toBe(2000);
    t.timers[1].fn();
    t.sockets[2].open();
    t.sockets[2].drop(1006);                                  // a successful open resets the backoff
    expect(t.timers[2].ms).toBe(1000);
  });

  it.each([4401, 1008])("does not reconnect after close code %i and reports lost authentication", (code) => {
    const t = setup();
    t.stream.start();
    t.sockets[0].drop(code);
    expect(t.authLost).toHaveBeenCalledTimes(1);
    expect(t.timers).toHaveLength(0);
    expect(t.states.at(-1)).toBe("closed");
  });

  it("stop() closes the socket and never reconnects", () => {
    const t = setup();
    t.stream.start();
    t.sockets[0].open();
    t.stream.stop();
    expect(t.sockets[0].closed).toBe(1000);
    t.sockets[0].drop(1006);
    expect(t.timers).toHaveLength(0);
    expect(t.states.at(-1)).toBe("closed");
  });

  it("ignores malformed frames", () => {
    const t = setup();
    t.stream.start();
    t.sockets[0].onmessage?.({ data: "not json" });
    expect(t.got).toEqual([]);
  });
});

describe("backoffMs", () => {
  it("grows exponentially, is capped at 30 s and jittered between 50% and 100%", () => {
    expect([0, 1, 2, 3, 4, 5, 9].map((a) => backoffMs(a, () => 1))).toEqual([1000, 2000, 4000, 8000, 16000, 30000, 30000]);
    expect(backoffMs(3, () => 0)).toBe(4000);
    for (let i = 0; i < 50; i++) { const d = backoffMs(4); expect(d).toBeGreaterThanOrEqual(8000); expect(d).toBeLessThanOrEqual(16000); }
  });
});
