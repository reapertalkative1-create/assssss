import { describe, expect, it } from "vitest";
import { describeEvent } from "./events";
import { fmtAgo, fmtDuration, parseChatIds, splitLines } from "./format";
import { actionCodes, actionLabel, errorLabel } from "./labels";
import type { EventItem } from "../api/types";

describe("format", () => {
  const now = Date.parse("2026-01-01T12:00:00Z");
  it.each([
    ["2026-01-01T11:59:58Z", "vừa xong"], ["2026-01-01T11:59:30Z", "30 giây trước"], ["2026-01-01T11:55:00Z", "5 phút trước"],
    ["2026-01-01T09:00:00Z", "3 giờ trước"], ["2025-12-30T12:00:00Z", "2 ngày trước"],
  ])("fmtAgo(%s)", (iso, expected) => expect(fmtAgo(iso, now)).toBe(expected));
  it("handles missing values", () => { expect(fmtAgo(null)).toBe("chưa bao giờ"); expect(fmtDuration(null)).toBe("—"); expect(fmtDuration(90)).toBe("2 phút"); });

  it("parses chat ids and reports exactly what is wrong", () => {
    expect(parseChatIds("-1001, -1002\n-1003;-1001")).toEqual({ ids: [-1001, -1002, -1003], invalid: [], duplicates: [-1001] });
    expect(parseChatIds("12 abc 0 -5x 1.5").invalid).toEqual(["abc", "0", "-5x", "1.5"]);
    expect(parseChatIds("   ")).toEqual({ ids: [], invalid: [], duplicates: [] });
    expect(parseChatIds("12345678901234567").invalid).toEqual(["12345678901234567"]);   // longer than any real chat id
  });
  it("splits lines", () => expect(splitLines(" a \n\n b\n")).toEqual(["a", "b"]));
});

describe("labels", () => {
  it("every action label is non-empty and unknown codes fall back to the code", () => {
    for (const code of actionCodes) expect(actionLabel(code).length).toBeGreaterThan(2);
    expect(actionLabel("future.unknown")).toBe("future.unknown");
  });
  it("error labels explain the cause and show the exact wait", () => {
    expect(errorLabel("flood_wait", 120)).toContain("chờ 120 giây");
    expect(errorLabel("code_invalid")).toMatch(/Mã xác nhận/);
    expect(errorLabel("something_new")).toBe("Lỗi: something_new");
    expect(errorLabel(null)).toBe("");
  });
  it("describes events without ever needing message content", () => {
    const job: EventItem = { key: "j1", ts: "2026-01-01T00:00:00Z", kind: "job", action: "job.failed", level: "error", actor: null, target_type: "job", target_id: "x",
      details: { route_id: "r", attempts: 2, max_attempts: 5, error: "forward_restricted" } };
    expect(describeEvent(job)).toEqual({ title: "Chuyển tiếp thất bại", meta: "Chat bật bảo vệ nội dung, không thể chuyển tiếp. · lần 2/5" });
    const audit: EventItem = { key: "a1", ts: "2026-01-01T00:00:00Z", kind: "audit", action: "route.start", level: "info", actor: "admin1", target_type: "route", target_id: "r", details: { name: "Tin sale" } };
    expect(describeEvent(audit)).toEqual({ title: "Bật tuyến", meta: "Tin sale · bởi admin1" });
  });
});
