import type { EventItem } from "../api/types";
import { actionLabel, errorLabel } from "./labels";

/** Human sentence for an event. Uses ids/counters/names only: events never carry message content. */
export function describeEvent(e: EventItem): { title: string; meta: string } {
  const d = e.details ?? {};
  const name = typeof d.name === "string" ? d.name : undefined;
  const parts: string[] = [];
  if (e.kind === "job") {
    if (typeof d.error === "string") parts.push(errorLabel(d.error));
    if (typeof d.attempts === "number" && typeof d.max_attempts === "number") parts.push(`lần ${d.attempts}/${d.max_attempts}`);
    return { title: actionLabel(e.action), meta: parts.join(" · ") };
  }
  if (name) parts.push(name);
  if (typeof d.error === "string") parts.push(errorLabel(d.error));
  if (typeof d.reason === "string") parts.push(errorLabel(d.reason));
  if (e.actor) parts.push(`bởi ${e.actor}`);
  return { title: actionLabel(e.action), meta: parts.join(" · ") };
}
