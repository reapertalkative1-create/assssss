import type { Cursor, EventItem } from "../api/types";

export type StreamState = "connecting" | "open" | "reconnecting" | "closed";
export interface SocketLike {
  onopen: ((ev: unknown) => void) | null;
  onmessage: ((ev: { data: string }) => void) | null;
  onclose: ((ev: { code: number }) => void) | null;
  onerror: ((ev: unknown) => void) | null;
  close(code?: number): void;
}
export type SocketFactory = (url: string) => SocketLike;

export interface StreamOptions {
  onEvents: (events: EventItem[], initial: boolean) => void;
  onState: (state: StreamState) => void;
  onAuthLost: () => void;
  makeSocket?: SocketFactory;
  url?: () => string;
  random?: () => number;
  setTimer?: (fn: () => void, ms: number) => number;
  clearTimer?: (id: number) => void;
}

const FATAL = new Set([1008, 4401]);   // forbidden origin / not authenticated: retrying cannot help

export function backoffMs(attempt: number, random: () => number = Math.random): number {
  const ceiling = Math.min(30000, 1000 * 2 ** attempt);
  return Math.round(ceiling / 2 + (random() * ceiling) / 2);   // 50–100 % of the ceiling: spreads out reconnect storms
}

/** WebSocket client that reconnects with exponential backoff and resumes from the last cursor (no gaps, no replays). */
export class EventStream {
  private socket: SocketLike | null = null;
  private cursor: Cursor | null = null;
  private attempt = 0;
  private timer: number | null = null;
  private stopped = false;
  private opts: Required<Pick<StreamOptions, "random" | "setTimer" | "clearTimer">> & StreamOptions;

  constructor(opts: StreamOptions) {
    this.opts = {
      random: Math.random, setTimer: (fn, ms) => window.setTimeout(fn, ms), clearTimer: (id) => window.clearTimeout(id), ...opts,
    };
  }

  private url(): string {
    const base = this.opts.url ? this.opts.url() : `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/api/ws/events`;
    return this.cursor ? `${base}?audit=${this.cursor.audit}&job=${encodeURIComponent(this.cursor.job)}` : base;
  }

  start(): void {
    this.stopped = false;
    this.connect();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer !== null) this.opts.clearTimer(this.timer);
    this.timer = null;
    this.socket?.close(1000);
    this.socket = null;
    this.opts.onState("closed");
  }

  private connect(): void {
    this.opts.onState(this.attempt === 0 && !this.cursor ? "connecting" : "reconnecting");
    const factory: SocketFactory = this.opts.makeSocket ?? ((u) => new WebSocket(u) as unknown as SocketLike);
    const sock = factory(this.url());
    this.socket = sock;
    sock.onopen = () => { this.attempt = 0; this.opts.onState("open"); };
    sock.onmessage = (ev) => {
      let msg: { type: string; events?: EventItem[]; cursor?: Cursor };
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.cursor) this.cursor = msg.cursor;
      if (msg.type === "hello") this.opts.onEvents(msg.events ?? [], true);
      else if (msg.type === "events" && msg.events?.length) this.opts.onEvents(msg.events, false);
    };
    sock.onerror = () => { /* onclose follows */ };
    sock.onclose = (ev) => {
      if (this.socket !== sock) return;
      this.socket = null;
      if (this.stopped) return;
      if (FATAL.has(ev.code)) { this.stopped = true; this.opts.onState("closed"); this.opts.onAuthLost(); return; }
      const delay = backoffMs(this.attempt++, this.opts.random);
      this.opts.onState("reconnecting");
      this.timer = this.opts.setTimer(() => { this.timer = null; this.connect(); }, delay);
    };
  }
}
