import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.schemas_accounts import AccountReport, AssignmentOut
from app.schemas_forwarding import RouteConfigOut

Platform = Literal["linux", "windows"]


def _name(v: str) -> str:
    v = " ".join(v.split())
    if not 1 <= len(v) <= 64:
        raise ValueError("Tên worker dài 1–64 ký tự.")
    return v


class WorkerCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    platform: Platform
    _n = field_validator("name")(_name)


class WorkerUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = None
    resource_reporting_enabled: bool | None = None

    @field_validator("name")
    @classmethod
    def _opt_name(cls, v):
        return None if v is None else _name(v)


class RotateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    grace_seconds: int | None = Field(default=None, ge=0, le=3600)


class WorkerOut(BaseModel):
    id: uuid.UUID
    name: str
    platform: Platform
    version: str | None
    hostname: str | None
    status: Literal["online", "offline", "degraded", "revoked"]
    health: str
    degraded_reason: str | None
    running_jobs: int
    cpu_percent: float | None
    memory_percent: float | None
    resource_reporting_enabled: bool
    last_heartbeat_at: datetime | None
    last_registered_at: datetime | None
    last_ip: str | None
    credential_issued_at: datetime
    revoked_at: datetime | None
    created_at: datetime


class WorkerCreated(WorkerOut):
    credential: str  # shown exactly once; only its hash is stored


# ----- worker-facing -----
class RegisterRequest(BaseModel):
    platform: Platform
    version: str = Field(min_length=1, max_length=32)
    hostname: str | None = Field(default=None, max_length=128)


class RegisterResponse(BaseModel):
    worker_id: uuid.UUID
    name: str
    heartbeat_interval_seconds: int
    heartbeat_timeout_seconds: int
    report_resources: bool
    server_time: datetime
    lease_ttl_seconds: int = 60
    accounts: list[AssignmentOut] = []
    routes: list[RouteConfigOut] = []


class Resources(BaseModel):
    cpu_percent: float | None = Field(default=None, ge=0, le=100)
    memory_percent: float | None = Field(default=None, ge=0, le=100)


class HeartbeatRequest(BaseModel):
    health: Literal["ok", "degraded"] = "ok"
    degraded_reason: str | None = Field(default=None, max_length=200)
    running_jobs: int = Field(default=0, ge=0, le=100000)
    resources: Resources | None = None
    accounts: list[AccountReport] = Field(default_factory=list)


class HeartbeatResponse(BaseModel):
    status: Literal["ok"] = "ok"
    server_time: datetime
    report_resources: bool
    lease_ttl_seconds: int = 60
    accounts: list[AssignmentOut] = []
    lost_leases: list[uuid.UUID] = []
    routes: list[RouteConfigOut] = []
