"""Password hashing (Argon2id), password policy and opaque token helpers."""
import hashlib
import secrets

from anyio import to_thread
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

_ph = PasswordHasher()  # argon2-cffi default type is Argon2id
_DUMMY_HASH = _ph.hash("dummy-password-used-for-constant-time-checks")

MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 128
_COMMON = {"password1234", "123456789012", "qwertyuiop12", "administrator", "changeme1234"}


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _ph.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False


def needs_rehash(password_hash: str) -> bool:
    return _ph.check_needs_rehash(password_hash)


async def ahash_password(password: str) -> str:
    return await to_thread.run_sync(hash_password, password)


async def averify_password(password_hash: str, password: str) -> bool:
    return await to_thread.run_sync(verify_password, password_hash, password)


async def averify_dummy(password: str) -> None:
    """Burn the same CPU time as a real check so unknown users are not distinguishable by timing."""
    await to_thread.run_sync(verify_password, _DUMMY_HASH, password)


def validate_password_policy(password: str, username: str | None = None) -> str | None:
    """Return a Vietnamese error message, or None when the password is acceptable."""
    if len(password) < MIN_PASSWORD_LENGTH:
        return f"Mật khẩu phải có ít nhất {MIN_PASSWORD_LENGTH} ký tự."
    if len(password) > MAX_PASSWORD_LENGTH:
        return f"Mật khẩu tối đa {MAX_PASSWORD_LENGTH} ký tự."
    if len(set(password)) < 5:
        return "Mật khẩu quá đơn giản."
    if password.lower() in _COMMON:
        return "Mật khẩu quá phổ biến."
    if username and username.lower() in password.lower():
        return "Mật khẩu không được chứa tên đăng nhập."
    return None


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()
