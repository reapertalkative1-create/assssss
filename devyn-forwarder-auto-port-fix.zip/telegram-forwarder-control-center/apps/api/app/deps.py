import secrets
from collections.abc import AsyncIterator
from dataclasses import dataclass

from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.errors import ApiError
from app.models import Role, User, WebSession
from app.security import hash_token
from app.types import utcnow

COOKIE_NAME = "tfcc_session"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


async def get_db(request: Request) -> AsyncIterator[AsyncSession]:
    """One transaction per request: commit on success, roll back on any exception."""
    async with request.app.state.sessionmaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


@dataclass
class AuthContext:
    user: User
    session: WebSession


def _unauth() -> ApiError:
    return ApiError(401, "unauthenticated", "Bạn chưa đăng nhập hoặc phiên đã hết hạn.")


async def load_session(db: AsyncSession, token: str | None, settings) -> AuthContext | None:
    """Resolve a session cookie to (user, session), or None if it is missing, revoked, expired or idle for too long."""
    if not token:
        return None
    row = (await db.execute(select(WebSession).where(WebSession.token_hash == hash_token(token)))).scalar_one_or_none()
    now = utcnow()
    if (
        row is None
        or row.revoked_at is not None
        or row.expires_at <= now
        or (now - row.last_seen_at).total_seconds() > settings.session_idle_seconds
    ):
        return None
    user = await db.get(User, row.user_id)
    if user is None or not user.is_active:
        return None
    if (now - row.last_seen_at).total_seconds() > 60:
        row.last_seen_at = now
    return AuthContext(user=user, session=row)


async def get_auth(request: Request, db: AsyncSession = Depends(get_db, scope="function")) -> AuthContext:
    ctx = await load_session(db, request.cookies.get(COOKIE_NAME), request.app.state.settings)
    if ctx is None:
        raise _unauth()
    return ctx


async def authenticated(request: Request, auth: AuthContext = Depends(get_auth)) -> AuthContext:
    """Valid session + CSRF check for state-changing methods."""
    if request.method not in SAFE_METHODS:
        sent = request.headers.get("x-csrf-token", "")
        if not secrets.compare_digest(sent, auth.session.csrf_token):
            raise ApiError(403, "csrf_failed", "Thiếu hoặc sai mã CSRF.")
    return auth


def require_role(*roles: Role):
    async def dependency(auth: AuthContext = Depends(authenticated)) -> AuthContext:
        if auth.user.role not in roles:
            raise ApiError(403, "forbidden", "Bạn không có quyền thực hiện thao tác này.")
        return auth

    return dependency
