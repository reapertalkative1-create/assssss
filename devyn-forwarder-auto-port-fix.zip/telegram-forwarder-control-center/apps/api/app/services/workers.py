"""Worker credential lifecycle and liveness rules. Heartbeat proves the worker process is reachable;
it is NOT evidence that any Telegram task is actually working."""
import hashlib
import logging
import secrets
import uuid
from datetime import datetime, timedelta

from sqlalchemy import and_, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_system_audit
from app.errors import ApiError
from app.models import Worker
from app.types import utcnow

log = logging.getLogger("tfcc.workers")
CRED_PREFIX = "tfw_"


def _hash(secret: str) -> str:
    return hashlib.sha256(secret.encode()).hexdigest()


def make_credential(worker_id: uuid.UUID) -> tuple[str, str]:
    """Return (credential shown once to the admin, hash stored in the DB)."""
    cred = f"{CRED_PREFIX}{worker_id.hex}.{secrets.token_urlsafe(32)}"
    return cred, _hash(cred)


def parse_credential_worker_id(credential: str) -> uuid.UUID | None:
    if not credential.startswith(CRED_PREFIX) or "." not in credential:
        return None
    try:
        return uuid.UUID(hex=credential[len(CRED_PREFIX):].split(".", 1)[0])
    except ValueError:
        return None


def create_worker(db: AsyncSession, name: str, platform: str, created_by: uuid.UUID | None) -> tuple[Worker, str]:
    worker_id = uuid.uuid4()
    cred, cred_hash = make_credential(worker_id)
    now = utcnow()
    worker = Worker(id=worker_id, name=name, name_key=name.lower(), platform=platform,
                    credential_hash=cred_hash, credential_issued_at=now, created_by=created_by, status="offline")
    db.add(worker)
    return worker, cred


def rotate_credential(worker: Worker, grace_seconds: int, now: datetime | None = None) -> str:
    if worker.revoked_at is not None:
        raise ApiError(409, "worker_revoked", "Worker đã bị thu hồi. Hãy tạo worker mới.")
    now = now or utcnow()
    cred, cred_hash = make_credential(worker.id)
    worker.previous_credential_hash = worker.credential_hash if grace_seconds > 0 else None
    worker.previous_valid_until = now + timedelta(seconds=grace_seconds) if grace_seconds > 0 else None
    worker.credential_hash = cred_hash
    worker.credential_issued_at = now
    return cred


def revoke(worker: Worker, now: datetime | None = None) -> bool:
    """Idempotent. Returns True if this call changed anything."""
    if worker.revoked_at is not None:
        return False
    worker.revoked_at = now or utcnow()
    worker.status = "revoked"
    worker.previous_credential_hash = None
    worker.previous_valid_until = None
    return True


def credential_matches(worker: Worker, credential: str, now: datetime) -> bool:
    presented = _hash(credential)
    if secrets.compare_digest(worker.credential_hash, presented):
        return True
    if worker.previous_credential_hash and worker.previous_valid_until and worker.previous_valid_until > now:
        return secrets.compare_digest(worker.previous_credential_hash, presented)
    return False


def effective_status(worker: Worker, now: datetime, timeout_seconds: int) -> str:
    """Computed at read time so it stays correct even if the background detector is not running."""
    if worker.revoked_at is not None:
        return "revoked"
    if worker.last_heartbeat_at is None or (now - worker.last_heartbeat_at).total_seconds() > timeout_seconds:
        return "offline"
    return "degraded" if worker.health == "degraded" else "online"


def status_clause(status: str, now: datetime, timeout_seconds: int):
    cutoff = now - timedelta(seconds=timeout_seconds)
    fresh = and_(Worker.revoked_at.is_(None), Worker.last_heartbeat_at.is_not(None), Worker.last_heartbeat_at >= cutoff)
    return {
        "revoked": Worker.revoked_at.is_not(None),
        "offline": and_(Worker.revoked_at.is_(None), or_(Worker.last_heartbeat_at.is_(None), Worker.last_heartbeat_at < cutoff)),
        "online": and_(fresh, Worker.health != "degraded"),
        "degraded": and_(fresh, Worker.health == "degraded"),
    }[status]


def sync_status(db: AsyncSession, worker: Worker, now: datetime, timeout_seconds: int) -> None:
    """Persist the effective status; emit an audit event only on a real transition."""
    new = effective_status(worker, now, timeout_seconds)
    if worker.status != new:
        old, worker.status = worker.status, new
        record_system_audit(db, f"worker.{new}", target_type="worker", target_id=str(worker.id),
                            details={"from": old, "name": worker.name})


async def mark_stale_offline(db: AsyncSession, now: datetime, timeout_seconds: int) -> list[str]:
    """Flip workers whose heartbeat expired to offline. Safe with several API processes: only the
    process whose UPDATE actually changes a row emits the event."""
    cutoff = now - timedelta(seconds=timeout_seconds)
    stale = (await db.execute(
        select(Worker.id, Worker.name).where(
            Worker.status.in_(("online", "degraded")), Worker.revoked_at.is_(None), Worker.last_heartbeat_at < cutoff)
    )).all()
    flipped: list[str] = []
    for wid, name in stale:
        res = await db.execute(
            update(Worker).where(Worker.id == wid, Worker.status.in_(("online", "degraded")))
            .values(status="offline").execution_options(synchronize_session=False)
        )
        if res.rowcount:
            record_system_audit(db, "worker.offline", target_type="worker", target_id=str(wid),
                                details={"from": "online", "name": name, "reason": "heartbeat_timeout"})
            log.warning("worker_offline", extra={"worker_id": str(wid), "worker_name": name})
            flipped.append(str(wid))
    return flipped
