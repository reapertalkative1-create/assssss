"""Bounded offline Telethon SQLite importer. Never executes uploaded SQL or extracts ZIP paths."""
import base64
import hashlib
import io
import ipaddress
import sqlite3
import struct
import zipfile
import zlib
from dataclasses import dataclass, field

MAX_UPLOAD = 10 * 1024 * 1024
MAX_SESSION = 1024 * 1024
MAX_EXPANDED = 32 * 1024 * 1024
MAX_FILES = 100


class ImportFormatError(ValueError):
    pass


@dataclass
class ParsedSession:
    filename: str
    session: str = field(default='', repr=False)
    fingerprint: str = field(default='', repr=False)
    error: str | None = None


def convert_session(raw: bytes) -> tuple[str, str]:
    if len(raw) > MAX_SESSION or not raw.startswith(b'SQLite format 3\x00'):
        raise ImportFormatError('invalid_telethon_session')
    db = sqlite3.connect(':memory:')
    try:
        db.deserialize(raw)
        db.execute('PRAGMA trusted_schema=OFF')
        db.execute('PRAGMA query_only=ON')
        db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, MAX_SESSION)
        db.set_progress_handler(lambda: 1, 20000)
        table = db.execute("SELECT type FROM sqlite_master WHERE name='sessions'").fetchone()
        if table != ('table',):
            raise ImportFormatError('invalid_telethon_session')
        rows = db.execute('SELECT dc_id, server_address, port, auth_key FROM sessions LIMIT 2').fetchall()
        if len(rows) != 1:
            raise ImportFormatError('invalid_telethon_session')
        dc, address, port, key = rows[0]
        if type(dc) is not int or not 1 <= dc <= 255 or type(port) is not int or not 1 <= port <= 65535:
            raise ImportFormatError('invalid_telethon_session')
        if not isinstance(key, bytes) or len(key) != 256 or not any(key):
            raise ImportFormatError('session_has_no_auth_key')
        ip = ipaddress.ip_address(address).packed
        packed = struct.pack('>B'+str(len(ip))+'sH256s', dc, ip, port, key)
        return '1' + base64.urlsafe_b64encode(packed).decode(), hashlib.sha256(key).hexdigest()
    except ImportFormatError:
        raise
    except (sqlite3.Error, ValueError, TypeError, struct.error):
        raise ImportFormatError('invalid_telethon_session') from None
    finally:
        db.close()


def parse_uploads(files: list[tuple[str, bytes]]) -> list[ParsedSession]:
    if sum(len(raw) for _, raw in files) > MAX_UPLOAD:
        raise ImportFormatError('upload_too_large')
    unpacked = []
    expanded = 0
    for name, raw in files:
        if name.lower().endswith('.zip'):
            try:
                with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                    if len(archive.infolist()) > 1000:
                        raise ImportFormatError('too_many_files')
                    for info in archive.infolist():
                        if info.is_dir() or not info.filename.lower().endswith('.session'):
                            continue
                        if info.flag_bits & 1 or info.file_size > MAX_SESSION:
                            raise ImportFormatError('invalid_archive')
                        expanded += info.file_size
                        if len(unpacked) >= MAX_FILES or expanded > MAX_EXPANDED:
                            raise ImportFormatError('too_many_files')
                        unpacked.append((info.filename.replace('\\','/').rsplit('/',1)[-1][:160], archive.read(info)))
            except (zipfile.BadZipFile, RuntimeError, NotImplementedError, OSError, EOFError, zlib.error):
                raise ImportFormatError('invalid_archive') from None
        elif name.lower().endswith('.session'):
            expanded += len(raw)
            unpacked.append((name.replace('\\','/').rsplit('/',1)[-1][:160],raw))
        else:
            raise ImportFormatError('unsupported_file_type')
        if len(unpacked) > MAX_FILES or expanded > MAX_EXPANDED:
            raise ImportFormatError('too_many_files')
    if not unpacked:
        raise ImportFormatError('no_session_files')
    result=[]
    for name, raw in unpacked:
        try:
            session, fingerprint = convert_session(raw)
            result.append(ParsedSession(name,session,fingerprint))
        except ImportFormatError as exc:
            result.append(ParsedSession(name,error=str(exc)))
    return result
