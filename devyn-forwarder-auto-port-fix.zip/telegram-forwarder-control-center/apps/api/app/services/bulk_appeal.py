"""Encrypted prepare -> preview -> explicit approval -> one-shot send pipeline."""
import hashlib,json,re
from datetime import timedelta
from sqlalchemy import select,func,update
from app.models import AccountBulkJob as J,AccountBulkItem as I,TelegramAccount as A,WorkerCommand as C
from app.services import accounts as svc
from app.errors import ApiError
from app.types import utcnow


def owner(job,item):return f'{job.id}:{item.account_id}'


async def store_preview(db,cmd,value,box):
    item=(await db.execute(select(I).where(I.command_id==cmd.id,I.status=='queued'))).scalar_one_or_none()
    if item is None or box is None:return False
    job=(await db.execute(select(J).where(J.id==item.job_id).with_for_update())).scalar_one_or_none()
    if not job or job.status!='preparing':return False
    item=(await db.execute(select(I).where(I.job_id==job.id,I.account_id==item.account_id).with_for_update().execution_options(populate_existing=True))).scalar_one()
    if item.status!='queued':return False
    text=value.get('text');mid=value.get('expected_reply_id');digest=value.get('expected_prompt_hash')
    if not isinstance(text,str) or not 1<=len(text)<=4000 or type(mid) is not int or not 0<mid<2147483648:return False
    if not isinstance(digest,str) or not re.fullmatch('[a-f0-9]{64}',digest):return False
    payload={'operation':'reply','text':text,'expected_reply_id':mid,'expected_prompt_hash':digest}
    item.payload_ciphertext=box.seal('appeal_preview',owner(job,item),json.dumps(payload))
    return True


async def counts(db,job):
    return dict((await db.execute(select(I.status,func.count()).where(I.job_id==job.id).group_by(I.status))).all())


async def process(db,job,settings,box):
    now=utcnow()
    if box is None:return
    queued=(await db.execute(select(I).where(I.job_id==job.id,I.status=='queued').limit(100))).scalars().all()
    for item in queued:
        cmd=await db.get(C,item.command_id)
        if cmd and cmd.status not in svc.FINAL_STATUSES:continue
        if job.status=='stopping':item.status='cancelled';item.payload_ciphertext=None;continue
        if cmd is None:item.status,item.error_code='error','command_missing';continue
        if cmd.type=='appeal_prepare':
            if cmd.status=='done' and item.payload_ciphertext:item.status='prepared';item.error_code=None
            else:item.status,item.error_code='error',(cmd.result or {}).get('appeal_error') or cmd.error_code or 'appeal_prepare_failed'
        else:
            delivery=(cmd.result or {}).get('action_delivery')
            if cmd.status=='done' and delivery=='sent':item.status='done';item.error_code=None
            else:item.status,item.error_code='error',(cmd.result or {}).get('spam_error') or cmd.error_code or 'appeal_delivery_uncertain'
    if job.status in ('preparing','running'):
        needed='pending' if job.status=='preparing' else 'pending_send'
        items=(await db.execute(select(I).where(I.job_id==job.id,I.status==needed).order_by(I.account_id).limit(100))).scalars().all()
        config=json.loads(box.open('appeal_settings',str(job.id),job.settings_ciphertext)) if job.settings_ciphertext else {}
        for item in items:
            a=(await db.execute(select(A).where(A.id==item.account_id).with_for_update())).scalar_one_or_none()
            if a is None or a.pending_deletion:item.status,item.error_code='error','account_missing';continue
            if a.auth_state!='authorized' or not a.session_ciphertext:item.status,item.error_code='error','account_not_ready';continue
            if a.flood_wait_until and a.flood_wait_until>now:item.status,item.error_code='error','flood_wait';continue
            try:await svc.worker_can_take_commands(db,a.assigned_worker_id,settings.heartbeat_timeout_seconds,now)
            except ApiError as exc:item.status,item.error_code='error',exc.code;continue
            pending=(await db.execute(select(C.id).where(C.account_id==a.id,C.status.in_(('pending','delivered')),C.expires_at>now))).first()
            if pending:continue
            backlog=(await db.execute(select(func.count()).select_from(C).where(C.worker_id==a.assigned_worker_id,
                C.status.in_(('pending','delivered')),C.expires_at>now))).scalar_one()
            if backlog>=30:continue
            if needed=='pending':
                profile=config.get('profiles',{}).get(str(a.id)) or config.get('profiles',{}).get(a.name_key) or {}
                payload={'template':config['template'],'name':a.name,'email':profile.get('email') or config.get('email',''),
                         'phone_override':profile.get('phone','')}
                typ='appeal_prepare'
            else:
                if a.spam_action_status=='uncertain':item.status,item.error_code='error','appeal_delivery_uncertain';item.payload_ciphertext=None;continue
                if a.spam_last_action_at and a.spam_last_action_at+timedelta(seconds=10)>now:continue
                payload=json.loads(box.open('appeal_preview',owner(job,item),item.payload_ciphertext))
                fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
                if a.spam_last_action_ref==fingerprint:item.status,item.error_code='error','spam_action_duplicate';item.payload_ciphertext=None;continue
                a.spam_last_action_ref=fingerprint;a.spam_last_action_at=now;a.spam_action_status='queued'
                typ='spam_reply'
            cmd=svc.create_command(db,box,worker_id=a.assigned_worker_id,account_id=a.id,type=typ,payload=payload,
                ttl=600,created_by=job.created_by,now=now)
            await db.flush();item.command_id=cmd.id;item.status='queued'
            if needed=='pending_send':item.payload_ciphertext=None
    await db.flush()
    if job.status=='running':
        await db.execute(update(I).where(I.job_id==job.id,I.status=='error').values(payload_ciphertext=None))
    state=await counts(db,job)
    if not any(state.get(k,0) for k in ('pending','pending_send','queued')):
        if job.status=='preparing':
            digest=hashlib.sha256()
            rows=await db.stream(select(I.account_id,I.payload_ciphertext).where(I.job_id==job.id,I.status=='prepared').order_by(I.account_id).execution_options(yield_per=100))
            async for aid,cipher in rows:digest.update(str(aid).encode());digest.update(cipher.encode())
            job.review_token=digest.hexdigest();job.status='preview'
        else:job.status='cancelled' if job.status=='stopping' else 'done';job.settings_ciphertext=None
    job.updated_at=now


async def cancel(db,job):
    now=utcnow()
    await db.execute(update(I).where(I.job_id==job.id,I.status.in_(('pending','pending_send','prepared'))).values(status='cancelled',payload_ciphertext=None))
    items=(await db.execute(select(I).where(I.job_id==job.id,I.status=='queued'))).scalars().all()
    for item in items:
        cmd=await db.get(C,item.command_id)
        if cmd and cmd.status=='pending':
            cmd.status='expired';cmd.payload_ciphertext=None;cmd.completed_at=now;item.status='cancelled';item.payload_ciphertext=None
            if cmd.type=='spam_reply':
                a=await db.get(A,item.account_id)
                if a and a.spam_last_action_at==cmd.created_at:a.spam_action_status='failed';a.spam_last_action_ref=None
    job.status='stopping';job.settings_ciphertext=None;job.review_token=None
