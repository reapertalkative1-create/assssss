import uuid

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import WebSession
from app.types import utcnow


async def revoke_user_sessions(db: AsyncSession, user_id: uuid.UUID, except_session_id: uuid.UUID | None = None) -> None:
    stmt = update(WebSession).where(WebSession.user_id == user_id, WebSession.revoked_at.is_(None))
    if except_session_id is not None:
        stmt = stmt.where(WebSession.id != except_session_id)
    await db.execute(stmt.values(revoked_at=utcnow()))
