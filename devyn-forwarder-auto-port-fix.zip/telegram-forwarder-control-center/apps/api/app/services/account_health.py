from sqlalchemy import func, or_
from app.models import TelegramAccount as A
DEAD = {'auth_key_unregistered','auth_key_duplicated','session_revoked','user_deactivated','phone_banned'}


def health(a):
    if a.health_override == 'frozen':return 'frozen'
    return a.health_status or 'unknown'


def conditions(q=None, auth_state=None, worker_id=None, health_status=None, desired_state=None, spam_status=None):
    filters=[]
    if q:
        term=q.strip().lower()
        filters.append(or_(A.name_key.contains(term,autoescape=True),func.lower(A.telegram_username).contains(term,autoescape=True)))
    if auth_state:filters.append(A.auth_state==auth_state)
    if worker_id:filters.append(A.assigned_worker_id==worker_id)
    if spam_status:filters.append(A.spam_status==spam_status)
    if desired_state:filters.append(A.desired_state==desired_state)
    if health_status:
        if health_status=='frozen':filters.append(or_(A.health_status=='frozen',A.health_override=='frozen'))
        else:filters.extend([A.health_status==health_status,or_(A.health_override.is_(None),A.health_override!='frozen')])
    return filters
