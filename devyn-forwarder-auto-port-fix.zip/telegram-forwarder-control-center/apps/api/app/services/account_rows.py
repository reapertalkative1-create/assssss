"""Bounded, batched activity summaries for the visible account page."""
from sqlalchemy import select, func, case, exists
from app.models import AccountBulkItem as I, AccountBulkJob as J, WorkerCommand as C


async def row_activity(db, account_ids):
    if not account_ids:
        return {}
    # Active work first; never load all history or issue a query for each row.
    active = I.status.in_(('pending', 'queued', 'draining', 'prepared', 'pending_send'))
    ranked = select(
        I.account_id, I.job_id, I.status, I.error_code,
        J.action, J.status.label('job_status'), J.updated_at,
        func.row_number().over(partition_by=I.account_id,
            order_by=(case((active, 0), else_=1), J.created_at.desc(), J.id.desc())).label('rn'),
    ).join(J, J.id == I.job_id).where(I.account_id.in_(account_ids)).subquery()
    rows = (await db.execute(select(ranked).where(ranked.c.rn <= 5).order_by(ranked.c.account_id, ranked.c.rn))).mappings()
    result = {}
    for row in rows:
        result.setdefault(row['account_id'], []).append({
            'id': str(row['job_id']), 'kind': 'bulk', 'action': row['action'],
            'status': row['status'], 'job_status': row['job_status'],
            'error_code': row['error_code'], 'updated_at': row['updated_at'],
        })
    # A check/login triggered outside the bulk scheduler still belongs on its row.
    commands = select(C.id, C.account_id, C.type, C.status, C.error_code, C.created_at, C.completed_at, C.result,
        func.row_number().over(partition_by=C.account_id,
            order_by=(case((C.status.in_(('pending', 'delivered')), 0), else_=1), C.created_at.desc(), C.id.desc())).label('rn'),
    ).where(C.account_id.in_(account_ids), ~exists(select(I.job_id).where(I.command_id == C.id))).subquery()
    for row in (await db.execute(select(commands).where(commands.c.rn == 1))).mappings():
        bot_error = (row['result'] or {}).get('spam_error')
        if (row['result'] or {}).get('action_delivery') == 'uncertain':
            bot_error = bot_error or 'appeal_delivery_uncertain'
        result.setdefault(row['account_id'], []).append({
            'id': str(row['id']), 'kind': 'command', 'action': row['type'],
            'status': 'error' if row['status']=='done' and bot_error else row['status'], 'job_status': None, 'error_code': row['error_code'] or bot_error,
            'updated_at': row['completed_at'] or row['created_at'],
        })
    return result
