"""Operational event feed (dashboard + realtime page) built from the audit trail and finished forward jobs.
Only metadata is exposed: never message content, phone numbers, sessions or credentials."""
from datetime import datetime, timezone

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AuditLog, ForwardJob, Role
from app.types import utcnow

OPERATOR_PREFIXES = ("worker.", "account.", "route.", "job.")  # operators do not see auth.* / user.* / keys.* events
JOB_STATUSES = ("succeeded", "failed", "dead_letter", "retry_wait")
ERROR = {"job.dead_letter", "job.failed", "account.invalidated"}
WARNING = {"worker.offline", "worker.degraded", "job.retry_wait", "worker.revoke", "auth.login_failed",
           "auth.account_locked", "auth.login_blocked", "account.lease_lost"}


def level_for(action: str) -> str:
    return "error" if action in ERROR else "warning" if action in WARNING else "info"


def audit_event(a: AuditLog) -> dict:
    return {"key": f"a:{a.id}", "ts": a.occurred_at.isoformat(), "kind": "audit", "action": a.action,
            "level": level_for(a.action), "actor": a.actor_username, "target_type": a.target_type,
            "target_id": a.target_id, "details": a.details}


def job_event(j: ForwardJob) -> dict:
    action = f"job.{j.status}"
    return {"key": f"j:{j.id}:{j.status}:{j.updated_at.isoformat()}", "ts": j.updated_at.isoformat(), "kind": "job",
            "action": action, "level": level_for(action), "actor": None, "target_type": "job", "target_id": str(j.id),
            "details": {"route_id": str(j.route_id), "attempts": j.attempts, "max_attempts": j.max_attempts,
                        "error": j.last_error_code}}


def _audit_filter(role: Role):
    if role == Role.ADMIN:
        return None
    return or_(*[AuditLog.action.startswith(p) for p in OPERATOR_PREFIXES])


async def recent_events(db: AsyncSession, role: Role, limit: int = 50) -> tuple[list[dict], dict]:
    """Newest `limit` events (oldest first) and the cursor from which a live stream continues without gaps or repeats."""
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
    flt = _audit_filter(role)
    if flt is not None:
        stmt = stmt.where(flt)
    audits = list((await db.execute(stmt)).scalars())
    jobs = list((await db.execute(select(ForwardJob).where(ForwardJob.status.in_(JOB_STATUSES))
                                  .order_by(ForwardJob.updated_at.desc()).limit(limit))).scalars())
    events = sorted([audit_event(a) for a in audits] + [job_event(j) for j in jobs], key=lambda e: e["ts"])[-limit:]
    latest_audit = (await db.execute(select(AuditLog.id).order_by(AuditLog.id.desc()).limit(1))).scalar_one_or_none() or 0
    job_cursor = max((j.updated_at for j in jobs), default=utcnow())
    return events, {"audit": latest_audit, "job": job_cursor.isoformat()}


def parse_cursor_time(value: str | None) -> datetime:
    try:
        dt = datetime.fromisoformat(value) if value else utcnow()
    except ValueError:
        return utcnow()
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


async def events_after(db: AsyncSession, role: Role, audit_id: int, job_ts: datetime, limit: int = 100) -> tuple[list[dict], dict]:
    stmt = select(AuditLog).where(AuditLog.id > audit_id).order_by(AuditLog.id).limit(limit)
    flt = _audit_filter(role)
    if flt is not None:
        stmt = stmt.where(flt)
    audits = list((await db.execute(stmt)).scalars())
    jobs = list((await db.execute(select(ForwardJob).where(ForwardJob.status.in_(JOB_STATUSES), ForwardJob.updated_at > job_ts)
                                  .order_by(ForwardJob.updated_at).limit(limit))).scalars())
    events = sorted([audit_event(a) for a in audits] + [job_event(j) for j in jobs], key=lambda e: e["ts"])
    # Non-visible audit rows (operators) must still advance the cursor, otherwise they would be re-read forever.
    newest = (await db.execute(select(AuditLog.id).where(AuditLog.id > audit_id).order_by(AuditLog.id).limit(limit))).scalars().all()
    return events, {"audit": max([audit_id, *newest]), "job": max([job_ts, *[j.updated_at for j in jobs]]).isoformat()}
