import logging

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import get_db
from app.errors import ApiError
from app.models import Worker
from app.services.workers import credential_matches, parse_credential_worker_id
from app.types import utcnow
from app.utils import client_ip

log = logging.getLogger("tfcc.worker_auth")


async def get_worker(request: Request, db: AsyncSession = Depends(get_db, scope="function")) -> Worker:
    """Bearer authentication for workers. Wrong id, wrong secret and malformed input all give the same 401."""
    limiter = request.app.state.worker_auth_limiter
    ip = client_ip(request) or "unknown"
    if limiter.is_limited(ip):
        raise ApiError(429, "too_many_attempts", "Quá nhiều lần xác thực thất bại. Thử lại sau.")

    def deny() -> ApiError:
        limiter.record(ip)
        log.warning("worker_auth_failed", extra={"ip": ip})  # never log the presented credential
        return ApiError(401, "invalid_credential", "Credential không hợp lệ.")

    scheme, _, credential = request.headers.get("authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not credential or len(credential) > 200:
        raise deny()
    worker_id = parse_credential_worker_id(credential)
    worker = await db.get(Worker, worker_id) if worker_id else None
    if worker is None or not credential_matches(worker, credential, utcnow()):
        raise deny()
    if worker.revoked_at is not None:  # reached only with a correct secret, so this leaks nothing
        raise ApiError(403, "worker_revoked", "Credential của worker đã bị thu hồi.")
    return worker
