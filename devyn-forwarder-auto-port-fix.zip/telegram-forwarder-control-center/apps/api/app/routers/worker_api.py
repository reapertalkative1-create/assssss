"""Endpoints called BY workers (outbound HTTPS only; workers never accept inbound connections)."""
from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import get_db
from app.deps_worker import get_worker
from app.errors import ApiError
from app.models import Worker
from app.schemas_workers import (
    HeartbeatRequest, HeartbeatResponse, RegisterRequest, RegisterResponse,
)
from app.services import accounts as acct_svc
from app.services.routes import routes_for_worker
from app.services.workers import sync_status
from app.types import utcnow
from app.utils import client_ip

router = APIRouter(prefix="/api/worker/v1", tags=["worker-api"])


@router.post("/register", response_model=RegisterResponse)
async def register(body: RegisterRequest, request: Request, worker: Worker = Depends(get_worker),
                   db: AsyncSession = Depends(get_db, scope="function")):
    """Called on every (re)connect. Re-registering is how a worker resynchronises after an outage."""
    settings = request.app.state.settings
    if body.platform != worker.platform:
        raise ApiError(409, "platform_mismatch",
                       f"Credential này dành cho worker {worker.platform}, không phải {body.platform}.")
    now = utcnow()
    worker.version, worker.hostname = body.version, body.hostname
    worker.last_registered_at = worker.last_heartbeat_at = now
    worker.last_ip = client_ip(request)
    worker.health, worker.degraded_reason = "ok", None
    sync_status(db, worker, now, settings.heartbeat_timeout_seconds)
    await record_audit(db, request, "worker.register", actor_id=worker.id, actor_username=f"worker:{worker.name}"[:32],
                       target_type="worker", target_id=str(worker.id),
                       details={"version": body.version, "platform": body.platform})
    return RegisterResponse(
        worker_id=worker.id, name=worker.name,
        heartbeat_interval_seconds=settings.worker_heartbeat_interval_seconds,
        heartbeat_timeout_seconds=settings.heartbeat_timeout_seconds,
        report_resources=worker.resource_reporting_enabled, server_time=now,
        lease_ttl_seconds=settings.account_lease_ttl_seconds,
        accounts=await acct_svc.assignments_for(db, worker.id), routes=await routes_for_worker(db, worker.id),
    )


@router.post("/heartbeat", response_model=HeartbeatResponse)
async def heartbeat(body: HeartbeatRequest, request: Request, worker: Worker = Depends(get_worker),
                    db: AsyncSession = Depends(get_db, scope="function")):
    """Proves the worker process is reachable. It says nothing about whether Telegram tasks succeed."""
    settings = request.app.state.settings
    now = utcnow()
    worker.last_heartbeat_at = now
    worker.last_ip = client_ip(request)
    worker.health = body.health
    worker.degraded_reason = body.degraded_reason if body.health == "degraded" else None
    worker.running_jobs = body.running_jobs
    if worker.resource_reporting_enabled and body.resources:
        worker.cpu_percent, worker.memory_percent = body.resources.cpu_percent, body.resources.memory_percent
    sync_status(db, worker, now, settings.heartbeat_timeout_seconds)
    ttl = settings.account_lease_ttl_seconds
    lost = await acct_svc.process_reports(db, worker, body.accounts, ttl, now)
    return HeartbeatResponse(server_time=now, report_resources=worker.resource_reporting_enabled, lease_ttl_seconds=ttl,
                             accounts=await acct_svc.assignments_for(db, worker.id), lost_leases=lost,
                             routes=await routes_for_worker(db, worker.id))
