from datetime import timedelta

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app import __version__
from app.deps import AuthContext, authenticated, get_db, require_role
from app.models import ForwardJob, ForwardRoute, Role, TelegramAccount, Worker
from app.services import accounts as acct_svc
from app.services import jobs as job_svc
from app.services import workers as worker_svc
from app.services.events import recent_events
from app.types import utcnow

router = APIRouter(tags=["dashboard"])


@router.get("/api/events/recent")
async def events_recent(limit: int = 50, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    events, cursor = await recent_events(db, auth.user.role, max(1, min(limit, 200)))
    return {"events": events, "cursor": cursor}


@router.get("/api/dashboard/summary")
async def summary(request: Request, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    now, timeout = utcnow(), request.app.state.settings.heartbeat_timeout_seconds

    workers = (await db.execute(select(Worker).order_by(Worker.name_key))).scalars().all()
    wcount = {"online": 0, "offline": 0, "degraded": 0, "revoked": 0}
    resources = []
    for w in workers:
        st = worker_svc.effective_status(w, now, timeout)
        wcount[st] += 1
        if st != "revoked":
            resources.append({"id": str(w.id), "name": w.name, "platform": w.platform, "status": st,
                              "cpu_percent": w.cpu_percent if st != "offline" else None,
                              "memory_percent": w.memory_percent if st != "offline" else None,
                              "running_jobs": w.running_jobs, "last_heartbeat_at": w.last_heartbeat_at})

    accounts = (await db.execute(select(TelegramAccount))).scalars().all()
    acount = {"total": len(accounts), "authorized": 0, "invalid": 0, "connected": 0, "running": 0}
    for a in accounts:
        acount["authorized"] += a.auth_state == "authorized"
        acount["invalid"] += a.auth_state == "invalid"
        acount["running"] += a.desired_state == "running"
        acount["connected"] += acct_svc.effective_connection_state(a, now) == "connected"

    rcount = {"active": 0, "paused": 0, "stopped": 0}
    for (st,) in (await db.execute(select(ForwardRoute.status))).all():
        rcount[st] = rcount.get(st, 0) + 1

    metrics = await job_svc.metrics(db, now)
    since = now - timedelta(hours=24)
    finished = (await db.execute(select(ForwardJob.status, ForwardJob.finished_at).where(
        ForwardJob.finished_at >= since, ForwardJob.status.in_(("succeeded", "failed", "dead_letter"))).limit(50000))).all()
    hour0 = now.replace(minute=0, second=0, microsecond=0)
    series = [{"hour": (hour0 - timedelta(hours=23 - i)).isoformat(), "succeeded": 0, "failed": 0} for i in range(24)]
    for st, fin in finished:
        idx = 23 - int((hour0 - fin.replace(minute=0, second=0, microsecond=0)).total_seconds() // 3600)
        if 0 <= idx < 24:
            series[idx]["succeeded" if st == "succeeded" else "failed"] += 1
    events, _ = await recent_events(db, auth.user.role, 15)
    return {
        "workers": wcount, "accounts": acount, "routes": rcount,
        "jobs": {**metrics, "last_24h": {"succeeded": sum(s["succeeded"] for s in series),
                                          "failed": sum(s["failed"] for s in series)}, "series": series},
        "resources": resources, "recent_events": events, "server_time": now,
    }


@router.get("/api/system/info")
async def system_info(request: Request, _: AuthContext = Depends(require_role(Role.ADMIN)), db: AsyncSession = Depends(get_db, scope="function")):
    """Effective, non-secret configuration. Values are read-only here: they come from the server environment."""
    s, box = request.app.state.settings, request.app.state.secret_box
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False
    return {
        "version": __version__, "environment": s.env, "database_ok": db_ok,
        "encryption": {"configured": box is not None, "keys": box.key_count if box else 0},
        "settings": {
            "heartbeat_timeout_seconds": s.heartbeat_timeout_seconds,
            "worker_heartbeat_interval_seconds": s.worker_heartbeat_interval_seconds,
            "account_lease_ttl_seconds": s.account_lease_ttl_seconds, "job_lease_ttl_seconds": s.job_lease_ttl_seconds,
            "job_retry_base_seconds": s.job_retry_base_seconds, "job_retry_cap_seconds": s.job_retry_cap_seconds,
            "account_rate_per_minute": s.account_rate_per_minute, "command_ttl_seconds": s.command_ttl_seconds,
            "session_ttl_seconds": s.session_ttl_seconds, "session_idle_seconds": s.session_idle_seconds,
            "login_lock_threshold": s.login_lock_threshold, "cookie_secure": s.cookie_secure,
        },
    }
