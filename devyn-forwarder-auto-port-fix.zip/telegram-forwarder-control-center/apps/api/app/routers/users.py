import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, get_db, require_role
from app.errors import ApiError
from app.models import Role, User
from app.schemas import Page, UserCreate, UserOut, UserUpdate
from app.security import ahash_password, validate_password_policy
from app.services.sessions import revoke_user_sessions

router = APIRouter(prefix="/api/users", tags=["users"])
admin_only = require_role(Role.ADMIN)


@router.get("", response_model=Page[UserOut])
async def list_users(
    q: str | None = Query(default=None, max_length=32),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    _: AuthContext = Depends(admin_only),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(User)
    if q:
        stmt = stmt.where(User.username.contains(q.strip().lower(), autoescape=True))
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(User.created_at.desc(), User.username).offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[UserOut](items=[UserOut.model_validate(r) for r in rows], total=total, page=page, page_size=page_size)


@router.post("", response_model=UserOut, status_code=201)
async def create_user(body: UserCreate, request: Request, auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    problem = validate_password_policy(body.password, body.username)
    if problem:
        raise ApiError(422, "weak_password", problem)
    user = User(username=body.username, password_hash=await ahash_password(body.password), role=body.role)
    db.add(user)
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "username_taken", "Tên đăng nhập đã tồn tại.") from None
    await record_audit(db, request, "user.create", actor=auth.user, target_type="user", target_id=str(user.id),
                       details={"username": user.username, "role": user.role.value})
    return user


@router.get("/{user_id}", response_model=UserOut)
async def get_user(user_id: uuid.UUID, _: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    user = await db.get(User, user_id)
    if user is None:
        raise ApiError(404, "not_found", "Không tìm thấy người dùng.")
    return user


@router.patch("/{user_id}", response_model=UserOut)
async def update_user(
    user_id: uuid.UUID, body: UserUpdate, request: Request,
    auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function"),
):
    target = await db.get(User, user_id)
    if target is None:
        raise ApiError(404, "not_found", "Không tìm thấy người dùng.")

    is_self = target.id == auth.user.id
    if is_self and (
        (body.role is not None and body.role != target.role) or body.is_active is False or body.password is not None
    ):
        # Also guarantees there is always at least one active admin: the acting admin cannot remove themselves.
        raise ApiError(409, "cannot_modify_self", "Không thể tự đổi vai trò, khóa hoặc đặt lại mật khẩu của chính mình tại đây.")

    changed: list[str] = []
    revoke = False
    if body.role is not None and body.role != target.role:
        target.role = body.role
        changed.append("role")
    if body.is_active is not None and body.is_active != target.is_active:
        target.is_active = body.is_active
        changed.append("is_active")
        revoke = revoke or not body.is_active
    if body.password is not None:
        problem = validate_password_policy(body.password, target.username)
        if problem:
            raise ApiError(422, "weak_password", problem)
        target.password_hash = await ahash_password(body.password)
        target.failed_login_count, target.locked_until = 0, None
        changed.append("password_reset")
        revoke = True
    if body.unlock:
        target.failed_login_count, target.locked_until = 0, None
        changed.append("unlock")

    if revoke:
        await revoke_user_sessions(db, target.id)
    if changed:
        await record_audit(db, request, "user.update", actor=auth.user, target_type="user", target_id=str(target.id),
                           details={"changed": changed, "role": target.role.value, "is_active": target.is_active})
    return target
