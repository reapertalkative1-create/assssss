import json,uuid
from fastapi import APIRouter,Depends,Request,Query
from sqlalchemy import select,func,insert,literal,update
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import AccountBulkJob as J,AccountBulkItem as I,TelegramAccount as A,Role
from app.deps import require_role,AuthContext,get_db
from app.audit import record_audit
from app.errors import ApiError
from app.schemas_accounts import BulkAppealRequest,BulkAppealConfirm
from app.services.account_health import conditions
from app.services.bulk_appeal import counts,owner
from app.types import utcnow
router=APIRouter(prefix='/api/account-appeals',tags=['account-appeals'])
admin=require_role(Role.ADMIN)


def box_for(request):
    if request.app.state.secret_box is None:raise ApiError(503,'encryption_not_configured','Chưa cấu hình khóa mã hóa.')
    return request.app.state.secret_box


async def get_job(db,jid,lock=False):
    stmt=select(J).where(J.id==jid,J.action=='bulk_appeal')
    if lock:stmt=stmt.with_for_update()
    job=(await db.execute(stmt)).scalar_one_or_none()
    if not job:raise ApiError(404,'not_found','Không tìm thấy bản kháng nghị.')
    return job


@router.post('',status_code=202)
async def create(body:BulkAppealRequest,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    box=box_for(request)
    if not body.all_matching and not body.account_ids:raise ApiError(422,'empty_selection','Chọn tài khoản cần chuẩn bị kháng nghị.')
    config={'template':body.template.get_secret_value(),'email':body.email.get_secret_value() if body.email else '',
            'profiles':{key.lower():{k:v.get_secret_value() for k,v in [('email',p.email),('phone',p.phone)] if v} for key,p in body.profiles.items()}}
    if '{email}' in config['template'] and not config['email'] and not config['profiles']:
        raise ApiError(422,'appeal_email_missing','Nhập email liên hệ chung hoặc email riêng cho từng tài khoản.')
    job=J(action='bulk_appeal',status='preparing',created_by=auth.user.id)
    db.add(job);await db.flush()
    job.settings_ciphertext=box.seal('appeal_settings',str(job.id),json.dumps(config))
    filters=conditions(**body.filters.model_dump()) if body.all_matching else [A.id.in_(body.account_ids)]
    if body.all_matching and body.exclude_ids:filters.append(A.id.not_in(body.exclude_ids))
    await db.execute(insert(I).from_select(['job_id','account_id','status'],select(literal(job.id,type_=A.id.type),A.id,literal('pending')).where(*filters,A.pending_deletion.is_(False))))
    job.total=(await db.execute(select(func.count()).select_from(I).where(I.job_id==job.id))).scalar_one()
    if not job.total:job.status='preview'
    await record_audit(db,request,'account.bulk_appeal_prepared',actor=auth.user,target_type='account_bulk',target_id=str(job.id),details={'total':job.total})
    return {'id':str(job.id),'status':job.status,'total':job.total}


@router.get('/{jid}')
async def preview(jid:uuid.UUID,request:Request,page:int=Query(1,ge=1),status:str|None=Query(None,max_length=16),
                  _:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    box=box_for(request);job=await get_job(db,jid)
    stmt=select(I,A.name).outerjoin(A,A.id==I.account_id).where(I.job_id==job.id)
    if status:stmt=stmt.where(I.status==status)
    total=(await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows=(await db.execute(stmt.order_by(I.account_id).offset((page-1)*20).limit(20))).all()
    items=[]
    for item,name in rows:
        text=None
        if item.payload_ciphertext and item.status=='prepared':text=json.loads(box.open('appeal_preview',owner(job,item),item.payload_ciphertext))['text']
        items.append({'account_id':str(item.account_id),'name':name or 'Đã xóa','status':item.status,'error_code':item.error_code,'text':text})
    return {'id':str(job.id),'status':job.status,'total':job.total,'counts':await counts(db,job),'review_token':job.review_token,
            'items':items,'items_total':total,'page_size':20}


@router.post('/{jid}/confirm',status_code=202)
async def confirm(jid:uuid.UUID,body:BulkAppealConfirm,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    job=await get_job(db,jid,True)
    if not body.facts_confirmed:raise ApiError(422,'appeal_facts_required','Cần xác nhận nội dung đúng với các tài khoản đã chọn.')
    if job.status in ('running','done'):return {'id':str(job.id),'status':job.status}
    if job.status!='preview' or job.review_token!=body.review_token:raise ApiError(409,'stale_appeal_preview','Bản xem trước đã thay đổi hoặc chưa chuẩn bị xong.')
    state=await counts(db,job)
    if not state.get('prepared'):raise ApiError(409,'appeal_no_ready_accounts','Chưa có tài khoản sẵn sàng gửi; xem nguyên nhân từng dòng.')
    await db.execute(update(I).where(I.job_id==job.id,I.status=='prepared').values(status='pending_send'))
    job.status='running';job.settings_ciphertext=None;job.updated_at=utcnow()
    await record_audit(db,request,'account.bulk_appeal_confirmed',actor=auth.user,target_type='account_bulk',target_id=str(job.id),details={'ready':state['prepared']})
    return {'id':str(job.id),'status':job.status}
