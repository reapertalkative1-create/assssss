import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app import __version__

router = APIRouter(tags=["health"])
log = logging.getLogger("tfcc.health")


@router.get("/health/live")
def live() -> dict[str, str]:
    """Liveness: the process is up. Does not check dependencies."""
    return {"status": "ok", "version": __version__}


@router.get("/health/ready")
async def ready(request: Request):
    """Readiness: the database answers. Error details are logged, never returned."""
    try:
        async with request.app.state.sessionmaker() as session:
            await session.execute(text("SELECT 1"))
    except Exception:
        log.warning("readiness_check_failed", exc_info=True)
        return JSONResponse(status_code=503, content={"status": "degraded", "database": "down"})
    return {"status": "ok", "database": "up", "version": __version__}
