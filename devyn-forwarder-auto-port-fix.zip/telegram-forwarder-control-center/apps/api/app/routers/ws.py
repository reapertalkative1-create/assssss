"""Realtime event stream (WebSocket). Read-only; authenticated by the same session cookie as the HTTP API."""
import asyncio
import logging
import time
from urllib.parse import urlparse

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.deps import COOKIE_NAME, load_session
from app.services.events import events_after, parse_cursor_time, recent_events

router = APIRouter()
log = logging.getLogger("tfcc.ws")
POLL_SECONDS = 1.0
PING_SECONDS = 20.0
REVALIDATE_SECONDS = 30.0   # a logged-out / revoked / deactivated user is disconnected within this time
BATCH = 100


def origin_allowed(ws: WebSocket, allowed: list[str]) -> bool:
    """Blocks cross-site WebSocket hijacking: browsers always send Origin; it must be this site or a configured origin."""
    origin = ws.headers.get("origin")
    if not origin:
        return True  # not a browser; the session cookie is still required
    return urlparse(origin).netloc == ws.headers.get("host") or origin in allowed


@router.websocket("/api/ws/events")
async def events_ws(ws: WebSocket, audit: int | None = None, job: str | None = None):
    app = ws.app
    settings, sessionmaker = app.state.settings, app.state.sessionmaker
    if not origin_allowed(ws, settings.cors_origins):
        await ws.close(code=1008)
        return
    async with sessionmaker() as db:
        ctx = await load_session(db, ws.cookies.get(COOKIE_NAME), settings)
        await db.commit()
        if ctx is None:
            await ws.close(code=4401)
            return
        role, token = ctx.user.role, ws.cookies.get(COOKIE_NAME)
        if audit is None:   # fresh connection: send recent history; a reconnect passes its cursor and gets only what it missed
            history, cursor = await recent_events(db, role, 50)
        else:
            history, cursor = [], {"audit": audit, "job": parse_cursor_time(job).isoformat()}
    await ws.accept()
    await ws.send_json({"type": "hello", "events": history, "cursor": cursor, "role": role.value})

    last_ping = last_check = time.monotonic()
    try:
        while True:
            try:
                msg = await asyncio.wait_for(ws.receive(), timeout=POLL_SECONDS)
                if msg["type"] == "websocket.disconnect":
                    break
            except asyncio.TimeoutError:
                pass
            now = time.monotonic()
            if now - last_check >= REVALIDATE_SECONDS:
                last_check = now
                async with sessionmaker() as db:
                    still = await load_session(db, token, settings)
                    await db.commit()
                if still is None or still.user.role != role:
                    await ws.close(code=4401)
                    return
            async with sessionmaker() as db:
                events, cursor = await events_after(db, role, cursor["audit"], parse_cursor_time(cursor["job"]), BATCH)
            if events:
                await ws.send_json({"type": "events", "events": events, "cursor": cursor})
                last_ping = now
            elif now - last_ping >= PING_SECONDS:
                await ws.send_json({"type": "ping", "cursor": cursor})
                last_ping = now
    except (WebSocketDisconnect, RuntimeError):
        return
    except Exception as exc:
        log.error("ws_error", extra={"error": type(exc).__name__})
        try:
            await ws.close(code=1011)
        except Exception:
            pass
