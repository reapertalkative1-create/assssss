import uuid
from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy import select, func, insert, literal, update, case
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.models import Role, AccountBulkJob, AccountBulkItem, TelegramAccount as A
from app.schemas_accounts import AccountBulkRequest
from app.services.account_health import conditions
from app.errors import ApiError
from app.types import utcnow
router=APIRouter(prefix='/api/account-bulk',tags=['account-bulk'])
admin=require_role(Role.ADMIN)


async def output(db,job):
    counts=dict((await db.execute(select(AccountBulkItem.status,func.count()).where(
        AccountBulkItem.job_id==job.id).group_by(AccountBulkItem.status))).all())
    return {'id':str(job.id),'action':job.action,'status':job.status,'total':job.total,'counts':counts,'created_at':job.created_at}


@router.post('',status_code=202)
async def create(body:AccountBulkRequest, request:Request, auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    if not body.all_matching and not body.account_ids:raise ApiError(422,'empty_selection','Chọn tài khoản hoặc chọn toàn bộ kết quả lọc.')
    if body.action in ('check','spam_check') and request.app.state.secret_box is None:raise ApiError(503,'encryption_not_configured','Chưa cấu hình khóa mã hóa.')
    filters=conditions(**body.filters.model_dump()) if body.all_matching else [A.id.in_(body.account_ids)]
    if body.all_matching and body.exclude_ids:filters.append(A.id.not_in(body.exclude_ids))
    filters.append(A.pending_deletion.is_(False))
    job=AccountBulkJob(action=body.action,created_by=auth.user.id)
    db.add(job);await db.flush()
    await db.execute(insert(AccountBulkItem).from_select(['job_id','account_id','status'],
        select(literal(job.id,type_=A.id.type),A.id,literal('pending')).where(*filters)))
    job.total=(await db.execute(select(func.count()).select_from(AccountBulkItem).where(AccountBulkItem.job_id==job.id))).scalar_one()
    if not job.total:job.status='done'
    await record_audit(db,request,'account.bulk_created',actor=auth.user,target_type='account_bulk',target_id=str(job.id),
        details={'action':body.action,'total':job.total})
    return await output(db,job)


@router.get('')
async def listing(page:int=Query(1,ge=1),page_size:int=Query(10,ge=1,le=100),status:str|None=Query(None,max_length=16),
                  _:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    stmt=select(AccountBulkJob)
    if status:stmt=stmt.where(AccountBulkJob.status==status)
    total=(await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    jobs=(await db.execute(stmt.order_by(case((AccountBulkJob.status.in_(('running','stopping','preparing','preview')),0),else_=1),
        AccountBulkJob.created_at.desc()).offset((page-1)*page_size).limit(page_size))).scalars().all()
    return {'items':[await output(db,j) for j in jobs],'total':total,'page':page,'page_size':page_size}


@router.get('/{job_id}')
async def details(job_id:uuid.UUID,page:int=Query(1,ge=1),status:str|None=Query(None,max_length=16),
                  _:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    job=await db.get(AccountBulkJob,job_id)
    if not job:raise ApiError(404,'not_found','Không tìm thấy tác vụ.')
    stmt=select(AccountBulkItem,A.name).outerjoin(A,A.id==AccountBulkItem.account_id).where(AccountBulkItem.job_id==job.id)
    if status:stmt=stmt.where(AccountBulkItem.status==status)
    total=(await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows=(await db.execute(stmt.order_by(AccountBulkItem.account_id).offset((page-1)*50).limit(50))).all()
    return {**await output(db,job),'items':[{'account_id':str(i.account_id),'name':name or 'Đã xóa','status':i.status,'error_code':i.error_code} for i,name in rows],
            'items_total':total,'page':page,'page_size':50}


@router.post('/{job_id}/cancel')
async def cancel(job_id:uuid.UUID,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    job=(await db.execute(select(AccountBulkJob).where(AccountBulkJob.id==job_id).with_for_update())).scalar_one_or_none()
    if not job:raise ApiError(404,'not_found','Không tìm thấy tác vụ.')
    if job.action=='bulk_appeal' and job.status in ('preparing','preview','running'):
        from app.services.bulk_appeal import cancel as cancel_appeal
        await cancel_appeal(db,job)
        await record_audit(db,request,'account.bulk_cancelled',actor=auth.user,target_type='account_bulk',target_id=str(job.id))
        return await output(db,job)
    if job.status=='running':
        await db.execute(update(AccountBulkItem).where(AccountBulkItem.job_id==job.id,AccountBulkItem.status=='pending').values(status='cancelled'))
        job.status='stopping'
        await record_audit(db,request,'account.bulk_cancelled',actor=auth.user,target_type='account_bulk',target_id=str(job.id))
    return await output(db,job)


@router.post('/{job_id}/retry',status_code=202)
async def retry_errors(job_id:uuid.UUID,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    original=await db.get(AccountBulkJob,job_id)
    if not original:raise ApiError(404,'not_found','Không tìm thấy tác vụ.')
    if original.action=='bulk_appeal':raise ApiError(409,'appeal_review_required','Tạo bản xem trước mới để kháng nghị lại; không tự phát lại nội dung cũ.')
    job=AccountBulkJob(action=original.action,created_by=auth.user.id)
    db.add(job);await db.flush()
    await db.execute(insert(AccountBulkItem).from_select(['job_id','account_id','status'],
        select(literal(job.id,type_=A.id.type),AccountBulkItem.account_id,literal('pending')).where(
            AccountBulkItem.job_id==original.id,AccountBulkItem.status=='error')))
    job.total=(await db.execute(select(func.count()).select_from(AccountBulkItem).where(AccountBulkItem.job_id==job.id))).scalar_one()
    if not job.total:job.status='done'
    await record_audit(db,request,'account.bulk_retry',actor=auth.user,target_type='account_bulk',target_id=str(job.id),details={'total':job.total})
    return await output(db,job)
