import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db
from app.errors import ApiError
from app.models import ForwardJob
from app.schemas import Page
from app.schemas_forwarding import BulkJobAction, JobOut, QueueMetrics
from app.services import jobs as svc
from app.types import utcnow

router = APIRouter(prefix="/api/jobs", tags=["jobs"])
queue_router = APIRouter(prefix="/api/queue", tags=["jobs"])


@queue_router.get("/metrics", response_model=QueueMetrics)
async def queue_metrics(_: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return await svc.metrics(db, utcnow())


@router.get("", response_model=Page[JobOut])
async def list_jobs(
    status: str | None = Query(default=None, pattern="^(pending|claimed|running|succeeded|retry_wait|failed|cancelled|dead_letter)$"),
    route_id: uuid.UUID | None = None,
    account_id: uuid.UUID | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=100),
    _: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(ForwardJob)
    if status:
        stmt = stmt.where(ForwardJob.status == status)
    if route_id:
        stmt = stmt.where(ForwardJob.route_id == route_id)
    if account_id:
        stmt = stmt.where(ForwardJob.account_id == account_id)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(ForwardJob.created_at.desc(), ForwardJob.id)
                             .offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[JobOut](items=[JobOut.model_validate(r) for r in rows], total=total, page=page, page_size=page_size)


@router.post("/bulk")
async def bulk_action(body: BulkJobAction, request: Request, auth: AuthContext = Depends(authenticated),
                      db: AsyncSession = Depends(get_db, scope="function")):
    """Retry or cancel up to `limit` jobs in one state (typically the dead-letter queue)."""
    allowed = {"retry": {"failed", "dead_letter"}, "cancel": {"failed", "dead_letter", "retry_wait", "pending"}}
    if body.status not in allowed[body.action]:
        raise ApiError(409, "invalid_state", f"Không thể {body.action} các tác vụ ở trạng thái {body.status}.")
    stmt = select(ForwardJob).where(ForwardJob.status == body.status)
    if body.route_id:
        stmt = stmt.where(ForwardJob.route_id == body.route_id)
    now = utcnow()
    jobs = (await db.execute(stmt.order_by(ForwardJob.created_at).limit(body.limit))).scalars().all()
    for j in jobs:
        await (svc.requeue if body.action == "retry" else svc.cancel)(db, j, now)
    if jobs:
        await record_audit(db, request, f"job.bulk_{body.action}", actor=auth.user, target_type="job",
                           details={"status": body.status, "count": len(jobs),
                                    "route_id": str(body.route_id) if body.route_id else None})
    return {"affected": len(jobs)}


async def _get(db, job_id):
    j = await db.get(ForwardJob, job_id)
    if j is None:
        raise ApiError(404, "not_found", "Không tìm thấy tác vụ.")
    return j


@router.get("/{job_id}", response_model=JobOut)
async def get_job(job_id: uuid.UUID, _: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return await _get(db, job_id)


@router.post("/{job_id}/retry", response_model=JobOut)
async def retry_job(job_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                    db: AsyncSession = Depends(get_db, scope="function")):
    j = await _get(db, job_id)
    if j.status not in ("failed", "dead_letter"):
        raise ApiError(409, "invalid_state", "Chỉ tác vụ failed/dead_letter mới thử lại thủ công được.")
    await svc.requeue(db, j, utcnow())
    await record_audit(db, request, "job.retry", actor=auth.user, target_type="job", target_id=str(j.id))
    return j


@router.post("/{job_id}/cancel", response_model=JobOut)
async def cancel_job(job_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                     db: AsyncSession = Depends(get_db, scope="function")):
    j = await _get(db, job_id)
    if j.status == "cancelled":
        return j  # idempotent
    if j.status not in ("pending", "retry_wait", "failed", "dead_letter"):
        raise ApiError(409, "invalid_state", "Không thể hủy tác vụ đang được worker xử lý hoặc đã hoàn tất.")
    await svc.cancel(db, j, utcnow())
    await record_audit(db, request, "job.cancel", actor=auth.user, target_type="job", target_id=str(j.id))
    return j
