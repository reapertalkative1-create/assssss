import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import Role, Worker
from app.schemas import Page
from app.schemas_workers import RotateRequest, WorkerCreate, WorkerCreated, WorkerOut, WorkerUpdate
from app.services import workers as svc
from app.types import utcnow

router = APIRouter(prefix="/api/workers", tags=["workers"])
admin_only = require_role(Role.ADMIN)


def to_out(w: Worker, request: Request) -> dict:
    timeout = request.app.state.settings.heartbeat_timeout_seconds
    return {
        "id": w.id, "name": w.name, "platform": w.platform, "version": w.version, "hostname": w.hostname,
        "status": svc.effective_status(w, utcnow(), timeout), "health": w.health,
        "degraded_reason": w.degraded_reason, "running_jobs": w.running_jobs, "cpu_percent": w.cpu_percent,
        "memory_percent": w.memory_percent, "resource_reporting_enabled": w.resource_reporting_enabled,
        "last_heartbeat_at": w.last_heartbeat_at, "last_registered_at": w.last_registered_at,
        "last_ip": w.last_ip, "credential_issued_at": w.credential_issued_at,
        "revoked_at": w.revoked_at, "created_at": w.created_at,
    }


async def _get(db: AsyncSession, worker_id: uuid.UUID) -> Worker:
    w = await db.get(Worker, worker_id)
    if w is None:
        raise ApiError(404, "not_found", "Không tìm thấy worker.")
    return w


@router.get("", response_model=Page[WorkerOut])
async def list_workers(
    request: Request,
    q: str | None = Query(default=None, max_length=64),
    status: str | None = Query(default=None, pattern="^(online|offline|degraded|revoked)$"),
    platform: str | None = Query(default=None, pattern="^(linux|windows)$"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    _: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(Worker)
    if q:
        stmt = stmt.where(Worker.name_key.contains(q.strip().lower(), autoescape=True))
    if platform:
        stmt = stmt.where(Worker.platform == platform)
    if status:
        stmt = stmt.where(svc.status_clause(status, utcnow(), request.app.state.settings.heartbeat_timeout_seconds))
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(Worker.created_at.desc(), Worker.name_key)
                             .offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[WorkerOut](items=[to_out(w, request) for w in rows], total=total, page=page, page_size=page_size)


@router.post("", response_model=WorkerCreated, status_code=201)
async def create_worker(body: WorkerCreate, request: Request, auth: AuthContext = Depends(admin_only),
                        db: AsyncSession = Depends(get_db, scope="function")):
    worker, credential = svc.create_worker(db, body.name, body.platform, auth.user.id)
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên worker đã tồn tại.") from None
    await record_audit(db, request, "worker.create", actor=auth.user, target_type="worker", target_id=str(worker.id),
                       details={"name": worker.name, "platform": worker.platform})
    return {**to_out(worker, request), "credential": credential}


@router.get("/{worker_id}", response_model=WorkerOut)
async def get_worker_detail(worker_id: uuid.UUID, request: Request, _: AuthContext = Depends(authenticated),
                            db: AsyncSession = Depends(get_db, scope="function")):
    return to_out(await _get(db, worker_id), request)


@router.patch("/{worker_id}", response_model=WorkerOut)
async def update_worker(worker_id: uuid.UUID, body: WorkerUpdate, request: Request,
                        auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    w = await _get(db, worker_id)
    changed = []
    if body.name is not None and body.name != w.name:
        w.name, w.name_key = body.name, body.name.lower()
        changed.append("name")
    if body.resource_reporting_enabled is not None and body.resource_reporting_enabled != w.resource_reporting_enabled:
        w.resource_reporting_enabled = body.resource_reporting_enabled
        if not body.resource_reporting_enabled:
            w.cpu_percent = w.memory_percent = None
        changed.append("resource_reporting_enabled")
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên worker đã tồn tại.") from None
    if changed:
        await record_audit(db, request, "worker.update", actor=auth.user, target_type="worker",
                           target_id=str(w.id), details={"changed": changed})
    return to_out(w, request)


@router.post("/{worker_id}/rotate-credential", response_model=WorkerCreated)
async def rotate_credential(worker_id: uuid.UUID, request: Request, body: RotateRequest | None = None,
                            auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    w = await _get(db, worker_id)
    grace = body.grace_seconds if body and body.grace_seconds is not None \
        else request.app.state.settings.worker_credential_grace_seconds
    credential = svc.rotate_credential(w, grace)
    await record_audit(db, request, "worker.rotate_credential", actor=auth.user, target_type="worker",
                       target_id=str(w.id), details={"grace_seconds": grace})
    return {**to_out(w, request), "credential": credential}


@router.post("/{worker_id}/revoke", response_model=WorkerOut)
async def revoke_worker(worker_id: uuid.UUID, request: Request, auth: AuthContext = Depends(admin_only),
                        db: AsyncSession = Depends(get_db, scope="function")):
    """Idempotent: revoking an already revoked worker returns its current state."""
    w = await _get(db, worker_id)
    if svc.revoke(w):
        await record_audit(db, request, "worker.revoke", actor=auth.user, target_type="worker", target_id=str(w.id))
    return to_out(w, request)
