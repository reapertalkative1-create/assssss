from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import AuthContext, get_db, require_role
from app.models import AuditLog, Role
from app.schemas import AuditOut, Page

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("", response_model=Page[AuditOut])
async def list_audit(
    action: str | None = Query(default=None, max_length=64, description="Exact action or prefix ending with '.'"),
    actor: str | None = Query(default=None, max_length=32),
    since: datetime | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=100),
    _: AuthContext = Depends(require_role(Role.ADMIN)),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(AuditLog)
    if action:
        stmt = stmt.where(AuditLog.action.startswith(action, autoescape=True) if action.endswith(".") else AuditLog.action == action)
    if actor:
        stmt = stmt.where(AuditLog.actor_username == actor.strip().lower())
    if since:
        stmt = stmt.where(AuditLog.occurred_at >= since)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(AuditLog.occurred_at.desc(), AuditLog.id.desc()).offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[AuditOut](items=[AuditOut.model_validate(r) for r in rows], total=total, page=page, page_size=page_size)
