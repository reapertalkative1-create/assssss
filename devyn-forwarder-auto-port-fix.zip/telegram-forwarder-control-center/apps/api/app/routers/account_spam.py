import hashlib
import json
import uuid
from datetime import timedelta
from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models import TelegramAccount, WorkerCommand, Role
from app.deps import AuthContext,get_db,require_role
from app.audit import record_audit
from app.errors import ApiError
from app.schemas_accounts import SpamActionRequest
from app.services import accounts as svc
from app.services.spam import load_report,token
from app.types import utcnow
router=APIRouter(prefix='/api/accounts',tags=['account-spam'])
admin=require_role(Role.ADMIN)


async def account(db,aid):
    a=(await db.execute(select(TelegramAccount).where(TelegramAccount.id==aid).with_for_update())).scalar_one_or_none()
    if not a or a.pending_deletion:raise ApiError(404,'not_found','Không tìm thấy tài khoản.')
    return a


def box_for(request):
    box=request.app.state.secret_box
    if box is None:raise ApiError(503,'encryption_not_configured','Chưa cấu hình khóa mã hóa.')
    return box


async def ready(db,a,request):
    if a.auth_state!='authorized' or not a.session_ciphertext:raise ApiError(409,'invalid_state','Cần xác thực session trước.')
    if a.flood_wait_until and a.flood_wait_until>utcnow():raise ApiError(429,'flood_wait','Telegram yêu cầu chờ trước khi thao tác tiếp.')
    await svc.worker_can_take_commands(db,a.assigned_worker_id,request.app.state.settings.heartbeat_timeout_seconds,utcnow())


async def pending(db,a):
    return (await db.execute(select(WorkerCommand).where(WorkerCommand.account_id==a.id,
        WorkerCommand.type.in_(('spam_check','spam_read','spam_reply','import_session')),
        WorkerCommand.status.in_(('pending','delivered')),WorkerCommand.expires_at>utcnow()))).scalars().first()


@router.get('/{aid}/spam')
async def report(aid:uuid.UUID,request:Request,_:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    a=await account(db,aid);value=load_report(box_for(request),a)
    cmd=await pending(db,a)
    return {'status':a.spam_status,'checked_at':a.spam_checked_at,'error_code':a.spam_error,
        'action_status':a.spam_action_status,'report':value,'report_token':token(value) if value else None,
        'pending_command_id':str(cmd.id) if cmd else None}


@router.post('/{aid}/spam/check',status_code=202)
async def check(aid:uuid.UUID,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    a=await account(db,aid);box=box_for(request);await ready(db,a,request)
    old=await pending(db,a)
    if old:return {'command_id':str(old.id),'status':old.status}
    now=utcnow()
    if a.spam_last_action_at and a.spam_last_action_at+timedelta(minutes=15)>now:
        raise ApiError(409,'appeal_in_progress','Vừa gửi tương tác. Dùng Lấy phản hồi mới để tránh khởi động lại cuộc hội thoại.')
    if a.spam_checked_at and a.spam_checked_at+timedelta(seconds=30)>now:
        raise ApiError(429,'spam_check_cooldown','Vừa kiểm tra; hãy chờ ít nhất 30 giây.')
    cmd=svc.create_command(db,box,worker_id=a.assigned_worker_id,account_id=a.id,type='spam_check',payload=None,
        ttl=3600,created_by=auth.user.id,now=now)
    await record_audit(db,request,'account.spam_check',actor=auth.user,target_type='account',target_id=str(a.id))
    return {'command_id':str(cmd.id),'status':cmd.status}


@router.post('/{aid}/spam/read',status_code=202)
async def read(aid:uuid.UUID,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    a=await account(db,aid);box=box_for(request);await ready(db,a,request)
    old=await pending(db,a)
    if old:return {'command_id':str(old.id),'status':old.status}
    cmd=svc.create_command(db,box,worker_id=a.assigned_worker_id,account_id=a.id,type='spam_read',payload=None,
        ttl=600,created_by=auth.user.id,now=utcnow())
    await record_audit(db,request,'account.spam_read',actor=auth.user,target_type='account',target_id=str(a.id))
    return {'command_id':str(cmd.id),'status':cmd.status}


@router.post('/{aid}/spam/action',status_code=202)
async def action(aid:uuid.UUID,body:SpamActionRequest,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    a=await account(db,aid);box=box_for(request)
    old=await db.get(WorkerCommand,body.request_id)
    if old:
        if old.account_id!=a.id or old.type!='spam_reply':raise ApiError(409,'request_conflict','Mã yêu cầu đã được dùng.')
        return {'command_id':str(old.id),'status':old.status}
    await ready(db,a,request)
    if await pending(db,a):raise ApiError(409,'spam_action_pending','Đợi thao tác đang xử lý hoàn tất.')
    value=load_report(box,a)
    if not value or token(value)!=body.report_token:raise ApiError(409,'stale_spam_report','Phản hồi SpamBot đã thay đổi. Hãy lấy phản hồi mới.')
    payload={'operation':body.operation}
    if body.operation=='reply':
        text=body.text.get_secret_value().strip() if body.text else ''
        if not text or not value.get('message_id'):raise ApiError(422,'invalid_appeal','Nhập nội dung thực tế và kiểm tra SpamBot trước.')
        payload.update(text=text,expected_reply_id=value['message_id'])
    else:
        button=next((b for b in value.get('buttons',[]) if b['id']==body.button_id),None)
        if not button:raise ApiError(422,'invalid_spambot_button','Nút không còn trong phản hồi hiện tại.')
        payload.update(button_id=button['id'],expected_button_text=button['text'])
    fingerprint=hashlib.sha256((body.report_token+json.dumps(payload,sort_keys=True)).encode()).hexdigest()
    if a.spam_last_action_ref==fingerprint:raise ApiError(409,'spam_action_duplicate','Thao tác này đã được gửi; lấy phản hồi mới, không gửi lặp.')
    now=utcnow()
    if a.spam_last_action_at and a.spam_last_action_at+timedelta(seconds=10)>now:
        raise ApiError(429,'spam_action_cooldown','Hãy chờ 10 giây giữa các tương tác.')
    cmd=svc.create_command(db,box,worker_id=a.assigned_worker_id,account_id=a.id,type='spam_reply',payload=payload,
        ttl=600,created_by=auth.user.id,now=now,command_id=body.request_id)
    a.spam_last_action_ref=fingerprint;a.spam_last_action_at=now;a.spam_action_status='queued'
    await record_audit(db,request,'account.spam_action',actor=auth.user,target_type='account',target_id=str(a.id),details={'operation':body.operation})
    return {'command_id':str(cmd.id),'status':cmd.status}
