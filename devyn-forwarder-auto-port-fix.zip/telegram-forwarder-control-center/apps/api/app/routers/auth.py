from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import COOKIE_NAME, AuthContext, authenticated, get_db
from app.errors import ApiError
from app.models import User, WebSession
from app.schemas import ChangePasswordRequest, LoginRequest, SessionOut, UserOut
from app.security import (
    averify_dummy,
    averify_password,
    ahash_password,
    hash_token,
    needs_rehash,
    new_token,
    validate_password_policy,
)
from app.services.sessions import revoke_user_sessions
from app.types import utcnow
from app.utils import client_ip

router = APIRouter(prefix="/api/auth", tags=["auth"])

_GENERIC_LOGIN_ERROR = "Sai tên đăng nhập hoặc mật khẩu, hoặc tài khoản đang bị khóa tạm thời."


def _lock_seconds(settings, failures: int) -> int:
    extra = max(0, failures - settings.login_lock_threshold)
    return min(settings.login_lock_base_seconds * (2**extra), settings.login_lock_max_seconds)


@router.post("/login", response_model=SessionOut)
async def login(body: LoginRequest, request: Request, response: Response, db: AsyncSession = Depends(get_db, scope="function")):
    settings = request.app.state.settings
    limiter = request.app.state.login_limiter
    ip = client_ip(request) or "unknown"
    username = body.username.strip().lower()
    now = utcnow()

    if limiter.is_limited(ip):
        await record_audit(db, request, "auth.login_blocked", details={"reason": "ip_rate_limit"})
        await db.commit()
        raise ApiError(429, "too_many_attempts", "Quá nhiều lần thử. Vui lòng thử lại sau.")

    user = (await db.execute(select(User).where(User.username == username))).scalar_one_or_none()
    locked = user is not None and user.locked_until is not None and user.locked_until > now

    if user is None or not user.is_active or locked:
        await averify_dummy(body.password)  # same cost whether or not the account exists
        limiter.record(ip)
        reason = "unknown_user" if user is None else ("inactive" if not user.is_active else "locked")
        await record_audit(
            db, request, "auth.login_blocked" if user is not None else "auth.login_failed",
            actor=user, details={"reason": reason},
        )
        await db.commit()
        raise ApiError(401, "invalid_credentials", _GENERIC_LOGIN_ERROR)

    if not await averify_password(user.password_hash, body.password):
        limiter.record(ip)
        user.failed_login_count += 1
        details = {"reason": "bad_password", "failed_count": user.failed_login_count}
        await record_audit(db, request, "auth.login_failed", actor=user, details=details)
        if user.failed_login_count >= settings.login_lock_threshold:
            seconds = _lock_seconds(settings, user.failed_login_count)
            user.locked_until = now + timedelta(seconds=seconds)
            await record_audit(db, request, "auth.account_locked", actor=user, details={"lock_seconds": seconds})
        await db.commit()
        raise ApiError(401, "invalid_credentials", _GENERIC_LOGIN_ERROR)

    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now
    if needs_rehash(user.password_hash):
        user.password_hash = await ahash_password(body.password)

    token, csrf = new_token(), new_token()
    db.add(
        WebSession(
            user_id=user.id,
            token_hash=hash_token(token),
            csrf_token=csrf,
            expires_at=now + timedelta(seconds=settings.session_ttl_seconds),
            ip=ip[:45],
            user_agent=(request.headers.get("user-agent") or "")[:255] or None,
        )
    )
    await record_audit(db, request, "auth.login", actor=user)
    response.set_cookie(
        COOKIE_NAME, token, max_age=settings.session_ttl_seconds, path="/",
        httponly=True, secure=settings.cookie_secure, samesite="lax",
    )
    return SessionOut(user=UserOut.model_validate(user), csrf_token=csrf)


@router.get("/me", response_model=SessionOut)
async def me(auth: AuthContext = Depends(authenticated)):
    return SessionOut(user=UserOut.model_validate(auth.user), csrf_token=auth.session.csrf_token)


@router.post("/logout", status_code=204)
async def logout(request: Request, auth: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    auth.session.revoked_at = utcnow()
    await record_audit(db, request, "auth.logout", actor=auth.user)
    response = Response(status_code=204)
    response.delete_cookie(COOKIE_NAME, path="/")
    return response


@router.post("/change-password", status_code=204)
async def change_password(
    body: ChangePasswordRequest,
    request: Request,
    auth: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    user = auth.user
    if not await averify_password(user.password_hash, body.current_password):
        await record_audit(db, request, "auth.password_change_failed", actor=user)
        await db.commit()
        raise ApiError(400, "wrong_password", "Mật khẩu hiện tại không đúng.")
    problem = validate_password_policy(body.new_password, user.username)
    if problem:
        raise ApiError(422, "weak_password", problem)
    user.password_hash = await ahash_password(body.new_password)
    await revoke_user_sessions(db, user.id, except_session_id=auth.session.id)
    await record_audit(db, request, "auth.password_changed", actor=user)
    return Response(status_code=204)


@router.post("/logout-others")
async def logout_other_sessions(request: Request, auth: AuthContext = Depends(authenticated),
                                db: AsyncSession = Depends(get_db, scope="function")):
    """Revokes every other browser session of the current user (keeps this one)."""
    from sqlalchemy import func, select as sa_select
    from app.models import WebSession

    others = (await db.execute(sa_select(func.count()).select_from(WebSession).where(
        WebSession.user_id == auth.user.id, WebSession.revoked_at.is_(None), WebSession.id != auth.session.id,
        WebSession.expires_at > utcnow()))).scalar_one()
    await revoke_user_sessions(db, auth.user.id, except_session_id=auth.session.id)
    await record_audit(db, request, "auth.logout_others", actor=auth.user, details={"sessions": others})
    return {"revoked": others}
