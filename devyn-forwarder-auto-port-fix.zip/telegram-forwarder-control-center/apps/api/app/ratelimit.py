import time
from collections import defaultdict, deque
from collections.abc import Callable


class SlidingWindowLimiter:
    """In-memory, per-process limiter. A Redis-backed variant replaces it when running multiple API processes."""

    def __init__(self, max_events: int, window_seconds: float, clock: Callable[[], float] = time.monotonic):
        self.max_events, self.window, self._clock = max_events, window_seconds, clock
        self._events: dict[str, deque[float]] = defaultdict(deque)

    def _prune(self, key: str) -> deque[float]:
        q = self._events[key]
        cutoff = self._clock() - self.window
        while q and q[0] <= cutoff:
            q.popleft()
        if not q:
            self._events.pop(key, None)
            return deque()
        return q

    def is_limited(self, key: str) -> bool:
        return len(self._prune(key)) >= self.max_events

    def record(self, key: str) -> None:
        self._prune(key)
        self._events[key].append(self._clock())

    def reset(self, key: str) -> None:
        self._events.pop(key, None)
