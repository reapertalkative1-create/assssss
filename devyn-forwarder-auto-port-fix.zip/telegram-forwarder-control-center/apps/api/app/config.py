"""Typed settings loaded from environment (prefix TFCC_). No secrets are hardcoded."""
from functools import lru_cache
from typing import Literal

from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TFCC_", env_file=".env", extra="ignore")

    env: Literal["development", "production"] = "development"
    database_url: str = "postgresql+asyncpg://tfcc:change-me@localhost:5432/tfcc"
    redis_url: str = "redis://localhost:6379/0"
    secret_key: SecretStr = SecretStr("")
    session_encryption_key: SecretStr = SecretStr("")  # one Fernet key, or several comma-separated (first = primary)
    session_encryption_key_file: str = ""               # alternative: file holding the key(s); must be mode 0600 on POSIX
    allowed_origins: str = ""
    cookie_secure: bool = True
    heartbeat_timeout_seconds: int = 60

    # Web sessions
    session_ttl_seconds: int = 43200        # absolute lifetime (12h)
    session_idle_seconds: int = 7200        # idle timeout (2h)

    # Login protection
    login_lock_threshold: int = 5           # failures before the account is temporarily locked
    login_lock_base_seconds: int = 60       # first lock duration; doubles per extra failure
    login_lock_max_seconds: int = 900
    login_ip_max_attempts: int = 20         # failed attempts per IP per window (per process)
    login_ip_window_seconds: int = 300
    worker_heartbeat_interval_seconds: int = 15      # suggested to workers at registration
    worker_credential_grace_seconds: int = 600       # old credential stays valid this long after rotation
    worker_sweep_interval_seconds: float = 10.0      # offline detector period; 0 disables it
    worker_auth_ip_max_attempts: int = 30            # failed worker authentications per IP per window
    account_lease_ttl_seconds: int = 60              # a Telegram session has ONE owner worker per lease
    command_ttl_seconds: int = 300                   # interactive commands (login/OTP) expire after this
    job_lease_ttl_seconds: int = 120                 # a claimed job not finished in time is recovered
    job_retry_base_seconds: float = 5.0              # retry delay = base * 2^(attempt-1), capped, +-20% jitter
    job_retry_cap_seconds: float = 900.0
    account_rate_per_minute: int = 30                # hard cap of forwards per Telegram account per minute
    trust_proxy_headers: bool = False       # true only behind our own Nginx (uses X-Real-IP)

    @field_validator("heartbeat_timeout_seconds")
    @classmethod
    def _positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("heartbeat_timeout_seconds must be > 0")
        return v

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in self.allowed_origins.split(",") if o.strip()]

    def assert_production_ready(self) -> None:
        """Refuse to start in production with missing/unsafe secrets."""
        if self.env != "production":
            return
        problems = []
        if len(self.secret_key.get_secret_value()) < 32:
            problems.append("TFCC_SECRET_KEY must be at least 32 characters")
        if not self.session_encryption_key.get_secret_value() and not self.session_encryption_key_file:
            problems.append("TFCC_SESSION_ENCRYPTION_KEY (or _FILE) is required")
        if not self.cookie_secure:
            problems.append("TFCC_COOKIE_SECURE must be true in production")
        if "*" in self.cors_origins:
            problems.append("TFCC_ALLOWED_ORIGINS must not contain '*'")
        if problems:
            raise RuntimeError("Unsafe production configuration: " + "; ".join(problems))


@lru_cache
def get_settings() -> Settings:
    return Settings()
