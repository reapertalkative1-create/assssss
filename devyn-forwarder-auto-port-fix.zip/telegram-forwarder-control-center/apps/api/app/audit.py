import uuid

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AuditLog, User
from app.utils import client_ip

_FORBIDDEN_KEYS = ("password", "token", "secret", "session", "otp", "hash", "credential")


def _clean(details: dict | None) -> dict | None:
    if not details:
        return None
    return {k: v for k, v in details.items() if not any(f in k.lower() for f in _FORBIDDEN_KEYS)}


async def record_audit(
    db: AsyncSession,
    request: Request,
    action: str,
    *,
    actor: User | None = None,
    actor_username: str | None = None,
    actor_id: uuid.UUID | None = None,
    target_type: str | None = None,
    target_id: str | None = None,
    details: dict | None = None,
) -> None:
    db.add(
        AuditLog(
            actor_user_id=actor.id if actor else actor_id,
            actor_username=actor.username if actor else actor_username,
            action=action,
            target_type=target_type,
            target_id=target_id,
            ip=client_ip(request),
            request_id=getattr(request.state, "request_id", None),
            details=_clean(details),
        )
    )


def record_system_audit(
    db: AsyncSession,
    action: str,
    *,
    target_type: str | None = None,
    target_id: str | None = None,
    details: dict | None = None,
) -> None:
    """Audit entry for events with no HTTP request (background detectors)."""
    db.add(AuditLog(actor_username="system", action=action, target_type=target_type,
                    target_id=target_id, details=_clean(details)))
