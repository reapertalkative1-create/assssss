from fastapi import Request


def client_ip(request: Request) -> str | None:
    if request.app.state.settings.trust_proxy_headers:
        real = request.headers.get("x-real-ip", "").strip()
        if real:
            return real[:45]
    return request.client.host if request.client else None
