import uuid
from datetime import datetime

from sqlalchemy import JSON, BigInteger, ForeignKey, Index, Integer, PrimaryKeyConstraint, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base
from app.types import UTCDateTime, utcnow


class ForwardRoute(Base):
    """source chat(s) -> destination chat(s) through one Telegram account. N sources x M destinations is allowed."""

    __tablename__ = "forward_routes"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("telegram_accounts.id", ondelete="CASCADE"), index=True)
    source_chat_ids: Mapped[list] = mapped_column(JSON)
    destination_chat_ids: Mapped[list] = mapped_column(JSON)
    mode: Mapped[str] = mapped_column(String(8), default="forward")  # forward (native) | copy (no "forwarded from")
    filters: Mapped[dict] = mapped_column(JSON, default=dict)
    priority: Mapped[int] = mapped_column(Integer, default=5)          # 1 = most urgent ... 9 = least
    rate_per_minute: Mapped[int] = mapped_column(Integer, default=20)
    max_attempts: Mapped[int] = mapped_column(Integer, default=5)
    status: Mapped[str] = mapped_column(String(12), default="stopped", index=True)  # stopped | active | paused
    verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    verification: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # {chat_id: {ok, can_send, title}}
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class RouteCheckpoint(Base):
    """Highest message id of a source chat already handed to the queue; lets a restarted worker catch up."""

    __tablename__ = "route_checkpoints"
    __table_args__ = (PrimaryKeyConstraint("route_id", "source_chat_id"),)

    route_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("forward_routes.id", ondelete="CASCADE"))
    source_chat_id: Mapped[int] = mapped_column(BigInteger)
    last_message_id: Mapped[int] = mapped_column(BigInteger)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ForwardJob(Base):
    """One message -> one destination. States and transitions: packages/shared-schemas/job_states.json.
    Delivery is at-least-once; idempotency_key (unique) prevents the same message being queued twice.
    The message content is never stored, only ids."""

    __tablename__ = "forward_jobs"
    __table_args__ = (
        Index("ix_forward_jobs_claim", "status", "priority", "available_at"),
        Index("ix_forward_jobs_account_claimed", "account_id", "claimed_at"),
        Index("ix_forward_jobs_route_status", "route_id", "status"),
    )

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    route_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("forward_routes.id", ondelete="CASCADE"))
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("telegram_accounts.id", ondelete="CASCADE"))
    source_chat_id: Mapped[int] = mapped_column(BigInteger)
    message_id: Mapped[int] = mapped_column(BigInteger)
    dest_chat_id: Mapped[int] = mapped_column(BigInteger)
    idempotency_key: Mapped[str] = mapped_column(String(120), unique=True)
    status: Mapped[str] = mapped_column(String(12), default="pending")
    priority: Mapped[int] = mapped_column(Integer, default=5)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=5)
    available_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    claim_epoch: Mapped[int] = mapped_column(Integer, default=0)  # fencing token for result reports
    lease_worker_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    lease_expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    claimed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
