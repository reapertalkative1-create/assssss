import uuid
from datetime import datetime

from sqlalchemy import Boolean, Float, Integer, String, true
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base
from app.types import UTCDateTime, utcnow


class Worker(Base):
    """A remote Telegram worker. Only SHA-256 hashes of its credentials are stored."""

    __tablename__ = "workers"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)  # lowercase name, enforces uniqueness
    platform: Mapped[str] = mapped_column(String(16))  # linux | windows (expected; verified at registration)
    version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    hostname: Mapped[str | None] = mapped_column(String(128), nullable=True)

    credential_hash: Mapped[str] = mapped_column(String(64))
    credential_issued_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    previous_credential_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    previous_valid_until: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)

    status: Mapped[str] = mapped_column(String(16), default="offline", index=True)  # online|offline|degraded|revoked
    health: Mapped[str] = mapped_column(String(16), default="ok")  # as reported by the worker: ok|degraded
    degraded_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    running_jobs: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    cpu_percent: Mapped[float | None] = mapped_column(Float, nullable=True)
    memory_percent: Mapped[float | None] = mapped_column(Float, nullable=True)
    resource_reporting_enabled: Mapped[bool] = mapped_column(Boolean, default=True, server_default=true())

    last_registered_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_heartbeat_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True, index=True)
    last_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
