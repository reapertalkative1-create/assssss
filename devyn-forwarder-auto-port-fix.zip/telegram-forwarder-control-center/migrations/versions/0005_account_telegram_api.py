"""Encrypted per-account Telegram application credentials."""
from alembic import op
import sqlalchemy as sa

revision = '0005'
down_revision = '0004'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('telegram_accounts', sa.Column('telegram_api_ciphertext', sa.Text(), nullable=True))


def downgrade():
    op.drop_column('telegram_accounts', 'telegram_api_ciphertext')
