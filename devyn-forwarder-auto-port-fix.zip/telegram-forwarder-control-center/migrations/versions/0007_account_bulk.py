"""Durable bulk management and session health."""
from alembic import op
import sqlalchemy as sa
from app.types import UTCDateTime
revision='0007'
down_revision='0006'
branch_labels=None
depends_on=None


def upgrade():
    op.add_column('telegram_accounts',sa.Column('health_status',sa.String(16),nullable=False,server_default='unknown'))
    op.add_column('telegram_accounts',sa.Column('health_checked_at',UTCDateTime(),nullable=True))
    op.add_column('telegram_accounts',sa.Column('health_error',sa.String(64),nullable=True))
    op.add_column('telegram_accounts',sa.Column('health_override',sa.String(16),nullable=True))
    op.create_index('ix_telegram_accounts_health_status','telegram_accounts',['health_status'])
    op.create_table('account_bulk_jobs',sa.Column('id',sa.Uuid(),primary_key=True),
        sa.Column('action',sa.String(24),nullable=False),sa.Column('status',sa.String(16),nullable=False),
        sa.Column('total',sa.Integer(),nullable=False),sa.Column('created_by',sa.Uuid(),nullable=True),
        sa.Column('created_at',UTCDateTime(),nullable=False),sa.Column('updated_at',UTCDateTime(),nullable=False))
    op.create_index('ix_account_bulk_jobs_status','account_bulk_jobs',['status'])
    op.create_table('account_bulk_items',sa.Column('job_id',sa.Uuid(),sa.ForeignKey('account_bulk_jobs.id',ondelete='CASCADE'),primary_key=True),
        sa.Column('account_id',sa.Uuid(),primary_key=True),sa.Column('status',sa.String(16),nullable=False),
        sa.Column('error_code',sa.String(64),nullable=True),sa.Column('command_id',sa.Uuid(),nullable=True))
    op.create_index('ix_account_bulk_items_status','account_bulk_items',['status'])
    op.create_index('ix_account_bulk_items_command_id','account_bulk_items',['command_id'])


def downgrade():
    op.drop_table('account_bulk_items');op.drop_table('account_bulk_jobs')
    op.drop_index('ix_telegram_accounts_health_status',table_name='telegram_accounts')
    for name in ('health_override','health_error','health_checked_at','health_status'):op.drop_column('telegram_accounts',name)
