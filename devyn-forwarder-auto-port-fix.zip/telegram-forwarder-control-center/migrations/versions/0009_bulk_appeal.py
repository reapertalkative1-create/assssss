"""Encrypted bulk appeal drafts, reviewed before sending."""
from alembic import op
import sqlalchemy as sa
revision='0009'
down_revision='0008'
branch_labels=None
depends_on=None


def upgrade():
    op.add_column('account_bulk_jobs',sa.Column('settings_ciphertext',sa.Text(),nullable=True))
    op.add_column('account_bulk_jobs',sa.Column('review_token',sa.String(64),nullable=True))
    op.add_column('account_bulk_items',sa.Column('payload_ciphertext',sa.Text(),nullable=True))


def downgrade():
    op.drop_column('account_bulk_items','payload_ciphertext')
    op.drop_column('account_bulk_jobs','review_token')
    op.drop_column('account_bulk_jobs','settings_ciphertext')
