"""Deduplicate uploaded session auth keys."""
from alembic import op
import sqlalchemy as sa
revision = '0006'
down_revision = '0005'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('telegram_accounts', sa.Column('import_fingerprint', sa.String(64), nullable=True))
    op.create_index('ix_telegram_accounts_import_fingerprint', 'telegram_accounts', ['import_fingerprint'], unique=True)


def downgrade():
    op.drop_index('ix_telegram_accounts_import_fingerprint', table_name='telegram_accounts')
    op.drop_column('telegram_accounts', 'import_fingerprint')
