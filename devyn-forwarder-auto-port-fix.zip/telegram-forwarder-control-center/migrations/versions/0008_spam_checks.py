"""SpamBot diagnostics and encrypted conversation snapshots."""
from alembic import op
import sqlalchemy as sa
from app.types import UTCDateTime
revision='0008'
down_revision='0007'
branch_labels=None
depends_on=None


def upgrade():
    for name,size,default in [('spam_status',16,'not_checked'),('spam_action_status',16,'none')]:
        op.add_column('telegram_accounts',sa.Column(name,sa.String(size),nullable=False,server_default=default))
    for name in ('spam_checked_at','spam_last_action_at'):op.add_column('telegram_accounts',sa.Column(name,UTCDateTime(),nullable=True))
    for name in ('spam_error','spam_last_action_ref'):op.add_column('telegram_accounts',sa.Column(name,sa.String(64),nullable=True))
    op.add_column('telegram_accounts',sa.Column('spam_reply_ciphertext',sa.Text(),nullable=True))
    op.create_index('ix_telegram_accounts_spam_status','telegram_accounts',['spam_status'])


def downgrade():
    op.drop_index('ix_telegram_accounts_spam_status',table_name='telegram_accounts')
    for name in ('spam_reply_ciphertext','spam_last_action_ref','spam_error','spam_last_action_at','spam_checked_at','spam_action_status','spam_status'):
        op.drop_column('telegram_accounts',name)
