@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows.ps1" -Mode Run
set "result=%errorlevel%"
if not "%result%"=="0" (
    echo.
    echo Start failed. Read the message above.
    pause
)
exit /b %result%
