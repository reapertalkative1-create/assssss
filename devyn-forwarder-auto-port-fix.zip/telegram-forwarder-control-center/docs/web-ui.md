# Web dashboard (Phase 6)

React 18 + TypeScript + Vite, Vietnamese UI, no UI framework or external fonts/scripts (self-contained; works under a strict CSP).
Light/dark/auto theme. Responsive: the left navigation becomes a drawer below 880 px.

## Pages and the API they use
| Page | Who | Real endpoints |
|---|---|---|
| Đăng nhập | all | `POST /api/auth/login`, `GET /api/auth/me` |
| Tổng quan | all | `GET /api/dashboard/summary` (polled every 10 s) |
| Tài khoản Telegram | all (admin manages) | `/api/accounts…` incl. login wizard (`login/start`, `login/code`, `login/password` + command polling), `check`, `start/stop`, `assignment`, `delete` |
| Tuyến chuyển tiếp | all (admin creates/edits/deletes) | `/api/routes…` incl. `verify`, `start/pause/resume/stop` |
| Hàng đợi tác vụ | all | `/api/jobs`, `/api/jobs/bulk`, `/api/queue/metrics` |
| Nhật ký trực tiếp | all | WebSocket `/api/ws/events` |
| Worker & máy chủ | all (admin manages) | `/api/workers…` incl. one-time credential, rotate, revoke |
| Người dùng, Nhật ký kiểm toán | admin | `/api/users…`, `/api/audit` |
| Cài đặt | all (system block: admin) | `/api/auth/change-password`, `/api/auth/logout-others`, `/api/system/info` |

Nothing in the UI is mock data. Every button calls the API, and a dialog reports success only after the server answered:
`ConfirmDialog` stays open and shows the server's error if the call fails. Dangerous actions (delete account/route, revoke worker) require
retyping the name. Role checks are enforced by the backend; the UI only hides what a role cannot use.

## Security notes
- The session cookie is `HttpOnly`; JavaScript never sees it. The CSRF token is kept in memory only and sent as `X-CSRF-Token` on non-GET calls.
- Secrets typed into the UI (phone, OTP, 2FA password, new passwords) are dropped from component state as soon as they are sent, are never put in the URL,
  never logged and never stored in `localStorage` (only the theme choice is).
- Worker credentials are shown once in a dialog that cannot be closed until the person confirms they saved it.
- The realtime stream is read-only. The server checks the session cookie **and** the `Origin` header (blocks cross-site WebSocket hijacking),
  re-validates the session every 30 s (logout, password change or deactivation disconnect it) and filters events by role
  (operators do not receive login/user events). Events carry ids and counters only, never message text.
- The browser reconnects with exponential backoff (1 s → 30 s, jittered) and resumes from the last cursor, so no events are missed or repeated.
  Close codes `4401` (not authenticated) and `1008` (forbidden origin) stop retrying and sign the user out.
- Behind a reverse proxy, forward `Host`, `Upgrade` and `Connection` headers (done in `deploy/nginx`, Phase 7), otherwise the Origin check rejects the socket.

## Development
```bash
cd apps/web && npm install
npm run dev          # http://localhost:5173, proxies /api (incl. WebSocket) to the API on :8000
npm run test         # vitest + jsdom
npm run build        # type-check + production bundle in dist/
```
Set `TFCC_COOKIE_SECURE=false` for the API when developing over plain http.

## Design
A cool paper-grey surface with a harbour-blue accent (dark mode: blue-navy). Status is never colour-only: pills carry a shape (circle, diamond, square,
hollow circle) as well as text. The one deliberate flourish is the pipeline strip on the dashboard (Worker → Tài khoản → Tuyến → Hàng đợi), which mirrors the
real data flow and turns amber/red at the stage where something is wrong; everything else stays quiet and dense for daily operation.

## Not verified
The UI has been tested with jsdom (behaviour, validation, secrets handling, reconnect logic) and its CSS class names are checked against the stylesheet,
but it has **not been looked at in a real browser** in this environment: layout, spacing, colour contrast, the mobile drawer and the dark theme need a visual check.
