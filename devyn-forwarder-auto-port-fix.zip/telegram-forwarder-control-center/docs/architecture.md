# Architecture

## Components
- **apps/api** — FastAPI control plane. Orchestrates only; never runs long Telegram work inside an HTTP request.
- **apps/web** — React + TypeScript + Vite dashboard.
- **workers/telegram-worker** — Telethon/asyncio worker; same code on Linux and Windows.
- **PostgreSQL** — source of truth for configuration, jobs, leases, audit.
- **Redis** — rate limiting, pub/sub for realtime logs, cache. Not a job queue.

## Decision 001 — Job queue lives in PostgreSQL
Workers are remote and connect outbound over HTTPS/WebSocket; Redis and PostgreSQL are never exposed
to the Internet. RQ/Celery require workers to reach Redis directly, which contradicts that model.
Therefore:
- Job state machine (see `packages/shared-schemas/job_states.json`) is stored in PostgreSQL.
- Workers claim jobs through the API; the API claims with `SELECT … FOR UPDATE SKIP LOCKED` plus a lease.
- Idempotency keys + unique constraints give at-least-once delivery with de-duplication
  (no exactly-once claim — Telegram does not guarantee it).
- Only one queue system exists.

## Decision 002 — Linux worker runs under systemd + venv
Same operating model as Windows (own venv, service manager, auto-restart). Docker is a documented alternative.

## Security baseline (enforced from Phase 2)
Argon2id, HttpOnly/Secure/SameSite cookies, CSRF, RBAC checked on the backend, revocable worker credentials,
Telegram sessions encrypted with a key stored separately from the database, no secrets in logs or Git.
