# Worker ↔ control plane protocol (Phase 3)

Workers connect **outbound over HTTPS only** (no inbound ports). WebSocket is used for the dashboard's
realtime logs (Phase 6); worker traffic stays plain request/response so it works through any proxy.

## Credential lifecycle
- An administrator creates a worker in the dashboard (`POST /api/workers`) and receives a credential **once**:
  `tfw_<worker-id-hex>.<256-bit secret>`. Only its SHA-256 is stored; it is never returned again or logged.
- **Rotate** (`POST /api/workers/{id}/rotate-credential`): issues a new credential. The previous one keeps working for a
  grace period (default 600 s, `grace_seconds` 0–3600, 0 = cut over immediately) so the worker config can be updated.
- **Revoke** (`POST /api/workers/{id}/revoke`): immediate and permanent; idempotent. The worker gets `403 worker_revoked`
  on its next call and exits with code 2. To bring a machine back, create a new worker.
- Wrong id, wrong secret, malformed header: identical `401`. Failed attempts are rate-limited per IP (`429`).

## Calls made by the worker (`Authorization: Bearer <credential>`)
| Call | Purpose |
|---|---|
| `POST /api/worker/v1/register` | Every (re)connect. Declares platform/version/hostname (platform must match what the admin chose, else `409 platform_mismatch`). Returns heartbeat interval/timeout and whether resource reporting is allowed. **This is the resync step after an outage**; job and Telegram-account assignments will be returned here in Phases 4–5. |
| `POST /api/worker/v1/heartbeat` | Every ~15 s: `health` (ok/degraded + reason), `running_jobs`, optional `resources` (CPU/RAM %, only if an admin allows it for that worker). |

## Status
`online` / `degraded` / `offline` / `revoked`, computed at read time from the last heartbeat (timeout 60 s) so it is correct
even if the background detector is down. A detector in the API process also persists the change and writes a single
`worker.offline` / `worker.online` audit event per transition (safe with several API processes).
**A heartbeat only proves the worker process is reachable; it is not evidence that any Telegram task works.**

## Worker behaviour
Exponential backoff with full jitter (1 s → 60 s cap), reset after a successful registration; re-registers after every outage.
Exit codes: `0` clean stop, `1` missing config, `2` credential rejected/revoked, `3` fatal misconfiguration (e.g. platform mismatch).
Service managers must **not** auto-restart on 2 or 3 (configured in Phases 7–8: systemd `RestartPreventExitStatus=2 3`, Windows service recovery).

---
# Telegram accounts (Phase 4)

## Single owner: leases
A session may only be used by the worker that holds the account's **lease**. Acquiring it is one atomic conditional `UPDATE`,
so two workers can never both win; `lease_epoch` is a fencing token that makes any late request from a previous owner fail.
- The account is **assigned** to one worker by an administrator. Only that worker can lease it.
- TTL 60 s (`TFCC_ACCOUNT_LEASE_TTL_SECONDS`). The worker renews it by listing the account in each heartbeat.
- **Worker-side self-fencing:** the worker keeps a local deadline = (time the renewing request was *sent*) + 80% of the TTL
  (monotonic clock). If it cannot renew in time (network partition) it closes the connection itself, so it stops using the session
  *before* the server may give it to another worker. A `lost_leases` answer makes it drop the connection immediately.
- **Handover** (reassigning): the old owner loses the right to renew at once; the new worker can acquire only after the old one
  released the lease or it expired (at most one TTL). The old owner can never write the session again (epoch fencing).
- The API shows a connection as `connected` only while the owner's lease is alive.

## Commands (dashboard → one worker), pull-based
`POST /api/worker/v1/commands/poll` (long poll, ≤25 s) → `send_code`, `sign_in_code`, `sign_in_password`, `check_connection`, `logout`.
Results go to `POST /api/worker/v1/commands/{id}/result` (idempotent; only whitelisted fields such as state/user id/username are kept).
States: `pending → delivered → done | failed | expired`. Undelivered commands expire after 5 min and their payload is wiped.
A half-finished login lives only in worker memory; if the worker restarts, the next step fails with `login_session_lost` and the admin starts over.

## Login → run → delete
1. Admin creates the account, assigns a worker, `login/start` (phone) → worker sends the code.
2. `login/code` (and `login/password` if 2FA) → worker signs in, takes the lease, uploads the session (encrypted server-side), releases it. `authorized ⇒ session stored` is enforced.
3. `start` / `stop` set the desired state (idempotent). The worker reconciles from the `accounts` list returned by register/heartbeat.
4. Errors are codes only: `flood_wait` (with the **exact** seconds Telegram demanded; the worker waits that long before retrying),
   `code_invalid`, `code_expired`, `password_invalid`, `phone_invalid`, `auth_key_unregistered` (session revoked → account becomes `invalid`, must log in again), …
5. **Delete** requires retyping the account name. Default: the owning worker terminates the session on Telegram, then the record is purged.
   `force` deletes without that (the session stays active on Telegram — audited as `revoked_on_telegram=false`). Deleting while the worker is offline needs `force`.

## Not verified here
Telegram itself is unreachable from the build sandbox. The worker logic is tested against a fake backend, and the Telethon adapter only
offline (error mapping, client setup). **The first real login must be tried on your machine** (see README, "First real Telegram test").

---
# Forwarding routes and the job queue (Phase 5)

## Routes
A route = one Telegram account + N source chats + M destination chats (1→1, 1→N, N→1, N→M). Chat ids are Telegram "marked" ids
(negative for groups/channels). Fields: `mode` (`forward` = native forward, `copy` = re-send without the "forwarded from" header;
protected chats refuse both), `filters` (keywords include/exclude, content types, `include_outgoing`), `priority` 1–9, `rate_per_minute`,
`max_attempts`. Status: `stopped` → `active` ⇄ `paused`. Start/stop/pause/resume are idempotent and return the real state.

**A route can only start after `verify`**: the owning worker checks that the account can read every source and write to every destination
(`verify_chats` command). Changing chats resets the verification. The route never forwards to a destination that was not verified, and the
worker also treats any rejected send as final (`destination_forbidden`). The system never joins chats and never tries to bypass restrictions.

## Message → job
The worker watches the sources of ACTIVE routes (Telethon `NewMessage`), applies the filters **locally** and sends only ids to the API
(`POST /api/worker/v1/jobs/enqueue`): one job per destination, `idempotency_key = route:source:message:destination` (unique), so a message is
queued once no matter how often it is observed (live + catch-up). Message text is never sent, stored or logged.

**Checkpoints** (per route and source) record the highest message id handed to the queue. They only move forward and only after the server accepted
the items. On every (re)connect or resume the worker catches up from the checkpoint (up to 200 messages per round, several rounds). The very first
start of a route begins "from now": existing history is not forwarded.

## Job states (`packages/shared-schemas/job_states.json`, enforced by the API and by a test)
`pending → claimed → running → succeeded`; `running → retry_wait → pending` (backoff), `running → failed` (permanent error), `running → dead_letter`
(retries exhausted), `claimed → pending` (lease expired before start). `failed` and `dead_letter` are parked until an operator retries or cancels them
(per job or in bulk). `succeeded` and `cancelled` are final.

- **Claim**: one conditional UPDATE (status + fencing `claim_epoch`) so a job is never given to two workers; only jobs of accounts the worker currently
  owns (valid lease), of ACTIVE routes, ordered by priority then age. Per-route and per-account per-minute limits are applied here.
- **Lease**: a claimed/running job not finished within `TFCC_JOB_LEASE_TTL_SECONDS` (120 s) is recovered by the API sweeper (restart-safe: state is in PostgreSQL).
  Results carry the epoch; a result from a worker that lost the job is rejected (`stale`).
- **Retries** are bounded: delay `5 s · 2^(attempt-1)` capped at 15 min with ±20 % jitter, then `dead_letter` (audited as `job.dead_letter`).
- **FloodWait** is never slept through and never counted as a failed attempt: the worker reports the exact seconds, the job waits `seconds + 1`, and the
  whole account is blocked until then (the rest of the batch is handed back unsent). SlowMode delays only that job. Dead sessions mark the account `invalid`.
- **At-least-once**: if a worker dies between "Telegram accepted the message" and "result reported", the recovered job is sent again. Telegram gives no
  idempotency key, so exactly-once is impossible; the design minimises the window (results are retried from memory first) and de-duplicates everything else.

## Known limits
Albums are forwarded message by message (not kept together). Message edits/deletes after queuing are not tracked. After a very long outage only
200 messages per round × 20 rounds are caught up per source. The per-minute caps are best-effort under simultaneous claims from the same worker.
