# Authentication & authorization (Phase 2)

- **Passwords:** Argon2id; min 12 chars; rejected if it contains the username or is trivially weak. Hashing runs in a thread pool.
- **Login:** unknown user, wrong password, inactive user and locked user all return the same 401 and spend the same CPU time (no enumeration, no timing oracle).
- **Lockout:** after `TFCC_LOGIN_LOCK_THRESHOLD` failures the account locks for 60 s, doubling per extra failure up to 15 min. Admins can unlock. A per-IP limiter returns 429.
- **Sessions:** random 256-bit token in an `HttpOnly`, `SameSite=Lax`, `Secure` cookie; only its SHA-256 is stored. Absolute (12 h) and idle (2 h) expiry. Deactivating a user, resetting a password or changing a password revokes sessions.
- **CSRF:** per-session token returned by `/api/auth/login` and `/api/auth/me`; required in `X-CSRF-Token` for every non-GET request.
- **RBAC:** enforced in backend dependencies. Operators cannot reach `/api/users` or `/api/audit`.
- **Audit:** append-only table (`auth.*`, `user.*`), with request id and IP; keys containing password/token/secret/session/otp/hash are dropped before writing; unknown usernames are never stored.
- **Errors:** `{"error": {"code", "message"}, "request_id"}`; validation errors list field names only, never submitted values.
- **Bootstrap:** `python -m app.cli create-admin <username>` (interactive or `--password-stdin`).
