"""Exit 0 if an active admin exists, 3 if setup must create one; other failures stay errors."""
import asyncio

from sqlalchemy import select
from app.config import get_settings
from app.db import make_engine, make_sessionmaker
from app.models import Role, User


async def main() -> int:
    engine = make_engine(get_settings().database_url)
    try:
        async with make_sessionmaker(engine)() as db:
            user = (await db.execute(select(User.id).where(
                User.role == Role.ADMIN, User.is_active.is_(True)).limit(1))).scalar_one_or_none()
            return 0 if user is not None else 3
    finally:
        await engine.dispose()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
