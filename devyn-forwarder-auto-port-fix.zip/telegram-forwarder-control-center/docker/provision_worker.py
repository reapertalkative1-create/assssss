"""Local Docker bootstrap. Secret input/output goes only through captured stdio, never CLI arguments."""
import argparse
import asyncio
import hashlib
import json
import re
import sys
import time
import uuid

from sqlalchemy import select
from app.audit import record_system_audit
from app.config import get_settings
from app.db import make_engine, make_sessionmaker
from app.models import Worker
from app.services.workers import (
    create_worker, credential_matches, effective_status, parse_credential_worker_id, rotate_credential,
)
from app.types import utcnow


def read_payload(raw: bytes) -> dict:
    # Windows PowerShell 5.1 may prefix native-command input with a UTF-8 BOM.
    body = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(body, dict):
        raise ValueError('Invalid bootstrap input.')
    return body


def local_name(installation: str, machine: str) -> str:
    machine = re.sub(r'[^A-Za-z0-9_.-]', '-', machine).strip('-')[:35] or 'PC'
    suffix = hashlib.sha256(installation.encode()).hexdigest()[:12]
    return f'Local-{machine}-{suffix}'


def result(worker: Worker, credential: str) -> dict:
    return {'id': str(worker.id), 'name': worker.name, 'credential': credential,
            'previous_registered': worker.last_registered_at.isoformat() if worker.last_registered_at else None}


async def provision(db, installation: str, machine: str, credential: str = '') -> dict:
    if not installation or len(installation) > 128 or len(machine) > 128 or len(credential) > 200:
        raise ValueError('Invalid local worker settings.')
    if credential:
        worker_id = parse_credential_worker_id(credential)
        worker = await db.get(Worker, worker_id) if worker_id else None
        if worker is None or not credential_matches(worker, credential, utcnow()):
            raise ValueError('Saved worker credential is invalid or was rotated. Check the worker settings in the dashboard.')
        if worker.revoked_at is not None:
            raise ValueError('This worker was revoked. It will not be reactivated automatically.')
        if worker.platform == 'linux':
            return result(worker, credential)
        # Preserve a manually created Windows worker; use a separate Linux worker for Docker.
    name = local_name(installation, machine)
    worker = (await db.execute(select(Worker).where(Worker.name_key == name.lower()).with_for_update())).scalar_one_or_none()
    if worker is None:
        worker, credential = create_worker(db, name, 'linux', None)
        await db.flush()
        action = 'worker.create'
    else:
        if worker.revoked_at is not None:
            raise ValueError('The local worker was revoked. It will not be reactivated automatically.')
        if worker.platform != 'linux':
            raise ValueError('Local worker name conflicts with a non-Linux worker.')
        # Recover from an interrupted host-side save; keep this worker's ID and account assignments.
        credential = rotate_credential(worker, grace_seconds=0)
        action = 'worker.rotate_credential'
    record_system_audit(db, action, target_type='worker', target_id=str(worker.id),
                        details={'name': worker.name, 'platform': 'linux', 'source': 'local_launcher'})
    return result(worker, credential)


async def main(payload: dict, wait: bool) -> dict:
    settings = get_settings()
    engine = make_engine(settings.database_url)
    sessions = make_sessionmaker(engine)
    try:
        if not wait:
            async with sessions() as db:
                async with db.begin():
                    out = await provision(db, payload.get('installation', ''), payload.get('machine', ''),
                                          payload.get('credential', ''))
            return out  # transaction committed before exposing the generated credential
        worker_id = uuid.UUID(payload['id'])
        deadline = time.monotonic() + 30
        async with sessions() as db:
            while time.monotonic() < deadline:
                worker = await db.get(Worker, worker_id, populate_existing=True)
                if worker is not None:
                    registered = worker.last_registered_at.isoformat() if worker.last_registered_at else None
                    status = effective_status(worker, utcnow(), settings.heartbeat_timeout_seconds)
                    if registered and registered != payload.get('previous_registered') and status in {'online', 'degraded'}:
                        return {'id': str(worker.id), 'name': worker.name, 'status': status}
                await db.rollback()
                await asyncio.sleep(.5)
        raise ValueError('Worker did not connect within 30 seconds. Check Docker worker logs, then run run.cmd again.')
    finally:
        await engine.dispose()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait-online', action='store_true')
    args = parser.parse_args()
    try:
        body = read_payload(sys.stdin.buffer.read(8192))
        output = asyncio.run(main(body, args.wait_online))
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
    except Exception:
        print('Local worker setup failed. Make sure setup.cmd completed and the database is running.', file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(output, ensure_ascii=True))
