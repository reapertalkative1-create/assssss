import {useState} from 'react';
import type {Route} from '../api/types';

export type SelectedRoute=Pick<Route,'id'|'name'|'account_id'|'account_name'>;
export function useRouteSelection(){
 const [chosen,setChosen]=useState<Map<string,SelectedRoute>>(()=>new Map());
 function add(rows:SelectedRoute[]){setChosen(old=>{const next=new Map(old);for(const r of rows)next.set(r.id,{id:r.id,name:r.name,account_id:r.account_id,account_name:r.account_name});return next;});}
 function remove(ids:string[]){setChosen(old=>{const next=new Map(old);ids.forEach(id=>next.delete(id));return next;});}
 function toggle(row:SelectedRoute){if(chosen.has(row.id))remove([row.id]);else add([row]);}
 return {chosen,rows:[...chosen.values()],add,remove,toggle,clear:()=>setChosen(new Map())};
}
