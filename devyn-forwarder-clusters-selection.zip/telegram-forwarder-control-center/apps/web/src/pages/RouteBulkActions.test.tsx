import {render,screen,waitFor,act} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {beforeEach,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn()}};});
import {api,ApiError} from '../api/client';
import type {Route} from '../api/types';
import {RouteBulkActions} from './RouteBulkActions';
const ready={id:'r1',name:'Route 1',account_id:'a1',account_name:'Ready SS',verified:true,status:'stopped',stats:{},link_config:{targets:['@group_one'],delay_seconds:60}} as Route;
const setup=(rows:Route[],extra={})=>render(<RouteBulkActions selected={rows} isAdmin onRefresh={vi.fn()} onRemove={vi.fn()} onClear={vi.fn()} {...extra}/>);
beforeEach(()=>{vi.clearAllMocks();vi.mocked(api.get).mockResolvedValue(ready);vi.mocked(api.post).mockResolvedValue({});});

it('rechecks current state, skips restricted accounts and reports individual failures',async()=>{
 const user=userEvent.setup(),blocked={...ready,id:'r2',account_name:'Blocked SS',account_restriction:'blocked'},offline={...ready,id:'r3',account_name:'Offline SS'};
 vi.mocked(api.get).mockImplementation(async path=>path.endsWith('r2')?blocked:path.endsWith('r3')?offline:ready);
 vi.mocked(api.post).mockImplementation(async path=>{if(path.includes('r3'))throw new ApiError(409,'worker_unavailable','Worker offline');return {};});
 setup([ready,{...blocked,account_restriction:null},offline]);
 await user.selectOptions(screen.getByLabelText('Thao tác trên dòng đã chọn'),'start');await user.click(screen.getByRole('button',{name:'Áp dụng (3)'}));
 await waitFor(()=>expect(screen.getByText('Đã xử lý 3/3 dòng.')).toBeVisible());
 expect(api.post).toHaveBeenCalledTimes(2);expect(api.post).toHaveBeenCalledWith('/api/routes/r1/start',undefined);expect(api.post).not.toHaveBeenCalledWith('/api/routes/r2/start',undefined);
 expect(screen.getByText('Blocked SS')).toBeVisible();expect(screen.getByText('Worker offline')).toBeVisible();expect(screen.getByText('Đã xử lý 1 · bỏ qua 1 · lỗi 1')).toBeVisible();
});

it('requires a delete click, skips active rows and keeps SS selection identities explicit',async()=>{
 const user=userEvent.setup(),remove=vi.fn(),active={...ready,id:'r2',account_name:'Running SS',status:'active'} as Route;
 vi.mocked(api.get).mockImplementation(async path=>path.endsWith('r2')?active:{...ready,name:'Renamed route'});
 setup([ready,active],{onRemove:remove});
 await user.selectOptions(screen.getByLabelText('Thao tác trên dòng đã chọn'),'delete');await user.click(screen.getByRole('button',{name:'Áp dụng (2)'}));
 expect(api.post).not.toHaveBeenCalled();await user.click(screen.getByRole('button',{name:'Xóa dòng đã chọn'}));
 await waitFor(()=>expect(remove).toHaveBeenCalledWith(['r1']));
 expect(api.post).toHaveBeenCalledWith('/api/routes/r1/delete',{confirm_name:'Renamed route'});expect(api.post).toHaveBeenCalledTimes(1);
 expect(await screen.findByText(/Dừng lượt trước khi xóa/)).toBeVisible();
});

it('cancels pending work when the component is closed before the fresh-state response',async()=>{
 let resolve!:(r:Route)=>void;vi.mocked(api.get).mockReturnValue(new Promise(r=>{resolve=r;}));
 const user=userEvent.setup(),view=setup([ready,{...ready,id:'r2'}]);
 await user.click(screen.getByRole('button',{name:'Áp dụng (2)'}));expect(api.get).toHaveBeenCalledTimes(1);view.unmount();
 await act(async()=>{resolve(ready);});expect(api.post).not.toHaveBeenCalled();expect(api.get).toHaveBeenCalledTimes(1);
});

it('previews only selected routes when saving a cluster and deduplicates SS checks',async()=>{
 const user=userEvent.setup(),save=vi.fn().mockResolvedValue(undefined);
 setup([ready,{...ready,id:'r2'}],{onSaveCluster:save});
 await user.click(screen.getByRole('button',{name:'Lưu thành cụm'}));expect(save).toHaveBeenCalledWith(['r1','r2']);expect(api.post).not.toHaveBeenCalled();
 await user.click(screen.getByRole('button',{name:/^Kiểm tra SS$/}));expect(screen.getByRole('button',{name:'Kiểm tra SS (1)'})).toBeVisible();
});
