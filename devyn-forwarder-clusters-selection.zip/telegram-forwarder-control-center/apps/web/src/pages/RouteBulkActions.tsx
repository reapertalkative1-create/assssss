import {useEffect,useRef,useState} from 'react';
import {api,ApiError} from '../api/client';
import type {Route} from '../api/types';
import type {SelectedRoute} from '../hooks/useRouteSelection';
import {Alert} from '../components/ui';
import {SenderChecks} from './SenderChecks';
import {deliveryDone} from './PostRoute';
import {errorLabel} from '../lib/labels';

export type RouteAction='verify'|'start'|'pause'|'resume'|'stop'|'delete';
const actions:Record<RouteAction,string>={verify:'Kiểm tra nhóm',start:'Bắt đầu gửi',pause:'Tạm dừng',resume:'Tiếp tục',stop:'Dừng lượt gửi',delete:'Xóa tuyến / lượt'};
export function skipRoute(action:RouteAction,r:Route):string|null{
 if(action==='verify')return r.link_config?.queued_at?'Lượt đã tạo hàng chờ.':r.verification_pending?'Đang kiểm tra nhóm.':null;
 if(action==='start'||action==='resume'){
  if(deliveryDone(r))return 'Lượt đã hoàn tất.';
  if(!r.verified)return 'Chưa xác minh nhóm.';
  if(r.account_issue||r.account_restriction)return errorLabel(r.account_issue??r.account_restriction)||'SS đang bị hạn chế.';
  if(r.account_wait_until&&Date.parse(r.account_wait_until)>Date.now())return 'Telegram yêu cầu chờ.';
  if(r.link_config?.pause_reason)return 'Cần đối chiếu kết quả trước khi tiếp tục.';
  if(action==='start'&&r.status!=='stopped')return 'Chỉ bắt đầu lượt đang dừng.';
  if(action==='resume'&&r.status!=='paused')return 'Lượt chưa tạm dừng.';
 }
 if(action==='pause'&&r.status!=='active')return 'Lượt không đang chạy.';
 if(action==='stop'&&r.status==='stopped')return 'Lượt đã dừng.';
 if(action==='delete'&&r.status!=='stopped')return 'Dừng lượt trước khi xóa.';
 return null;
}
interface Result {id:string;name:string;kind:'ok'|'skip'|'error';message:string}
export function RouteBulkActions({selected,isAdmin,disabled=false,onRefresh,onRemove,onClear,onSaveCluster,onBusyChange}:{selected:SelectedRoute[];isAdmin:boolean;disabled?:boolean;onRefresh:()=>void;onRemove:(ids:string[])=>void;onClear:()=>void;onSaveCluster?:(ids:string[])=>Promise<void>;onBusyChange?:(busy:boolean)=>void}){
 const [action,setAction]=useState<RouteAction>('verify'),[busy,setBusy]=useState(false),[results,setResults]=useState<Result[]>([]),[progress,setProgress]=useState(''),[confirm,setConfirm]=useState(false),[error,setError]=useState(''),[checks,setChecks]=useState(false);
 const mounted=useRef(true),cancelled=useRef(false),running=useRef(false);
 const ids=[...new Set(selected.map(r=>r.account_id))];
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;cancelled.current=true;onBusyChange?.(false);};},[onBusyChange]);
 function lock(value:boolean){running.current=value;if(mounted.current){setBusy(value);onBusyChange?.(value);}}
 async function perform(){
  if(running.current||!selected.length)return;
  const snapshot=[...selected],task=action;cancelled.current=false;setConfirm(false);setResults([]);setError('');lock(true);
  const done:Result[]=[];
  try{
   for(const row of snapshot){
    if(cancelled.current)break;
    let item:Result;
    if(mounted.current)setProgress(`${done.length+1}/${snapshot.length} · ${row.account_name??row.name}`);
    try{
     const current=await api.get<Route>(`/api/routes/${row.id}`);
     if(cancelled.current)break;
     const reason=skipRoute(task,current);
     if(reason)item={id:row.id,name:current.account_name??row.name,kind:'skip',message:reason};
     else{
      await api.post(`/api/routes/${row.id}/${task}`,task==='delete'?{confirm_name:current.name}:undefined);
      item={id:row.id,name:current.account_name??row.name,kind:'ok',message:task==='verify'?'Đã gửi yêu cầu kiểm tra.':`${actions[task]}: đã xử lý.`};
      if(task==='delete'&&mounted.current)onRemove([row.id]);
     }
    }catch(e){item={id:row.id,name:row.account_name??row.name,kind:'error',message:e instanceof ApiError?e.message:'Không thực hiện được.'};}
    done.push(item);if(mounted.current)setResults([...done]);
   }
   if(mounted.current)setProgress(`${cancelled.current?'Đã ngừng thao tác':'Đã xử lý'} ${done.length}/${snapshot.length} dòng.`);
  }finally{if(mounted.current)onRefresh();lock(false);}
 }
 async function saveCluster(){if(!onSaveCluster||running.current)return;lock(true);setError('');try{await onSaveCluster(selected.map(r=>r.id));}catch(e){if(mounted.current)setError(e instanceof ApiError?e.message:'Không lấy được cấu hình.');}finally{lock(false);}}
 const locked=busy||disabled;
 return <div className="route-bulk-bar">
  <div className="route-selection-head"><strong>Đã chọn {selected.length} dòng <span>· {ids.length} SS</span></strong><div className="row"><button className="btn ghost sm" disabled={locked||!selected.length} onClick={onClear}>Bỏ chọn</button>{busy&&<button className="btn sm" onClick={()=>{cancelled.current=true;setProgress('Đang hoàn tất yêu cầu hiện tại…');}}>Ngừng thao tác</button>}</div></div>
  <div className="route-bulk-controls"><select className="select" aria-label="Thao tác trên dòng đã chọn" value={action} disabled={locked} onChange={e=>{setAction(e.target.value as RouteAction);setConfirm(false);}}>{Object.entries(actions).filter(([key])=>key!=='delete'||isAdmin).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select><button className="btn sm primary" disabled={locked||!selected.length} onClick={()=>action==='delete'?setConfirm(true):void perform()}>Áp dụng ({selected.length})</button>{isAdmin&&<><button className="btn sm" disabled={locked||!selected.length} onClick={()=>setChecks(v=>!v)} aria-expanded={checks}>Kiểm tra SS</button>{onSaveCluster&&<button className="btn sm" disabled={locked||!selected.length} onClick={()=>void saveCluster()}>Lưu thành cụm</button>}</>}</div>
  {!selected.length&&<span className="hint">Tích các dòng cần thao tác. Chọn cả trang hoặc tất cả kết quả ở phía trên.</span>}
  {confirm&&<Alert tone="bad">Xóa {selected.length} dòng đã chọn đang dừng và tác vụ liên quan trong ứng dụng. Tài khoản Telegram vẫn được giữ.<div className="row"><button className="btn sm danger" disabled={locked} onClick={()=>void perform()}>Xóa dòng đã chọn</button><button className="btn sm" disabled={locked} onClick={()=>setConfirm(false)}>Hủy</button></div></Alert>}
  {checks&&isAdmin&&<SenderChecks ids={ids} disabled={locked} onFinished={onRefresh}/>}
  {progress&&<div className="route-bulk-progress" role="status">{progress}{!!results.length&&<span>Đã xử lý {results.filter(r=>r.kind==='ok').length} · bỏ qua {results.filter(r=>r.kind==='skip').length} · lỗi {results.filter(r=>r.kind==='error').length}</span>}</div>}
  {!!results.some(r=>r.kind!=='ok')&&<details className="route-bulk-errors" open><summary>Dòng cần xử lý ({results.filter(r=>r.kind!=='ok').length})</summary>{results.filter(r=>r.kind!=='ok').slice(0,100).map(r=><div key={r.id}><strong>{r.name}</strong><span>{r.kind==='skip'?'Bỏ qua: ':''}{r.message}</span></div>)}{results.filter(r=>r.kind!=='ok').length>100&&<p>Hiện 100 dòng đầu. Thu hẹp lựa chọn để xem chi tiết.</p>}</details>}
  {error&&<Alert tone="bad">{error}</Alert>}
 </div>;
}
