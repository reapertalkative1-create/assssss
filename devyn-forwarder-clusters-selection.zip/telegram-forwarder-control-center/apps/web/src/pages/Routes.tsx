import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api, ApiError } from "../api/client";
import type { Account, CommandAccepted, ContentType, Page, Route, RouteInput, WorkClusterSeed } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { Alert, Check, EmptyState, PageHead, Pill, SelectField, TextArea, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtDateTime, parseChatIds, splitLines } from "../lib/format";
import { authState, contentTypes, errorLabel, routeStatus } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";
import { waitForCommand } from "./Accounts";
import {PostRouteForm,PostRouteDetail,deliveryDone,deliveryLabel} from "./PostRoute";

import {useRouteSelection} from '../hooks/useRouteSelection';
import {RouteBulkActions} from './RouteBulkActions';
import {WorkClusters} from './WorkClusters';
import {PostBatch} from "./PostBatch";

type Dialog = {kind:"cluster";seed?:WorkClusterSeed;fromAccounts?:boolean} | {kind:"batch";batchId:string} | {kind:"post";route?:Route;clone?:boolean;fromAccounts?:boolean} | { kind: "form"; route?: Route } | { kind: "detail"; route: Route } | { kind: "delete"; route: Route };
const ALL_TYPES = Object.keys(contentTypes) as ContentType[];

export function RoutesPage() {
  const { isAdmin,user } = useAuth();
  const toast = useToast();
  const location=useLocation(),navigate=useNavigate();
  const tab=location.pathname==='/work-clusters'?'clusters':'routes';
  const setTab=(value:'clusters'|'routes')=>navigate(value==='clusters'?'/work-clusters':'/routes');
  const selection=useRouteSelection();
  const [clusterTick,setClusterTick]=useState(0);
  const [bulkBusy,setBulkBusy]=useState(false),[selecting,setSelecting]=useState(false),[selectError,setSelectError]=useState(''),[kind,setKind]=useState('');
  useEffect(()=>{if(isAdmin&&location.state?.clusterFromAccounts){setDialog({kind:'cluster',fromAccounts:true});navigate(location.pathname,{replace:true,state:null});}else if(isAdmin&&location.state?.composeFromAccounts){setDialog({kind:"post",fromAccounts:true});navigate(location.pathname,{replace:true,state:null});}},[location.key,isAdmin]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busy, setBusy] = useState<string>();
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<Route>>("/api/routes", { q: search, status, kind, page, page_size: 20 }, signal), [search, status, kind, page], { interval: 5000,enabled:tab==='routes' });

  async function act(r: Route, action: "start" | "pause" | "resume" | "stop", done: string) {
    setBusy(r.id);
    try { await api.post(`/api/routes/${r.id}/${action}`); toast.success(done); list.reload(); }
    catch (e) { toast.error(e instanceof ApiError ? e.message : "Thao tác thất bại."); }
    finally { setBusy(undefined); }
  }
  async function verify(r: Route) {
    setBusy(r.id);
    try {
      const acc = await api.post<CommandAccepted>(`/api/routes/${r.id}/verify`);
      if(r.link_config){toast.success("Đang kiểm tra bài viết và quyền gửi vào nhóm. Xem tiến độ trong Chi tiết.");list.reload();return;}
      const cmd = await waitForCommand(r.account_id, acc.command_id, undefined, 3);
      if (cmd.status === "done") toast.success("Đã kiểm tra quyền truy cập. Xem kết quả trong Chi tiết.");
      else toast.error(cmd.status === "expired" ? "Worker không phản hồi kịp." : errorLabel(cmd.error_code, cmd.retry_after) || "Xác minh thất bại.");
      list.reload();
    } catch (e) { toast.error(e instanceof ApiError ? e.message : "Xác minh thất bại."); }
    finally { setBusy(undefined); }
  }

  async function selectAll(){setSelecting(true);setSelectError('');try{const data=await api.post<{items:Route[]}>('/api/routes/selection',{q:search,status:status||null,kind:kind||null});selection.add(data.items);}catch(e){setSelectError(e instanceof ApiError?e.message:'Không lấy được danh sách.');}finally{setSelecting(false);}}
  async function saveCluster(ids:string[]){const seed=await api.post<WorkClusterSeed>('/api/work-clusters/from-routes/preview',{route_ids:ids});setDialog({kind:'cluster',seed});}
  const visible=list.data?.items??[],allPage=!!visible.length&&visible.every(r=>selection.chosen.has(r.id));
  const cols: Column<Route>[] = [
    {key:'select',header:<input type="checkbox" aria-label="Chọn trang hiện tại" checked={allPage} disabled={bulkBusy||selecting||!visible.length} ref={el=>{if(el)el.indeterminate=!allPage&&visible.some(r=>selection.chosen.has(r.id));}} onChange={()=>allPage?selection.remove(visible.map(r=>r.id)):selection.add(visible)}/>,width:'36px',cell:r=><input type="checkbox" aria-label={`Chọn dòng ${r.account_name??r.name} · ${r.id}`} checked={selection.chosen.has(r.id)} disabled={bulkBusy||selecting} onChange={()=>selection.toggle(r)}/>},
    {key:'name',header:'Bài viết / lượt gửi',width:'28%',cell:r=><div className="stack tight"><strong>{r.link_config?.work_cluster_name??(r.link_config?'Gửi bài từ liên kết':r.name)}</strong>{!r.link_config&&<span className="hint">Theo dõi nguồn tự động</span>}{r.link_config&&<a className="route-post-link" href={r.link_config.post_link} target="_blank" rel="noreferrer">{r.link_config.post_link}</a>}</div>},
    {key:'account',header:'Tài khoản',cell:r=><div><strong className="small">{r.account_name??'—'}</strong><div className="hint">{r.mode==='copy'?'Sao chép nội dung':'Chuyển tiếp gốc'}</div></div>},
    {key:'state',header:'Trạng thái',cell:r=><div className="stack tight"><Pill tone={r.verification_error||r.account_issue||r.account_restriction||r.link_config?.pause_reason?'bad':deliveryDone(r)?'ok':r.status==='active'?'ok':'warn'}>{deliveryLabel(r)}</Pill><span className="hint">{r.link_config?`${r.destination_chat_ids.length||r.link_config.targets.length} nhóm · nghỉ ${r.link_config.delay_seconds}s`:r.verified?'Đã xác minh':'Chưa xác minh'}</span></div>},
    {key:'stats',header:'Tiến độ',cell:r=><div className="stack tight"><span className="small"><b>{r.stats.succeeded??0}</b> đã gửi · {['pending','retry_wait','claimed','running'].reduce((n,k)=>n+(r.stats[k]??0),0)} chờ</span><span className="hint">{(r.stats.failed??0)+(r.stats.dead_letter??0)} lỗi{r.link_config?.scheduled_at?` · ${fmtDateTime(r.link_config.scheduled_at)}`:''}</span></div>},
    {key:'actions',header:'',align:'right',cell:r=><div className="route-row-actions">
      {r.status==='stopped'&&r.verified&&!deliveryDone(r)&&<button className="btn sm primary" disabled={bulkBusy||busy===r.id||!!r.account_issue||!!r.link_config?.pause_reason} onClick={()=>void act(r,'start',r.link_config?'Đã bắt đầu gửi.':'Đã bật tuyến.')}>{r.link_config?'Bắt đầu gửi':'Bật'}</button>}
      {r.status==='active'&&!deliveryDone(r)&&<button className="btn sm" disabled={bulkBusy||busy===r.id} onClick={()=>void act(r,'pause','Đã tạm dừng.')}>Tạm dừng</button>}
      {r.status==='paused'&&!deliveryDone(r)&&<button className="btn sm primary" disabled={bulkBusy||busy===r.id||!!r.account_issue||!!r.link_config?.pause_reason} onClick={()=>void act(r,'resume','Đã tiếp tục.')}>Tiếp tục</button>}
      {!r.verified&&!r.link_config?.queued_at&&<button className="btn sm" disabled={bulkBusy||busy===r.id||r.verification_pending} onClick={()=>void verify(r)}>{r.verification_pending?'Đang kiểm tra…':'Kiểm tra nhóm'}</button>}
      <button className="btn sm" disabled={bulkBusy} onClick={()=>setDialog({kind:'detail',route:r})}>Chi tiết</button>{r.link_config?.batch_id&&<button className="btn sm" disabled={bulkBusy} onClick={()=>setDialog({kind:"batch",batchId:r.link_config!.batch_id!})}>Mở lượt</button>}
      <details className="session-actions"><summary className="btn sm">Thao tác</summary><div className="route-menu">
        {r.status!=='stopped'&&<button className="btn sm" disabled={bulkBusy||busy===r.id} onClick={()=>void act(r,'stop','Đã dừng, giữ hàng chờ để tiếp tục khi cần.')}>Dừng</button>}
        {!r.link_config&&<button className="btn sm" onClick={()=>void verify(r)}>Xác minh lại</button>}
        {isAdmin&&r.link_config&&<button className="btn sm" disabled={bulkBusy} onClick={()=>setDialog({kind:'post',route:r,clone:true})}>Tạo bản mới</button>}
        {isAdmin&&!r.link_config?.work_cluster_id&&(!r.link_config||!r.link_config.queued_at&&r.status==='stopped')&&<button className="btn sm" disabled={bulkBusy} onClick={()=>setDialog(r.link_config?{kind:'post',route:r}:{kind:'form',route:r})}>Sửa</button>}
        {isAdmin&&<button className="btn sm danger" disabled={bulkBusy} onClick={()=>setDialog({kind:'delete',route:r})}>Xóa</button>}
      </div></details>
    </div>},
  ];
  const saved = (msg: string) => { setDialog(null); toast.success(msg); list.reload(); };
  return (
    <div className="routes-page stack">
      <PageHead title={tab==='clusters'?'Cụm làm việc':'Tuyến chuyển tiếp'} actions={isAdmin && tab==='routes' && <><button className="btn" onClick={()=>setDialog({kind:"form"})}>Theo dõi nguồn</button><button className="btn primary" onClick={()=>setDialog({kind:"post"})}>Gửi bài từ liên kết</button></>}>
        {tab==='clusters'?'Lưu SS và nhóm nhận một lần, mỗi ngày chọn bài mới.':'Tích các dòng để kiểm tra, điều khiển nhiều SS hoặc lưu thành cụm.'}
      </PageHead>
      <div className="seg" aria-label="Chế độ tuyến gửi"><button aria-pressed={tab==='clusters'} onClick={()=>setTab('clusters')}>Cụm làm việc</button><button aria-pressed={tab==='routes'} onClick={()=>setTab('routes')}>Lịch sử / tuyến</button></div>
      {tab==='clusters'&&user&&<WorkClusters key={`${user.id}:${clusterTick}`} owner={user.id} isAdmin={isAdmin} onOpenBatch={batchId=>setDialog({kind:'batch',batchId})}/>}
      {tab==='routes'&&<><div className="toolbar">
        <input className="input" placeholder="Tìm tên SS, cụm hoặc tuyến…" maxLength={64} disabled={bulkBusy||selecting} aria-label="Tìm tuyến" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className="select" aria-label="Lọc trạng thái" disabled={bulkBusy||selecting} value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">Mọi trạng thái</option>
          {Object.entries(routeStatus).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select className="select" aria-label="Loại tuyến" disabled={bulkBusy||selecting} value={kind} onChange={e=>{setKind(e.target.value);setPage(1);}}><option value="">Mọi loại</option><option value="post">Bài từ liên kết</option><option value="watch">Theo dõi nguồn</option></select>
      </div>
      <div className="route-pick-tools"><button className="btn sm" disabled={bulkBusy||selecting||!visible.length} onClick={()=>selection.add(visible)}>Chọn trang này</button><button className="btn sm" disabled={bulkBusy||selecting||!list.data?.total} onClick={()=>void selectAll()}>{selecting?'Đang chọn…':`Chọn tất cả kết quả (${list.data?.total??0})`}</button><span className="hint">Lựa chọn được giữ khi đổi trang/bộ lọc.</span></div>
      {selectError&&<Alert tone="bad">{selectError}</Alert>}
      <RouteBulkActions selected={selection.rows} isAdmin={isAdmin} disabled={selecting||!!busy} onRefresh={list.reload} onRemove={selection.remove} onClear={selection.clear} onSaveCluster={isAdmin?saveCluster:undefined} onBusyChange={setBulkBusy}/>
      <DataTable caption="Danh sách tuyến chuyển tiếp" columns={cols} rows={list.data?.items} rowKey={(r) => r.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title={search || status ? "Không có tuyến phù hợp" : "Chưa có tuyến nào"}
          >
          {search || status ? "Thử bỏ bớt bộ lọc." : "Bấm Gửi bài từ liên kết để nhập TXT hoặc dán danh sách nhóm."}</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={20} total={list.data.total} onPage={setPage} />}</>}

      {dialog?.kind==='cluster'&&user&&<PostRouteForm clusterMode fromAccounts={dialog.fromAccounts} initialCluster={dialog.seed} draftOwner={user.id} onClose={()=>setDialog(null)} onSaved={()=>{}} onClusterSaved={c=>{setClusterTick(t=>t+1);setDialog(null);toast.success(`Đã tạo cụm “${c.name}”.`);navigate('/work-clusters');}}/>}
      {dialog?.kind === "batch"&&<PostBatch isAdmin={isAdmin} onSaveCluster={saveCluster} batchId={dialog.batchId} onClose={()=>{setDialog(null);list.reload();}} onDetail={r=>setDialog({kind:"detail",route:r})}/>}
      {dialog?.kind === "post"&&user&&<PostRouteForm key={`${user.id}:${dialog.route?.id??'new'}:${dialog.clone?'clone':'edit'}`} draftOwner={user.id} fromAccounts={dialog.fromAccounts} route={dialog.route} clone={dialog.clone} onClose={()=>setDialog(null)} onSaved={r=>{list.reload();setDialog(r.link_config?.batch_id?{kind:"batch",batchId:r.link_config.batch_id}:{kind:"detail",route:r});toast.success("Đã lưu bản nháp. Kiểm tra nhóm rồi bấm Bắt đầu gửi.");}}/>}
      {dialog?.kind === "form" && <RouteForm route={dialog.route} onClose={() => setDialog(null)} onSaved={() => saved(dialog.route ? "Đã lưu tuyến." : "Đã tạo tuyến. Hãy xác minh rồi bật tuyến.")} />}
      {dialog?.kind === "detail" && (dialog.route.link_config?<PostRouteDetail route={dialog.route} onClose={()=>{setDialog(null);list.reload();}} onVerify={()=>verify(dialog.route)} onAction={action=>act(dialog.route,action,action==='stop'?'Đã dừng, giữ hàng chờ.':'Đã cập nhật đợt gửi.')}/>:<RouteDetail route={dialog.route} onClose={() => setDialog(null)} />)}
      {dialog?.kind === "delete" && (
        <ConfirmDialog title={`Xóa tuyến ${dialog.route.name}?`} confirmLabel="Xóa tuyến" danger requireText={dialog.route.name} onClose={() => setDialog(null)}
          onConfirm={async () => { await api.post(`/api/routes/${dialog.route.id}/delete`, { confirm_name: dialog.route.name }); toast.success("Đã xóa tuyến."); list.reload(); }}>
          <p>Toàn bộ tác vụ của tuyến này (kể cả tác vụ đã xong) và điểm đánh dấu tiến độ sẽ bị xóa. Tuyến phải đang ở trạng thái <strong>Đã dừng</strong>.</p>
        </ConfirmDialog>)}
    </div>
  );
}

function RouteDetail({ route: r, onClose }: { route: Route; onClose: () => void }) {
  const chats = [...r.source_chat_ids.map((id) => ({ id, role: "Nguồn" })), ...r.destination_chat_ids.map((id) => ({ id, role: "Đích" }))];
  const f = r.filters;
  return (
    <Modal wide title={`Chi tiết tuyến ${r.name}`} onClose={onClose} footer={<><Link className="btn" to={`/jobs?route=${r.id}`}>Xem tác vụ của tuyến</Link><button className="btn primary" onClick={onClose}>Đóng</button></>}>
      <dl className="kv">
        <dt>Tài khoản</dt><dd>{r.account_name ?? "—"}</dd>
        <dt>Chế độ</dt><dd>{r.mode === "copy" ? "Sao chép nội dung (không kèm “chuyển tiếp từ”)" : "Chuyển tiếp gốc"}</dd>
        <dt>Ưu tiên / tốc độ</dt><dd>Mức {r.priority} (1 là khẩn nhất) · tối đa {r.rate_per_minute} tin/phút · thử lại tối đa {r.max_attempts} lần</dd>
        <dt>Bộ lọc</dt><dd>
          {f.content_types.length ? `Loại: ${f.content_types.map((t) => contentTypes[t]).join(", ")}. ` : "Mọi loại nội dung. "}
          {f.keywords_include.length ? `Phải chứa một trong: ${f.keywords_include.join(", ")}. ` : ""}
          {f.keywords_exclude.length ? `Loại trừ: ${f.keywords_exclude.join(", ")}. ` : ""}
          {f.include_outgoing ? "Gồm cả tin do chính tài khoản gửi." : "Bỏ qua tin do chính tài khoản gửi."}</dd>
        <dt>Xác minh</dt><dd>{r.verified_at ? `${r.verified ? "Đạt" : "Chưa đạt"} lúc ${fmtDateTime(r.verified_at)}` : "Chưa xác minh"}</dd>
      </dl>
      <table className="table">
        <thead><tr><th scope="col">Chat</th><th scope="col">Vai trò</th><th scope="col">Tên</th><th scope="col">Quyền</th><th scope="col">Đã xử lý đến tin</th></tr></thead>
        <tbody>{chats.map((c) => {
          const v = r.verification?.[String(c.id)];
          const ok = !v ? null : c.role === "Nguồn" ? v.ok : v.ok && v.can_send;
          return (
            <tr key={`${c.role}${c.id}`}>
              <td className="mono">{c.id}</td><td>{c.role}</td><td>{v?.title ?? "—"}</td>
              <td>{ok === null ? <Pill tone="idle">Chưa kiểm tra</Pill> : ok ? <Pill tone="ok">{c.role === "Nguồn" ? "Đọc được" : "Gửi được"}</Pill> : <Pill tone="bad">{v?.ok ? "Không được gửi" : "Không truy cập được"}</Pill>}</td>
              <td className="mono">{c.role === "Nguồn" ? (r.checkpoints[String(c.id)] ?? "—") : ""}</td>
            </tr>);
        })}</tbody>
      </table>
    </Modal>
  );
}

export function RouteForm({ route, onClose, onSaved }: { route?: Route; onClose: () => void; onSaved: () => void }) {
  const editing = !!route;
  const accounts = useQuery((signal) => api.get<Page<Account>>("/api/accounts", { page_size: 100 }, signal), [], { enabled: !editing });
  const [name, setName] = useState(route?.name ?? "");
  const [accountId, setAccountId] = useState(route?.account_id ?? "");
  const [sources, setSources] = useState((route?.source_chat_ids ?? []).join("\n"));
  const [dests, setDests] = useState((route?.destination_chat_ids ?? []).join("\n"));
  const [mode, setMode] = useState<"forward" | "copy">(route?.mode ?? "forward");
  const [types, setTypes] = useState<ContentType[]>(route?.filters.content_types ?? []);
  const [include, setInclude] = useState((route?.filters.keywords_include ?? []).join("\n"));
  const [exclude, setExclude] = useState((route?.filters.keywords_exclude ?? []).join("\n"));
  const [outgoing, setOutgoing] = useState(route?.filters.include_outgoing ?? false);
  const [priority, setPriority] = useState(String(route?.priority ?? 5));
  const [rate, setRate] = useState(String(route?.rate_per_minute ?? 20));
  const [attempts, setAttempts] = useState(String(route?.max_attempts ?? 5));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const chatsLocked = editing && route.status !== "stopped";

  function validate(): RouteInput | null {
    const e: Record<string, string> = {};
    const src = parseChatIds(sources), dst = parseChatIds(dests);
    if (!name.trim()) e.name = "Nhập tên tuyến.";
    if (!editing && !accountId) e.account_id = "Chọn tài khoản.";
    for (const [key, p, label] of [["source_chat_ids", src, "nguồn"], ["destination_chat_ids", dst, "đích"]] as const) {
      if (p.invalid.length) e[key] = `Chat id không hợp lệ: ${p.invalid.slice(0, 3).join(", ")}. Dùng số nguyên như -1001234567890.`;
      else if (p.duplicates.length) e[key] = `Bị trùng: ${p.duplicates.slice(0, 3).join(", ")}.`;
      else if (p.ids.length === 0) e[key] = `Cần ít nhất một chat ${label}.`;
      else if (p.ids.length > 50) e[key] = "Tối đa 50 chat.";
    }
    if (!e.source_chat_ids && !e.destination_chat_ids && src.ids.some((i) => dst.ids.includes(i))) e.destination_chat_ids = "Một chat không thể vừa là nguồn vừa là đích.";
    const num = (v: string, lo: number, hi: number) => /^\d+$/.test(v) && Number(v) >= lo && Number(v) <= hi;
    if (!num(priority, 1, 9)) e.priority = "Từ 1 đến 9.";
    if (!num(rate, 1, 600)) e.rate_per_minute = "Từ 1 đến 600.";
    if (!num(attempts, 1, 10)) e.max_attempts = "Từ 1 đến 10.";
    const kwInc = splitLines(include), kwExc = splitLines(exclude);
    if ([...kwInc, ...kwExc].some((k) => k.length > 100)) e.keywords = "Mỗi từ khóa tối đa 100 ký tự.";
    setErrors(e);
    if (Object.keys(e).length) return null;
    return { name: name.trim(), account_id: accountId || undefined, source_chat_ids: src.ids, destination_chat_ids: dst.ids, mode,
      filters: { keywords_include: kwInc, keywords_exclude: kwExc, content_types: types, include_outgoing: outgoing },
      priority: Number(priority), rate_per_minute: Number(rate), max_attempts: Number(attempts) };
  }
  async function submit() {
    const body = validate();
    if (!body) return;
    setBusy(true); setError(undefined);
    try {
      if (editing) {
        const { account_id: _ignored, ...rest } = body;
        void _ignored;
        await api.patch(`/api/routes/${route.id}`, chatsLocked ? { ...rest, source_chat_ids: undefined, destination_chat_ids: undefined } : rest);
      } else await api.post("/api/routes", body);
      onSaved();
    } catch (e) { setErrors((cur) => ({ ...cur, ...fieldErrors(e) })); setError(e instanceof ApiError ? e.message : "Không lưu được tuyến."); setBusy(false); }
  }
  const toggle = (t: ContentType) => setTypes((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]));
  return (
    <Modal wide title={editing ? `Sửa tuyến ${route.name}` : "Tạo tuyến chuyển tiếp"} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void submit()} disabled={busy}>{busy ? "Đang lưu…" : editing ? "Lưu thay đổi" : "Tạo tuyến"}</button></>}>
      <div className="form-grid">
        <TextField label="Tên tuyến" value={name} onChange={(e) => setName(e.target.value)} error={errors.name} maxLength={64} />
        {editing ? <TextField label="Tài khoản" value={route.account_name ?? ""} disabled hint="Không đổi được tài khoản của tuyến." readOnly /> : (
          <SelectField label="Tài khoản Telegram" value={accountId} onChange={(e) => setAccountId(e.target.value)} error={errors.account_id}>
            <option value="">Chọn tài khoản…</option>
            {accounts.data?.items.map((a) => <option key={a.id} value={a.id}>{a.name} — {authState[a.auth_state].label}</option>)}
          </SelectField>)}
        <TextArea label="Chat nguồn" rows={4} value={sources} onChange={(e) => setSources(e.target.value)} error={errors.source_chat_ids} disabled={chatsLocked}
          hint={chatsLocked ? "Hãy dừng tuyến để sửa nguồn/đích." : "Mỗi dòng một chat id. Nhóm/kênh có dạng -100…"} spellCheck={false} />
        <TextArea label="Chat đích" rows={4} value={dests} onChange={(e) => setDests(e.target.value)} error={errors.destination_chat_ids} disabled={chatsLocked}
          hint={chatsLocked ? "Hãy dừng tuyến để sửa nguồn/đích." : "Mỗi dòng một chat id. Đổi nguồn/đích sẽ cần xác minh lại."} spellCheck={false} />
        <div className="field span-2">
          <span className="label" id="mode-label">Cách gửi</span>
          <div className="seg" role="group" aria-labelledby="mode-label">
            <button type="button" aria-pressed={mode === "forward"} onClick={() => setMode("forward")}>Chuyển tiếp gốc</button>
            <button type="button" aria-pressed={mode === "copy"} onClick={() => setMode("copy")}>Sao chép nội dung</button>
          </div>
          <span className="hint">{mode === "forward" ? "Giữ nhãn “chuyển tiếp từ”. Không dùng được với chat bật bảo vệ nội dung." : "Gửi lại nội dung như tin mới, không có nhãn nguồn. Cũng bị chặn ở chat bật bảo vệ nội dung."}</span>
        </div>
        <fieldset className="field span-2" style={{ border: 0, padding: 0, margin: 0 }}>
          <legend className="label">Chỉ chuyển các loại nội dung (để trống = tất cả)</legend>
          <div className="row" style={{ gap: 16 }}>{ALL_TYPES.map((t) => <Check key={t} checked={types.includes(t)} onChange={() => toggle(t)} label={contentTypes[t]} />)}</div>
        </fieldset>
        <TextArea label="Phải chứa một trong các từ khóa" rows={3} value={include} onChange={(e) => setInclude(e.target.value)} error={errors.keywords} hint="Mỗi dòng một từ khóa, không phân biệt hoa thường. Để trống = không yêu cầu." />
        <TextArea label="Loại trừ nếu chứa từ khóa" rows={3} value={exclude} onChange={(e) => setExclude(e.target.value)} hint="Tin chứa bất kỳ từ khóa nào ở đây sẽ bị bỏ qua." />
        <div className="span-2"><Check checked={outgoing} onChange={(e) => setOutgoing(e.target.checked)} label="Cũng chuyển tin do chính tài khoản này gửi" hint="Mặc định tắt để tránh vòng lặp (tin hệ thống vừa gửi bị chuyển lại)." /></div>
        <TextField label="Mức ưu tiên (1–9)" type="number" min={1} max={9} value={priority} onChange={(e) => setPriority(e.target.value)} error={errors.priority} hint="1 được xử lý trước 9." />
        <TextField label="Tối đa tin mỗi phút" type="number" min={1} max={600} value={rate} onChange={(e) => setRate(e.target.value)} error={errors.rate_per_minute} />
        <TextField label="Số lần thử tối đa" type="number" min={1} max={10} value={attempts} onChange={(e) => setAttempts(e.target.value)} error={errors.max_attempts} hint="Hết số lần này, tác vụ vào hàng chờ lỗi để bạn xử lý." />
      </div>
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
