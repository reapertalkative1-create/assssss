import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn()}};});
import {api,ApiError} from '../api/client';
import {PostBatch} from './PostBatch';
it('starts only verified unrestricted SS and displays per-account failures without claiming success',async()=>{
 const user=userEvent.setup();
 const base={id:'r1',account_name:'Ready SS',account_id:'a1',verified:true,status:'stopped',stats:{},link_config:{targets:['@target_1'],delay_seconds:60}};
 const rows=[base,{...base,id:'r2',account_name:'Blocked SS',account_restriction:'blocked'},{...base,id:'r3',account_name:'Draft SS',verified:false}];vi.mocked(api.get).mockImplementation(async path=>path.includes('/batches/')?{items:rows}:rows.find(r=>path.endsWith(r.id))!);
 vi.mocked(api.post).mockRejectedValue(new ApiError(409,'worker_unavailable','Worker đang offline.'));
 render(<PostBatch batchId="b1" onClose={()=>{}} onDetail={()=>{}}/>);
 await waitFor(()=>expect(screen.getByLabelText('Chọn SS Ready SS')).toBeVisible());expect(api.post).not.toHaveBeenCalled();
 await user.click(screen.getByRole('button',{name:'Chọn kết quả lọc (3)'}));
 await user.selectOptions(screen.getByLabelText('Thao tác trên dòng đã chọn'),'start');
 await user.click(screen.getByRole('button',{name:'Áp dụng (3)'}));
 expect(await screen.findByText('Worker đang offline.')).toBeVisible();
 expect(api.post).toHaveBeenCalledTimes(1);expect(api.post).toHaveBeenCalledWith('/api/routes/r1/start',undefined);
});
