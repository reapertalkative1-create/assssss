import re
import uuid
from datetime import datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

_PHONE = re.compile(r"^\+?[0-9]{7,15}$")


class AccountName(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        v = " ".join(v.split())
        if not 1 <= len(v) <= 64:
            raise ValueError("Tên tài khoản dài 1–64 ký tự.")
        return v


class AccountRename(AccountName):
    pass


def _api_hash(value):
    if value is None:
        return None
    raw = value.get_secret_value() if isinstance(value, SecretStr) else str(value)
    raw = raw.strip()
    if not re.fullmatch(r'[0-9a-fA-F]{32}', raw):
        raise ValueError('api_hash phải gồm 32 ký tự hexadecimal, lấy từ my.telegram.org.')
    return SecretStr(raw.lower())


class TelegramApiSelection(BaseModel):
    model_config = ConfigDict(extra='forbid')
    api_id: int | None = Field(default=None, ge=1, le=2147483647)
    api_hash: SecretStr | None = None
    _hash = field_validator('api_hash', mode='before')(_api_hash)

    @model_validator(mode='after')
    def _pair(self):
        if (self.api_id is None) != (self.api_hash is None):
            raise ValueError('Nhập đầy đủ api_id và api_hash.')
        return self


class AccountCreate(AccountName, TelegramApiSelection):
    worker_id: uuid.UUID | None = None
    group_id: uuid.UUID | None = None


class TelegramApiConfig(BaseModel):
    model_config = ConfigDict(extra='forbid')
    api_id: int = Field(ge=1, le=2147483647)
    api_hash: SecretStr
    _hash = field_validator('api_hash', mode='before')(_api_hash)


class AssignRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    worker_id: uuid.UUID | None


class LoginStart(BaseModel):
    model_config = ConfigDict(extra="forbid")
    phone: str = Field(max_length=32)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v: str) -> str:
        v = re.sub(r"[\s().-]", "", v)
        if not _PHONE.fullmatch(v):
            raise ValueError("Số điện thoại không hợp lệ (định dạng quốc tế, ví dụ +84901234567).")
        return v if v.startswith("+") else "+" + v


class LoginCode(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(max_length=16)

    @field_validator("code")
    @classmethod
    def _code(cls, v: str) -> str:
        v = v.strip().replace(" ", "")
        if not re.fullmatch(r"[0-9]{4,8}", v):
            raise ValueError("Mã xác nhận gồm 4–8 chữ số.")
        return v


class LoginPassword(BaseModel):
    model_config = ConfigDict(extra="forbid")
    password: str = Field(min_length=1, max_length=256)


class DeleteAccount(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirm_name: str = Field(max_length=64)
    telegram_logout: bool = True   # also terminate the session on Telegram's side
    force: bool = False            # delete even if the worker cannot log out (session stays active on Telegram!)


class AccountRowOperation(BaseModel):
    id: uuid.UUID
    kind: Literal['bulk', 'command']
    action: str
    status: str
    job_status: str | None = None
    error_code: str | None = None
    updated_at: datetime


class AccountOut(BaseModel):
    group_id: uuid.UUID | None = None
    group_name: str | None = None
    restriction_term: Literal['none','unknown','permanent','temporary'] = 'none'
    restriction_until: datetime | None = None
    proxy_label: str | None = None
    proxy_status: str = 'unknown'
    proxy_checked_at: datetime | None = None
    proxy_error: str | None = None
    proxy_latency_ms: int | None = None

    id: uuid.UUID
    name: str
    phone_masked: str | None
    telegram_user_id: int | None
    telegram_username: str | None
    auth_state: str
    desired_state: Literal["running", "stopped"]
    connection_state: str
    connection_error: str | None
    last_active_at: datetime | None
    assigned_worker_id: uuid.UUID | None
    assigned_worker_name: str | None
    owner_worker_id: uuid.UUID | None  # worker currently holding the lease
    has_session: bool                  # whether a session exists; its content is never exposed
    telegram_api_configured: bool = False
    session_imported: bool = False
    spam_status: str = 'not_checked'
    spam_checked_at: datetime | None = None
    spam_error: str | None = None
    spam_action_status: str = 'none'
    spam_response: str | None = None
    row_operations: list[AccountRowOperation] = Field(default_factory=list)
    health_status: str = 'unknown'
    health_source: str = 'telegram'
    health_checked_at: datetime | None = None
    health_error: str | None = None
    flood_wait_until: datetime | None = None
    pending_deletion: bool
    created_at: datetime


class CommandAccepted(BaseModel):
    command_id: uuid.UUID
    status: str


class CommandOut(BaseModel):
    id: uuid.UUID
    type: str
    status: str
    error_code: str | None
    retry_after: int | None
    result: dict | None
    created_at: datetime
    completed_at: datetime | None


class DeleteOut(BaseModel):
    status: Literal["deleted", "logout_requested"]
    telegram_session_revoked: bool | None = None
    command_id: uuid.UUID | None = None


# ---------------- worker-facing ----------------
class AssignmentOut(BaseModel):
    proxy_version: int = 0
    account_id: uuid.UUID
    name: str
    desired_state: Literal["running", "stopped"]


class AccountReport(BaseModel):
    account_id: uuid.UUID
    epoch: int = Field(ge=0)
    state: Literal["connecting", "connected", "error"]
    error_code: str | None = Field(default=None, max_length=64)


class PollRequest(BaseModel):
    wait_seconds: int = Field(default=0, ge=0, le=25)


class PolledCommand(BaseModel):
    id: uuid.UUID
    type: str
    account_id: uuid.UUID
    payload: dict | None


class PollResponse(BaseModel):
    commands: list[PolledCommand]


class CommandResultIn(BaseModel):
    status: Literal["done", "failed"]
    result: dict | None = None
    error_code: str | None = Field(default=None, max_length=64)
    retry_after: int | None = Field(default=None, ge=0, le=2147483647)


class LeaseOut(BaseModel):
    epoch: int
    ttl_seconds: int


class EpochIn(BaseModel):
    epoch: int = Field(ge=1)


class SessionFetchOut(BaseModel):
    session: str
    version: int


class SessionUpload(BaseModel):
    epoch: int = Field(ge=1)
    session: str = Field(min_length=20, max_length=20000)
    expected_version: int | None = Field(default=None, ge=0)


class SessionVersionOut(BaseModel):
    version: int


class ImportFile(BaseModel):
    model_config = ConfigDict(extra='forbid')
    filename: str = Field(min_length=1, max_length=200)
    content: SecretStr = Field(max_length=14 * 1024 * 1024)


class SessionImportRequest(TelegramApiSelection):
    group_id: uuid.UUID | None = None
    auto_check_spam: bool = False
    require_proxy: bool = False
    proxy_protocol: Literal['socks5', 'socks4', 'http'] = 'socks5'
    # Positions refer to the expanded session files, including invalid/duplicate files.
    proxies: list[Annotated[SecretStr, Field(min_length=1, max_length=2048)]] | None = Field(default=None, max_length=100)
    worker_id: uuid.UUID
    files: list[ImportFile] = Field(min_length=1, max_length=100)


class ImportStatusRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')
    command_ids: list[uuid.UUID] = Field(min_length=1, max_length=100)


class AccountFilters(BaseModel):
    group_id: uuid.UUID | None=None
    ungrouped: bool=False
    proxy_status: Literal['alive','dead','unknown','checking'] | None=None
    model_config=ConfigDict(extra='forbid')
    q: str | None=Field(default=None,max_length=64)
    auth_state: str | None=Field(default=None,max_length=24)
    worker_id: uuid.UUID | None=None
    health_status: Literal['unknown','live','dead','frozen','waiting','error'] | None=None
    desired_state: Literal['running','stopped'] | None=None
    spam_status: Literal['not_checked','clear','limited','blocked','unknown','error'] | None=None


class AccountBulkRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    action: Literal['start','stop','check','spam_check','proxy_check','delete','mark_frozen','clear_mark']
    all_matching: bool=False
    exclude_ids: list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    account_ids: list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    filters: AccountFilters=Field(default_factory=AccountFilters)


class SpamActionRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    request_id: uuid.UUID
    report_token: str = Field(min_length=64,max_length=64,pattern=r'^[a-f0-9]{64}$')
    operation: Literal['reply','button']
    text: SecretStr | None = Field(default=None,max_length=4000)
    button_id: str | None = Field(default=None,max_length=64,pattern=r'^[0-9]+:[0-9]+:[0-9]+$')


class AppealProfile(BaseModel):
    model_config=ConfigDict(extra='forbid')
    email: SecretStr | None=Field(default=None,max_length=320)
    phone: SecretStr | None=Field(default=None,max_length=16)

    @model_validator(mode='after')
    def valid(self):
        if self.email and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',self.email.get_secret_value()):
            raise ValueError('Email không hợp lệ.')
        if self.phone and not re.fullmatch(r'\+?[0-9]{7,15}',self.phone.get_secret_value()):
            raise ValueError('Số điện thoại cần có mã quốc gia.')
        return self


class BulkAppealRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    all_matching: bool=False
    account_ids: list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    exclude_ids: list[uuid.UUID]=Field(default_factory=list,max_length=10000)
    filters: AccountFilters=Field(default_factory=AccountFilters)
    template: SecretStr=Field(min_length=1,max_length=3500)
    email: SecretStr | None=Field(default=None,max_length=320)
    profiles: dict[str,AppealProfile]=Field(default_factory=dict,max_length=10000)

    @model_validator(mode='after')
    def valid(self):
        text=self.template.get_secret_value()
        if any(f not in ('name','phone','email') for f in re.findall(r'\{([^{}]+)\}',text)):
            raise ValueError('Chỉ hỗ trợ {name}, {phone}, {email}.')
        if self.email and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',self.email.get_secret_value()):
            raise ValueError('Email chung không hợp lệ.')
        if any(len(key)>128 for key in self.profiles):raise ValueError('Tên hoặc ID tài khoản quá dài.')
        return self


class BulkAppealConfirm(BaseModel):
    model_config=ConfigDict(extra='forbid')
    review_token: str=Field(min_length=64,max_length=64,pattern=r'^[a-f0-9]{64}$')
    facts_confirmed: bool
