import uuid
from app.models import ForwardRoute, TelegramAccount
from tests.conftest import run_db
from tests.unit.test_accounts_api import env
from tests.unit.test_multi_senders import body


def batch(env, ids, **extra):
    response = env.client.post('/api/post-routes/batches', headers=env.h, json=body(ids, **extra))
    assert response.status_code == 201, response.text
    return response.json()['items']


def test_selection_matches_filters_and_has_only_identities(env):
    a = env.make_account('Khách hàng A'); b = env.make_account('Nội bộ B')
    rows = batch(env, [a,b])
    async def change(db):
        r = await db.get(ForwardRoute,uuid.UUID(rows[0]['id']))
        r.status='paused';r.link_config={**r.link_config,'work_cluster_name':'Cụm miền Nam'}
    run_db(env.settings,change)
    for query, count in [({'q':'KHÁCH HÀNG'},1),({'q':'miền nam'},1),({'status':'paused'},1),({'kind':'post'},2),({'kind':'watch'},0)]:
        selected = env.client.post('/api/routes/selection', headers=env.h, json=query)
        listing = env.client.get('/api/routes',params=query)
        assert selected.status_code == listing.status_code == 200
        assert len(selected.json()['items']) == listing.json()['total'] == count
        assert {r['id'] for r in selected.json()['items']} == {r['id'] for r in listing.json()['items']}
        assert all(set(r)=={'id','name','account_id','account_name'} for r in selected.json()['items'])
    assert env.client.get('/api/jobs').json()['total']==0


def test_preview_reuses_accounts_and_deduplicates_targets_without_creating_or_sending(env):
    ids=[env.make_account('A'),env.make_account('B')]
    rows=batch(env,ids)
    repeated=batch(env,ids,post_link='https://t.me/source_group/124',delay_seconds=120,mode='copy')
    route_ids=[r['id'] for r in rows+repeated]
    result=env.client.post('/api/work-clusters/from-routes/preview',headers=env.h,json={'route_ids':route_ids})
    assert result.status_code==200,result.text
    data=result.json()
    assert len(data['targets'])==4 and len(data['senders'])==2
    assert {a['id'] for a in data['senders']}==set(ids)
    assert data['mixed_settings'] and data['delay_seconds']==120 and data['mode']=='forward'
    assert env.client.get('/api/work-clusters').json()['total']==0
    assert env.client.get('/api/jobs').json()['total']==0
    retry=env.client.post('/api/work-clusters/from-routes/preview',headers=env.h,json={'route_ids':list(reversed(route_ids))})
    assert retry.json()==data
    saved=env.client.post('/api/work-clusters',headers=env.h,json={'request_id':str(uuid.uuid4()),'name':'Cụm từ lượt cũ',
        'account_ids':[a['id'] for a in data['senders']],'targets_text':'\n'.join(data['targets']),'mode':data['mode'],'delay_seconds':data['delay_seconds']})
    assert saved.status_code==201,saved.text
    assert saved.json()['account_count']==2 and saved.json()['target_count']==4
    assert env.client.get('/api/routes').json()['total']==4
    assert env.client.get('/api/routes/'+rows[0]['id']).json()['link_config']==rows[0]['link_config']


def test_preview_rejects_missing_rows_watchers_and_deleted_accounts(env):
    aid=env.make_account();row=batch(env,[aid])[0]
    url='/api/work-clusters/from-routes/preview'
    assert env.client.post(url,headers=env.h,json={'route_ids':[row['id'],str(uuid.uuid4())]}).status_code==409
    async def watcher(db):
        r=ForwardRoute(name='Watch',name_key='watch',account_id=uuid.UUID(aid),source_chat_ids=[-1001],destination_chat_ids=[-1002])
        db.add(r);await db.flush();return str(r.id)
    wid=run_db(env.settings,watcher)
    assert env.client.post(url,headers=env.h,json={'route_ids':[wid]}).status_code==422
    async def mark(db):(await db.get(TelegramAccount,uuid.UUID(aid))).__setattr__('pending_deletion',True)
    run_db(env.settings,mark)
    assert env.client.post(url,headers=env.h,json={'route_ids':[row['id']]}).status_code==409
    assert env.client.get('/api/work-clusters').json()['total']==0


def test_selection_and_preview_permissions(env,new_client,seed_user,login):
    aid=env.make_account();rid=batch(env,[aid])[0]['id']
    assert env.client.post('/api/routes/selection',json={}).status_code==403
    seed_user('viewer',role='operator');c=new_client();h=login(c,'viewer')
    assert c.post('/api/routes/selection',headers=h,json={}).status_code==200
    assert c.post('/api/work-clusters/from-routes/preview',headers=h,json={'route_ids':[rid]}).status_code==403
