"""Worker settings. Same code on Linux and Windows; only the platform label differs."""
import sys
from functools import lru_cache
from typing import Literal
from urllib.parse import urlsplit

from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def detect_platform() -> Literal["linux", "windows"]:
    return "windows" if sys.platform.startswith("win") else "linux"


class WorkerSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TFCC_WORKER_", env_file=".env", extra="ignore")

    control_plane_url: str = ""
    id: str = ""  # optional; the worker id is embedded in the credential
    name: str = "worker"
    credential: SecretStr = SecretStr("")
    # Telegram app credentials (my.telegram.org) live ONLY on the worker; the control plane never sees them.
    telegram_api_id: int | None = None
    telegram_api_hash: SecretStr = SecretStr("")

    @property
    def telegram_configured(self) -> bool:
        return bool(self.telegram_api_id and self.telegram_api_hash.get_secret_value())

    @field_validator("control_plane_url")
    @classmethod
    def _https_only(cls, v: str) -> str:
        v = v.strip().rstrip("/")
        if not v:
            return v
        try:
            url = urlsplit(v)
            host, port = url.hostname, url.port
        except ValueError:
            raise ValueError("control_plane_url is not a valid HTTP(S) URL") from None
        if (not host or port == 0 or url.username is not None or url.password is not None or url.query or url.fragment
                or any(c.isspace() for c in v)):
            raise ValueError("control_plane_url must have a host and no userinfo, query or fragment")
        if url.scheme != "https" and not (url.scheme == "http" and host in {"localhost", "127.0.0.1", "::1"}):
            raise ValueError("control_plane_url must use https:// (http only for loopback hosts)")
        return v

    @property
    def platform(self) -> Literal["linux", "windows"]:
        return detect_platform()


@lru_cache
def get_worker_settings() -> WorkerSettings:
    return WorkerSettings()
