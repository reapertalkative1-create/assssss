"""Telegram access behind a small interface so the account logic can be tested without Telegram.

TelethonBackend is the real implementation. Sessions are Telethon StringSessions held in memory only:
the worker never writes session files to disk. FloodWait is never slept through silently: the exact wait
Telegram asked for is surfaced to the caller (flood_sleep_threshold=0)."""
import asyncio
from dataclasses import dataclass
from typing import Any, Protocol


class BackendError(Exception):
    """A Telegram-side failure reduced to a stable code (no message text, which might contain personal data)."""

    def __init__(self, code: str, retry_after: int | None = None):
        super().__init__(code)
        self.code, self.retry_after = code, retry_after


@dataclass(frozen=True)
class UserInfo:
    telegram_user_id: int
    username: str | None


@dataclass(frozen=True)
class SignInResult:
    kind: str  # "authorized" | "password_needed"
    user: UserInfo | None = None


@dataclass(frozen=True)
class ChatInfo:
    ok: bool                     # the account can see the chat
    can_send: bool | None = None  # the account may write to it (best effort; the send itself is the final authority)
    title: str | None = None


@dataclass(frozen=True)
class MessageFacts:
    chat_id: int
    message_id: int
    text: str                    # stays on the worker (used only for keyword filters); never sent to the API or logged
    kind: str                    # text|photo|video|voice|audio|sticker|document|other
    outgoing: bool = False
    is_service: bool = False


class TelegramBackend(Protocol):
    async def prime(self, handle: Any) -> None: ...
    async def resolve_chats(self, handle: Any, chat_ids: list[int]) -> dict[int, ChatInfo]: ...
    async def latest_message_id(self, handle: Any, chat_id: int) -> int: ...
    async def history_since(self, handle: Any, chat_id: int, min_id: int, limit: int) -> list[MessageFacts]: ...
    def watch(self, handle: Any, chat_ids: set[int], callback: Any) -> Any: ...
    def unwatch(self, handle: Any, token: Any) -> None: ...
    async def forward(self, handle: Any, source: int, message_id: int, dest: int, mode: str) -> int | None: ...
    async def send_code(self, phone: str) -> Any: ...
    async def sign_in_code(self, handle: Any, code: str) -> SignInResult: ...
    async def sign_in_password(self, handle: Any, password: str) -> UserInfo: ...
    def session_string(self, handle: Any) -> str: ...
    async def connect(self, session: str) -> tuple[Any, UserInfo]: ...
    def is_connected(self, handle: Any) -> bool: ...
    async def disconnect(self, handle: Any) -> None: ...
    async def log_out(self, handle: Any) -> None: ...


def map_error(exc: BaseException) -> BackendError:
    from telethon import errors as e

    if isinstance(exc, BackendError):
        return exc
    if isinstance(exc, e.FloodWaitError):
        return BackendError("flood_wait", int(exc.seconds))           # whole account must wait
    if isinstance(exc, e.SlowModeWaitError):
        return BackendError("slow_mode", int(exc.seconds))            # only this chat: not an account-wide wait
    table = [
        (e.PhoneNumberInvalidError, "phone_invalid"), (e.PhoneNumberBannedError, "phone_banned"),
        (e.PhoneNumberFloodError, "phone_flood"), (e.PhoneCodeInvalidError, "code_invalid"),
        (e.PhoneCodeEmptyError, "code_invalid"), (e.PhoneCodeExpiredError, "code_expired"),
        (e.PasswordHashInvalidError, "password_invalid"), (e.ApiIdInvalidError, "telegram_api_id_invalid"),
        (e.AuthKeyUnregisteredError, "auth_key_unregistered"), (e.AuthKeyDuplicatedError, "auth_key_duplicated"),
        (e.UserDeactivatedBanError, "user_deactivated"), (e.UserDeactivatedError, "user_deactivated"),
        (e.SessionRevokedError, "session_revoked"), (e.SessionExpiredError, "session_revoked"),
        (e.ChatWriteForbiddenError, "destination_forbidden"), (e.ChatAdminRequiredError, "destination_forbidden"),
        (e.UserBannedInChannelError, "destination_forbidden"), (e.ChatSendMediaForbiddenError, "destination_forbidden"),
        (e.ChatSendPlainForbiddenError, "destination_forbidden"), (e.UserIsBlockedError, "destination_forbidden"),
        (e.ChatRestrictedError, "destination_forbidden"), (e.ChannelPrivateError, "chat_unavailable"),
        (e.ChannelInvalidError, "chat_unavailable"), (e.PeerIdInvalidError, "chat_unavailable"),
        (e.MessageIdInvalidError, "message_not_found"), (e.MessageEmptyError, "message_not_found"),
        (e.ChatForwardsRestrictedError, "forward_restricted"), (e.MediaEmptyError, "media_unsupported"),
    ]
    for cls, code in table:
        if isinstance(exc, cls):
            return BackendError(code)
    if isinstance(exc, (ConnectionError, OSError, asyncio.TimeoutError)):
        return BackendError("network_error")
    return BackendError("telegram_error")


def _facts(msg) -> MessageFacts:
    if msg.sticker:
        kind = "sticker"
    elif msg.photo:
        kind = "photo"
    elif msg.voice:
        kind = "voice"
    elif msg.audio:
        kind = "audio"
    elif msg.video or msg.video_note or msg.gif:
        kind = "video"
    elif msg.document:
        kind = "document"
    elif msg.media:
        kind = "other"
    else:
        kind = "text"
    return MessageFacts(int(msg.chat_id), int(msg.id), msg.message or "", kind, bool(msg.out), bool(getattr(msg, "action", None)))


def _user_info(me) -> UserInfo:
    return UserInfo(int(me.id), getattr(me, "username", None))


class _Handle:
    def __init__(self, client, phone: str | None = None, phone_code_hash: str | None = None):
        self.client, self.phone, self.phone_code_hash = client, phone, phone_code_hash


class TelethonBackend:
    def __init__(self, api_id: int, api_hash: str):
        self._api_id, self._api_hash = api_id, api_hash

    def _new_client(self, session: str = ""):
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        return TelegramClient(StringSession(session), self._api_id, self._api_hash, flood_sleep_threshold=0)

    async def send_code(self, phone: str) -> _Handle:
        client = self._new_client()
        try:
            await client.connect()
            sent = await client.send_code_request(phone)
        except BaseException as exc:
            await self._quiet_disconnect(client)
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise map_error(exc) from None
        return _Handle(client, phone, sent.phone_code_hash)

    async def sign_in_code(self, handle: _Handle, code: str) -> SignInResult:
        from telethon import errors as e

        try:
            await handle.client.sign_in(phone=handle.phone, code=code, phone_code_hash=handle.phone_code_hash)
        except e.SessionPasswordNeededError:
            return SignInResult("password_needed")
        except Exception as exc:
            raise map_error(exc) from None
        return SignInResult("authorized", _user_info(await handle.client.get_me()))

    async def sign_in_password(self, handle: _Handle, password: str) -> UserInfo:
        try:
            await handle.client.sign_in(password=password)
            return _user_info(await handle.client.get_me())
        except Exception as exc:
            raise map_error(exc) from None

    def session_string(self, handle: _Handle) -> str:
        return handle.client.session.save()

    async def connect(self, session: str) -> tuple[_Handle, UserInfo]:
        client = self._new_client(session)
        try:
            await client.connect()
            if not await client.is_user_authorized():
                raise BackendError("auth_key_unregistered")
            me = await client.get_me()
        except BaseException as exc:
            await self._quiet_disconnect(client)
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise map_error(exc) from None
        return _Handle(client), _user_info(me)

    def is_connected(self, handle: _Handle) -> bool:
        return bool(handle.client.is_connected())

    async def disconnect(self, handle: _Handle) -> None:
        await self._quiet_disconnect(handle.client)

    async def log_out(self, handle: _Handle) -> None:
        try:
            await handle.client.log_out()  # terminates the session on Telegram's side
        except Exception as exc:
            raise map_error(exc) from None

    # ----- chats, history, live messages, forwarding -----
    async def prime(self, handle: _Handle) -> None:
        """A client restored from a StringSession knows no chats yet; loading the dialogs fills Telethon's entity cache
        (needed to address chats by id). Can be slow for accounts with thousands of chats."""
        try:
            await handle.client.get_dialogs()
        except Exception as exc:
            raise map_error(exc) from None

    async def resolve_chats(self, handle: _Handle, chat_ids: list[int]) -> dict[int, ChatInfo]:
        out: dict[int, ChatInfo] = {}
        for cid in chat_ids:
            try:
                entity = await handle.client.get_entity(cid)
                title = getattr(entity, "title", None) or getattr(entity, "first_name", None)
                perms = await handle.client.get_permissions(entity)
                can_send = bool(perms is None or getattr(perms, "is_admin", False) or getattr(perms, "send_messages", False)
                                or getattr(perms, "post_messages", False))
                out[cid] = ChatInfo(True, can_send, (title or "")[:100] or None)
            except Exception as exc:
                err = map_error(exc)
                if err.code in ("flood_wait", "network_error"):
                    raise err from None
                out[cid] = ChatInfo(False, None, None)
        return out

    async def latest_message_id(self, handle: _Handle, chat_id: int) -> int:
        try:
            msgs = await handle.client.get_messages(chat_id, limit=1)
        except Exception as exc:
            raise map_error(exc) from None
        return int(msgs[0].id) if msgs else 0

    async def history_since(self, handle: _Handle, chat_id: int, min_id: int, limit: int) -> list[MessageFacts]:
        try:
            return [_facts(m) async for m in handle.client.iter_messages(chat_id, min_id=min_id, limit=limit, reverse=True)]
        except Exception as exc:
            raise map_error(exc) from None

    def watch(self, handle: _Handle, chat_ids: set[int], callback) -> Any:
        from telethon import events

        async def _handler(event):
            try:
                callback(_facts(event.message))
            except Exception:
                pass  # a bad message must never break the update loop

        builder = events.NewMessage(chats=list(chat_ids))
        handle.client.add_event_handler(_handler, builder)
        return (_handler, builder)

    def unwatch(self, handle: _Handle, token) -> None:
        try:
            handle.client.remove_event_handler(token[0], token[1])
        except Exception:
            pass

    async def forward(self, handle: _Handle, source: int, message_id: int, dest: int, mode: str) -> int | None:
        client = handle.client
        try:
            if mode == "forward":
                sent = await client.forward_messages(dest, message_id, from_peer=source)
            else:  # copy: re-send the content without the "forwarded from" header (refused for protected chats)
                msg = await client.get_messages(source, ids=message_id)
                if msg is None or getattr(msg, "empty", False):
                    raise BackendError("message_not_found")
                if getattr(msg, "noforwards", False):
                    raise BackendError("forward_restricted")
                sent = await client.send_message(dest, msg)
        except Exception as exc:
            raise map_error(exc) from None
        sent = sent[0] if isinstance(sent, list) and sent else sent
        if not sent:
            raise BackendError("message_not_found")
        return getattr(sent, "id", None)

    @staticmethod
    async def _quiet_disconnect(client) -> None:
        try:
            await asyncio.wait_for(client.disconnect(), timeout=5)
        except Exception:
            pass
