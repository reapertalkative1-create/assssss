import re
import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

_PHONE = re.compile(r"^\+?[0-9]{7,15}$")


class AccountCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        v = " ".join(v.split())
        if not 1 <= len(v) <= 64:
            raise ValueError("Tên tài khoản dài 1–64 ký tự.")
        return v


class AccountRename(AccountCreate):
    pass


class AssignRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    worker_id: uuid.UUID | None


class LoginStart(BaseModel):
    model_config = ConfigDict(extra="forbid")
    phone: str = Field(max_length=32)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v: str) -> str:
        v = re.sub(r"[\s().-]", "", v)
        if not _PHONE.fullmatch(v):
            raise ValueError("Số điện thoại không hợp lệ (định dạng quốc tế, ví dụ +84901234567).")
        return v if v.startswith("+") else "+" + v


class LoginCode(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(max_length=16)

    @field_validator("code")
    @classmethod
    def _code(cls, v: str) -> str:
        v = v.strip().replace(" ", "")
        if not re.fullmatch(r"[0-9]{4,8}", v):
            raise ValueError("Mã xác nhận gồm 4–8 chữ số.")
        return v


class LoginPassword(BaseModel):
    model_config = ConfigDict(extra="forbid")
    password: str = Field(min_length=1, max_length=256)


class DeleteAccount(BaseModel):
    model_config = ConfigDict(extra="forbid")
    confirm_name: str = Field(max_length=64)
    telegram_logout: bool = True   # also terminate the session on Telegram's side
    force: bool = False            # delete even if the worker cannot log out (session stays active on Telegram!)


class AccountOut(BaseModel):
    id: uuid.UUID
    name: str
    phone_masked: str | None
    telegram_user_id: int | None
    telegram_username: str | None
    auth_state: str
    desired_state: Literal["running", "stopped"]
    connection_state: str
    connection_error: str | None
    last_active_at: datetime | None
    assigned_worker_id: uuid.UUID | None
    assigned_worker_name: str | None
    owner_worker_id: uuid.UUID | None  # worker currently holding the lease
    has_session: bool                  # whether a session exists; its content is never exposed
    pending_deletion: bool
    created_at: datetime


class CommandAccepted(BaseModel):
    command_id: uuid.UUID
    status: str


class CommandOut(BaseModel):
    id: uuid.UUID
    type: str
    status: str
    error_code: str | None
    retry_after: int | None
    result: dict | None
    created_at: datetime
    completed_at: datetime | None


class DeleteOut(BaseModel):
    status: Literal["deleted", "logout_requested"]
    telegram_session_revoked: bool | None = None
    command_id: uuid.UUID | None = None


# ---------------- worker-facing ----------------
class AssignmentOut(BaseModel):
    account_id: uuid.UUID
    name: str
    desired_state: Literal["running", "stopped"]


class AccountReport(BaseModel):
    account_id: uuid.UUID
    epoch: int = Field(ge=0)
    state: Literal["connecting", "connected", "error"]
    error_code: str | None = Field(default=None, max_length=64)


class PollRequest(BaseModel):
    wait_seconds: int = Field(default=0, ge=0, le=25)


class PolledCommand(BaseModel):
    id: uuid.UUID
    type: str
    account_id: uuid.UUID
    payload: dict | None


class PollResponse(BaseModel):
    commands: list[PolledCommand]


class CommandResultIn(BaseModel):
    status: Literal["done", "failed"]
    result: dict | None = None
    error_code: str | None = Field(default=None, max_length=64)
    retry_after: int | None = Field(default=None, ge=0, le=86400)


class LeaseOut(BaseModel):
    epoch: int
    ttl_seconds: int


class EpochIn(BaseModel):
    epoch: int = Field(ge=1)


class SessionFetchOut(BaseModel):
    session: str
    version: int


class SessionUpload(BaseModel):
    epoch: int = Field(ge=1)
    session: str = Field(min_length=20, max_length=20000)
    expected_version: int | None = Field(default=None, ge=0)


class SessionVersionOut(BaseModel):
    version: int
