"""Encryption of Telegram sessions and transient command payloads.

Keys live OUTSIDE the database (env var or a 0600 file) so a stolen DB dump alone is useless.
Several keys may be configured: the first encrypts, all decrypt, which allows key rotation.
Every ciphertext is bound to its owner (purpose + record id) so rows cannot be swapped."""
import json
import os
import re
import stat
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken, MultiFernet


class CryptoError(Exception):
    """Never carries plaintext, keys or tokens in its message."""


class SecretBox:
    def __init__(self, keys: list[str]):
        if not keys:
            raise CryptoError("no encryption key configured")
        try:
            self._fernets = [Fernet(k.encode()) for k in keys]
        except Exception:
            raise CryptoError("invalid encryption key (expected a Fernet key: python -m app.cli generate-key)") from None
        self._multi = MultiFernet(self._fernets)

    @property
    def key_count(self) -> int:
        return len(self._fernets)

    @staticmethod
    def generate_key() -> str:
        return Fernet.generate_key().decode()

    def seal(self, purpose: str, owner_id: str, plaintext: str) -> str:
        envelope = json.dumps({"v": 1, "p": purpose, "o": owner_id, "d": plaintext}, separators=(",", ":"))
        return self._multi.encrypt(envelope.encode()).decode()

    def open(self, purpose: str, owner_id: str, token: str) -> str:
        try:
            envelope = json.loads(self._multi.decrypt(token.encode()))
        except (InvalidToken, ValueError):
            raise CryptoError("cannot decrypt (wrong or missing key, or corrupted data)") from None
        if envelope.get("p") != purpose or envelope.get("o") != owner_id:
            raise CryptoError("ciphertext does not belong to this record")
        return envelope["d"]

    def is_current(self, token: str) -> bool:
        """True if the token is encrypted with the primary key."""
        try:
            self._fernets[0].decrypt(token.encode())
            return True
        except InvalidToken:
            return False

    def rotate(self, token: str) -> str:
        """Re-encrypt with the primary key."""
        try:
            return self._multi.rotate(token.encode()).decode()
        except InvalidToken:
            raise CryptoError("cannot decrypt (wrong or missing key, or corrupted data)") from None


def _check_key_file_permissions(path: Path) -> None:
    if os.name != "posix":
        return  # Windows: rely on NTFS ACLs (see docs/key-management.md)
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o077:
        raise CryptoError(f"key file {path} must not be accessible by group/others (chmod 600); mode is {oct(mode)}")


def load_keys(raw_key: str, key_file: str = "") -> list[str]:
    parts: list[str] = []
    if key_file:
        path = Path(key_file)
        if not path.is_file():
            raise CryptoError(f"key file not found: {key_file}")
        _check_key_file_permissions(path)
        parts.append(path.read_text(encoding="utf-8"))
    if raw_key:
        parts.append(raw_key)
    return [k for k in re.split(r"[,\s]+", "\n".join(parts)) if k]


def build_secret_box(raw_key: str, key_file: str = "") -> SecretBox | None:
    keys = load_keys(raw_key, key_file)
    return SecretBox(keys) if keys else None
