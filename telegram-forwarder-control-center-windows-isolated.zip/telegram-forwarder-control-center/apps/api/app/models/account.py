import uuid
from datetime import datetime

from sqlalchemy import JSON, BigInteger, Boolean, ForeignKey, Index, Integer, String, Text, false
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base
from app.types import UTCDateTime, utcnow


class TelegramAccount(Base):
    """A Telegram user account. The session is stored encrypted and is never returned by any API."""

    __tablename__ = "telegram_accounts"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(64))
    name_key: Mapped[str] = mapped_column(String(64), unique=True)
    phone_masked: Mapped[str | None] = mapped_column(String(32), nullable=True)  # the full number is never stored
    telegram_user_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # unauthenticated -> awaiting_code -> (awaiting_password ->) authorized ; invalid = Telegram rejected the session
    auth_state: Mapped[str] = mapped_column(String(24), default="unauthenticated", index=True)
    desired_state: Mapped[str] = mapped_column(String(16), default="stopped")  # running | stopped
    connection_state: Mapped[str] = mapped_column(String(24), default="disconnected")
    connection_error: Mapped[str | None] = mapped_column(String(64), nullable=True)
    last_active_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)

    assigned_worker_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("workers.id", ondelete="SET NULL"), nullable=True, index=True)

    session_ciphertext: Mapped[str | None] = mapped_column(Text, nullable=True)
    session_version: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    session_updated_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)

    # Lease = time-limited exclusive ownership of the session. lease_epoch is a fencing token.
    lease_worker_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    lease_expires_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    lease_epoch: Mapped[int] = mapped_column(Integer, default=0, server_default="0")

    flood_wait_until: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)  # Telegram FloodWait, exact
    pending_deletion: Mapped[bool] = mapped_column(Boolean, default=False, server_default=false())
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class WorkerCommand(Base):
    """Short interactive RPC from the dashboard to one worker (login, OTP, logout...).
    Sensitive payloads (phone, OTP, 2FA password) are encrypted, wiped on delivery and on expiry."""

    __tablename__ = "worker_commands"
    __table_args__ = (Index("ix_worker_commands_worker_status", "worker_id", "status"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    worker_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("workers.id", ondelete="CASCADE"))
    account_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("telegram_accounts.id", ondelete="CASCADE"), index=True)
    route_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("forward_routes.id", ondelete="CASCADE", name="fk_worker_commands_route_id"), nullable=True)
    type: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending|delivered|done|failed|expired
    payload_ciphertext: Mapped[str | None] = mapped_column(Text, nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    retry_after: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    delivered_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime)
