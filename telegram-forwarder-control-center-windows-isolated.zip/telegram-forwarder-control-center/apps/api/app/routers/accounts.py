import asyncio
import time
import uuid

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_audit
from app.deps import AuthContext, authenticated, get_db, require_role
from app.errors import ApiError
from app.models import Role, TelegramAccount, Worker, WorkerCommand
from app.schemas import Page
from app.schemas_accounts import (
    AccountCreate, AccountOut, AccountRename, AssignRequest, CommandAccepted, CommandOut, DeleteAccount, DeleteOut,
    LoginCode, LoginPassword, LoginStart,
)
from app.services import accounts as svc
from app.types import utcnow

router = APIRouter(prefix="/api/accounts", tags=["accounts"])
admin_only = require_role(Role.ADMIN)


def _box(request: Request):
    if request.app.state.secret_box is None:
        raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session (TFCC_SESSION_ENCRYPTION_KEY).")
    return request.app.state.secret_box


async def _out(db: AsyncSession, accounts: list[TelegramAccount]) -> list[dict]:
    now = utcnow()
    ids = {a.assigned_worker_id for a in accounts if a.assigned_worker_id}
    names = dict((await db.execute(select(Worker.id, Worker.name).where(Worker.id.in_(ids)))).all()) if ids else {}
    return [{
        "id": a.id, "name": a.name, "phone_masked": a.phone_masked, "telegram_user_id": a.telegram_user_id,
        "telegram_username": a.telegram_username, "auth_state": a.auth_state, "desired_state": a.desired_state,
        "connection_state": svc.effective_connection_state(a, now),
        "connection_error": a.connection_error, "last_active_at": a.last_active_at,
        "assigned_worker_id": a.assigned_worker_id, "assigned_worker_name": names.get(a.assigned_worker_id),
        "owner_worker_id": a.lease_worker_id if svc.lease_active(a, now) else None,
        "has_session": a.session_version > 0 and a.session_ciphertext is not None,
        "pending_deletion": a.pending_deletion, "created_at": a.created_at,
    } for a in accounts]


async def _get(db: AsyncSession, account_id: uuid.UUID) -> TelegramAccount:
    a = await db.get(TelegramAccount, account_id)
    if a is None:
        raise ApiError(404, "not_found", "Không tìm thấy tài khoản Telegram.")
    return a


def _no_pending_deletion(a: TelegramAccount) -> None:
    if a.pending_deletion:
        raise ApiError(409, "pending_deletion", "Tài khoản đang chờ xóa.")


@router.get("", response_model=Page[AccountOut])
async def list_accounts(
    q: str | None = Query(default=None, max_length=64),
    auth_state: str | None = Query(default=None, max_length=24),
    worker_id: uuid.UUID | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    _: AuthContext = Depends(authenticated),
    db: AsyncSession = Depends(get_db, scope="function"),
):
    stmt = select(TelegramAccount)
    if q:
        stmt = stmt.where(TelegramAccount.name_key.contains(q.strip().lower(), autoescape=True))
    if auth_state:
        stmt = stmt.where(TelegramAccount.auth_state == auth_state)
    if worker_id:
        stmt = stmt.where(TelegramAccount.assigned_worker_id == worker_id)
    total = (await db.execute(select(func.count()).select_from(stmt.subquery()))).scalar_one()
    rows = (await db.execute(stmt.order_by(TelegramAccount.created_at.desc(), TelegramAccount.name_key)
                             .offset((page - 1) * page_size).limit(page_size))).scalars().all()
    return Page[AccountOut](items=await _out(db, list(rows)), total=total, page=page, page_size=page_size)


@router.post("", response_model=AccountOut, status_code=201)
async def create_account(body: AccountCreate, request: Request, auth: AuthContext = Depends(admin_only),
                         db: AsyncSession = Depends(get_db, scope="function")):
    a = TelegramAccount(name=body.name, name_key=body.name.lower(), created_by=auth.user.id)
    db.add(a)
    try:
        await db.flush()
    except IntegrityError:
        raise ApiError(409, "name_taken", "Tên tài khoản đã tồn tại.") from None
    await record_audit(db, request, "account.create", actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"name": a.name})
    return (await _out(db, [a]))[0]


@router.get("/{account_id}", response_model=AccountOut)
async def get_account(account_id: uuid.UUID, _: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    return (await _out(db, [await _get(db, account_id)]))[0]


@router.patch("/{account_id}", response_model=AccountOut)
async def rename_account(account_id: uuid.UUID, body: AccountRename, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if body.name != a.name:
        old, a.name, a.name_key = a.name, body.name, body.name.lower()
        try:
            await db.flush()
        except IntegrityError:
            raise ApiError(409, "name_taken", "Tên tài khoản đã tồn tại.") from None
        await record_audit(db, request, "account.update", actor=auth.user, target_type="account", target_id=str(a.id),
                           details={"changed": ["name"], "from": old, "to": a.name})
    return (await _out(db, [a]))[0]


@router.put("/{account_id}/assignment", response_model=AccountOut)
async def assign_worker(account_id: uuid.UUID, body: AssignRequest, request: Request,
                        auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    """Changing the worker never lets two workers share a session: the previous owner loses its right to renew
    immediately and the new worker can only acquire the lease after the old one is released or expires."""
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if body.worker_id is not None:
        w = await db.get(Worker, body.worker_id)
        if w is None:
            raise ApiError(404, "worker_not_found", "Không tìm thấy worker.")
        if w.revoked_at is not None:
            raise ApiError(409, "worker_revoked", "Worker đã bị thu hồi.")
    if a.assigned_worker_id != body.worker_id:
        before, a.assigned_worker_id = a.assigned_worker_id, body.worker_id
        if a.auth_state in ("awaiting_code", "awaiting_password"):
            a.auth_state = "unauthenticated"  # the half-finished login lived in the old worker's memory
        await svc.supersede_login_commands(db, a.id, utcnow())
        await record_audit(db, request, "account.assign", actor=auth.user, target_type="account", target_id=str(a.id),
                           details={"from": str(before) if before else None, "to": str(body.worker_id) if body.worker_id else None})
    return (await _out(db, [a]))[0]


# ----------------------------------------------------------------- login flow (admin only; OTP never stored/audited)
async def _dispatch(request: Request, db: AsyncSession, auth: AuthContext, a: TelegramAccount, type: str,
                    payload: dict | None, audit_action: str, audit_details: dict | None = None) -> dict:
    settings = request.app.state.settings
    now = utcnow()
    worker = await svc.worker_can_take_commands(db, a.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
    if type in svc.LOGIN_COMMANDS and type == "send_code":
        await svc.supersede_login_commands(db, a.id, now)
    cmd = svc.create_command(db, _box(request) if payload else None, worker_id=worker.id, account_id=a.id, type=type,
                             payload=payload, ttl=settings.command_ttl_seconds, created_by=auth.user.id, now=now)
    await record_audit(db, request, audit_action, actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"command_id": str(cmd.id), **(audit_details or {})})
    return {"command_id": cmd.id, "status": "pending"}


@router.post("/{account_id}/login/start", response_model=CommandAccepted, status_code=202)
async def login_start(account_id: uuid.UUID, body: LoginStart, request: Request, auth: AuthContext = Depends(admin_only),
                      db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.auth_state not in svc.LOGIN_ALLOWED_STATES:
        raise ApiError(409, "invalid_state", "Tài khoản đã được xác thực. Hãy đăng xuất hoặc xóa trước khi đăng nhập lại.")
    _box(request)
    a.phone_masked = svc.mask_phone(body.phone)
    return await _dispatch(request, db, auth, a, "send_code", {"phone": body.phone}, "account.login_start",
                           {"phone": a.phone_masked})


@router.post("/{account_id}/login/code", response_model=CommandAccepted, status_code=202)
async def login_code(account_id: uuid.UUID, body: LoginCode, request: Request, auth: AuthContext = Depends(admin_only),
                     db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if a.auth_state != "awaiting_code":
        raise ApiError(409, "invalid_state", "Tài khoản không ở bước chờ mã xác nhận.")
    return await _dispatch(request, db, auth, a, "sign_in_code", {"code": body.code}, "account.login_code_submitted")


@router.post("/{account_id}/login/password", response_model=CommandAccepted, status_code=202)
async def login_password(account_id: uuid.UUID, body: LoginPassword, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    if a.auth_state != "awaiting_password":
        raise ApiError(409, "invalid_state", "Tài khoản không ở bước chờ mật khẩu hai lớp.")
    return await _dispatch(request, db, auth, a, "sign_in_password", {"password": body.password},
                           "account.login_password_submitted")


# ----------------------------------------------------------------- operation (operators allowed)
@router.post("/{account_id}/check", response_model=CommandAccepted, status_code=202)
async def check_connection(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                           db: AsyncSession = Depends(get_db, scope="function")):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if a.auth_state != "authorized":
        raise ApiError(409, "invalid_state", "Tài khoản chưa được xác thực.")
    return await _dispatch(request, db, auth, a, "check_connection", None, "account.check")


async def _set_desired(account_id, desired, request, auth, db):
    a = await _get(db, account_id)
    _no_pending_deletion(a)
    if desired == "running":
        if a.auth_state != "authorized":
            raise ApiError(409, "invalid_state", "Tài khoản chưa được xác thực.")
        if a.assigned_worker_id is None:
            raise ApiError(409, "no_worker_assigned", "Tài khoản chưa được gán cho worker nào.")
    if a.desired_state != desired:  # idempotent: repeating the call changes nothing and writes no audit
        a.desired_state = desired
        await record_audit(db, request, f"account.{'start' if desired == 'running' else 'stop'}", actor=auth.user,
                           target_type="account", target_id=str(a.id))
    return (await _out(db, [a]))[0]


@router.post("/{account_id}/start", response_model=AccountOut)
async def start_account(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                        db: AsyncSession = Depends(get_db, scope="function")):
    return await _set_desired(account_id, "running", request, auth, db)


@router.post("/{account_id}/stop", response_model=AccountOut)
async def stop_account(account_id: uuid.UUID, request: Request, auth: AuthContext = Depends(authenticated),
                       db: AsyncSession = Depends(get_db, scope="function")):
    return await _set_desired(account_id, "stopped", request, auth, db)


@router.get("/{account_id}/commands/{command_id}", response_model=CommandOut)
async def get_command(account_id: uuid.UUID, command_id: uuid.UUID, wait_seconds: int = Query(default=0, ge=0, le=25),
                      _: AuthContext = Depends(authenticated), db: AsyncSession = Depends(get_db, scope="function")):
    """Optionally waits (short polling on the server side) until the command finishes."""
    deadline = time.monotonic() + wait_seconds
    while True:
        cmd = await db.get(WorkerCommand, command_id, populate_existing=True)
        if cmd is None or cmd.account_id != account_id:  # also true once a deleted account's commands are purged
            raise ApiError(404, "not_found", "Không tìm thấy lệnh.")
        if cmd.status in svc.FINAL_STATUSES or time.monotonic() >= deadline:
            return cmd
        await db.commit()  # do not sit in an open transaction while waiting
        await asyncio.sleep(0.5)


# ----------------------------------------------------------------- deletion with explicit confirmation
@router.post("/{account_id}/delete", response_model=DeleteOut)
async def delete_account(account_id: uuid.UUID, body: DeleteAccount, request: Request,
                         auth: AuthContext = Depends(admin_only), db: AsyncSession = Depends(get_db, scope="function")):
    """The caller must retype the account name. By default the Telegram session is terminated on Telegram's side
    (by the owning worker) before the record is purged; `force` skips that and leaves the session active there."""
    a = await _get(db, account_id)
    if body.confirm_name != a.name:
        raise ApiError(422, "confirmation_mismatch", "Tên xác nhận không khớp với tên tài khoản.")
    settings, now = request.app.state.settings, utcnow()
    has_session = a.session_version > 0 and a.session_ciphertext is not None

    if has_session and body.telegram_logout and not body.force:
        worker = await svc.worker_can_take_commands(db, a.assigned_worker_id, settings.heartbeat_timeout_seconds, now)
        a.pending_deletion, a.desired_state = True, "stopped"
        cmd = svc.create_command(db, None, worker_id=worker.id, account_id=a.id, type="logout", payload=None,
                                 ttl=settings.command_ttl_seconds, created_by=auth.user.id, now=now)
        await record_audit(db, request, "account.delete_requested", actor=auth.user, target_type="account",
                           target_id=str(a.id), details={"name": a.name, "command_id": str(cmd.id)})
        return {"status": "logout_requested", "command_id": cmd.id}

    await record_audit(db, request, "account.delete", actor=auth.user, target_type="account", target_id=str(a.id),
                       details={"name": a.name, "had_stored_login": has_session, "forced": body.force,
                                "revoked_on_telegram": False if has_session else None})
    await svc.purge_account(db, a)
    return {"status": "deleted", "telegram_session_revoked": False if has_session else None}
