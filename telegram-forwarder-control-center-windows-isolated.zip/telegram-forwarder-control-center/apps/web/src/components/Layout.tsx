import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../state/auth";
import { ErrorBoundary } from "./ErrorBoundary";
import { Icon, type IconName } from "./icons";

const nav: { to: string; label: string; icon: IconName; admin?: boolean; group?: string }[] = [
  { to: "/", label: "Tổng quan", icon: "dashboard" },
  { to: "/accounts", label: "Tài khoản Telegram", icon: "accounts", group: "Chuyển tiếp" },
  { to: "/routes", label: "Tuyến chuyển tiếp", icon: "routes" },
  { to: "/jobs", label: "Hàng đợi tác vụ", icon: "jobs" },
  { to: "/logs", label: "Nhật ký trực tiếp", icon: "logs" },
  { to: "/workers", label: "Worker & máy chủ", icon: "workers", group: "Hệ thống" },
  { to: "/users", label: "Người dùng", icon: "users", admin: true },
  { to: "/audit", label: "Nhật ký kiểm toán", icon: "audit", admin: true },
  { to: "/settings", label: "Cài đặt", icon: "settings" },
];

export function Layout() {
  const { user, logout, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  useEffect(() => setOpen(false), [loc.pathname]);
  let lastGroup = "";
  return (
    <div className="app">
      <header className="topbar">
        <button className="btn ghost" aria-label="Mở menu" aria-expanded={open} onClick={() => setOpen(true)}><Icon name="menu" /></button>
        <strong>Telegram Forwarder</strong>
      </header>
      <aside className={`rail ${open ? "open" : ""}`} aria-label="Điều hướng chính">
        <div className="brand"><Icon name="logo" size={22} /> Telegram Forwarder</div>
        <nav className="nav">
          {nav.filter((n) => !n.admin || isAdmin).map((n) => {
            const heading = n.group && n.group !== lastGroup ? n.group : null;
            if (n.group) lastGroup = n.group;
            return (
              <div key={n.to}>
                {heading && <div className="nav-group">{heading}</div>}
                <NavLink to={n.to} end={n.to === "/"}><Icon name={n.icon} /> {n.label}</NavLink>
              </div>
            );
          })}
        </nav>
        <div className="rail-foot">
          <div><strong>{user?.username}</strong><div className="muted small">{isAdmin ? "Quản trị viên" : "Vận hành viên"}</div></div>
          <button className="btn sm" onClick={() => void logout()}><Icon name="logout" size={16} /> Đăng xuất</button>
        </div>
      </aside>
      {open && <div style={{ position: "fixed", inset: 0, zIndex: 35 }} onClick={() => setOpen(false)} aria-hidden="true" />}
      <main className="main" id="main">
        <ErrorBoundary resetKey={loc.pathname}><Outlet /></ErrorBoundary>
      </main>
    </div>
  );
}
