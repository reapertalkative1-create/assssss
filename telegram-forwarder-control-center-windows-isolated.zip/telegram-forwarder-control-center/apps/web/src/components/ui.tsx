import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { ApiError } from "../api/client";
import type { Tone } from "../lib/labels";

export const Pill = ({ tone, children }: { tone: Tone; children: ReactNode }) => <span className={`pill ${tone}`}>{children}</span>;

export function Meter({ value, hotAt = 85 }: { value: number | null | undefined; hotAt?: number }) {
  if (value == null) return <span className="muted">—</span>;
  const v = Math.max(0, Math.min(100, value));
  return (
    <span className={`meter ${v >= hotAt ? "hot" : ""}`} role="img" aria-label={`${Math.round(v)}%`}>
      <span className="bar"><i style={{ width: `${v}%` }} /></span>
      <span className="small">{Math.round(v)}%</span>
    </span>
  );
}

export const Skeleton = ({ width = "100%" }: { width?: string }) => <span className="skeleton" style={{ width }} aria-hidden="true" />;

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return <div className="empty"><h3>{title}</h3>{children && <p>{children}</p>}{action}</div>;
}

export function ErrorState({ error, onRetry }: { error: ApiError; onRetry?: () => void }) {
  return (
    <div className="empty" role="alert">
      <h3>Không tải được dữ liệu</h3>
      <p>{error.message}</p>
      {onRetry && <button className="btn" onClick={onRetry}>Thử lại</button>}
    </div>
  );
}

export const Alert = ({ tone = "warn", children }: { tone?: "ok" | "warn" | "bad"; children: ReactNode }) =>
  <div className={`alert ${tone}`} role={tone === "bad" ? "alert" : "status"}>{children}</div>;

export function PageHead({ title, children, actions }: { title: string; children?: ReactNode; actions?: ReactNode }) {
  return <div className="page-head"><div><h1>{title}</h1>{children && <p>{children}</p>}</div>{actions && <div className="row">{actions}</div>}</div>;
}

interface FieldShell { label: string; hint?: string; error?: string }
function Shell({ id, label, hint, error, children }: FieldShell & { id: string; children: ReactNode }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children}
      {error ? <span className="err" id={`${id}-err`} role="alert">{error}</span> : hint ? <span className="hint" id={`${id}-hint`}>{hint}</span> : null}
    </div>
  );
}
const describe = (id: string, f: FieldShell) => (f.error ? `${id}-err` : f.hint ? `${id}-hint` : undefined);

export function TextField({ label, hint, error, ...rest }: FieldShell & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return <Shell id={id} label={label} hint={hint} error={error}><input id={id} className="input" aria-invalid={!!error} aria-describedby={describe(id, { label, hint, error })} {...rest} /></Shell>;
}
export function TextArea({ label, hint, error, ...rest }: FieldShell & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return <Shell id={id} label={label} hint={hint} error={error}><textarea id={id} className="textarea" aria-invalid={!!error} aria-describedby={describe(id, { label, hint, error })} {...rest} /></Shell>;
}
export function SelectField({ label, hint, error, children, ...rest }: FieldShell & SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return <Shell id={id} label={label} hint={hint} error={error}><select id={id} className="select" aria-describedby={describe(id, { label, hint, error })} {...rest}>{children}</select></Shell>;
}
export function Check({ label, hint, ...rest }: { label: ReactNode; hint?: string } & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return <div className="check"><input id={id} type="checkbox" {...rest} /><label htmlFor={id}>{label}{hint && <span className="hint" style={{ display: "block" }}>{hint}</span>}</label></div>;
}

/** Field-level messages returned by the API (422) keyed by field name. */
export function fieldErrors(e: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (e instanceof ApiError) for (const f of e.fields) out[f.field.split(".").pop() ?? f.field] = f.message;
  return out;
}
