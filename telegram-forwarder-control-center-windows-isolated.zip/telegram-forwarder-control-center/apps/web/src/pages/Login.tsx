import { useState, type FormEvent } from "react";
import { ApiError } from "../api/client";
import { Alert, TextField } from "../components/ui";
import { Icon } from "../components/icons";
import { useAuth } from "../state/auth";

export function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<{ username?: string; password?: string }>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const next = {
      username: username.trim() ? undefined : "Nhập tên đăng nhập.",
      password: password ? undefined : "Nhập mật khẩu.",
    };
    setErrors(next);
    if (next.username || next.password) return;
    setBusy(true);
    setError(undefined);
    try {
      await login(username.trim(), password);
    } catch (err) {
      setPassword("");
      setError(err instanceof ApiError ? (err.status === 429 ? "Quá nhiều lần thử. Hãy chờ vài phút rồi thử lại." : err.message) : "Đăng nhập thất bại.");
      setBusy(false);
    }
  }

  return (
    <div className="login">
      <form className="panel login-card" onSubmit={(e) => void submit(e)} noValidate>
        <div className="panel-head"><div className="brand" style={{ padding: 0 }}><Icon name="logo" size={22} /> Telegram Forwarder</div></div>
        <div className="panel-body">
          <h1>Đăng nhập</h1>
          {error && <Alert tone="bad">{error}</Alert>}
          <TextField label="Tên đăng nhập" value={username} onChange={(e) => setUsername(e.target.value)} error={errors.username}
            autoComplete="username" autoCapitalize="none" spellCheck={false} autoFocus />
          <TextField label="Mật khẩu" type="password" value={password} onChange={(e) => setPassword(e.target.value)} error={errors.password}
            autoComplete="current-password" />
          <button className="btn primary" type="submit" disabled={busy}>{busy ? "Đang đăng nhập…" : "Đăng nhập"}</button>
          <p className="hint">Quên mật khẩu? Nhờ quản trị viên đặt lại trong mục Người dùng.</p>
        </div>
      </form>
    </div>
  );
}
