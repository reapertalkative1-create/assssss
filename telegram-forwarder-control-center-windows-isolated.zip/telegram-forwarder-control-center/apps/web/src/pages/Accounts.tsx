import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import type { Account, AuthState, Command, CommandAccepted, DeleteResult, Page, Worker } from "../api/types";
import { DataTable, Pagination, type Column } from "../components/DataTable";
import { Modal } from "../components/Modal";
import { Alert, Check, EmptyState, PageHead, Pill, SelectField, TextField, fieldErrors } from "../components/ui";
import { useDebounced, useQuery } from "../hooks/useQuery";
import { fmtAgo } from "../lib/format";
import { authState, connectionState, errorLabel } from "../lib/labels";
import { useAuth } from "../state/auth";
import { useToast } from "../state/toast";

type Dialog = { kind: "create" } | { kind: "login"; a: Account } | { kind: "assign"; a: Account } | { kind: "rename"; a: Account } | { kind: "delete"; a: Account };

/** Waits (long-polling on the server) until the worker finished a command. Resolves with the final command. */
export async function waitForCommand(accountId: string, commandId: string, signal?: AbortSignal, rounds = 4): Promise<Command> {
  let cmd: Command | undefined;
  for (let i = 0; i < rounds; i++) {
    cmd = await api.get<Command>(`/api/accounts/${accountId}/commands/${commandId}`, { wait_seconds: 15 }, signal);
    if (cmd.status === "done" || cmd.status === "failed" || cmd.status === "expired") return cmd;
  }
  return cmd!;
}

export function AccountsPage() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [state, setState] = useState("");
  const [page, setPage] = useState(1);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busyId, setBusyId] = useState<string>();
  const search = useDebounced(q);
  const list = useQuery((signal) => api.get<Page<Account>>("/api/accounts", { q: search, auth_state: state, page, page_size: 20 }, signal), [search, state, page], { interval: 5000 });

  async function act(a: Account, label: string, fn: () => Promise<unknown>) {
    setBusyId(a.id);
    try { await fn(); toast.success(label); list.reload(); }
    catch (e) { toast.error(e instanceof ApiError ? e.message : "Thao tác thất bại."); }
    finally { setBusyId(undefined); }
  }
  async function check(a: Account) {
    setBusyId(a.id);
    try {
      const acc = await api.post<CommandAccepted>(`/api/accounts/${a.id}/check`);
      const cmd = await waitForCommand(a.id, acc.command_id, undefined, 3);
      if (cmd.status === "done") toast.success(`Kết nối ${a.name} hoạt động bình thường.`);
      else toast.error(cmd.status === "expired" ? "Worker không phản hồi kịp." : errorLabel(cmd.error_code, cmd.retry_after) || "Kiểm tra thất bại.");
      list.reload();
    } catch (e) { toast.error(e instanceof ApiError ? e.message : "Kiểm tra thất bại."); }
    finally { setBusyId(undefined); }
  }

  const cols: Column<Account>[] = [
    { key: "name", header: "Tài khoản", cell: (a) => <><strong>{a.name}</strong><div className="muted small">{[a.telegram_username && `@${a.telegram_username}`, a.phone_masked].filter(Boolean).join(" · ") || "Chưa đăng nhập"}</div></> },
    { key: "auth", header: "Xác thực", cell: (a) => <Pill tone={authState[a.auth_state].tone}>{authState[a.auth_state].label}</Pill> },
    { key: "conn", header: "Kết nối", cell: (a) => {
      const c = connectionState[a.connection_state] ?? connectionState.disconnected;
      return <><Pill tone={c.tone}>{c.label}</Pill>{a.connection_error && <div className="muted small">{errorLabel(a.connection_error)}</div>}</>;
    } },
    { key: "worker", header: "Worker", cell: (a) => a.assigned_worker_name ?? <span className="muted">Chưa gán</span> },
    { key: "active", header: "Hoạt động", cell: (a) => fmtAgo(a.last_active_at) },
    { key: "actions", header: "", align: "right", cell: (a) => {
      const disabled = busyId === a.id || a.pending_deletion;
      return (
        <div className="actions">
          {a.pending_deletion && <span className="muted small">Đang chờ xóa</span>}
          {a.auth_state === "authorized" && (a.desired_state === "running"
            ? <button className="btn sm" disabled={disabled} onClick={() => void act(a, "Đã tắt tài khoản.", () => api.post(`/api/accounts/${a.id}/stop`))}>Tắt</button>
            : <button className="btn sm primary" disabled={disabled || !a.assigned_worker_id} title={a.assigned_worker_id ? "" : "Hãy gán worker trước"} onClick={() => void act(a, "Đã bật tài khoản.", () => api.post(`/api/accounts/${a.id}/start`))}>Bật</button>)}
          {a.auth_state === "authorized" && <button className="btn sm" disabled={disabled} onClick={() => void check(a)}>Kiểm tra</button>}
          {isAdmin && a.auth_state !== "authorized" && <button className="btn sm primary" disabled={disabled || !a.assigned_worker_id} title={a.assigned_worker_id ? "" : "Hãy gán worker trước"} onClick={() => setDialog({ kind: "login", a })}>Đăng nhập Telegram</button>}
          {isAdmin && <button className="btn sm" disabled={disabled} onClick={() => setDialog({ kind: "assign", a })}>Gán worker</button>}
          {isAdmin && <button className="btn sm" disabled={disabled} onClick={() => setDialog({ kind: "rename", a })}>Đổi tên</button>}
          {isAdmin && <button className="btn sm danger" disabled={busyId === a.id} onClick={() => setDialog({ kind: "delete", a })}>Xóa</button>}
        </div>);
    } },
  ];

  const close = () => setDialog(null);
  const saved = (msg: string) => { setDialog(null); toast.success(msg); list.reload(); };
  return (
    <div className="stack">
      <PageHead title="Tài khoản Telegram" actions={isAdmin && <button className="btn primary" onClick={() => setDialog({ kind: "create" })}>Thêm tài khoản</button>}>
        Mỗi tài khoản dùng một phiên (session) riêng, chỉ một worker được giữ phiên tại một thời điểm. Phiên được mã hóa và không bao giờ hiển thị ở đây.
      </PageHead>
      <div className="toolbar">
        <input className="input" placeholder="Tìm theo tên…" aria-label="Tìm tài khoản" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        <select className="select" aria-label="Lọc theo xác thực" value={state} onChange={(e) => { setState(e.target.value); setPage(1); }}>
          <option value="">Mọi trạng thái xác thực</option>
          {(Object.keys(authState) as AuthState[]).map((s) => <option key={s} value={s}>{authState[s].label}</option>)}
        </select>
      </div>
      <DataTable caption="Danh sách tài khoản Telegram" columns={cols} rows={list.data?.items} rowKey={(a) => a.id} loading={list.loading} error={list.error} onRetry={list.reload}
        empty={<EmptyState title={search || state ? "Không có tài khoản phù hợp" : "Chưa có tài khoản Telegram"}
          action={isAdmin && !search && !state ? <button className="btn primary" onClick={() => setDialog({ kind: "create" })}>Thêm tài khoản đầu tiên</button> : undefined}>
          {search || state ? "Thử bỏ bớt bộ lọc." : "Thêm tài khoản, gán cho một worker rồi đăng nhập bằng số điện thoại."}</EmptyState>} />
      {list.data && <Pagination page={page} pageSize={20} total={list.data.total} onPage={setPage} />}

      {dialog?.kind === "create" && <NameDialog title="Thêm tài khoản Telegram" action="Tạo tài khoản" initial="" onClose={close}
        submit={(name) => api.post("/api/accounts", { name })} onDone={() => saved("Đã tạo tài khoản.")} />}
      {dialog?.kind === "rename" && <NameDialog title={`Đổi tên ${dialog.a.name}`} action="Lưu tên" initial={dialog.a.name} onClose={close}
        submit={(name) => api.patch(`/api/accounts/${dialog.a.id}`, { name })} onDone={() => saved("Đã đổi tên.")} />}
      {dialog?.kind === "assign" && <AssignDialog a={dialog.a} onClose={close} onDone={() => saved("Đã cập nhật worker.")} />}
      {dialog?.kind === "login" && <LoginWizard a={dialog.a} onClose={() => { close(); list.reload(); }} />}
      {dialog?.kind === "delete" && <DeleteDialog a={dialog.a} onClose={close} onDone={() => saved("Đã xóa tài khoản.")} />}
    </div>
  );
}

function NameDialog({ title, action, initial, submit, onDone, onClose }: { title: string; action: string; initial: string; submit: (name: string) => Promise<unknown>; onDone: () => void; onClose: () => void }) {
  const [name, setName] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  async function go() {
    if (!name.trim()) { setFields({ name: "Nhập tên." }); return; }
    setBusy(true); setErr(undefined); setFields({});
    try { await submit(name); onDone(); } catch (e) { setFields(fieldErrors(e)); setErr(e instanceof ApiError ? e.message : "Thao tác thất bại."); setBusy(false); }
  }
  return (
    <Modal title={title} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy}>{action}</button></>}>
      <TextField label="Tên hiển thị" hint="Chỉ để bạn phân biệt, ví dụ: Sale Hà Nội 1" value={name} onChange={(e) => setName(e.target.value)} error={fields.name} maxLength={64} />
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

function AssignDialog({ a, onClose, onDone }: { a: Account; onClose: () => void; onDone: () => void }) {
  const workers = useQuery((signal) => api.get<Page<Worker>>("/api/workers", { page_size: 100 }, signal), []);
  const [value, setValue] = useState(a.assigned_worker_id ?? "");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  async function go() {
    setBusy(true); setErr(undefined);
    try { await api.put(`/api/accounts/${a.id}/assignment`, { worker_id: value || null }); onDone(); }
    catch (e) { setErr(e instanceof ApiError ? e.message : "Không gán được."); setBusy(false); }
  }
  const usable = (workers.data?.items ?? []).filter((w) => w.status !== "revoked");
  return (
    <Modal title={`Gán worker cho ${a.name}`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button><button className="btn primary" onClick={() => void go()} disabled={busy || workers.loading}>Lưu</button></>}>
      <SelectField label="Worker" value={value} onChange={(e) => setValue(e.target.value)}
        hint="Đổi worker không làm hai worker dùng chung một phiên: worker mới chỉ nhận phiên sau khi worker cũ trả lại hoặc hết hạn (tối đa vài chục giây).">
        <option value="">Chưa gán</option>
        {usable.map((w) => <option key={w.id} value={w.id}>{w.name} ({w.platform}) — {w.status === "online" ? "online" : "không online"}</option>)}
      </SelectField>
      {a.auth_state === "awaiting_code" || a.auth_state === "awaiting_password" ? <Alert>Đăng nhập đang dở sẽ bị hủy và phải bắt đầu lại.</Alert> : null}
      {err && <Alert tone="bad">{err}</Alert>}
    </Modal>
  );
}

type Step = "phone" | "code" | "password" | "done";

export function LoginWizard({ a, onClose }: { a: Account; onClose: () => void }) {
  const [step, setStep] = useState<Step>(a.auth_state === "awaiting_code" ? "code" : a.auth_state === "awaiting_password" ? "password" : "phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [fields, setFields] = useState<Record<string, string>>({});
  const abort = useRef(new AbortController());
  useEffect(() => () => abort.current.abort(), []);

  async function run(path: string, body: unknown, onDone: (cmd: Command) => void, onFail: (cmd: Command) => void) {
    setBusy(true); setError(undefined); setFields({});
    try {
      const acc = await api.post<CommandAccepted>(`/api/accounts/${a.id}${path}`, body);
      const cmd = await waitForCommand(a.id, acc.command_id, abort.current.signal);
      if (cmd.status === "done") onDone(cmd);
      else if (cmd.status === "expired" || cmd.status === "pending" || cmd.status === "delivered") setError("Worker không phản hồi kịp. Kiểm tra worker đang online rồi thử lại.");
      else { setError(errorLabel(cmd.error_code, cmd.retry_after)); onFail(cmd); }
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      setFields(fieldErrors(e)); setError(e instanceof ApiError ? e.message : "Thao tác thất bại.");
    } finally { setBusy(false); }
  }
  const afterSignIn = (cmd: Command) => setStep((cmd.result as { state?: string } | null)?.state === "awaiting_password" ? "password" : "done");

  function submitPhone() {
    const value = phone;
    setPhone("");   // secrets leave component state as soon as they are sent
    void run("/login/start", { phone: value }, () => setStep("code"), () => setPhone(value));
  }
  function submitCode() {
    const value = code;
    setCode("");
    void run("/login/code", { code: value }, afterSignIn, (cmd) => { if (cmd.error_code === "code_expired" || cmd.error_code === "login_session_lost") setStep("phone"); });
  }
  function submitPassword() {
    const value = password;
    setPassword("");
    void run("/login/password", { password: value }, () => setStep("done"), (cmd) => { if (cmd.error_code === "login_session_lost") setStep("phone"); });
  }

  const foot = step === "done" ? <button className="btn primary" onClick={onClose}>Xong</button> : (
    <>
      <button className="btn" onClick={onClose} disabled={busy}>Đóng</button>
      {step === "phone" && <button className="btn primary" disabled={busy || !phone.trim()} onClick={submitPhone}>Gửi mã xác nhận</button>}
      {step === "code" && <button className="btn primary" disabled={busy || !code.trim()} onClick={submitCode}>Xác nhận mã</button>}
      {step === "password" && <button className="btn primary" disabled={busy || !password} onClick={submitPassword}>Xác nhận mật khẩu</button>}
    </>);
  return (
    <Modal title={`Đăng nhập Telegram cho ${a.name}`} onClose={onClose} dismissible={!busy} footer={foot}>
      {step === "phone" && <TextField label="Số điện thoại" hint="Định dạng quốc tế, ví dụ +84901234567. Số này chỉ được gửi cho worker, không lưu trên máy chủ." type="tel" inputMode="tel"
        autoComplete="off" value={phone} onChange={(e) => setPhone(e.target.value)} error={fields.phone} autoFocus />}
      {step === "code" && <TextField label="Mã xác nhận" hint="Telegram vừa gửi mã vào ứng dụng Telegram (hoặc SMS) của số này." inputMode="numeric" autoComplete="one-time-code"
        value={code} onChange={(e) => setCode(e.target.value)} error={fields.code} maxLength={8} autoFocus />}
      {step === "password" && <TextField label="Mật khẩu hai lớp" hint="Tài khoản này bật xác minh hai bước trên Telegram." type="password" autoComplete="off"
        value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} autoFocus />}
      {step === "done" && <Alert tone="ok">Đã đăng nhập thành công. Phiên được lưu mã hóa. Bây giờ bạn có thể bật tài khoản.</Alert>}
      {busy && <p className="muted" role="status">Đang chờ worker xử lý…</p>}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}

function DeleteDialog({ a, onClose, onDone }: { a: Account; onClose: () => void; onDone: () => void }) {
  const [typed, setTyped] = useState("");
  const [logout, setLogout] = useState(true);
  const [force, setForce] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [waiting, setWaiting] = useState(false);
  const abort = useRef(new AbortController());
  useEffect(() => () => abort.current.abort(), []);

  async function go(forceNow = force) {
    setBusy(true); setError(undefined);
    try {
      const r = await api.post<DeleteResult>(`/api/accounts/${a.id}/delete`, { confirm_name: typed, telegram_logout: logout, force: forceNow });
      if (r.status === "deleted") { onDone(); return; }
      setWaiting(true);
      const until = Date.now() + 70000;
      while (Date.now() < until && !abort.current.signal.aborted) {
        await new Promise((res) => setTimeout(res, 2000));
        try { await api.get(`/api/accounts/${a.id}`, undefined, abort.current.signal); }
        catch (e) { if (e instanceof ApiError && e.status === 404) { onDone(); return; } if ((e as Error).name === "AbortError") return; }
      }
      setWaiting(false);
      setError("Worker chưa đăng xuất được phiên trên Telegram. Tài khoản vẫn còn nguyên. Bạn có thể thử lại hoặc chọn xóa ngay (phiên vẫn còn hiệu lực trên Telegram).");
      setBusy(false);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Không xóa được."); setBusy(false); setWaiting(false); }
  }
  const blocked = typed !== a.name;
  return (
    <Modal title={`Xóa tài khoản ${a.name}?`} onClose={onClose} dismissible={!busy}
      footer={<><button className="btn" onClick={onClose} disabled={busy}>Hủy</button>
        {error && !force && a.has_session && <button className="btn danger" onClick={() => { setForce(true); void go(true); }} disabled={busy || blocked}>Xóa ngay, không đăng xuất</button>}
        <button className="btn danger solid" disabled={busy || blocked} onClick={() => void go()}>{busy ? "Đang xử lý…" : "Xóa tài khoản"}</button></>}>
      <p>Các tuyến và tác vụ của tài khoản này cũng bị xóa. Hành động này <strong>không thể hoàn tác</strong>.</p>
      {a.has_session && (
        <>
          <Check checked={logout} onChange={(e) => setLogout(e.target.checked)} disabled={force} label="Đăng xuất phiên này trên Telegram trước khi xóa" hint="Worker sẽ chấm dứt phiên phía Telegram (khuyên dùng). Cần worker đang online." />
          <Check checked={force} onChange={(e) => setForce(e.target.checked)} label="Xóa ngay, không đăng xuất" hint="Phiên vẫn còn hiệu lực trong mục Thiết bị của Telegram cho tới khi bạn tự chấm dứt." />
          {force && <Alert tone="warn">Phiên Telegram sẽ <strong>không bị thu hồi</strong>. Hãy vào Telegram → Cài đặt → Thiết bị để chấm dứt thủ công.</Alert>}
        </>
      )}
      <TextField label={`Gõ “${a.name}” để xác nhận`} value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off" spellCheck={false} />
      {waiting && <p className="muted" role="status">Đang chờ worker đăng xuất phiên trên Telegram…</p>}
      {error && <Alert tone="bad">{error}</Alert>}
    </Modal>
  );
}
