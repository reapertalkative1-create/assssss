import { useState } from "react";
import { api, ApiError } from "../api/client";
import type { SystemInfo } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { Alert, ErrorState, PageHead, Pill, Skeleton, TextField, fieldErrors } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { fmtDateTime } from "../lib/format";
import { useAuth } from "../state/auth";
import { getTheme, setTheme, type Theme } from "../state/theme";
import { useToast } from "../state/toast";

const settingLabels: Record<string, string> = {
  heartbeat_timeout_seconds: "Worker bị coi là mất kết nối sau (giây)", worker_heartbeat_interval_seconds: "Chu kỳ heartbeat của worker (giây)",
  account_lease_ttl_seconds: "Thời hạn quyền dùng phiên Telegram (giây)", job_lease_ttl_seconds: "Thời hạn xử lý một tác vụ (giây)",
  job_retry_base_seconds: "Chờ trước lần thử lại đầu tiên (giây)", job_retry_cap_seconds: "Thời gian chờ thử lại tối đa (giây)",
  account_rate_per_minute: "Giới hạn tin mỗi phút cho một tài khoản", command_ttl_seconds: "Thời hạn lệnh đăng nhập/OTP (giây)",
  session_ttl_seconds: "Thời hạn phiên web (giây)", session_idle_seconds: "Tự đăng xuất khi không hoạt động (giây)",
  login_lock_threshold: "Số lần đăng nhập sai trước khi khóa tạm", cookie_secure: "Cookie chỉ gửi qua HTTPS",
};

export function SettingsPage() {
  const { user, isAdmin, logout } = useAuth();
  const toast = useToast();
  const [theme, setThemeState] = useState<Theme>(getTheme());
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const [others, setOthers] = useState(false);
  const info = useQuery((signal) => api.get<SystemInfo>("/api/system/info", undefined, signal), [], { enabled: isAdmin });

  async function changePassword() {
    const e: Record<string, string> = {};
    if (!cur) e.current_password = "Nhập mật khẩu hiện tại.";
    if (next.length < 12) e.new_password = "Mật khẩu mới cần ít nhất 12 ký tự.";
    else if (user && next.toLowerCase().includes(user.username)) e.new_password = "Mật khẩu không được chứa tên đăng nhập.";
    if (next !== again) e.again = "Hai mật khẩu không khớp.";
    setErrors(e); if (Object.keys(e).length) return;
    setBusy(true); setError(undefined);
    try {
      await api.post("/api/auth/change-password", { current_password: cur, new_password: next });
      setCur(""); setNext(""); setAgain("");
      toast.success("Đã đổi mật khẩu. Các phiên đăng nhập khác đã bị đăng xuất.");
    } catch (err) { setErrors(fieldErrors(err)); setError(err instanceof ApiError ? err.message : "Không đổi được mật khẩu."); }
    finally { setBusy(false); }
  }
  const pick = (t: Theme) => { setTheme(t); setThemeState(t); };
  return (
    <div className="stack">
      <PageHead title="Cài đặt" />
      <section className="panel">
        <div className="panel-head"><h2>Tài khoản của bạn</h2></div>
        <div className="panel-body stack">
          <dl className="kv">
            <dt>Tên đăng nhập</dt><dd>{user?.username}</dd><dt>Vai trò</dt><dd>{isAdmin ? "Quản trị viên" : "Vận hành viên"}</dd>
            <dt>Đăng nhập gần nhất</dt><dd>{fmtDateTime(user?.last_login_at)}</dd>
          </dl>
          <div className="field"><span className="label" id="theme-label">Giao diện</span>
            <div className="seg" role="group" aria-labelledby="theme-label">
              {([["auto", "Theo hệ thống"], ["light", "Sáng"], ["dark", "Tối"]] as [Theme, string][]).map(([t, l]) => <button key={t} type="button" aria-pressed={theme === t} onClick={() => pick(t)}>{l}</button>)}
            </div></div>
          <div className="row"><button className="btn" onClick={() => setOthers(true)}>Đăng xuất các thiết bị khác</button><button className="btn" onClick={() => void logout()}>Đăng xuất</button></div>
        </div>
      </section>

      <section className="panel">
        <div className="panel-head"><h2>Đổi mật khẩu</h2></div>
        <form className="panel-body stack" style={{ maxWidth: 420 }} onSubmit={(e) => { e.preventDefault(); void changePassword(); }} noValidate>
          <TextField label="Mật khẩu hiện tại" type="password" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} error={errors.current_password} />
          <TextField label="Mật khẩu mới" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} error={errors.new_password} hint="Ít nhất 12 ký tự." />
          <TextField label="Nhập lại mật khẩu mới" type="password" autoComplete="new-password" value={again} onChange={(e) => setAgain(e.target.value)} error={errors.again} />
          {error && <Alert tone="bad">{error}</Alert>}
          <div><button className="btn primary" type="submit" disabled={busy}>{busy ? "Đang lưu…" : "Đổi mật khẩu"}</button></div>
        </form>
      </section>

      {isAdmin && (
        <section className="panel">
          <div className="panel-head"><h2>Hệ thống</h2></div>
          <div className="panel-body stack">
            {info.error && !info.data ? <ErrorState error={info.error} onRetry={info.reload} /> : !info.data ? <Skeleton /> : (
              <>
                <dl className="kv">
                  <dt>Phiên bản</dt><dd>{info.data.version}</dd>
                  <dt>Môi trường</dt><dd>{info.data.environment === "production" ? "Production" : "Phát triển"}</dd>
                  <dt>Cơ sở dữ liệu</dt><dd><Pill tone={info.data.database_ok ? "ok" : "bad"}>{info.data.database_ok ? "Hoạt động" : "Lỗi kết nối"}</Pill></dd>
                  <dt>Mã hóa phiên Telegram</dt><dd><Pill tone={info.data.encryption.configured ? "ok" : "bad"}>{info.data.encryption.configured ? `Đã cấu hình (${info.data.encryption.keys} khóa)` : "Chưa cấu hình"}</Pill></dd>
                </dl>
                {!info.data.encryption.configured && <Alert tone="bad">Chưa có khóa mã hóa nên không thể đăng nhập tài khoản Telegram. Xem docs/key-management.md.</Alert>}
                {info.data.environment === "production" && info.data.settings.cookie_secure === false && <Alert tone="bad">Cookie đang không bắt buộc HTTPS.</Alert>}
                <table className="table"><thead><tr><th scope="col">Thiết lập hiệu lực</th><th scope="col" className="right">Giá trị</th></tr></thead>
                  <tbody>{Object.entries(info.data.settings).map(([k, v]) => <tr key={k}><td>{settingLabels[k] ?? k}</td><td className="right mono">{typeof v === "boolean" ? (v ? "có" : "không") : v}</td></tr>)}</tbody></table>
                <p className="muted small">Các giá trị này lấy từ biến môi trường của máy chủ (tiền tố TFCC_). Muốn đổi, sửa cấu hình và khởi động lại API.</p>
              </>)}
          </div>
        </section>)}

      {others && (
        <ConfirmDialog title="Đăng xuất các thiết bị khác?" confirmLabel="Đăng xuất các thiết bị khác" onClose={() => setOthers(false)}
          onConfirm={async () => { const r = await api.post<{ revoked: number }>("/api/auth/logout-others"); toast.success(r.revoked ? `Đã đăng xuất ${r.revoked} phiên khác.` : "Không có phiên nào khác đang đăng nhập."); }}>
          <p>Mọi trình duyệt khác đang đăng nhập bằng tài khoản của bạn sẽ bị đăng xuất. Phiên hiện tại được giữ nguyên.</p>
        </ConfirmDialog>)}
    </div>
  );
}
