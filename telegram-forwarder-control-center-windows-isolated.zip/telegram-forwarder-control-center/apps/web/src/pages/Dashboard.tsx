import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { Summary } from "../api/types";
import { EventList } from "../components/EventList";
import { Meter, Pill, ErrorState, PageHead, Skeleton, EmptyState } from "../components/ui";
import { useQuery } from "../hooks/useQuery";
import { fmtAgo, fmtDuration, fmtNumber } from "../lib/format";
import { workerStatus, type Tone } from "../lib/labels";

function Stage({ to, name, big, of, sub, tone }: { to: string; name: string; big: string; of?: string; sub: string; tone: Tone }) {
  return (
    <Link to={to} className={`stage ${tone}`}>
      <span className="name">{name}</span>
      <span className="big">{big}{of && <small> / {of}</small>}</span>
      <span className="small muted">{sub}</span>
    </Link>
  );
}

export function pipelineTones(s: Summary): Record<"workers" | "accounts" | "routes" | "queue", Tone> {
  const w = s.workers, total = w.online + w.offline + w.degraded;
  const workers: Tone = total === 0 ? "idle" : w.online === 0 ? "bad" : w.offline + w.degraded > 0 ? "warn" : "ok";
  const a = s.accounts;
  const accounts: Tone = a.invalid > 0 ? "bad" : a.running === 0 ? "idle" : a.connected < a.running ? "warn" : "ok";
  const r = s.routes;
  const routes: Tone = (r.active ?? 0) === 0 ? ((r.paused ?? 0) > 0 ? "warn" : "idle") : (r.paused ?? 0) > 0 ? "warn" : "ok";
  const q = s.jobs;
  const queue: Tone = q.needs_attention > 0 ? "bad" : (q.oldest_pending_age_seconds ?? 0) > 120 ? "warn" : "ok";
  return { workers, accounts, routes, queue };
}

function HourlyBars({ series }: { series: Summary["jobs"]["series"] }) {
  const max = Math.max(1, ...series.map((s) => s.succeeded + s.failed));
  const w = 480, h = 110, bw = 14, gap = (w - bw * series.length) / (series.length - 1);
  return (
    <svg className="bars" viewBox={`0 0 ${w} ${h + 16}`} role="img" aria-label="Số tác vụ thành công và lỗi theo từng giờ trong 24 giờ qua" preserveAspectRatio="none">
      <line className="axis" x1="0" x2={w} y1={h} y2={h} />
      {series.map((s, i) => {
        const x = i * (bw + gap), okH = (s.succeeded / max) * (h - 6), badH = (s.failed / max) * (h - 6);
        return (
          <g key={s.hour}>
            <title>{`${new Date(s.hour).getHours()}h: ${s.succeeded} thành công, ${s.failed} lỗi`}</title>
            <rect className="ok" x={x} y={h - okH} width={bw} height={okH} rx="2" />
            <rect className="bad" x={x} y={h - okH - badH} width={bw} height={badH} rx="2" />
          </g>
        );
      })}
      <text x="0" y={h + 13} fontSize="10" fill="currentColor" opacity="0.6">{new Date(series[0].hour).getHours()}h</text>
      <text x={w} y={h + 13} fontSize="10" fill="currentColor" opacity="0.6" textAnchor="end">{new Date(series[series.length - 1].hour).getHours()}h</text>
    </svg>
  );
}

export function DashboardPage() {
  const q = useQuery((signal) => api.get<Summary>("/api/dashboard/summary", undefined, signal), [], { interval: 10000 });
  const s = q.data;
  if (q.error && !s) return <><PageHead title="Tổng quan" /><ErrorState error={q.error} onRetry={q.reload} /></>;
  if (!s) return <><PageHead title="Tổng quan" /><Skeleton /></>;

  const tones = pipelineTones(s), w = s.workers, a = s.accounts, r = s.routes, j = s.jobs;
  const workerTotal = w.online + w.offline + w.degraded;
  const waiting = (j.by_status.pending ?? 0) + (j.by_status.retry_wait ?? 0) + (j.by_status.claimed ?? 0) + (j.by_status.running ?? 0);
  const rate = j.last_24h.succeeded + j.last_24h.failed ? Math.round((j.last_24h.succeeded / (j.last_24h.succeeded + j.last_24h.failed)) * 100) : null;
  return (
    <div className="stack">
      <PageHead title="Tổng quan">Tình trạng chuỗi chuyển tiếp từ worker đến hàng đợi. Cập nhật mỗi 10 giây.</PageHead>

      <div className="pipeline" aria-label="Chuỗi xử lý">
        <Stage to="/workers" name="Worker" tone={tones.workers} big={String(w.online)} of={String(workerTotal)}
          sub={w.offline + w.degraded ? `${w.offline} mất kết nối, ${w.degraded} suy giảm` : workerTotal ? "Tất cả đang online" : "Chưa có worker"} />
        <Stage to="/accounts" name="Tài khoản Telegram" tone={tones.accounts} big={String(a.connected)} of={String(a.running)}
          sub={a.invalid ? `${a.invalid} cần đăng nhập lại` : `${a.authorized} đã xác thực, ${a.total} tổng`} />
        <Stage to="/routes" name="Tuyến đang chạy" tone={tones.routes} big={String(r.active ?? 0)}
          sub={`${r.paused ?? 0} tạm dừng, ${r.stopped ?? 0} đã dừng`} />
        <Stage to="/jobs" name="Hàng đợi" tone={tones.queue} big={fmtNumber(waiting)}
          sub={j.needs_attention ? `${j.needs_attention} tác vụ lỗi cần xử lý` : j.oldest_pending_age_seconds ? `Cũ nhất chờ ${fmtDuration(j.oldest_pending_age_seconds)}` : "Không có tác vụ chờ"} />
      </div>

      <div className="two-col">
        <section className="panel">
          <div className="panel-head"><h2>Kết quả 24 giờ qua</h2>
            <span className="muted small">{fmtNumber(j.last_24h.succeeded)} thành công · {fmtNumber(j.last_24h.failed)} lỗi{rate !== null && ` · ${rate}%`}</span></div>
          <div className="panel-body stack tight">
            <HourlyBars series={j.series} />
            <div className="legend"><span><i style={{ background: "var(--ok)" }} />Thành công</span><span><i style={{ background: "var(--bad)" }} />Lỗi</span></div>
          </div>
        </section>

        <section className="panel">
          <div className="panel-head"><h2>Tài nguyên worker</h2></div>
          {s.resources.length === 0 ? <EmptyState title="Chưa có worker">Thêm worker trong mục Worker & máy chủ.</EmptyState> : (
            <table className="table">
              <thead><tr><th scope="col">Worker</th><th scope="col">CPU</th><th scope="col">RAM</th></tr></thead>
              <tbody>
                {s.resources.map((x) => (
                  <tr key={x.id}>
                    <td><div>{x.name}</div><Pill tone={workerStatus[x.status].tone}>{workerStatus[x.status].label}</Pill></td>
                    <td><Meter value={x.cpu_percent} /></td><td><Meter value={x.memory_percent} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>

      <section className="panel">
        <div className="panel-head"><h2>Hoạt động gần nhất</h2><Link to="/logs">Xem nhật ký trực tiếp</Link></div>
        {s.recent_events.length === 0 ? <EmptyState title="Chưa có hoạt động nào">Sự kiện sẽ xuất hiện ở đây khi bạn tạo worker, tài khoản hoặc tuyến.</EmptyState>
          : <EventList events={[...s.recent_events].reverse()} />}
        <div className="panel-body muted small">Máy chủ cập nhật {fmtAgo(s.server_time)}.</div>
      </section>
    </div>
  );
}
