#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Setup', 'Run')][string]$Mode = 'Run',
    [switch]$NoBrowser
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:AppRoot = Split-Path -Parent $PSScriptRoot
$script:ConfigFile = Join-Path $script:AppRoot '.env.docker'
$script:ReadyFile = Join-Path $script:AppRoot '.docker-ready'

function New-RandomBytes {
    param([int]$Length)
    $bytes = New-Object byte[] $Length
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return ,$bytes
}

function New-DockerConfig {
    if (Test-Path -LiteralPath $script:ConfigFile) { return }
    $password = -join ((New-RandomBytes 32) | ForEach-Object { $_.ToString('x2') })
    $secret = -join ((New-RandomBytes 32) | ForEach-Object { $_.ToString('x2') })
    $key = [Convert]::ToBase64String((New-RandomBytes 32)).Replace('+', '-').Replace('/', '_')
    $project = 'tfcc-' + [Guid]::NewGuid().ToString('N').Substring(0, 12)
    $content = @(
        '# Private settings for this Docker installation. Do not share this file.',
        "TFCC_COMPOSE_PROJECT=$project",
        "TFCC_DB_PASSWORD=$password",
        "TFCC_SECRET_KEY=$secret",
        "TFCC_SESSION_ENCRYPTION_KEY=$key",
        'TFCC_HTTP_PORT=8787',
        '# Fill all three worker fields after creating a LINUX worker in the dashboard.',
        'TFCC_WORKER_CREDENTIAL=',
        'TFCC_WORKER_TELEGRAM_API_ID=0',
        'TFCC_WORKER_TELEGRAM_API_HASH=',
        ''
    ) -join "`r`n"
    # CreateNew prevents reruns/concurrent setup from overwriting existing encryption keys.
    $stream = [IO.File]::Open($script:ConfigFile, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $bytes = [Text.Encoding]::ASCII.GetBytes($content)
        $stream.Write($bytes, 0, $bytes.Length)
    } finally { $stream.Dispose() }
    Write-Host 'Created .env.docker with private random keys.'
}

function Read-DockerConfig {
    $result = @{}
    foreach ($line in (Get-Content -LiteralPath $script:ConfigFile)) {
        if ($line -match '^\s*([A-Z0-9_]+)\s*=(.*)$') {
            $result[$matches[1]] = $matches[2].Trim().Trim('"').Trim("'")
        }
    }
    foreach ($name in @('TFCC_COMPOSE_PROJECT', 'TFCC_DB_PASSWORD', 'TFCC_SECRET_KEY', 'TFCC_SESSION_ENCRYPTION_KEY')) {
        if (-not $result.ContainsKey($name) -or -not $result[$name]) {
            throw "Missing $name in .env.docker. Restore the existing setting; do not replace existing keys."
        }
    }
    if ($result['TFCC_COMPOSE_PROJECT'] -notmatch '^[a-z0-9][a-z0-9_-]+$') {
        throw 'Invalid TFCC_COMPOSE_PROJECT in .env.docker.'
    }
    $port = 0
    if (-not $result.ContainsKey('TFCC_HTTP_PORT') -or -not [int]::TryParse($result['TFCC_HTTP_PORT'], [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        throw 'TFCC_HTTP_PORT must be a number from 1 to 65535.'
    }
    return $result
}

function Invoke-Docker {
    param([string[]]$DockerArgs, [int[]]$AllowedCodes = @(0))
    # Compose writes normal progress to stderr. Windows PowerShell 5.1 must use exit codes here.
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & docker @DockerArgs | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($AllowedCodes -notcontains $code) {
        throw "Docker command failed (exit $code). Check the Docker output above."
    }
    return $code
}

function Assert-Docker {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        throw 'Install Docker Desktop for Windows, select Linux containers, then open Docker Desktop and retry.'
    }
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $engine = (& docker info --format '{{.OSType}}' 2>$null | Out-String).Trim()
        $engineCode = $LASTEXITCODE
        $version = (& docker compose version --short 2>$null | Out-String).Trim()
        $versionCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($engineCode -ne 0) { throw 'Docker Desktop is not ready. Open it, wait for Engine running, then retry.' }
    if ($engine -ne 'linux') { throw 'Switch Docker Desktop to Linux containers, then retry.' }
    if ($versionCode -ne 0) { throw 'Docker Compose is missing. Update Docker Desktop.' }
    $match = [regex]::Match($version, '(\d+)\.(\d+)\.(\d+)')
    if (-not $match.Success -or [version]$match.Value -lt [version]'2.20.0') {
        throw 'Docker Compose 2.20 or newer is required. Update Docker Desktop.'
    }
}

function Start-Application {
    param([hashtable]$Config)
    $compose = @('compose', '--env-file', '.env.docker', '-f', 'compose.yaml')
    # Drain the worker before replacing API containers; it shares the API's network namespace.
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'stop', 'worker')))
    [void](Invoke-Docker -DockerArgs ($compose + @('up', '-d', '--wait', '--wait-timeout', '180', 'api', 'web')))
    $workerReady = $Config.ContainsKey('TFCC_WORKER_CREDENTIAL') -and $Config['TFCC_WORKER_CREDENTIAL'] -and
        $Config.ContainsKey('TFCC_WORKER_TELEGRAM_API_HASH') -and $Config['TFCC_WORKER_TELEGRAM_API_HASH'] -and
        $Config.ContainsKey('TFCC_WORKER_TELEGRAM_API_ID') -and $Config['TFCC_WORKER_TELEGRAM_API_ID'] -match '^[1-9][0-9]*$'
    if ($workerReady) {
        [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'up', '-d', '--wait', '--wait-timeout', '180', '--force-recreate', 'worker')))
    } else {
        Write-Host 'Dashboard ready. Telegram worker stays off until its three fields are filled in .env.docker.'
    }
    $url = 'http://127.0.0.1:' + $Config['TFCC_HTTP_PORT']
    Write-Host "Application running: $url"
    Write-Host 'Containers keep running in the background. Stop them in Docker Desktop when finished.'
    if (-not $NoBrowser) {
        try { Start-Process $url } catch { Write-Host "Open this address in your browser: $url" }
    }
}

function Start-Setup {
    $compose = @('compose', '--env-file', '.env.docker', '-f', 'compose.yaml')
    New-DockerConfig
    $config = Read-DockerConfig
    Write-Host 'Building isolated images. The first setup requires internet and may take several minutes.'
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'build', '--pull')))
    [void](Invoke-Docker -DockerArgs ($compose + @('up', '-d', '--wait', '--wait-timeout', '180', 'db')))
    [void](Invoke-Docker -DockerArgs ($compose + @('run', '--rm', '-T', '--no-deps', 'api', 'python', '-m', 'alembic', 'upgrade', 'head')))
    $status = Invoke-Docker -DockerArgs ($compose + @('run', '--rm', '-T', '--no-deps', 'api', 'python', 'docker/admin_status.py')) -AllowedCodes @(0, 3)
    if ($status -eq 3) {
        $username = Read-Host 'Admin username [admin]'
        if (-not $username) { $username = 'admin' }
        Write-Host 'Enter a password twice (12+ characters, without your username). Input is hidden.'
        $savedPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & docker @compose run --rm --no-deps api python -m app.cli create-admin $username
            $adminCode = $LASTEXITCODE
        } finally { $ErrorActionPreference = $savedPreference }
        if ($adminCode -ne 0) { throw 'Admin creation failed. Run setup.cmd again to retry; your existing data is kept.' }
    } else {
        Write-Host 'An active admin already exists. Keeping the current account and database.'
    }
    Start-Application -Config $config
    [IO.File]::WriteAllText($script:ReadyFile, $config['TFCC_COMPOSE_PROJECT'], [Text.Encoding]::ASCII)
    Write-Host 'Setup complete. Next time, double-click run.cmd.'
}

function Main {
    Set-Location -LiteralPath $script:AppRoot
    Assert-Docker
    if ($Mode -eq 'Setup') {
        Start-Setup
    } else {
        if (-not (Test-Path -LiteralPath $script:ConfigFile) -or -not (Test-Path -LiteralPath $script:ReadyFile)) {
            throw 'Run setup.cmd successfully once before using run.cmd.'
        }
        $config = Read-DockerConfig
        $project = (Get-Content -LiteralPath $script:ReadyFile -Raw).Trim()
        if ($project -ne $config['TFCC_COMPOSE_PROJECT']) { throw 'Installation settings changed. Run setup.cmd again.' }
        Start-Application -Config $config
    }
}

if ($MyInvocation.InvocationName -ne '.') {
    try { Main; exit 0 } catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
}
