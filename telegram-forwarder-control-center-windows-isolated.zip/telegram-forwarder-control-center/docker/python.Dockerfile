# syntax=docker/dockerfile:1
FROM python:3.12-slim AS base
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
WORKDIR /app
RUN groupadd --gid 10001 app && useradd --uid 10001 --gid app --no-create-home app

FROM base AS api
COPY apps/api ./apps/api
RUN --mount=type=secret,id=proxy_ca \
    if [ -f /run/secrets/proxy_ca ]; then export PIP_CERT=/run/secrets/proxy_ca; fi; \
    python -m pip install --no-cache-dir ./apps/api
COPY migrations ./migrations
COPY alembic.ini ./alembic.ini
COPY --chmod=644 docker/admin_status.py ./docker/admin_status.py
RUN chmod 755 /app/docker
USER app
CMD ["python", "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]

FROM base AS worker
COPY workers/telegram-worker ./workers/telegram-worker
RUN --mount=type=secret,id=proxy_ca \
    if [ -f /run/secrets/proxy_ca ]; then export PIP_CERT=/run/secrets/proxy_ca; fi; \
    python -m pip install --no-cache-dir ./workers/telegram-worker
USER app
CMD ["python", "-m", "worker.main", "run"]
