param([string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$originalLocation = Get-Location
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('tfcc launcher space & ' + [Guid]::NewGuid().ToString('N'))
[void](New-Item -ItemType Directory -Path $testRoot)
function Assert-True { param($Value, [string]$Message); if (-not $Value) { throw $Message } }
function Assert-Fails { param([scriptblock]$Action); $failed = $false; try { & $Action } catch { $failed = $true }; Assert-True $failed 'Expected an error, but the action succeeded.' }
try {
    $launcher = Join-Path $ProjectRoot 'scripts/windows.ps1'
    $tokens = $null; $parseErrors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($launcher, [ref]$tokens, [ref]$parseErrors)
    Assert-True ($parseErrors.Count -eq 0) 'PowerShell syntax errors.'
    . $launcher -NoBrowser
    $script:AppRoot = $testRoot
    $script:ConfigFile = Join-Path $testRoot '.env.docker'
    $script:ReadyFile = Join-Path $testRoot '.docker-ready'
    New-DockerConfig
    $config = Read-DockerConfig
    Assert-True ($config['TFCC_DB_PASSWORD'] -match '^[0-9a-f]{64}$') 'DB password must have 32 random bytes.'
    Assert-True ($config['TFCC_SECRET_KEY'] -match '^[0-9a-f]{64}$') 'App secret must have 32 random bytes.'
    $rawKey = [Convert]::FromBase64String($config['TFCC_SESSION_ENCRYPTION_KEY'].Replace('-', '+').Replace('_', '/'))
    Assert-True ($rawKey.Length -eq 32) 'Invalid Fernet key.'
    $hash = (Get-FileHash -LiteralPath $script:ConfigFile).Hash
    New-DockerConfig
    Assert-True ((Get-FileHash -LiteralPath $script:ConfigFile).Hash -eq $hash) 'Rerun overwrote existing keys.'
    $saved = [IO.File]::ReadAllText($script:ConfigFile)
    [IO.File]::AppendAllText($script:ConfigFile, "`r`nTFCC_HTTP_PORT=not-a-port`r`n")
    Assert-Fails { Read-DockerConfig }
    [IO.File]::WriteAllText($script:ConfigFile, $saved)

    $script:MockEngine = 'linux'; $script:MockVersion = '2.40.3'; $script:MockExit = 0
    $script:InteractiveCalls = 0
    function docker {
        param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Values)
        $global:LASTEXITCODE = $script:MockExit
        if ($Values[0] -eq 'info') { return $script:MockEngine }
        if ($Values -contains 'version') { return $script:MockVersion }
        if ($Values -contains 'create-admin') { $script:InteractiveCalls++ }
    }
    Assert-Docker
    $script:MockEngine = 'windows'; Assert-Fails { Assert-Docker }; $script:MockEngine = 'linux'
    $script:MockVersion = '2.19.0'; Assert-Fails { Assert-Docker }; $script:MockVersion = '2.40.3'
    $script:MockExit = 9; Assert-Fails { Invoke-Docker -DockerArgs @('info') }; $script:MockExit = 0

    $script:Calls = New-Object 'Collections.Generic.List[string]'
    $script:AdminStatus = 0
    function Invoke-Docker {
        param([string[]]$DockerArgs, [int[]]$AllowedCodes = @(0))
        $script:Calls.Add(($DockerArgs -join '|'))
        if ($DockerArgs -contains 'docker/admin_status.py') { return $script:AdminStatus }
        return 0
    }
    Start-Application -Config $config
    Assert-True (@($script:Calls | Where-Object { $_ -match 'stop\|worker$' }).Count -eq 1) 'Incomplete worker config must stop any old worker.'
    $script:Calls.Clear()
    $config['TFCC_WORKER_CREDENTIAL'] = 'test-credential'
    $config['TFCC_WORKER_TELEGRAM_API_ID'] = '123'
    $config['TFCC_WORKER_TELEGRAM_API_HASH'] = 'test-hash'
    Start-Application -Config $config
    Assert-True (@($script:Calls | Where-Object { $_ -match '--profile\|telegram\|up.*\|worker$' }).Count -eq 1) 'Complete worker config must start the worker profile.'

    $Mode = 'Run'
    Assert-Fails { Main }
    Start-Setup
    Assert-True (Test-Path -LiteralPath $script:ReadyFile) 'Setup did not mark successful completion.'
    Assert-True ($script:InteractiveCalls -eq 0) 'Setup must preserve an existing admin.'
    Main
    Assert-True ((Get-FileHash -LiteralPath $script:ConfigFile).Hash -eq $hash) 'Run/setup changed private configuration.'
    $script:AdminStatus = 3
    function Read-Host { param([string]$Prompt); return 'test-admin' }
    Start-Setup
    Assert-True ($script:InteractiveCalls -eq 1) 'Fresh setup must create an admin interactively.'
    [IO.File]::WriteAllText($script:ReadyFile, 'different-installation')
    Assert-Fails { Main }
    Write-Host 'PASS: syntax, random keys, rerun safety, ports, Docker checks, worker profiles, setup and run.'
} finally {
    Set-Location -LiteralPath $originalLocation
    Remove-Item -LiteralPath $testRoot -Recurse -Force
}
