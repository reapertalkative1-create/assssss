"""Telegram account handling on the worker.

Safety rules implemented here:
  * A session is used ONLY while this worker holds the account's lease. The worker keeps a local deadline
    (acquire/heartbeat send time + 80% of the lease TTL, on a monotonic clock). If it cannot get the lease renewed
    in time it disconnects by itself, so a partitioned worker stops using the session BEFORE the server can hand
    it to someone else.
  * Sessions live in memory only (no session files). OTP, 2FA password and session strings are never logged.
  * Telegram errors are reduced to stable codes; FloodWait carries the exact wait Telegram asked for."""
import asyncio
import logging
import time
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any

from worker.backoff import Backoff
from worker.client import (
    ConflictError, ControlPlaneClient, ControlPlaneError, NotFoundError, TransientError, HeartbeatInfo, RegisterInfo,
)
from worker.telegram_backend import BackendError, TelegramBackend

log = logging.getLogger("tfcc.accounts")

DEAD_SESSION_CODES = {"auth_key_unregistered", "user_deactivated", "session_revoked", "auth_key_duplicated"}
DROP_LOGIN_CODES = {"code_expired", "phone_invalid", "phone_banned", "phone_flood", "flood_wait"}
LOGIN_TTL_SECONDS = 600


@dataclass
class _Login:
    handle: Any
    created: float


@dataclass
class _Active:
    epoch: int
    deadline: float
    state: str = "connecting"          # connecting | connected
    handle: Any = None
    version: int = 0
    session: str = field(default="", repr=False)


class AccountManager:
    def __init__(self, client: ControlPlaneClient, backend: TelegramBackend | None, *,
                 clock: Callable[[], float] = time.monotonic, margin: float = 0.8,
                 command_wait: int = 20, default_cooldown: float = 30.0):
        self._client, self._backend, self._clock = client, backend, clock
        self._margin, self._command_wait, self._default_cooldown = margin, command_wait, default_cooldown
        self._logins: dict[str, _Login] = {}
        self._active: dict[str, _Active] = {}
        self._cooldown: dict[str, float] = {}
        self._errors: dict[str, str] = {}
        self._reported: dict[str, int] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._tasks: set[asyncio.Task] = set()
        self._import_slots = asyncio.Semaphore(3)
        self._spam_slots = asyncio.Semaphore(2)
        self._starting: set[str] = set()
        self._wanted: set[str] = set()
        self._command_inflight=0
        self.lease_ttl = 60.0
        self.listeners: list[Any] = []   # e.g. the ForwardEngine: on_account_connected / on_account_dropped

    # ------------------------------------------------------------------ helpers
    def _lock(self, aid: str) -> asyncio.Lock:
        return self._locks.setdefault(aid, asyncio.Lock())

    def _spawn(self, coro: Coroutine) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)

        def _done(t: asyncio.Task) -> None:
            self._tasks.discard(t)
            if not t.cancelled() and t.exception() is not None:
                log.error("background_task_failed", extra={"error": type(t.exception()).__name__})

        task.add_done_callback(_done)

    async def _safe_disconnect(self, handle: Any) -> None:
        if handle is not None and self._backend is not None:
            try:
                await asyncio.wait_for(self._backend.disconnect(handle), timeout=5)
            except Exception:
                pass

    async def _notify(self, event: str, *args) -> None:
        for listener in self.listeners:
            try:
                await getattr(listener, event)(*args)
            except Exception as exc:  # a listener must never break connection handling
                log.error("listener_failed", extra={"event": event, "error": type(exc).__name__})

    def handle_for(self, aid: str) -> Any:
        """The live Telegram handle, only while this worker still owns the account (None once fenced/stopped)."""
        act = self._active.get(aid)
        return act.handle if act is not None and act.state == "connected" else None

    async def report_error(self, aid: str, code: str) -> None:
        """The forwarding side hit an account-level error (e.g. session revoked): stop using it and tell the API."""
        await self._drop(aid, code)
        self._errors[aid] = code
        self._cooldown[aid] = self._clock() + self._default_cooldown

    def connected_accounts(self) -> list[str]:
        return [a for a, act in self._active.items() if act.state == "connected"]

    # ------------------------------------------------------------------ interactive commands (login, check, logout)
    async def command_loop(self, stop: asyncio.Event) -> None:
        backoff = Backoff(1.0, 30.0)
        while not stop.is_set():
            if self._command_inflight >= 5:
                await self._sleep(.2,stop)
                continue
            try:
                cmds = await self._client.poll_commands(self._command_wait)
                backoff.reset()
            except TransientError:
                await self._sleep(backoff.next(), stop)
                continue
            except ControlPlaneError:
                return  # credential problems are handled (and the process stopped) by the heartbeat loop
            for cmd in cmds:
                self._command_inflight += 1
                self._spawn(self._run_command(cmd))
            if not cmds and self._command_wait < 1:
                await self._sleep(1.0, stop)

    @staticmethod
    async def _sleep(seconds: float, stop: asyncio.Event) -> None:
        try:
            await asyncio.wait_for(stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _run_command(self, cmd: dict) -> None:
        aid, cid, typ = str(cmd["account_id"]), str(cmd["id"]), cmd["type"]
        payload = cmd.get("payload") or {}
        try:
            async with self._lock(aid):
                result = await self._execute(typ, aid, payload)
            await self._report(cid, "done", result=result)
        except BackendError as exc:
            log.warning("command_failed", extra={"type": typ, "error": exc.code})
            await self._report(cid, "failed", error_code=exc.code, retry_after=exc.retry_after)
        except ConflictError as exc:
            await self._report(cid, "failed", error_code=exc.code)
        except (ControlPlaneError, Exception) as exc:  # never log the exception text: it may carry personal data
            log.error("command_error", extra={"type": typ, "error": type(exc).__name__})
            await self._report(cid, "failed", error_code="internal_error")
        finally:
            self._command_inflight=max(0,self._command_inflight-1)
            payload.clear()

    async def _report(self, cid: str, status: str, **kw) -> None:
        try:
            await self._client.post_command_result(cid, status, **kw)
        except ControlPlaneError as exc:
            log.warning("result_not_delivered", extra={"command": cid, "error": type(exc).__name__})

    async def _execute(self, typ: str, aid: str, payload: dict) -> dict:
        if self._backend is None:
            raise BackendError("telegram_api_not_configured")
        if typ in ('spam_check','spam_read','spam_reply'):
            async with self._import_slots:
                async with asyncio.timeout(90):
                    operation='check' if typ=='spam_check' else 'read' if typ=='spam_read' else payload['operation']
                    return await self._check(aid,spam_action={'operation':operation,**payload})
        if typ == 'bulk_check':
            async with self._import_slots:
                try:
                    async with asyncio.timeout(45):return await self._check(aid)
                except TimeoutError:raise BackendError('session_check_timeout') from None
        if typ == 'import_session':
            async with self._import_slots:
                try:
                    async with asyncio.timeout(90 if payload.get('check_spam') else 45):
                        result = await self._check(aid,check_spam=True) if payload.get('check_spam') else await self._check(aid)
                except TimeoutError:
                    raise BackendError('session_check_timeout') from None
                return {**result, 'state':'authorized'}
        if typ == "send_code":
            return await self._send_code(aid, payload["phone"])
        if typ == "sign_in_code":
            return await self._sign_in(aid, code=payload["code"])
        if typ == "sign_in_password":
            return await self._sign_in(aid, password=payload["password"])
        if typ == "check_connection":
            return await self._execute('bulk_check',aid,payload)
        if typ == "verify_chats":
            return await self._verify_chats(aid, [int(c) for c in payload["chat_ids"]])
        if typ == "logout":
            return await self._logout(aid)
        raise BackendError("unknown_command")

    async def _connect_telegram(self, aid: str, session: str):
        connect = getattr(self._backend, 'connect_for', None)
        return await connect(aid, session) if connect is not None else await self._backend.connect(session)

    async def _send_code(self, aid: str, phone: str) -> dict:
        await self._drop_login(aid)
        send = getattr(self._backend, 'send_code_for', None)
        handle = await send(aid, phone) if send is not None else await self._backend.send_code(phone)
        self._logins[aid] = _Login(handle, self._clock())
        return {"state": "awaiting_code"}

    async def _drop_login(self, aid: str) -> None:
        login = self._logins.pop(aid, None)
        if login:
            await self._safe_disconnect(login.handle)

    async def _sign_in(self, aid: str, *, code: str | None = None, password: str | None = None) -> dict:
        login = self._logins.get(aid)
        if login is None:
            raise BackendError("login_session_lost")  # e.g. the worker restarted between the steps
        try:
            if code is not None:
                res = await self._backend.sign_in_code(login.handle, code)
                if res.kind == "password_needed":
                    return {"state": "awaiting_password"}
                user = res.user
            else:
                user = await self._backend.sign_in_password(login.handle, password)
        except BackendError as exc:
            if exc.code in DROP_LOGIN_CODES:
                await self._drop_login(aid)
            raise
        return await self._finish_login(aid, login, user)

    async def _finish_login(self, aid: str, login: _Login, user) -> dict:
        try:
            epoch, _ = await self._client.acquire_lease(aid)
        except ConflictError:
            raise BackendError("lease_held") from None
        try:
            session = self._backend.session_string(login.handle)
            await self._client.upload_session(aid, epoch, session, expected_version=None)
        finally:
            await self._release(aid, epoch)
        self._logins.pop(aid, None)
        await self._safe_disconnect(login.handle)
        return {"state": "authorized", "telegram_user_id": user.telegram_user_id, "username": user.username}

    async def _release(self, aid: str, epoch: int) -> None:
        try:
            await self._client.release_lease(aid, epoch)
        except ControlPlaneError:
            pass  # the lease simply expires

    async def _spam_report(self,handle,action):
        try:
            async with self._spam_slots:
                async with asyncio.timeout(30):
                    return await self._backend.check_spam(handle,**action)
        except BackendError as exc:
            return {'status':'error','error_code':exc.code,'delivery':'not_sent'}
        except TimeoutError:
            return {'status':'error','error_code':'spambot_timeout','delivery':'uncertain'}
        except Exception as exc:
            from worker.telegram_backend import map_error
            return {'status':'error','error_code':map_error(exc).code,'delivery':'not_sent'}

    async def _check(self, aid: str, *, check_spam=False, spam_action=None) -> dict:
        act = self._active.get(aid)
        if act and act.state == "connected":  # never open a second connection with the same auth key
            check=getattr(self._backend,'check_health',None)
            if check:await check(act.handle)
            result={"connection_state":"connected"}
            if check_spam or spam_action:
                result['spam_report']=await self._spam_report(act.handle,spam_action or {'operation':'check'})
            return result
        try:
            epoch, _ = await self._client.acquire_lease(aid)
        except ConflictError:
            raise BackendError("lease_held") from None
        handle = None
        try:
            data = await self._client.fetch_session(aid, epoch)
            handle, user = await self._connect_telegram(aid, data.session)
            fresh = self._backend.session_string(handle)
            if fresh != data.session:
                await self._client.upload_session(aid, epoch, fresh, expected_version=data.version)
            result={"connection_state":"connected","telegram_user_id":user.telegram_user_id,"username":user.username}
            if check_spam or spam_action:result['spam_report']=await self._spam_report(handle,spam_action or {'operation':'check'})
            return result
        finally:
            await self._safe_disconnect(handle)
            await self._release(aid, epoch)

    async def _verify_chats(self, aid: str, chat_ids: list[int]) -> dict:
        """Can this account read every source and write to every destination? Uses the running connection if any."""
        handle = self.handle_for(aid)
        if handle is not None:
            infos = await self._backend.resolve_chats(handle, chat_ids)
        else:
            try:
                epoch, _ = await self._client.acquire_lease(aid)
            except ConflictError:
                raise BackendError("lease_held") from None
            temp = None
            try:
                data = await self._client.fetch_session(aid, epoch)
                temp, _ = await self._connect_telegram(aid, data.session)
                await self._backend.prime(temp)
                infos = await self._backend.resolve_chats(temp, chat_ids)
            finally:
                await self._safe_disconnect(temp)
                await self._release(aid, epoch)
        return {"chats": {str(c): {"ok": i.ok, "can_send": i.can_send, "title": i.title} for c, i in infos.items()}}

    async def _logout(self, aid: str) -> dict:
        await self._stop_locked(aid, upload=False)
        try:
            epoch, _ = await self._client.acquire_lease(aid)
        except ConflictError:
            raise BackendError("lease_held") from None
        handle = None
        try:
            try:
                data = await self._client.fetch_session(aid, epoch)
            except NotFoundError:
                return {}  # nothing stored, nothing to revoke
            try:
                handle, _ = await self._connect_telegram(aid, data.session)
            except BackendError as exc:
                if exc.code in DEAD_SESSION_CODES:
                    return {}  # Telegram already considers it logged out
                raise
            await self._backend.log_out(handle)
            return {}
        finally:
            await self._safe_disconnect(handle)
            await self._release(aid, epoch)

    # ------------------------------------------------------------------ connections for accounts that should be running
    def heartbeat_accounts(self) -> list[dict]:
        """What this worker reports (and thereby asks to renew) in each heartbeat."""
        reports, self._reported = [], {}
        for aid, act in self._active.items():
            reports.append({"account_id": aid, "epoch": act.epoch, "state": act.state, "error_code": None})
            self._reported[aid] = act.epoch
        for aid, code in self._errors.items():
            if aid not in self._active:
                reports.append({"account_id": aid, "epoch": 0, "state": "error", "error_code": code})
        return reports

    async def on_register(self, info: RegisterInfo, sent_at: float) -> None:
        await self._apply(info.lease_ttl_seconds, info.accounts, (), sent_at)

    async def on_heartbeat(self, info: HeartbeatInfo, sent_at: float) -> None:
        await self._apply(info.lease_ttl_seconds, info.accounts, info.lost_leases, sent_at)

    async def _apply(self, ttl: float, assignments, lost, sent_at: float) -> None:
        self.lease_ttl = float(ttl)
        lost = set(lost)
        for aid in lost:  # the server revoked our right to this session: stop using it NOW, do not touch it again
            await self._drop(aid, "lease_lost")
        for aid, act in self._active.items():
            if aid not in lost and self._reported.get(aid) == act.epoch:
                act.deadline = max(act.deadline, sent_at + self.lease_ttl * self._margin)
        want = {a.account_id for a in assignments if a.desired_state == "running"}
        self._wanted = want
        for aid in list(self._errors):
            if aid not in want:
                self._errors.pop(aid, None)
        for aid in list(self._active):
            if aid not in want:
                self._spawn(self._stop(aid))
        self._pump_starts()

    def _pump_starts(self):
        if self._backend is None:return
        now=self._clock()
        for aid in self._wanted:
            if aid not in self._active and aid not in self._starting and len(self._starting)<3 and now>=self._cooldown.get(aid,0.0):
                self._starting.add(aid)
                self._spawn(self._start_bounded(aid))

    async def _start_bounded(self,aid):
        try:
            if aid in self._wanted:await self._start(aid)
        except Exception:
            self._cooldown[aid]=self._clock()+self._default_cooldown
            raise
        finally:
            self._starting.discard(aid)
            self._pump_starts()

    async def _start(self, aid: str) -> None:
        async with self._lock(aid):
            if aid in self._active:
                return
            t0 = self._clock()
            try:
                epoch, ttl = await self._client.acquire_lease(aid)
            except ConflictError:  # previous owner still holds it; it will release or expire
                self._cooldown[aid] = self._clock() + 5.0
                return
            except (NotFoundError, ControlPlaneError):
                self._cooldown[aid] = self._clock() + 5.0
                return
            self.lease_ttl = ttl
            act = _Active(epoch=epoch, deadline=t0 + ttl * self._margin)
            self._active[aid] = act
            handle = None
            try:
                data = await self._client.fetch_session(aid, epoch)
                handle, _user = await self._connect_telegram(aid, data.session)
            except BackendError as exc:
                await self._start_failed(aid, act, exc)
                return
            except ControlPlaneError:
                await self._start_failed(aid, act, BackendError("control_plane_error"))
                return
            if self._active.get(aid) is not act:  # fenced while connecting
                await self._safe_disconnect(handle)
                return
            try:
                await self._backend.prime(handle)   # load chats so they can be addressed by id
            except BackendError as exc:
                log.warning("prime_failed", extra={"account_id": aid, "error": exc.code})
            if self._active.get(aid) is not act:
                await self._safe_disconnect(handle)
                return
            act.handle, act.state, act.version, act.session = handle, "connected", data.version, data.session
            self._errors.pop(aid, None)
            log.info("account_connected", extra={"account_id": aid, "epoch": epoch})
            await self._notify("on_account_connected", aid, handle)

    async def _start_failed(self, aid: str, act: _Active, exc: BackendError) -> None:
        if self._active.get(aid) is act:
            self._active.pop(aid, None)
            await self._release(aid, act.epoch)
        self._errors[aid] = exc.code
        self._cooldown[aid] = self._clock() + (exc.retry_after if exc.retry_after else self._default_cooldown)
        log.warning("account_start_failed", extra={"account_id": aid, "error": exc.code, "retry_after": exc.retry_after})

    async def _stop(self, aid: str) -> None:
        async with self._lock(aid):
            await self._stop_locked(aid, upload=True)

    async def _stop_locked(self, aid: str, *, upload: bool) -> None:
        act = self._active.pop(aid, None)
        if act is None:
            return
        await self._notify("on_account_dropped", aid)
        if act.handle is not None:
            if upload and self._backend is not None:
                try:
                    fresh = self._backend.session_string(act.handle)
                    if fresh and fresh != act.session:
                        await self._client.upload_session(aid, act.epoch, fresh, expected_version=act.version)
                except ControlPlaneError:
                    log.warning("session_upload_skipped", extra={"account_id": aid})
            await self._safe_disconnect(act.handle)
        await self._release(aid, act.epoch)

    async def _drop(self, aid: str, reason: str) -> None:
        """Immediate, lock-free self-fencing: forget the connection and close the socket. No upload, no release."""
        act = self._active.pop(aid, None)
        if act is None:
            return
        log.warning("account_dropped", extra={"account_id": aid, "reason": reason})
        await self._notify("on_account_dropped", aid)
        await self._safe_disconnect(act.handle)

    # ------------------------------------------------------------------ fencing / housekeeping
    async def enforce_deadlines(self) -> None:
        now = self._clock()
        for aid, act in list(self._active.items()):
            if now >= act.deadline:
                await self._drop(aid, "lease_deadline_passed")  # could not renew in time: we no longer own the session
            elif act.state == "connected" and self._backend is not None and not self._backend.is_connected(act.handle):
                await self._drop(aid, "connection_lost")
                self._errors[aid] = "connection_lost"
                self._cooldown[aid] = now + 5.0
        for aid, login in list(self._logins.items()):
            if now - login.created > LOGIN_TTL_SECONDS:
                await self._drop_login(aid)

    async def fencing_loop(self, stop: asyncio.Event, interval: float = 1.0) -> None:
        while not stop.is_set():
            await self._sleep(interval, stop)
            try:
                await self.enforce_deadlines()
            except Exception as exc:  # the loop must survive anything
                log.error("fencing_error", extra={"error": type(exc).__name__})

    async def shutdown(self) -> None:
        """Graceful stop: save changed sessions, release leases, close sockets (bounded by a timeout)."""
        self._wanted.clear()
        tasks = list(self._tasks)
        for task in tasks:
            task.cancel()
        try:
            await asyncio.wait_for(self._shutdown(tasks), timeout=10)
        except asyncio.TimeoutError:
            log.warning("shutdown_timeout")

    async def _shutdown(self, tasks=()) -> None:
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        for aid in list(self._active):
            await self._stop_locked(aid, upload=True)
        for aid in list(self._logins):
            await self._drop_login(aid)
