"""Telegram account state machine, session leases and the dashboard->worker command channel.

Single-owner guarantee: a session can only be used by the worker holding an unexpired lease; the lease is taken
with one atomic conditional UPDATE, so two workers can never both win. `lease_epoch` is a fencing token that
makes late requests from a previous owner fail."""
import json
import logging
import re
import uuid
from datetime import datetime, timedelta

from sqlalchemy import or_, select, update, case
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit import record_system_audit
from app.crypto import CryptoError, SecretBox
from app.errors import ApiError
from app.models import ForwardJob, ForwardRoute, RouteCheckpoint, TelegramAccount, Worker, WorkerCommand
from app.services import routes as route_svc
from app.services import workers as worker_svc

log = logging.getLogger("tfcc.accounts")

LOGIN_ALLOWED_STATES = {"import_failed", "unauthenticated", "invalid", "awaiting_code", "awaiting_password"}
LOGIN_COMMANDS = {"send_code", "sign_in_code", "sign_in_password"}
SENSITIVE_COMMANDS = LOGIN_COMMANDS
FINAL_STATUSES = {"done", "failed", "expired"}
# Telegram says the session itself is dead: the account must be logged in again.
INVALIDATING_CODES = {"auth_key_unregistered", "user_deactivated", "session_revoked", "auth_key_duplicated"}
# The login attempt cannot continue and must be restarted from the phone number.
RESTART_LOGIN_CODES = {"code_expired", "login_session_lost", "phone_code_expired", "phone_invalid"}


def mask_phone(phone: str) -> str:
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 6:
        return "•••"
    return f"+{digits[:2]}{'•' * (len(digits) - 4)}{digits[-2:]}"


def lease_active(a: TelegramAccount, now: datetime) -> bool:
    return a.lease_worker_id is not None and a.lease_expires_at is not None and a.lease_expires_at > now


def effective_connection_state(a: TelegramAccount, now: datetime) -> str:
    """A connection only counts while the owner's lease is alive; otherwise it is, by definition, gone."""
    if a.desired_state == "running" and lease_active(a, now):
        return a.connection_state if a.connection_state in ("connecting", "connected", "error") else "connecting"
    return "disconnected"


# ------------------------------------------------------------------ leases
async def acquire_lease(db: AsyncSession, account_id: uuid.UUID, worker_id: uuid.UUID, ttl: int, now: datetime) -> int | None:
    """Atomically take (or re-take) the lease. Returns the new fencing epoch, or None if someone else holds it."""
    res = await db.execute(
        update(TelegramAccount)
        .where(
            TelegramAccount.id == account_id,
            TelegramAccount.assigned_worker_id == worker_id,
            or_(TelegramAccount.pending_deletion.is_(False),select(WorkerCommand.id).where(
                WorkerCommand.account_id==account_id,WorkerCommand.worker_id==worker_id,WorkerCommand.type=='logout',
                WorkerCommand.status.in_(('pending','delivered')),WorkerCommand.expires_at>now).exists()),
            or_(TelegramAccount.lease_worker_id.is_(None), TelegramAccount.lease_expires_at <= now,
                TelegramAccount.lease_worker_id == worker_id),
        )
        .values(lease_worker_id=worker_id, lease_expires_at=now + timedelta(seconds=ttl),
                lease_epoch=TelegramAccount.lease_epoch + 1)
        .execution_options(synchronize_session=False)
    )
    if res.rowcount != 1:
        return None
    return (await db.execute(select(TelegramAccount.lease_epoch).where(TelegramAccount.id == account_id))).scalar_one()


async def release_lease(db: AsyncSession, account_id: uuid.UUID, worker_id: uuid.UUID, epoch: int) -> None:
    await db.execute(
        update(TelegramAccount)
        .where(TelegramAccount.id == account_id, TelegramAccount.lease_worker_id == worker_id,
               TelegramAccount.lease_epoch == epoch)
        .values(lease_worker_id=None, lease_expires_at=None, connection_state="disconnected")
        .execution_options(synchronize_session=False)
    )


def require_lease(a: TelegramAccount, worker_id: uuid.UUID, epoch: int, now: datetime) -> None:
    if not (a.lease_worker_id == worker_id and a.lease_epoch == epoch and lease_active(a, now)):
        raise ApiError(409, "lease_invalid", "Worker không còn giữ quyền sở hữu session này.")


async def process_reports(db: AsyncSession, worker: Worker, reports: list, ttl: int, now: datetime) -> list[uuid.UUID]:
    """Heartbeat piggyback: renew leases of connections the worker says it holds and record their state.
    Returns the accounts whose lease could NOT be renewed (the worker must drop them immediately)."""
    lost: list[uuid.UUID] = []
    ids=list({r.account_id for r in reports})
    accounts={}
    for start in range(0,len(ids),500):
        accounts.update({a.id:a for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.id.in_(ids[start:start+500])))).scalars()})
    for r in reports:
        a = accounts.get(r.account_id)
        if a is None or a.assigned_worker_id != worker.id:
            lost.append(r.account_id)
            continue
        if r.epoch == 0:  # error report from a worker that holds no lease (e.g. failed to connect)
            a.connection_state, a.connection_error = "error", r.error_code
            if r.error_code:
                from app.services.account_health import DEAD
                a.health_status='dead' if r.error_code in DEAD else 'frozen' if r.error_code=='account_frozen' else 'waiting' if r.error_code=='flood_wait' else 'error'
                a.health_error=r.error_code;a.health_checked_at=now
                if a.health_status in ('frozen','dead'):a.desired_state='stopped'
            _maybe_invalidate(db, a, r.error_code)
            continue
        valid = (a.lease_worker_id == worker.id and a.lease_epoch == r.epoch and lease_active(a, now)
                 and not a.pending_deletion)
        if not valid:
            lost.append(r.account_id)
            continue
        a.lease_expires_at = now + timedelta(seconds=ttl)
        a.connection_state, a.connection_error = r.state, r.error_code
        if r.state == "connected":
            a.last_active_at = now
        _maybe_invalidate(db, a, r.error_code)
        if a.auth_state == "invalid":
            lost.append(a.id)
    return lost


def _maybe_invalidate(db: AsyncSession, a: TelegramAccount, error_code: str | None) -> None:
    if error_code in INVALIDATING_CODES and a.auth_state == "authorized":
        a.auth_state, a.desired_state = "invalid", "stopped"
        record_system_audit(db, "account.invalidated", target_type="account", target_id=str(a.id),
                            details={"reason": error_code, "name": a.name})


async def assignments_for(db: AsyncSession, worker_id: uuid.UUID) -> list[dict]:
    rows = (await db.execute(
        select(TelegramAccount).where(
            TelegramAccount.assigned_worker_id == worker_id, TelegramAccount.auth_state == "authorized",
            TelegramAccount.pending_deletion.is_(False))
    )).scalars().all()
    return [{"account_id": a.id, "name": a.name, "desired_state": a.desired_state} for a in rows]


# ------------------------------------------------------------------ commands
def create_command(db: AsyncSession, box: SecretBox | None, *, worker_id: uuid.UUID, account_id: uuid.UUID, type: str,
                   payload: dict | None, ttl: int, created_by: uuid.UUID | None, now: datetime,
                   route_id: uuid.UUID | None = None, command_id: uuid.UUID | None = None) -> WorkerCommand:
    cmd_id = command_id or uuid.uuid4()
    ciphertext = None
    if payload:
        if box is None:
            raise ApiError(503, "encryption_not_configured", "Chưa cấu hình khóa mã hóa session.")
        ciphertext = box.seal("command", str(cmd_id), json.dumps(payload))
    cmd = WorkerCommand(id=cmd_id, worker_id=worker_id, account_id=account_id, route_id=route_id, type=type, status="pending",
                        payload_ciphertext=ciphertext, created_by=created_by, created_at=now,
                        expires_at=now + timedelta(seconds=ttl))
    db.add(cmd)
    return cmd


async def supersede_login_commands(db: AsyncSession, account_id: uuid.UUID, now: datetime) -> None:
    await db.execute(
        update(WorkerCommand)
        .where(WorkerCommand.account_id == account_id, WorkerCommand.type.in_(LOGIN_COMMANDS),
               WorkerCommand.status.in_(("pending", "delivered")))
        .values(status="expired", payload_ciphertext=None, completed_at=now)
        .execution_options(synchronize_session=False)
    )


async def claim_commands(db: AsyncSession, box: SecretBox | None, worker_id: uuid.UUID, now: datetime, limit: int = 5) -> list[dict]:
    """Hand pending commands to the worker once. The encrypted payload is wiped in the same transaction."""
    pending = (await db.execute(
        select(WorkerCommand).where(WorkerCommand.worker_id == worker_id, WorkerCommand.status == "pending",
                                    WorkerCommand.expires_at > now).order_by(case((WorkerCommand.type.in_(LOGIN_COMMANDS),0),(WorkerCommand.type=='spam_reply',1),(WorkerCommand.type=='spam_read',2),else_=3),WorkerCommand.created_at).limit(limit)
    )).scalars().all()
    out: list[dict] = []
    for cmd in pending:
        ciphertext = cmd.payload_ciphertext
        res = await db.execute(
            update(WorkerCommand).where(WorkerCommand.id == cmd.id, WorkerCommand.status == "pending")
            .values(status="delivered", delivered_at=now, payload_ciphertext=None)
            .execution_options(synchronize_session=False)
        )
        if not res.rowcount:
            continue  # another poll got it first
        payload = None
        if ciphertext:
            try:
                payload = json.loads(box.open("command", str(cmd.id), ciphertext)) if box else None
            except CryptoError:
                payload = None
            if payload is None:
                await db.execute(update(WorkerCommand).where(WorkerCommand.id == cmd.id)
                                 .values(status="failed", error_code="payload_unreadable", completed_at=now)
                                 .execution_options(synchronize_session=False))
                continue
        out.append({"id": cmd.id, "type": cmd.type, "account_id": cmd.account_id, "payload": payload})
    return out


async def expire_commands(db: AsyncSession, now: datetime) -> int:
    expiring=(await db.execute(select(WorkerCommand).where(WorkerCommand.type=='spam_reply',
        WorkerCommand.status.in_(('pending','delivered')),WorkerCommand.expires_at<=now))).scalars().all()
    for cmd in expiring:
        values={'spam_action_status':'uncertain' if cmd.delivered_at else 'failed'}
        if not cmd.delivered_at:values['spam_last_action_ref']=None
        await db.execute(update(TelegramAccount).where(TelegramAccount.id==cmd.account_id,
            TelegramAccount.spam_last_action_at==cmd.created_at).values(**values))
    res = await db.execute(
        update(WorkerCommand)
        .where(WorkerCommand.status.in_(("pending", "delivered")), WorkerCommand.expires_at <= now)
        .values(status="expired", payload_ciphertext=None, completed_at=now)
        .execution_options(synchronize_session=False)
    )
    return res.rowcount or 0


def _clean_result(result: dict | None) -> dict:
    """Keep only whitelisted, non-secret fields; anything else the worker sends is dropped."""
    result = result or {}
    out: dict = {}
    if result.get("state") in ("awaiting_code", "awaiting_password", "authorized"):
        out["state"] = result["state"]
    if result.get("connection_state") in ("connected", "disconnected"):
        out["connection_state"] = result["connection_state"]
    chats = result.get("chats")
    if isinstance(chats, dict):
        clean_chats = {}
        for k, v in list(chats.items())[:200]:
            try:
                key = str(int(k))
            except (TypeError, ValueError):
                continue
            if isinstance(v, dict):
                title = v.get("title")
                clean_chats[key] = {"ok": bool(v.get("ok")), "can_send": bool(v["can_send"]) if v.get("can_send") is not None else None,
                                    "title": title[:100] if isinstance(title, str) else None}
        out["chats"] = clean_chats
    if isinstance(result.get("telegram_user_id"), int) and not isinstance(result["telegram_user_id"], bool):
        out["telegram_user_id"] = result["telegram_user_id"]
    if isinstance(result.get("username"), str):
        out["username"] = result["username"][:64]
    from app.services.spam import clean_report
    report=clean_report(result.get('spam_report'))
    if report is not None:out['spam_report']=report
    return out


async def apply_result(db: AsyncSession, cmd: WorkerCommand, acct: TelegramAccount | None, status: str, result: dict | None,
                       error_code: str | None, retry_after: int | None, now: datetime, *, box=None) -> None:
    clean = _clean_result(result)
    report=clean.pop('spam_report',None)
    if acct is not None and report is not None:
        acct.spam_status=report['status'];acct.spam_error=report.get('error_code')
        if cmd.type!='spam_read':acct.spam_checked_at=now
        if box is not None:acct.spam_reply_ciphertext=box.seal('spam_report',str(acct.id),json.dumps(report,ensure_ascii=False))
        clean['spam_status']=report['status']
        if report.get('error_code'):clean['spam_error']=report['error_code']
        if report.get('retry_after'):acct.flood_wait_until=now+timedelta(seconds=report['retry_after'])
        if cmd.type=='spam_reply':
            delivery=report.get('delivery','uncertain')
            acct.spam_action_status='sent' if delivery=='sent' else 'failed' if delivery=='not_sent' else 'uncertain'
            clean['action_delivery']=delivery
            if delivery=='not_sent':acct.spam_last_action_ref=None
    if acct is not None and cmd.type in ('spam_check','spam_read','spam_reply') and status=='failed':
        acct.spam_status='error';acct.spam_error=error_code;acct.spam_checked_at=now
        if cmd.type=='spam_reply':acct.spam_action_status='uncertain'
    cmd.status, cmd.result, cmd.completed_at, cmd.payload_ciphertext = status, clean or None, now, None
    cmd.error_code = (error_code or None) if status == "failed" else None
    cmd.retry_after = retry_after if status == "failed" else None
    if acct is None:
        return

    if cmd.type in ('check_connection','import_session','sign_in_code','sign_in_password','spam_check','spam_read','spam_reply'):
        from app.services.account_health import DEAD
        if status=='failed':
            acct.health_checked_at=now;acct.health_error=error_code
            acct.health_status=('dead' if error_code in DEAD else 'frozen' if error_code=='account_frozen' else 'waiting' if error_code=='flood_wait' else 'error')
            if error_code=='flood_wait' and retry_after:
                acct.flood_wait_until=now+timedelta(seconds=retry_after)
            if acct.health_status in ('dead','frozen'):acct.desired_state='stopped'
        elif clean.get('connection_state')=='connected' or clean.get('state')=='authorized':
            acct.health_checked_at=now
            if acct.flood_wait_until and acct.flood_wait_until>now:
                acct.health_status='waiting';acct.health_error='flood_wait'
            else:
                acct.health_status='live';acct.health_error=None;acct.flood_wait_until=None

    if status == "failed":
        if cmd.type == 'import_session':
            acct.auth_state = 'invalid' if error_code in INVALIDATING_CODES else 'import_failed'
            acct.connection_state, acct.connection_error = 'error', error_code
        if cmd.type in LOGIN_COMMANDS and error_code in RESTART_LOGIN_CODES:
            acct.auth_state = "unauthenticated"
        if error_code in INVALIDATING_CODES and acct.auth_state == "authorized":
            _maybe_invalidate(db, acct, error_code)
        if cmd.type == "check_connection":
            acct.connection_state, acct.connection_error = "error", error_code
        return

    state = clean.get("state")
    if cmd.type == "send_code":
        acct.auth_state = "awaiting_code"
    elif cmd.type in ("sign_in_code", "sign_in_password", "import_session"):
        if state == "awaiting_password":
            acct.auth_state = "awaiting_password"
        elif state == "authorized":
            if acct.session_version < 1 or not acct.session_ciphertext:
                # Invariant: authorized  =>  an encrypted session is stored.
                cmd.status, cmd.error_code = "failed", "session_not_uploaded"
                return
            acct.auth_state = "authorized"
            acct.telegram_user_id = clean.get("telegram_user_id", acct.telegram_user_id)
            acct.telegram_username = clean.get("username", acct.telegram_username)
            acct.connection_state, acct.connection_error = "disconnected", None
            record_system_audit(db, "account.authorized", target_type="account", target_id=str(acct.id),
                                details={"name": acct.name, "telegram_user_id": acct.telegram_user_id})
    elif cmd.type == "verify_chats":
        route = await db.get(ForwardRoute, cmd.route_id) if cmd.route_id else None
        found = {int(k) for k in clean.get("chats", {})}
        if route is not None and route_svc.all_chats(route) <= found:   # ignore results for an outdated chat list
            route.verification, route.verified_at = clean["chats"], now
    elif cmd.type == "check_connection":
        acct.connection_state = clean.get("connection_state", "disconnected")
        acct.connection_error = None
        if acct.connection_state == "connected":
            acct.last_active_at = now
    elif cmd.type == "logout":
        if acct.pending_deletion:
            await purge_account(db, acct)
        else:
            wipe_session(acct)
            acct.auth_state, acct.desired_state, acct.connection_state = "unauthenticated", "stopped", "disconnected"
            acct.telegram_user_id = acct.telegram_username = acct.phone_masked = None


def wipe_session(acct: TelegramAccount) -> None:
    acct.session_ciphertext, acct.session_version, acct.session_updated_at = None, 0, None
    acct.lease_worker_id = acct.lease_expires_at = None


async def purge_account(db: AsyncSession, acct: TelegramAccount) -> None:
    """Remove the account and everything hanging off it (explicit: SQLite does not enforce FK cascades)."""
    from sqlalchemy import delete
    route_ids = list((await db.execute(select(ForwardRoute.id).where(ForwardRoute.account_id == acct.id))).scalars())
    await db.execute(delete(WorkerCommand).where(WorkerCommand.account_id == acct.id))
    await db.execute(delete(ForwardJob).where(ForwardJob.account_id == acct.id))
    if route_ids:
        await db.execute(delete(RouteCheckpoint).where(RouteCheckpoint.route_id.in_(route_ids)))
        await db.execute(delete(ForwardRoute).where(ForwardRoute.id.in_(route_ids)))
    await db.delete(acct)


async def worker_can_take_commands(db: AsyncSession, worker_id: uuid.UUID | None, timeout: int, now: datetime) -> Worker:
    if worker_id is None:
        raise ApiError(409, "no_worker_assigned", "Tài khoản chưa được gán cho worker nào.")
    w = await db.get(Worker, worker_id)
    if w is None or worker_svc.effective_status(w, now, timeout) not in ("online", "degraded"):
        raise ApiError(409, "worker_unavailable", "Worker được gán đang offline hoặc đã bị thu hồi.")
    return w
