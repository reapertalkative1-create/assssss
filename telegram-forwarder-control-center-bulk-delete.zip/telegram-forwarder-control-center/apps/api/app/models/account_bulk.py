import uuid
from datetime import datetime
from sqlalchemy import String, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
from app.types import UTCDateTime, utcnow


class AccountBulkJob(Base):
    __tablename__ = 'account_bulk_jobs'
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    action: Mapped[str] = mapped_column(String(24))
    status: Mapped[str] = mapped_column(String(16), default='running', index=True)
    total: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[uuid.UUID | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class AccountBulkItem(Base):
    __tablename__ = 'account_bulk_items'
    job_id: Mapped[uuid.UUID] = mapped_column(ForeignKey('account_bulk_jobs.id', ondelete='CASCADE'), primary_key=True)
    account_id: Mapped[uuid.UUID] = mapped_column(primary_key=True)
    status: Mapped[str] = mapped_column(String(16), default='pending', index=True)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    command_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True, index=True)
