﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Setup', 'Run')][string]$Mode = 'Run',
    [switch]$NoBrowser
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:AppRoot = Split-Path -Parent $PSScriptRoot
$script:ConfigFile = Join-Path $script:AppRoot '.env.docker'
$script:ReadyFile = Join-Path $script:AppRoot '.docker-ready'
$script:VersionFile = Join-Path $script:AppRoot 'APP_VERSION'
$script:InstalledVersionFile = Join-Path $script:AppRoot '.docker-version'

function Get-AppVersion {
    if (-not (Test-Path -LiteralPath $script:VersionFile)) { throw 'APP_VERSION is missing. Extract the complete ZIP into the application folder.' }
    $value = (Get-Content -LiteralPath $script:VersionFile -Raw).Trim()
    if ($value -notmatch '^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$') { throw 'Invalid APP_VERSION. Extract the complete ZIP again.' }
    return $value
}

function Assert-WebVersion {
    param([hashtable]$Config)
    $expected = Get-AppVersion
    $url = 'http://127.0.0.1:' + $Config['TFCC_HTTP_PORT']
    try { $info = Invoke-RestMethod -Uri ($url + '/version.json') -TimeoutSec 15 }
    catch { throw "Cannot verify the web update at $url. Run setup.cmd again and open the address printed by this launcher." }
    if (-not $info -or -not ($info.PSObject.Properties.Name -contains 'version') -or $info.version -ne $expected) {
        throw "The web container at $url is outdated. Run setup.cmd from this folder, then refresh the browser with Ctrl+F5."
    }
    Write-Host ('Application version: ' + $expected)
}

function New-RandomBytes {
    param([int]$Length)
    $bytes = New-Object byte[] $Length
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return ,$bytes
}

function New-DockerConfig {
    if (Test-Path -LiteralPath $script:ConfigFile) { return }
    $password = -join ((New-RandomBytes 32) | ForEach-Object { $_.ToString('x2') })
    $secret = -join ((New-RandomBytes 32) | ForEach-Object { $_.ToString('x2') })
    $key = [Convert]::ToBase64String((New-RandomBytes 32)).Replace('+', '-').Replace('/', '_')
    $project = 'tfcc-' + [Guid]::NewGuid().ToString('N').Substring(0, 12)
    $content = @(
        '# Private settings for this Docker installation. Do not share this file.',
        "TFCC_COMPOSE_PROJECT=$project",
        "TFCC_DB_PASSWORD=$password",
        "TFCC_SECRET_KEY=$secret",
        "TFCC_SESSION_ENCRYPTION_KEY=$key",
        'TFCC_HTTP_PORT=8787',
        '# The launcher creates and saves the local worker credential automatically.',
        'TFCC_WORKER_CREDENTIAL=',
        'TFCC_WORKER_TELEGRAM_API_ID=0',
        'TFCC_WORKER_TELEGRAM_API_HASH=',
        ''
    ) -join "`r`n"
    # CreateNew prevents reruns/concurrent setup from overwriting existing encryption keys.
    $stream = [IO.File]::Open($script:ConfigFile, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $bytes = [Text.Encoding]::ASCII.GetBytes($content)
        $stream.Write($bytes, 0, $bytes.Length)
    } finally { $stream.Dispose() }
    Write-Host 'Created .env.docker with private random keys.'
}

function Read-DockerConfig {
    $result = @{}
    foreach ($line in (Get-Content -LiteralPath $script:ConfigFile)) {
        if ($line -match '^\s*([A-Z0-9_]+)\s*=(.*)$') {
            $result[$matches[1]] = $matches[2].Trim().Trim('"').Trim("'")
        }
    }
    foreach ($name in @('TFCC_COMPOSE_PROJECT', 'TFCC_DB_PASSWORD', 'TFCC_SECRET_KEY', 'TFCC_SESSION_ENCRYPTION_KEY')) {
        if (-not $result.ContainsKey($name) -or -not $result[$name]) {
            throw "Missing $name in .env.docker. Restore the existing setting; do not replace existing keys."
        }
    }
    if ($result['TFCC_COMPOSE_PROJECT'] -notmatch '^[a-z0-9][a-z0-9_-]+$') {
        throw 'Invalid TFCC_COMPOSE_PROJECT in .env.docker.'
    }
    $port = 0
    if (-not $result.ContainsKey('TFCC_HTTP_PORT') -or -not [int]::TryParse($result['TFCC_HTTP_PORT'], [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        throw 'TFCC_HTTP_PORT must be a number from 1 to 65535.'
    }
    return $result
}

function Invoke-Docker {
    param([string[]]$DockerArgs, [int[]]$AllowedCodes = @(0), [switch]$DetectPortConflict)
    # Compose writes normal progress to stderr. Windows PowerShell 5.1 must use exit codes here.
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $messages = New-Object 'Collections.Generic.List[string]'
        if ($DetectPortConflict) {
            & docker @DockerArgs 2>&1 | ForEach-Object { $messages.Add($_.ToString()); Write-Host $_ }
        } else { & docker @DockerArgs | Out-Host }
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($AllowedCodes -notcontains $code) {
        $failure = New-Object InvalidOperationException "Docker command failed (exit $code). Check the Docker output above."
        if ($DetectPortConflict -and ($messages -join "`n") -match '(?i)port is already allocated|address already in use|ports are not available|forbidden by its access permissions') {
            $failure.Data['PortConflict'] = $true
        }
        throw $failure
    }
    return $code
}

function Assert-Docker {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        throw 'Install Docker Desktop for Windows, select Linux containers, then open Docker Desktop and retry.'
    }
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $engine = (& docker info --format '{{.OSType}}' 2>$null | Out-String).Trim()
        $engineCode = $LASTEXITCODE
        $version = (& docker compose version --short 2>$null | Out-String).Trim()
        $versionCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $savedPreference }
    if ($engineCode -ne 0) { throw 'Docker Desktop is not ready. Open it, wait for Engine running, then retry.' }
    if ($engine -ne 'linux') { throw 'Switch Docker Desktop to Linux containers, then retry.' }
    if ($versionCode -ne 0) { throw 'Docker Compose is missing. Update Docker Desktop.' }
    $match = [regex]::Match($version, '(\d+)\.(\d+)\.(\d+)')
    if (-not $match.Success -or [version]$match.Value -lt [version]'2.20.0') {
        throw 'Docker Compose 2.20 or newer is required. Update Docker Desktop.'
    }
}

function Invoke-DockerJson {
    param([string[]]$DockerArgs, [string]$InputJson,
        [string]$FailureMessage = 'Automatic worker connection failed. Read the Docker message above, then retry.')
    $savedPreference = $ErrorActionPreference
    $savedEncoding = $OutputEncoding
    try {
        $ErrorActionPreference = 'Continue'
        $OutputEncoding = New-Object Text.UTF8Encoding $false
        $output = $InputJson | & docker @DockerArgs
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $savedPreference
        $OutputEncoding = $savedEncoding
    }
    if ($code -ne 0) { throw $FailureMessage }
    try { return (($output | Out-String).Trim().TrimStart([char]0xFEFF) | ConvertFrom-Json) }
    catch { throw 'Docker returned an invalid JSON response. Please run setup.cmd again.' }
}

function Write-DockerSettings {
    param([hashtable]$Values)
    $old = [IO.File]::ReadAllText($script:ConfigFile)
    $text = $old
    foreach ($key in $Values.Keys) {
        $pattern = '(?m)^[ \t]*' + [regex]::Escape($key) + '[ \t]*=[^\r\n]*'
        $line = $key + '=' + $Values[$key]
        if ([regex]::IsMatch($text, $pattern)) {
            $text = [regex]::Replace($text, $pattern, [Text.RegularExpressions.MatchEvaluator]{ param($m) $line })
        } else { $text = $text.TrimEnd() + "`r`n" + $line + "`r`n" }
    }
    if ($text -eq $old) { return }
    $temporary = $script:ConfigFile + '.tmp-' + [Guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllText($temporary, $text, (New-Object Text.UTF8Encoding $false))
        [IO.File]::Replace($temporary, $script:ConfigFile, [NullString]::Value)
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Connect-LocalWorker {
    param([hashtable]$Config)
    $machine = $env:COMPUTERNAME
    if (-not $machine) { $machine = [Environment]::MachineName }
    $machine = [regex]::Replace($machine, '[^A-Za-z0-9_.-]', '-')
    $machine = $machine.Substring(0, [Math]::Min(63, $machine.Length))
    $credential = ''
    if ($Config.ContainsKey('TFCC_WORKER_CREDENTIAL')) { $credential = $Config['TFCC_WORKER_CREDENTIAL'] }
    $payload = @{ installation = $Config['TFCC_COMPOSE_PROJECT']; machine = $machine; credential = $credential } | ConvertTo-Json -Compress
    $compose = @('compose', '--env-file', '.env.docker', '-f', 'compose.yaml')
    $worker = Invoke-DockerJson -DockerArgs ($compose + @('exec', '-T', 'api', 'python', 'docker/provision_worker.py')) -InputJson $payload
    if (-not $worker.credential -or $worker.credential -notmatch '^tfw_[0-9a-f]{32}\.[A-Za-z0-9_-]+$') {
        throw 'Invalid worker bootstrap result.'
    }
    Write-DockerSettings -Values @{
        TFCC_WORKER_CREDENTIAL = $worker.credential
        TFCC_WORKER_ID = $worker.id
        TFCC_WORKER_HOSTNAME = $machine
    }
    $Config['TFCC_WORKER_CREDENTIAL'] = $worker.credential
    $Config['TFCC_WORKER_ID'] = $worker.id
    $Config['TFCC_WORKER_HOSTNAME'] = $machine
    return $worker
}

function Get-DockerPortOwners {
    # Read only network bindings and Compose labels; never inspect credentials.
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $ids = @(& docker ps -q)
        $code = $LASTEXITCODE
        if ($code -ne 0) { throw 'Cannot read Docker containers to choose a web port.' }
        if (-not $ids.Count) { return }
        $lines = @(& docker inspect --format '{{json .NetworkSettings.Ports}}|{{json .Config.Labels}}' @ids)
        $code = $LASTEXITCODE
        if ($code -ne 0) { throw 'Cannot read Docker port bindings. Retry when Docker Desktop is ready.' }
    } finally { $ErrorActionPreference = $savedPreference }
    foreach ($line in $lines) {
        $parts = ([string]$line).Split(@('|'), 2, [StringSplitOptions]::None)
        if ($parts.Count -ne 2) { throw 'Invalid Docker port response.' }
        $ports = $parts[0] | ConvertFrom-Json
        $labels = $parts[1] | ConvertFrom-Json
        $project = ''; $service = ''
        if ($null -ne $labels) {
            $p = $labels.PSObject.Properties['com.docker.compose.project']
            $s = $labels.PSObject.Properties['com.docker.compose.service']
            if ($null -ne $p) { $project = [string]$p.Value }
            if ($null -ne $s) { $service = [string]$s.Value }
        }
        if ($null -eq $ports) { continue }
        foreach ($property in $ports.PSObject.Properties) {
            foreach ($binding in @($property.Value)) {
                if ($null -eq $binding) { continue }
                $number = 0
                if ([int]::TryParse([string]$binding.HostPort, [ref]$number)) {
                    [pscustomobject]@{ Port = $number; Project = $project; Service = $service }
                }
            }
        }
    }
}

function Test-LocalPortFree {
    param([int]$Port)
    $listener = New-Object Net.Sockets.TcpListener ([Net.IPAddress]::Loopback), $Port
    try {
        $listener.ExclusiveAddressUse = $true
        $listener.Start()
        return $true
    } catch [Net.Sockets.SocketException] { return $false }
    finally { $listener.Stop() }
}

function Select-HttpPort {
    param([hashtable]$Config, [int[]]$ExcludePorts = @())
    $owners = @(Get-DockerPortOwners)
    $original = [int]$Config['TFCC_HTTP_PORT']
    for ($offset = 0; $offset -lt 100; $offset++) {
        $candidate = $original + $offset
        if ($candidate -gt 65535) { $candidate = 1024 + $candidate - 65536 }
        if ($ExcludePorts -contains $candidate) { continue }
        $bindings = @($owners | Where-Object { $_.Port -eq $candidate })
        $ours = $bindings.Count -gt 0 -and @($bindings | Where-Object {
            $_.Project -ne $Config['TFCC_COMPOSE_PROJECT'] -or $_.Service -ne 'web'
        }).Count -eq 0
        if ($bindings.Count -gt 0 -and -not $ours) { continue }
        if (-not $ours -and -not (Test-LocalPortFree -Port $candidate)) { continue }
        if ($candidate -ne $original) {
            Write-DockerSettings -Values @{ TFCC_HTTP_PORT = [string]$candidate }
            $Config['TFCC_HTTP_PORT'] = [string]$candidate
            Write-Host "Port $original is busy or unavailable. Using http://127.0.0.1:$candidate (saved for next run)."
        }
        # Compose's inherited environment must agree with the persisted setting.
        $env:TFCC_HTTP_PORT = [string]$candidate
        return
    }
    throw "No available web port found near $original. Set TFCC_HTTP_PORT to a free port in .env.docker and retry."
}

function Start-Application {
    param([hashtable]$Config)
    $compose = @('compose', '--env-file', '.env.docker', '-f', 'compose.yaml')
    Select-HttpPort -Config $Config
    # Drain the worker before replacing API containers; it shares the API's network namespace.
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'stop', 'worker')))
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'rm', '-f', 'worker')))
    $triedPorts = @()
    for ($attempt = 0; $attempt -lt 3; $attempt++) {
        try {
            [void](Invoke-Docker -DockerArgs ($compose + @('up', '-d', '--wait', '--wait-timeout', '180', 'api', 'web')) -DetectPortConflict)
            break
        } catch {
            if (-not $_.Exception.Data.Contains('PortConflict') -or $attempt -eq 2) { throw }
            $triedPorts += [int]$Config['TFCC_HTTP_PORT']
            Write-Host 'The web port became unavailable during startup. Selecting another port...'
            Select-HttpPort -Config $Config -ExcludePorts $triedPorts
        }
    }
    Assert-WebVersion -Config $Config
    Write-Host 'Connecting this computer to the dashboard...'
    $worker = Connect-LocalWorker -Config $Config
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'up', '-d', '--wait', '--wait-timeout', '180', '--force-recreate', 'worker')))
    $payload = @{ id = $worker.id; previous_registered = $worker.previous_registered } | ConvertTo-Json -Compress
    $connected = Invoke-DockerJson -DockerArgs ($compose + @('exec', '-T', 'api', 'python', 'docker/provision_worker.py', '--wait-online')) -InputJson $payload
    Write-Host ('Computer connected: ' + $connected.name)
    if (-not $Config.ContainsKey('TFCC_WORKER_TELEGRAM_API_HASH') -or -not $Config['TFCC_WORKER_TELEGRAM_API_HASH'] -or
        -not $Config.ContainsKey('TFCC_WORKER_TELEGRAM_API_ID') -or $Config['TFCC_WORKER_TELEGRAM_API_ID'] -notmatch '^[1-9][0-9]*$') {
        Write-Host 'Worker is online. Add a Telegram account and enter API ID/hash on the web dashboard.'
    }
    $url = 'http://127.0.0.1:' + $Config['TFCC_HTTP_PORT']
    Write-Host "Application running: $url"
    Write-Host 'Containers keep running in the background. Stop them in Docker Desktop when finished.'
    if (-not $NoBrowser) {
        try { Start-Process $url } catch { Write-Host "Open this address in your browser: $url" }
    }
}

function New-SetupAdmin {
    param([string[]]$Compose)
    $username = ''
    try {
        while ($true) {
            if (-not $username) {
                $username = Read-Host 'Tên đăng nhập quản trị [admin]'
                if ([string]::IsNullOrWhiteSpace($username)) { $username = 'admin' }
            }
            Write-Host 'Mật khẩu hiển thị khi nhập. Ít nhất 12 ký tự, không chứa tên đăng nhập.'
            $password = Read-Host 'Mật khẩu'
            $confirmation = Read-Host 'Nhập lại mật khẩu'
            if (-not [string]::Equals($password, $confirmation, [StringComparison]::Ordinal)) {
                Write-Host 'Hai mật khẩu không khớp. Nhập lại cả hai lần; kiểm tra chữ hoa/thường và dấu cách.' -ForegroundColor Yellow
                continue
            }
            # JSON stdin preserves punctuation, spaces and Unicode; never put passwords in command arguments.
            $payload = @{ username = $username; password = $password; password_confirm = $confirmation } | ConvertTo-Json -Compress
            $result = Invoke-DockerJson -DockerArgs ($Compose + @('run', '--rm', '-T', '--no-deps', 'api', 'python', 'docker/create_admin.py')) -InputJson $payload -FailureMessage 'Không tạo được quản trị viên. Kiểm tra Docker/cơ sở dữ liệu rồi chạy lại setup.cmd; dữ liệu cũ được giữ nguyên.'
            $password = $null; $confirmation = $null; $payload = $null
            if ($result.ok -eq $true) {
                Write-Host ("Đã tạo quản trị viên '" + $result.username + "'.")
                return
            }
            Write-Host $result.message -ForegroundColor Yellow
            if ($result.code -in @('invalid_username', 'username_exists')) { $username = '' }
            elseif ($result.code -notin @('invalid_password', 'password_mismatch')) {
                throw 'Không tạo được quản trị viên. Chạy lại setup.cmd để thử lại.'
            }
        }
    } finally { $password = $null; $confirmation = $null; $payload = $null }
}

function Start-Setup {
    $compose = @('compose', '--env-file', '.env.docker', '-f', 'compose.yaml')
    New-DockerConfig
    $config = Read-DockerConfig
    Write-Host 'Building isolated images. The first setup requires internet and may take several minutes.'
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'build', '--pull')))
    Write-Host 'Pausing the worker and web/API before upgrading delivery history...'
    [void](Invoke-Docker -DockerArgs ($compose + @('--profile', 'telegram', 'stop', '--timeout', '30', 'worker')))
    [void](Invoke-Docker -DockerArgs ($compose + @('stop', 'web', 'api')))
    [void](Invoke-Docker -DockerArgs ($compose + @('up', '-d', '--wait', '--wait-timeout', '180', 'db')))
    [void](Invoke-Docker -DockerArgs ($compose + @('run', '--rm', '-T', '--no-deps', 'api', 'python', '-m', 'alembic', 'upgrade', 'head')))
    $status = Invoke-Docker -DockerArgs ($compose + @('run', '--rm', '-T', '--no-deps', 'api', 'python', 'docker/admin_status.py')) -AllowedCodes @(0, 3)
    if ($status -eq 3) {
        New-SetupAdmin -Compose $compose
    } else {
        Write-Host 'An active admin already exists. Keeping the current account and database.'
    }
    Start-Application -Config $config
    [IO.File]::WriteAllText($script:ReadyFile, $config['TFCC_COMPOSE_PROJECT'], [Text.Encoding]::ASCII)
    [IO.File]::WriteAllText($script:InstalledVersionFile, (Get-AppVersion), [Text.Encoding]::ASCII)
    Write-Host 'Setup complete. Next time, double-click run.cmd.'
}

function Main {
    Set-Location -LiteralPath $script:AppRoot
    try {
        $lock = [IO.File]::Open((Join-Path $script:AppRoot '.launcher.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    } catch { throw 'Another setup/run is already running, or this folder is not writable.' }
    try {
    Assert-Docker
    if ($Mode -eq 'Setup') {
        Start-Setup
    } else {
        if (-not (Test-Path -LiteralPath $script:ConfigFile) -or -not (Test-Path -LiteralPath $script:ReadyFile)) {
            throw 'Run setup.cmd successfully once before using run.cmd.'
        }
        $config = Read-DockerConfig
        $project = (Get-Content -LiteralPath $script:ReadyFile -Raw).Trim()
        if ($project -ne $config['TFCC_COMPOSE_PROJECT']) { throw 'Installation settings changed. Run setup.cmd again.' }
        $installedVersion = if (Test-Path -LiteralPath $script:InstalledVersionFile) { (Get-Content -LiteralPath $script:InstalledVersionFile -Raw).Trim() } else { '' }
        if ($installedVersion -ne (Get-AppVersion)) {
            Write-Host 'New application version detected. Updating containers and database; existing settings and sessions are kept.'
            Start-Setup
        } else { Start-Application -Config $config }
    }
    } finally { $lock.Dispose() }
}

if ($MyInvocation.InvocationName -ne '.') {
    try { Main; exit 0 } catch { Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
}
