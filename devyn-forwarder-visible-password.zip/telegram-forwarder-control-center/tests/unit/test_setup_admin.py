"""Exercise the real JSON helper process and the interactive CLI's retry path."""
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest
from sqlalchemy import select

from app import cli
from app.db import make_engine, make_sessionmaker
from app.models import AuditLog, User
from app.security import verify_password

ROOT = Path(__file__).resolve().parents[2]
VISIBLE_PASSWORD = '  Đặc-Biệt-9&|^%!"\'\\$🙂  '


def run_helper(settings, data):
    env = {**os.environ, "TFCC_DATABASE_URL": settings.database_url, "PYTHONUTF8": "1"}
    result = subprocess.run(
        [sys.executable, str(ROOT / "docker/create_admin.py")],
        input=json.dumps(data, ensure_ascii=False).encode("utf-8"),
        capture_output=True, env=env, timeout=30,
    )
    return result, json.loads(result.stdout)


def test_setup_creation_preserves_password_and_login(settings, client, login):
    payload = {"username": " Setup-Admin ", "password": VISIBLE_PASSWORD, "password_confirm": VISIBLE_PASSWORD}
    result, response = run_helper(settings, payload)
    assert result.returncode == 0 and response == {"ok": True, "username": "setup-admin"}
    assert VISIBLE_PASSWORD.encode() not in result.stdout + result.stderr
    assert login(client, "setup-admin", VISIBLE_PASSWORD)

    async def check():
        engine = make_engine(settings.database_url)
        try:
            async with make_sessionmaker(engine)() as db:
                user = (await db.execute(select(User))).scalar_one()
                assert verify_password(user.password_hash, VISIBLE_PASSWORD)
                logs = (await db.execute(select(AuditLog))).scalars().all()
                assert all(VISIBLE_PASSWORD not in json.dumps(log.details, ensure_ascii=False) for log in logs)
        finally:
            await engine.dispose()
    asyncio.run(check())
    result, response = run_helper(settings, payload)
    assert result.returncode == 0 and response["code"] == "username_exists"


@pytest.mark.parametrize("username,password,confirmation,code", [
    ("test-admin", "Case-Sensitive-9", "case-sensitive-9", "password_mismatch"),
    ("test-admin", "Has-Trailing-Space9 ", "Has-Trailing-Space9", "password_mismatch"),
    ("test-admin", "short", "short", "invalid_password"),
    ("test-admin", "Contains-test-admin9", "Contains-test-admin9", "invalid_password"),
    ("bad name", VISIBLE_PASSWORD, VISIBLE_PASSWORD, "invalid_username"),
])
def test_setup_validation_creates_no_user(settings, username, password, confirmation, code):
    result, response = run_helper(settings, {"username": username, "password": password, "password_confirm": confirmation})
    assert result.returncode == 0 and response["ok"] is False and response["code"] == code
    assert password.encode() not in result.stdout + result.stderr
    async def check():
        engine = make_engine(settings.database_url)
        try:
            async with make_sessionmaker(engine)() as db:
                assert (await db.execute(select(User))).first() is None
        finally:
            await engine.dispose()
    asyncio.run(check())


def test_setup_invalid_payload_fails_without_echo(settings):
    result, response = run_helper(settings, {"password": VISIBLE_PASSWORD})
    assert result.returncode == 1 and response["code"] == "invalid_request"
    assert VISIBLE_PASSWORD.encode() not in result.stdout + result.stderr


def test_visible_cli_retries_then_accepts_exact_input(settings, client, login, monkeypatch, capsys):
    answers = iter(["Case-Sensitive-9", "case-sensitive-9", "short", "short", VISIBLE_PASSWORD, VISIBLE_PASSWORD])
    prompts = []
    def visible_input(prompt):
        prompts.append(prompt)
        return next(answers)
    monkeypatch.setattr("builtins.input", visible_input)
    monkeypatch.setattr(cli, "get_settings", lambda: settings)
    assert cli.main(["create-admin", "Cli-Admin"]) == 0
    assert len(prompts) == 6
    assert "không khớp" in capsys.readouterr().out
    assert login(client, "cli-admin", VISIBLE_PASSWORD)


def test_cli_password_stdin_remains_noninteractive(settings, client, login, monkeypatch):
    import io
    monkeypatch.setattr(cli, "get_settings", lambda: settings)
    monkeypatch.setattr(sys, "stdin", io.StringIO(VISIBLE_PASSWORD + "\r\n"))
    monkeypatch.setattr("builtins.input", lambda _: pytest.fail("stdin mode must not prompt"))
    assert cli.main(["create-admin", "Stdin-Admin", "--password-stdin"]) == 0
    assert login(client, "stdin-admin", VISIBLE_PASSWORD)
