"""Create the setup administrator from UTF-8 JSON stdin, without a Docker TTY."""
import asyncio
import json
import sys

from app.cli import create_admin
from app.config import get_settings
from app.schemas import normalize_username
from app.security import validate_password_policy


def reply(ok: bool, **fields) -> None:
    # ASCII output also works with Windows PowerShell's native output decoding.
    print(json.dumps({"ok": ok, **fields}, ensure_ascii=True))


def main() -> int:
    try:
        data = json.loads(sys.stdin.read(8193))
        if not isinstance(data, dict) or set(data) != {"username", "password", "password_confirm"}:
            raise ValueError
        if not all(isinstance(value, str) for value in data.values()):
            raise ValueError
    except (ValueError, UnicodeError):
        reply(False, code="invalid_request", message="Dữ liệu tạo tài khoản không hợp lệ.")
        return 1
    try:
        username = normalize_username(data["username"])
    except ValueError:
        reply(False, code="invalid_username", message="Tên đăng nhập cần 3–32 ký tự: chữ, số, dấu _, . hoặc -.")
        return 0
    if data["password"] != data["password_confirm"]:
        reply(False, code="password_mismatch", message="Hai mật khẩu không khớp. Vui lòng nhập lại.")
        return 0
    problem = validate_password_policy(data["password"], username)
    if problem:
        reply(False, code="invalid_password", message=problem)
        return 0
    try:
        asyncio.run(create_admin(get_settings().database_url, username, data["password"]))
    except SystemExit:
        # Username and policy were validated above; creation can still hit a duplicate.
        reply(False, code="username_exists", message="Tên đăng nhập đã tồn tại. Hãy dùng tên khác.")
        return 0
    except Exception:
        # Do not print database parameters or the request on failure.
        reply(False, code="creation_failed", message="Không tạo được tài khoản. Kiểm tra kết nối cơ sở dữ liệu rồi chạy lại setup.cmd.")
        return 1
    reply(True, username=username)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
