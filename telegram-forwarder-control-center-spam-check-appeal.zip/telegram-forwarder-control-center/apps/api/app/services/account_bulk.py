"""Database snapshots and bounded, restartable bulk scheduling."""
from sqlalchemy import select, func
from app.models import AccountBulkJob, AccountBulkItem, TelegramAccount, WorkerCommand
from app.services import accounts as svc
from app.errors import ApiError
from app.types import utcnow
from datetime import timedelta


async def process_job(db, job, settings, box):
    now=utcnow()
    queued=(await db.execute(select(AccountBulkItem).where(AccountBulkItem.job_id==job.id,
        AccountBulkItem.status=='queued').limit(200))).scalars().all()
    command_ids=[i.command_id for i in queued if i.command_id]
    commands={c.id:c for c in (await db.execute(select(WorkerCommand).where(WorkerCommand.id.in_(command_ids)))).scalars()} if command_ids else {}
    for item in queued:
        cmd=commands.get(item.command_id)
        if cmd is None:item.status,item.error_code='error','command_missing'
        elif cmd.status in svc.FINAL_STATUSES:
            item.status='done' if cmd.status=='done' else 'error'
            item.error_code=cmd.error_code or ('command_expired' if cmd.status=='expired' else None)
            if job.action=='spam_check' and cmd.status=='done' and (cmd.result or {}).get('spam_error'):
                item.status,item.error_code='error',cmd.result['spam_error']
    if job.status=='running':
        items=(await db.execute(select(AccountBulkItem).where(AccountBulkItem.job_id==job.id,
            AccountBulkItem.status=='pending').order_by(AccountBulkItem.account_id).limit(100))).scalars().all()
        ids=[i.account_id for i in items]
        accounts={a.id:a for a in (await db.execute(select(TelegramAccount).where(TelegramAccount.id.in_(ids)))).scalars()} if ids else {}
        existing_commands={c.account_id:c for c in (await db.execute(select(WorkerCommand).where(WorkerCommand.account_id.in_(ids),
            WorkerCommand.type.in_(('check_connection','import_session','spam_check','spam_read','spam_reply')),WorkerCommand.status.in_(('pending','delivered')),
            WorkerCommand.expires_at>now))).scalars()} if ids and job.action in ('check','spam_check') else {}
        workers={a.assigned_worker_id for a in accounts.values() if a.assigned_worker_id}
        backlogs=dict((await db.execute(select(WorkerCommand.worker_id,func.count()).where(WorkerCommand.worker_id.in_(workers),
            WorkerCommand.status.in_(('pending','delivered')),WorkerCommand.type.in_(('check_connection','import_session','spam_check','spam_read','spam_reply')),
            WorkerCommand.expires_at>now).group_by(WorkerCommand.worker_id))).all()) if workers and job.action in ('check','spam_check') else {}
        worker_errors={}
        for item in items:
            a=accounts.get(item.account_id)
            if a is None or a.pending_deletion:
                item.status,item.error_code='error','account_missing';continue
            if job.action=='stop':a.desired_state='stopped';item.status='done';continue
            if job.action=='mark_frozen':
                a.health_override='frozen';a.desired_state='stopped';item.status='done';continue
            if job.action=='clear_mark':a.health_override=None;item.status='done';continue
            if job.action=='start':
                if a.auth_state!='authorized' or not a.assigned_worker_id or a.health_override=='frozen' or a.health_status in ('frozen','dead'):
                    item.status,item.error_code='error','account_not_ready';continue
                if a.flood_wait_until and a.flood_wait_until>now:
                    item.status,item.error_code='error','flood_wait';continue
                a.desired_state='running';item.status='done';continue
            if not a.session_ciphertext:
                item.status,item.error_code='error','no_session';continue
            if a.auth_state in ('awaiting_code','awaiting_password'):
                item.status,item.error_code='error','login_in_progress';continue
            if a.flood_wait_until and a.flood_wait_until>now:
                item.status,item.error_code='error','flood_wait';continue
            if a.assigned_worker_id not in worker_errors:
                try:
                    await svc.worker_can_take_commands(db,a.assigned_worker_id,settings.heartbeat_timeout_seconds,now)
                    worker_errors[a.assigned_worker_id]=None
                except ApiError as exc:worker_errors[a.assigned_worker_id]=exc.code
            if worker_errors[a.assigned_worker_id]:
                item.status,item.error_code='error',worker_errors[a.assigned_worker_id];continue
            existing=existing_commands.get(a.id)
            if job.action=='spam_check':
                if a.spam_last_action_at and a.spam_last_action_at+timedelta(minutes=15)>now:
                    item.status,item.error_code='error','appeal_in_progress';continue
                if a.spam_checked_at and a.spam_checked_at+timedelta(minutes=10)>now and a.spam_status in ('clear','limited','unknown') and not a.spam_error:
                    item.status='done';continue
                if existing and existing.type=='import_session':continue
                if existing and existing.type!='spam_check':existing=None
            if existing:item.command_id,item.status=existing.id,'queued';continue
            if backlogs.get(a.assigned_worker_id,0)>=30:continue
            typ=('spam_check' if job.action=='spam_check' else 'check_connection') if a.auth_state=='authorized' else 'import_session'
            if typ=='import_session':a.auth_state='importing'
            cmd=svc.create_command(db,box,worker_id=a.assigned_worker_id,account_id=a.id,type=typ,payload={'check_spam':True} if job.action=='spam_check' and typ=='import_session' else None,
                ttl=3600,created_by=job.created_by,now=now)
            await db.flush()
            item.command_id,item.status=cmd.id,'queued'
            backlogs[a.assigned_worker_id]=backlogs.get(a.assigned_worker_id,0)+1
    await db.flush()
    remaining=(await db.execute(select(func.count()).select_from(AccountBulkItem).where(
        AccountBulkItem.job_id==job.id,AccountBulkItem.status.in_(('pending','queued'))))).scalar_one()
    if remaining==0:job.status='cancelled' if job.status=='stopping' else 'done'
    job.updated_at=now


async def tick(db,settings,box):
    jobs=(await db.execute(select(AccountBulkJob).where(AccountBulkJob.status.in_(('running','stopping')))
        .order_by(AccountBulkJob.updated_at).limit(5).with_for_update(skip_locked=True))).scalars().all()
    for job in jobs:await process_job(db,job,settings,box)
