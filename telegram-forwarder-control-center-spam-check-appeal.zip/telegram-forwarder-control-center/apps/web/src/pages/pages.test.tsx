import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Account, Summary } from "../api/types";

vi.mock("../api/client", async (orig) => {
  const real = await orig<typeof import("../api/client")>();
  return { ...real, api: { get: vi.fn(), post: vi.fn(), put: vi.fn(), patch: vi.fn() } };
});
import { ApiError, api } from "../api/client";
import { ToastProvider } from "../state/toast";
import { AuthProvider } from "../state/auth";
import { LoginWizard } from "./Accounts";
import { pipelineTones } from "./Dashboard";
import { LoginPage } from "./Login";
import { RouteForm } from "./Routes";

const mocked = { get: vi.mocked(api.get), post: vi.mocked(api.post) };
beforeEach(() => { vi.clearAllMocks(); });
const wrap = (ui: React.ReactElement) => render(<MemoryRouter><ToastProvider>{ui}</ToastProvider></MemoryRouter>);

describe("LoginPage", () => {
  it("validates before calling the API, shows the server message and clears the password after a failure", async () => {
    const user = userEvent.setup();
    mocked.get.mockRejectedValue(new ApiError(401, "unauthenticated", "x"));            // /auth/me on mount
    mocked.post.mockRejectedValueOnce(new ApiError(401, "invalid_credentials", "Sai tên đăng nhập hoặc mật khẩu."));
    wrap(<AuthProvider><LoginPage /></AuthProvider>);
    await user.click(screen.getByRole("button", { name: "Đăng nhập" }));
    expect(screen.getByText("Nhập tên đăng nhập.")).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();

    await user.type(screen.getByLabelText("Tên đăng nhập"), "admin1");
    await user.type(screen.getByLabelText("Mật khẩu"), "wrong-password");
    await user.click(screen.getByRole("button", { name: "Đăng nhập" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Sai tên đăng nhập hoặc mật khẩu.");
    expect(mocked.post).toHaveBeenCalledWith("/api/auth/login", { username: "admin1", password: "wrong-password" });
    expect(screen.getByLabelText("Mật khẩu")).toHaveValue("");
    expect(screen.getByLabelText("Tên đăng nhập")).toHaveValue("admin1");
  });
});

const account = { id: "acc1", name: "Sale 1", auth_state: "unauthenticated" } as Account;

describe("LoginWizard", () => {
  it("moves phone → code → done and drops each secret from the form as soon as it is sent", async () => {
    const user = userEvent.setup();
    mocked.post.mockImplementation(async (path: string) => ({ command_id: path.includes("start") ? "c1" : "c2", status: "pending" }));
    mocked.get.mockImplementation(async (path: string) => ({
      id: path.includes("c1") ? "c1" : "c2", type: "x", status: "done", error_code: null, retry_after: null, created_at: "", completed_at: "",
      result: path.includes("c2") ? { state: "authorized" } : { state: "awaiting_code" },
    }));
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    const code = await screen.findByLabelText("Mã xác nhận");
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/acc1/login/start", { phone: "+84901234567" });
    expect(screen.queryByDisplayValue("+84901234567")).toBeNull();

    await user.type(code, "48213");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByText(/Đã đăng nhập thành công/)).toBeInTheDocument();
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/acc1/login/code", { code: "48213" });
    expect(document.body.innerHTML).not.toContain("48213");
    expect(document.body.innerHTML).not.toContain("901234567");
  });

  it("asks for the 2FA password when Telegram requires it and explains a wrong code in plain Vietnamese", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    const results = [
      { status: "failed", error_code: "code_invalid", result: null },
      { status: "done", error_code: null, result: { state: "awaiting_password" } },
    ];
    mocked.get.mockImplementation(async () => ({ id: "c", type: "x", retry_after: null, created_at: "", completed_at: "", ...results.shift()! }));
    wrap(<LoginWizard a={{ ...account, auth_state: "awaiting_code" }} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Mã xác nhận"), "11111");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Mã xác nhận không đúng.");
    expect(screen.getByLabelText("Mã xác nhận")).toHaveValue("");               // the rejected code is not kept in the form
    await user.type(screen.getByLabelText("Mã xác nhận"), "22222");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    const pw = await screen.findByLabelText("Mật khẩu hai lớp");
    expect(pw).toHaveAttribute("type", "password");
  });

  it("starts over with an empty phone field after the code expired (no secret is kept between steps)", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    const results = [{ status: "done", error_code: null, result: { state: "awaiting_code" } }, { status: "failed", error_code: "code_expired", result: null }];
    mocked.get.mockImplementation(async () => ({ id: "c", type: "x", retry_after: null, created_at: "", completed_at: "", ...results.shift()! }));
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    await user.type(await screen.findByLabelText("Mã xác nhận"), "99999");
    await user.click(screen.getByRole("button", { name: "Xác nhận mã" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("hết hạn");
    expect(await screen.findByLabelText("Số điện thoại")).toHaveValue("");
  });

  it("says so when the worker does not answer in time", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({ command_id: "c", status: "pending" });
    mocked.get.mockResolvedValue({ id: "c", type: "x", status: "expired", error_code: null, retry_after: null, created_at: "", completed_at: "", result: null });
    wrap(<LoginWizard a={account} onClose={() => {}} />);
    await user.type(screen.getByLabelText("Số điện thoại"), "+84901234567");
    await user.click(screen.getByRole("button", { name: "Gửi mã xác nhận" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("Worker không phản hồi kịp");
  });
});

describe("RouteForm", () => {
  beforeEach(() => { mocked.get.mockResolvedValue({ items: [{ id: "acc1", name: "Sale 1", auth_state: "authorized" }], total: 1, page: 1, page_size: 100 }); });

  it("explains invalid chat ids, duplicates and overlaps instead of sending bad data", async () => {
    const user = userEvent.setup();
    wrap(<RouteForm onClose={() => {}} onSaved={() => {}} />);
    await user.type(screen.getByLabelText("Tên tuyến"), "Tin sale");
    await user.selectOptions(await screen.findByLabelText("Tài khoản Telegram"), "acc1");
    await user.type(screen.getByLabelText("Chat nguồn"), "-1001\nabc");
    await user.type(screen.getByLabelText("Chat đích"), "-1001");
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    expect(await screen.findByText(/Chat id không hợp lệ: abc/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();

    const src = screen.getByLabelText("Chat nguồn");
    await user.clear(src);
    await user.type(src, "-1001");
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    expect(await screen.findByText(/vừa là nguồn vừa là đích/)).toBeInTheDocument();
    expect(mocked.post).not.toHaveBeenCalled();
  });

  it("sends a clean payload: normalised ids, keyword lists and numeric settings", async () => {
    const user = userEvent.setup();
    mocked.post.mockResolvedValue({});
    const onSaved = vi.fn();
    wrap(<RouteForm onClose={() => {}} onSaved={onSaved} />);
    await user.type(screen.getByLabelText("Tên tuyến"), "  Tin sale ");
    await user.selectOptions(await screen.findByLabelText("Tài khoản Telegram"), "acc1");
    await user.type(screen.getByLabelText("Chat nguồn"), "-1001, -1002");
    await user.type(screen.getByLabelText("Chat đích"), "-2001");
    await user.type(screen.getByLabelText("Phải chứa một trong các từ khóa"), "giá rẻ\n\nsale");
    await user.click(screen.getByLabelText("Ảnh"));
    await user.click(screen.getByRole("button", { name: "Sao chép nội dung" }));
    await user.click(screen.getByRole("button", { name: "Tạo tuyến" }));
    await waitFor(() => expect(onSaved).toHaveBeenCalled());
    expect(mocked.post).toHaveBeenCalledWith("/api/routes", {
      name: "Tin sale", account_id: "acc1", source_chat_ids: [-1001, -1002], destination_chat_ids: [-2001], mode: "copy",
      filters: { keywords_include: ["giá rẻ", "sale"], keywords_exclude: [], content_types: ["photo"], include_outgoing: false },
      priority: 5, rate_per_minute: 20, max_attempts: 5,
    });
  });
});

describe("dashboard pipeline", () => {
  const base = (): Summary => ({
    workers: { online: 2, offline: 0, degraded: 0, revoked: 0 }, accounts: { total: 3, authorized: 3, invalid: 0, connected: 3, running: 3 },
    routes: { active: 2, paused: 0, stopped: 1 },
    jobs: { by_status: {}, oldest_pending_age_seconds: null, succeeded_last_5m: 0, needs_attention: 0, last_24h: { succeeded: 0, failed: 0 }, series: [] },
    resources: [], recent_events: [], server_time: "",
  });
  it("is green when everything works", () => expect(pipelineTones(base())).toEqual({ workers: "ok", accounts: "ok", routes: "ok", queue: "ok" }));
  it("turns each stage amber or red for the right reason", () => {
    const s = base();
    s.workers = { online: 1, offline: 1, degraded: 0, revoked: 0 }; s.accounts.invalid = 1; s.routes.paused = 1; s.jobs.needs_attention = 4;
    expect(pipelineTones(s)).toEqual({ workers: "warn", accounts: "bad", routes: "warn", queue: "bad" });
    const none = base(); none.workers = { online: 0, offline: 2, degraded: 0, revoked: 0 };
    expect(pipelineTones(none).workers).toBe("bad");
    const idle = base(); idle.workers = { online: 0, offline: 0, degraded: 0, revoked: 0 }; idle.accounts.running = 0; idle.routes.active = 0;
    expect(pipelineTones(idle)).toMatchObject({ workers: "idle", accounts: "idle", routes: "idle" });
    const slow = base(); slow.jobs.oldest_pending_age_seconds = 300;
    expect(pipelineTones(slow).queue).toBe("warn");
  });
});

describe("Telegram API web form", () => {
  it("creates an assigned account with API credentials and clears the hash", async () => {
    const { TelegramAccountForm } = await import("./Accounts");
    const user = userEvent.setup();
    mocked.get.mockResolvedValue({ items: [{ id: "worker1", name: "My PC", status: "online" }], total: 1 });
    mocked.post.mockResolvedValue({ ...account, telegram_api_configured: true });
    const saved = vi.fn();
    wrap(<TelegramAccountForm onClose={() => {}} onSaved={saved} />);
    await waitFor(() => expect(screen.getByLabelText("Worker")).toHaveValue("worker1"));
    await user.click(screen.getByRole("button", { name: "Tạo và đăng nhập" }));
    expect(mocked.post).not.toHaveBeenCalled();
    await user.type(screen.getByLabelText("Tên hiển thị"), "Sale 1");
    await user.type(screen.getByLabelText("api_id"), "12345");
    const hash = screen.getByLabelText("api_hash");
    expect(hash).toHaveAttribute("type", "password");
    await user.type(hash, "abcdef0123456789abcdef0123456789");
    await user.click(screen.getByRole("button", { name: "Tạo và đăng nhập" }));
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts", { name: "Sale 1", worker_id: "worker1", api_id: 12345, api_hash: "abcdef0123456789abcdef0123456789" });
    expect(hash).toHaveValue("");
    expect(saved).toHaveBeenCalledWith(expect.objectContaining({ telegram_api_configured: true }));
  });
  it("updates existing credentials without returning the old hash", async () => {
    const { TelegramAccountForm } = await import("./Accounts");
    const user = userEvent.setup();
    vi.mocked(api.put).mockResolvedValue({ ...account, telegram_api_configured: true });
    wrap(<TelegramAccountForm a={{ ...account, telegram_api_configured: true }} onClose={() => {}} onSaved={() => {}} />);
    expect(screen.getByLabelText("api_hash")).toHaveValue("");
    await user.type(screen.getByLabelText("api_id"), "999");
    await user.type(screen.getByLabelText("api_hash"), "a".repeat(32));
    await user.click(screen.getByRole("button", { name: "Lưu cấu hình" }));
    expect(api.put).toHaveBeenCalledWith("/api/accounts/acc1/telegram-api", { api_id: 999, api_hash: "a".repeat(32) });
  });
});

describe("Session import", () => {
  it("uploads a session with API credentials and shows worker progress", async () => {
    const { SessionImport } = await import("./SessionImport");
    const user = userEvent.setup();
    mocked.get.mockResolvedValue({items:[{id:"w1",name:"My PC",status:"online"}]});
    mocked.post.mockImplementation(async (path: string) => path.endsWith("/status")
      ? {items:[{command_id:"c1",account_id:"a1",status:"done"}]}
      : {items:[{index:0,filename:"sample.session",account_id:"a1",command_id:"c1",status:"queued"}]});
    wrap(<SessionImport onClose={()=>{}} />);
    await waitFor(()=>expect(screen.getByLabelText("Worker")).toHaveValue("w1"));
    await user.click(screen.getByRole("button",{name:"Nhập và kiểm tra session"}));
    expect(mocked.post).not.toHaveBeenCalled();
    await user.upload(screen.getByLabelText("File session hoặc ZIP"),new File(["fake session"],"sample.session"));
    await user.type(screen.getByLabelText("api_id"),"12345");
    await user.type(screen.getByLabelText("api_hash"),"a".repeat(32));
    await user.click(screen.getByRole("button",{name:"Nhập và kiểm tra session"}));
    await waitFor(()=>expect(screen.getByText(/Thành công: 1 \/ 1/)).toBeInTheDocument());
    expect(mocked.post).toHaveBeenCalledWith("/api/accounts/import-sessions",expect.objectContaining({worker_id:"w1",api_id:12345,api_hash:"a".repeat(32),files:[{filename:"sample.session",content:btoa("fake session")}]}));
    expect(screen.queryByLabelText("api_hash")).not.toBeInTheDocument();
  });
});

describe("Unlimited session upload",()=>{
  it("automatically splits 101 selected files into requests of 100 and 1",async()=>{
    const {SessionImport}=await import("./SessionImport");
    const user=userEvent.setup();
    mocked.get.mockResolvedValue({items:[{id:"w1",name:"My PC",status:"online"}]});
    let number=0;
    mocked.post.mockImplementation(async(path:string,body?:unknown)=>{
      if(path.endsWith('/status'))return {items:(body as {command_ids:string[]}).command_ids.map(id=>({command_id:id,status:'done'}))};
      const files=(body as {files:{filename:string}[]}).files;
      return {items:files.map((f,index)=>({index,filename:f.filename,command_id:`cmd-${number++}`,status:'queued'}))};
    });
    wrap(<SessionImport onClose={()=>{}}/>);
    await waitFor(()=>expect(screen.getByLabelText('Worker')).toHaveValue('w1'));
    await user.upload(screen.getByLabelText('File session hoặc ZIP'),Array.from({length:101},(_,i)=>new File(['x'],`${i}.session`)));
    await user.type(screen.getByLabelText('api_id'),'12345');await user.type(screen.getByLabelText('api_hash'),'a'.repeat(32));
    await user.click(screen.getByRole('button',{name:'Nhập và kiểm tra session'}));
    await waitFor(()=>expect(mocked.post.mock.calls.filter(([p])=>p==='/api/accounts/import-sessions')).toHaveLength(2),{timeout:10000});
    const calls=mocked.post.mock.calls.filter(([p])=>p==='/api/accounts/import-sessions');
    expect((calls[0][1] as {files:unknown[]}).files).toHaveLength(100);
    expect((calls[1][1] as {files:unknown[]}).files).toHaveLength(1);
    expect(await screen.findByText(/Đã gửi 101 session/)).toBeInTheDocument();
  },15000);
});

describe("SpamBot appeal panel",()=>{
  it("requires an explicit preview confirmation before sending to SpamBot",async()=>{
    const {SpamPanel}=await import('./SpamPanel');
    const user=userEvent.setup();
    mocked.get.mockImplementation(async(path:string)=>path.endsWith('/spam')?{
      status:'limited',checked_at:null,error_code:null,action_status:'none',pending_command_id:null,report_token:'a'.repeat(64),
      report:{status:'limited',message_id:101,text:'Your account is now limited',buttons:[{id:'101:0:0',text:'This is a mistake'}],delivery:'sent'}
    }:{status:'done',result:{action_delivery:'sent'}});
    mocked.post.mockResolvedValue({command_id:'c1'});
    wrap(<SpamPanel a={{...account,auth_state:'authorized'}} onClose={()=>{}}/>);
    await screen.findByText('Your account is now limited');
    await user.type(screen.getByLabelText('Nội dung kháng nghị / trả lời SpamBot'),'Please review my restriction.');
    await user.click(screen.getByRole('button',{name:'Xem trước và gửi kháng nghị'}));
    expect(mocked.post).not.toHaveBeenCalled();
    expect(screen.getByText('Xác nhận gửi bằng Sale 1 tới @SpamBot')).toBeInTheDocument();
    await user.click(screen.getByRole('button',{name:'Xác nhận gửi nội dung'}));
    await waitFor(()=>expect(mocked.post).toHaveBeenCalledWith('/api/accounts/acc1/spam/action',expect.objectContaining({operation:'reply',report_token:'a'.repeat(64),text:'Please review my restriction.'})));
    await waitFor(()=>expect(screen.getByLabelText('Nội dung kháng nghị / trả lời SpamBot')).toHaveValue(''));
    expect(mocked.post.mock.calls[0][1]).not.toHaveProperty('recipient');
  });
  it("reads new replies without sending a /start check",async()=>{
    const {SpamPanel}=await import('./SpamPanel');
    const user=userEvent.setup();
    mocked.get.mockImplementation(async(path:string)=>path.endsWith('/spam')?{status:'unknown',action_status:'sent',report:null,report_token:null,pending_command_id:null}:{status:'done',result:{}});
    mocked.post.mockResolvedValue({command_id:'c2'});
    wrap(<SpamPanel a={{...account,auth_state:'authorized'}} onClose={()=>{}}/>);
    await user.click(screen.getByRole('button',{name:'Lấy phản hồi mới'}));
    expect(mocked.post).toHaveBeenCalledWith('/api/accounts/acc1/spam/read');
    expect(mocked.post).not.toHaveBeenCalledWith('/api/accounts/acc1/spam/check');
  });
});
