from pathlib import Path

from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect

import app.models  # noqa: F401
from app.db import Base

ROOT = Path(__file__).resolve().parents[2]


def _cfg(url: str) -> Config:
    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "migrations"))
    cfg.set_main_option("sqlalchemy.url", url)
    cfg.attributes["configure_logger"] = False
    return cfg


def test_upgrade_matches_models_and_downgrade_cleans(tmp_path):
    path = tmp_path / "mig.db"
    cfg = _cfg(f"sqlite+aiosqlite:///{path}")
    command.upgrade(cfg, "head")

    engine = create_engine(f"sqlite:///{path}")
    with engine.connect() as conn:
        assert {"users", "web_sessions", "audit_logs"} <= set(inspect(conn).get_table_names())
        diff = compare_metadata(MigrationContext.configure(conn, opts={"compare_type": True}), Base.metadata)
        assert diff == []

    command.downgrade(cfg, "base")
    with engine.connect() as conn:
        assert set(inspect(conn).get_table_names()) <= {"alembic_version"}


def test_saved_settings_upgrade_preserves_existing_accounts(tmp_path):
    from sqlalchemy.orm import Session
    from app.models import TelegramAccount
    path = tmp_path / 'settings-upgrade.db'
    cfg = _cfg(f'sqlite+aiosqlite:///{path}')
    command.upgrade(cfg, '0010')
    engine = create_engine(f'sqlite:///{path}')
    with Session(engine) as db:
        account = TelegramAccount(name='Existing SS', name_key='existing ss',
            telegram_api_ciphertext='keep-existing-api', proxy_label='socks5://proxy.example:1080')
        db.add(account); db.commit(); aid = account.id
    command.upgrade(cfg, 'head')
    with Session(engine) as db:
        account = db.get(TelegramAccount, aid)
        assert account.telegram_api_ciphertext == 'keep-existing-api'
        assert account.proxy_label == 'socks5://proxy.example:1080'
    assert 'application_settings' in inspect(engine).get_table_names()
    engine.dispose()


def test_post_guards_backfill_existing_deliveries_and_keep_history_on_delete(tmp_path):
    from sqlalchemy.orm import Session
    from sqlalchemy import select
    from app.models import TelegramAccount,ForwardRoute,ForwardJob,PostDelivery,PostTargetOwner
    from app.types import utcnow
    import uuid
    path=tmp_path/'post-upgrade.db';cfg=_cfg(f'sqlite+aiosqlite:///{path}')
    command.upgrade(cfg,'0014');engine=create_engine(f'sqlite:///{path}')
    with Session(engine) as db:
        a=TelegramAccount(name='Existing sender',name_key='existing sender');db.add(a);db.flush()
        r=ForwardRoute(name='Existing post',name_key='existing post',account_id=a.id,source_chat_ids=[-1001],destination_chat_ids=[-2001],link_config={'targets':['@target_group'],'queued_at':utcnow().isoformat()});db.add(r);db.flush()
        j=ForwardJob(route_id=r.id,account_id=a.id,source_chat_id=-1001,message_id=123,dest_chat_id=-2001,idempotency_key='existing-key',status='succeeded');db.add(j);db.commit();aid=a.id;jid=j.id;rid=r.id
    command.upgrade(cfg,'head')
    with Session(engine) as db:
        assert db.get(PostTargetOwner,'ref:@target_group').account_id==aid
        assert db.get(PostTargetOwner,'chat:-2001').account_id==aid
        receipt=db.get(PostDelivery,(-1001,123,-2001));assert receipt.job_id==jid and receipt.route_id==rid
        db.delete(db.get(ForwardJob,jid));db.delete(db.get(ForwardRoute,rid));db.commit()
        assert db.get(PostDelivery,(-1001,123,-2001)).job_id==jid
    engine.dispose()
