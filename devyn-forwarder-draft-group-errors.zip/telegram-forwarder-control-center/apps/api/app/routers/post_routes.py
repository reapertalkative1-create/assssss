import uuid
from datetime import datetime
from fastapi import APIRouter,Depends,Request,Query
from pydantic import BaseModel,ConfigDict,Field,field_validator
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.audit import record_audit
from app.deps import AuthContext,get_db,require_role
from app.errors import ApiError
from app.models import ForwardRoute,TelegramAccount,Role
from app.schemas_forwarding import RouteOut
from app.services.post_links import parse_post_link,parse_targets
from app.services import post_delivery
from app.routers.routes import _out

router=APIRouter(prefix='/api/post-routes',tags=['post-routes'])
admin=require_role(Role.ADMIN)

class TargetListInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    targets_text:str=Field(min_length=1,max_length=500000)


@router.post('/validate-targets')
async def validate_targets(body:TargetListInput,auth:AuthContext=Depends(admin)):
    refs=parse_targets(body.targets_text)
    return {'count':len(refs)}

class PostRouteInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    name:str=Field(min_length=1,max_length=64)
    account_id:uuid.UUID
    post_link:str=Field(min_length=1,max_length=500)
    targets_text:str=Field(min_length=1,max_length=500000)
    delay_seconds:int=Field(default=60,ge=5,le=86400)
    scheduled_at:datetime|None=None
    mode:str='forward'
    @field_validator('name')
    @classmethod
    def name_ok(cls,v):
        v=' '.join(v.split())
        if not v:raise ValueError('Nhập tên đợt gửi.')
        return v
    @field_validator('mode')
    @classmethod
    def mode_ok(cls,v):
        if v not in ('forward','copy'):raise ValueError('Chọn forward hoặc copy.')
        return v
    @field_validator('scheduled_at')
    @classmethod
    def aware(cls,v):
        if v is not None and v.tzinfo is None:raise ValueError('Lịch gửi cần múi giờ.')
        return v

async def save(body,request,auth,db,route=None):
    acct=await db.get(TelegramAccount,body.account_id)
    if acct is None or acct.pending_deletion:raise ApiError(404,'account_not_found','Không tìm thấy tài khoản Telegram.')
    if request.app.state.secret_box is None:raise ApiError(503,'encryption_not_configured','Chưa có khóa mã hóa.')
    try:post=parse_post_link(body.post_link)
    except ValueError as exc:raise ApiError(422,'invalid_post_link',str(exc)) from None
    refs=parse_targets(body.targets_text)
    for ref,owner in (await post_delivery.owners_for(db,refs)).items():
        if owner!=body.account_id:await post_delivery.owner_error(db,ref,owner)
    if route is not None and (route.link_config is None or route.status!='stopped' or route.link_config.get('queued_at')):
        raise ApiError(409,'post_route_locked','Chỉ sửa đợt chưa gửi và đang dừng. Tạo bản mới nếu đã gửi.')
    if route is None:
        route=ForwardRoute(id=uuid.uuid4(),created_by=auth.user.id,source_chat_ids=[],destination_chat_ids=[],filters={},priority=5,max_attempts=3)
        db.add(route)
    route.name=body.name;route.name_key=body.name.lower();route.account_id=body.account_id;route.mode=body.mode
    route.source_chat_ids=[];route.destination_chat_ids=[];route.verified_at=None;route.verification=None
    route.rate_per_minute=max(1,60//body.delay_seconds)
    metadata={k:v for k,v in (route.link_config or {}).items() if k in ('batch_id','batch_size','unused_senders','request_signature')}
    route.link_config={**metadata,'post_link':post['url'],'targets':refs,'delay_seconds':body.delay_seconds,'scheduled_at':body.scheduled_at.isoformat() if body.scheduled_at else None}
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'name_taken','Tên tuyến đã tồn tại.') from None
    await record_audit(db,request,'route.post_saved',actor=auth.user,target_type='route',target_id=str(route.id),details={'groups':len(refs)})
    return (await _out(db,[route]))[0]

@router.post('',response_model=RouteOut,status_code=201)
async def create(body:PostRouteInput,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    return await save(body,request,auth,db)

@router.patch('/{rid}',response_model=RouteOut)
async def edit(rid:uuid.UUID,body:PostRouteInput,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    r=await db.get(ForwardRoute,rid)
    if r is None:raise ApiError(404,'not_found','Không tìm thấy tuyến.')
    return await save(body,request,auth,db,r)


from sqlalchemy import select
from app.deps import authenticated
from app.services.post_senders import SenderSelection, SenderStatus, resolve_senders, list_senders
from app.schemas_accounts import AccountFilters

class PostBatchInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    # A stable request ID makes retrying a lost response return the existing drafts.
    request_id: uuid.UUID
    account_ids:list[uuid.UUID]=Field(min_length=1,max_length=1000)
    post_link:str=Field(min_length=1,max_length=500)
    targets_text:str=Field(min_length=1,max_length=500000)
    delay_seconds:int=Field(default=60,ge=5,le=86400)
    mode:str='forward'
    _mode=field_validator('mode')(PostRouteInput.mode_ok.__func__)


@router.post('/senders')
async def senders(body:SenderSelection,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    return await resolve_senders(db,body,timeout=request.app.state.settings.heartbeat_timeout_seconds)


@router.get('/senders')
async def sender_list(request:Request,status_filter:SenderStatus='all',q:str|None=Query(None,max_length=64),
                      group_id:uuid.UUID|None=None,ungrouped:bool=False,page:int=Query(1,ge=1),page_size:int=Query(50,ge=1,le=100),
                      auth:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    return await list_senders(db,AccountFilters(q=q,group_id=group_id,ungrouped=ungrouped),status_filter,page,page_size,
                              timeout=request.app.state.settings.heartbeat_timeout_seconds)


async def batch_routes(db,batch_id):
    return list((await db.execute(select(ForwardRoute).where(
        ForwardRoute.link_config['batch_id'].as_string()==str(batch_id)
    ).order_by(ForwardRoute.name_key))).scalars())


@router.get('/batches/{batch_id}')
async def get_batch(batch_id:uuid.UUID,auth:AuthContext=Depends(authenticated),db:AsyncSession=Depends(get_db,scope='function')):
    rows=await batch_routes(db,batch_id)
    if not rows:raise ApiError(404,'not_found','Không tìm thấy cụm gửi.')
    return {'batch_id':str(batch_id),'items':await _out(db,rows)}


@router.post('/batches',status_code=201)
async def create_batch(body:PostBatchInput,request:Request,auth:AuthContext=Depends(admin),db:AsyncSession=Depends(get_db,scope='function')):
    import hashlib,json
    signature=hashlib.sha256(json.dumps(body.model_dump(mode='json',exclude={'request_id'}),sort_keys=True).encode()).hexdigest()
    existing=await batch_routes(db,body.request_id)
    if existing:
        if any(r.created_by!=auth.user.id or r.link_config.get('request_signature')!=signature for r in existing):
            raise ApiError(409,'request_conflict','Yêu cầu đã thay đổi. Mở biểu mẫu mới để tạo đợt khác.')
        return {'batch_id':str(body.request_id),'items':await _out(db,existing),'unused_senders':existing[0].link_config.get('unused_senders',0)}
    selected=await resolve_senders(db,SenderSelection(account_ids=body.account_ids),strict=True,timeout=request.app.state.settings.heartbeat_timeout_seconds)
    refs=parse_targets(body.targets_text)
    if request.app.state.secret_box is None:raise ApiError(503,'encryption_not_configured','Chưa có khóa mã hóa.')
    try:post=parse_post_link(body.post_link)
    except ValueError as exc:raise ApiError(422,'invalid_post_link',str(exc)) from None
    accounts=selected['items']
    assignments=await post_delivery.partition(db,refs,accounts)
    used=[a for a in accounts if assignments[uuid.UUID(a['id'])]];routes=[]
    unused=len(accounts)-len(used)
    # Each normalized target belongs to exactly one account. Never redistribute
    # work when a selected account is restricted or receives FloodWait.
    for index,account in enumerate(used):
        name=f"Đợt {body.request_id.hex} · {index+1:04d}"
        route=ForwardRoute(id=uuid.uuid4(),name=name,name_key=name.lower(),account_id=uuid.UUID(account['id']),
            created_by=auth.user.id,source_chat_ids=[],destination_chat_ids=[],filters={},priority=5,max_attempts=3,
            mode=body.mode,rate_per_minute=max(1,60//body.delay_seconds),link_config={
                'post_link':post['url'],'targets':assignments[uuid.UUID(account['id'])],'delay_seconds':body.delay_seconds,'scheduled_at':None,
                'batch_id':str(body.request_id),'batch_size':len(used),'unused_senders':unused,'request_signature':signature})
        db.add(route);routes.append(route)
    try:await db.flush()
    except IntegrityError:raise ApiError(409,'batch_in_progress','Yêu cầu này đang được lưu. Bấm Lưu lại để lấy kết quả, không tạo bản sao.') from None
    await record_audit(db,request,'route.post_batch_saved',actor=auth.user,target_type='post_batch',target_id=str(body.request_id),
        details={'accounts':len(used),'targets':len(refs),'unused_senders':unused})
    return {'batch_id':str(body.request_id),'items':await _out(db,routes),'unused_senders':unused}
