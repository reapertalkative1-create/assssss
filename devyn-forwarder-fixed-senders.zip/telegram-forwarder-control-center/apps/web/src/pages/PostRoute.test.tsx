import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter} from 'react-router-dom';
import {beforeEach,describe,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn(),patch:vi.fn()}};});
import {api} from '../api/client';
import type {Route} from '../api/types';
import {PostRouteForm,PostRouteDetail} from './PostRoute';
const route={id:'r1',name:'Thông báo',account_id:'a1',account_name:'My SS',source_chat_ids:[],destination_chat_ids:[],mode:'forward',filters:{content_types:[],keywords_include:[],keywords_exclude:[],include_outgoing:false},priority:5,rate_per_minute:1,max_attempts:3,status:'stopped',verified:false,verified_at:null,verification:null,stats:{},checkpoints:{},created_at:'2026-11-12T10:00:00Z',updated_at:'2026-11-12T10:00:00Z',link_config:{post_link:'https://t.me/source_group/123',targets:['@group_one','@group_two'],delay_seconds:60,scheduled_at:null}} as Route;
const accounts={items:[{id:'a1',name:'My SS',auth_state:'authorized',desired_state:'stopped',health_status:'live',health_source:'telegram',spam_status:'clear',pending_deletion:false,assigned_worker_id:'w1'}],total:1};
beforeEach(()=>{vi.clearAllMocks();vi.mocked(api.get).mockImplementation(async(path:string)=>path==='/api/post-routes/senders'?accounts:path==='/api/jobs'?{items:[],total:0}:route);vi.mocked(api.post).mockResolvedValue({items:[route]});});
const wrap=(node:React.ReactNode)=>render(<MemoryRouter>{node}</MemoryRouter>);
describe('Post-link delivery editor',()=>{
 it('shows duplicate skips without presenting them as successful sends',async()=>{
  const duplicate={...route,verified:true,link_config:{...route.link_config!,queued_at:'2026-11-14T00:00:00Z',queued_count:0,duplicate_count:2}};
  vi.mocked(api.get).mockResolvedValue(duplicate);
  wrap(<PostRouteDetail route={duplicate} onClose={()=>{}} onVerify={vi.fn()} onAction={vi.fn()}/>);
  expect(await screen.findByText('Bỏ qua bài trùng')).toBeVisible();
  expect(screen.getByText(/Bỏ qua 2 nhóm/)).toBeVisible();
  expect(screen.queryByRole('button',{name:'Bắt đầu gửi'})).not.toBeInTheDocument();
 });
 it('requires an explicit delivery review and does not resume automatically',async()=>{
  const user=userEvent.setup(),action=vi.fn();
  const held={...route,status:'paused',stats:{failed:1,pending:1},link_config:{...route.link_config!,queued_at:'2026-11-14T00:00:00Z',pause_reason:'delivery_uncertain'}} as Route;
  const job={id:'j1',status:'failed',last_error_code:'delivery_uncertain',dest_chat_id:-1001,available_at:'2026-11-14T00:00:00Z'};
  vi.mocked(api.get).mockImplementation(async path=>path==='/api/jobs'?{items:[job],total:1}:held);
  wrap(<PostRouteDetail route={held} onClose={()=>{}} onVerify={vi.fn()} onAction={action}/>);
  expect(screen.getByRole('button',{name:'Tiếp tục'})).toBeDisabled();
  await user.click(screen.getAllByRole('button',{name:'Tiến độ từng nhóm'})[0]);
  await user.click(await screen.findByRole('button',{name:'Chưa gửi · thử lại'}));
  expect(api.post).toHaveBeenCalledWith('/api/jobs/j1/review-delivery',{delivered:false});
  expect(action).not.toHaveBeenCalled();
 });
 it('uploads TXT and saves a draft linked to an SS without sending',async()=>{
  const user=userEvent.setup(),saved=vi.fn();wrap(<PostRouteForm onClose={()=>{}} onSaved={saved}/>);
  await user.click(screen.getByRole('button',{name:'Lưu đợt gửi'}));expect(api.post).not.toHaveBeenCalled();
  expect(screen.queryByLabelText('Tên đợt gửi')).not.toBeInTheDocument();
  expect(screen.queryByLabelText('Bắt đầu từ')).not.toBeInTheDocument();
  await user.click(await screen.findByLabelText('Chọn SS My SS'));
  await user.type(screen.getByLabelText('Liên kết bài viết Telegram'),'https://t.me/source_group/123');
  const f=new File(['x'],'groups.txt',{type:'text/plain'});Object.defineProperty(f,'text',{value:async()=>'@group_one\nhttps://t.me/group_two'});
  await user.upload(screen.getByLabelText('File danh sách nhóm .txt'),f);
  await waitFor(()=>expect(screen.getByLabelText('Nhóm nhận bài')).toHaveValue('@group_one\nhttps://t.me/group_two'));
  await user.click(screen.getByRole('button',{name:'Lưu đợt gửi'}));
  expect(api.post).toHaveBeenCalledWith('/api/post-routes/batches',{request_id:expect.any(String),account_ids:['a1'],post_link:'https://t.me/source_group/123',targets_text:'@group_one\nhttps://t.me/group_two',delay_seconds:60,mode:'forward'});
  expect(api.post).toHaveBeenCalledTimes(1);expect(saved).toHaveBeenCalledWith(route);
 });
 it('requires verification before exposing the send action',async()=>{
  const user=userEvent.setup(),action=vi.fn().mockResolvedValue(undefined);
  const verify=vi.fn().mockImplementation(async()=>{vi.mocked(api.get).mockResolvedValue({...route,verified:true,destination_chat_ids:[-1001,-1002]});});
  wrap(<PostRouteDetail route={route} onClose={()=>{}} onVerify={verify} onAction={action}/>);
  expect(screen.queryByRole('button',{name:'Bắt đầu gửi'})).not.toBeInTheDocument();
  await user.click(screen.getByRole('button',{name:'Kiểm tra nhóm'}));
  expect(verify).toHaveBeenCalledTimes(1);expect(action).not.toHaveBeenCalled();
  await user.click(await screen.findByRole('button',{name:'Bắt đầu gửi'}));expect(action).toHaveBeenCalledWith('start');
 });
 it('keeps only verified groups when explicitly requested',async()=>{
  const user=userEvent.setup();wrap(<PostRouteForm route={{...route,link_config:{...route.link_config!,checks:[{index:0,id:-1001,ok:true,can_send:true,title:'One',error_code:null},{index:1,id:null,ok:false,can_send:false,title:'',error_code:'not_joined'}]}}} onClose={()=>{}} onSaved={()=>{}}/>);
  await user.click(screen.getByRole('button',{name:'Chỉ giữ nhóm hợp lệ'}));expect(screen.getByLabelText('Nhóm nhận bài')).toHaveValue('@group_one');
 });
});
