import {useEffect,useState} from 'react';
import {render,screen,waitFor} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {MemoryRouter} from 'react-router-dom';
import {beforeEach,expect,it,vi} from 'vitest';
vi.mock('../api/client',async orig=>{const real=await orig<typeof import('../api/client')>();return {...real,api:{get:vi.fn(),post:vi.fn()}};});
import {api} from '../api/client';
import {SenderPicker,type Sender} from './SenderPicker';
import {AccountSelectionProvider,useAccountSelection} from '../state/accountSelection';
const a={id:'a1',name:'SS A',auth_state:'authorized',assigned_worker_id:'w1',health_status:'live',spam_status:'clear',group_name:'Nhóm A'};
const b={...a,id:'a2',name:'SS B',group_name:'Nhóm B'};
const blocked={...a,id:'bad',name:'SS blocked',spam_status:'blocked'};
const selection={all_matching:true,account_ids:[],exclude_ids:['excluded'],filters:{group_id:'g1'}};
function Form({saved=false}:{saved?:boolean}){const [value,setValue]=useState<Sender[]>([]);const {setSaved}=useAccountSelection();useEffect(()=>{if(saved)setSaved({selection,count:2});},[saved,setSaved]);return <><SenderPicker value={value} onChange={setValue}/><output aria-label="selected ids">{value.map(a=>a.id).join(',')}</output></>;}
beforeEach(()=>{
 vi.clearAllMocks();vi.mocked(api.get).mockImplementation(async(path,query)=>path==='/api/account-groups'?[{id:'g1',name:'Nhóm A',count:2},{id:'g2',name:'Nhóm B',count:1}]:query?.page===2||query?.group_id==='g2'?{items:[b],total:51}:{items:[a,blocked],total:51});
 vi.mocked(api.post).mockResolvedValue({items:[a,b],skipped:[],skipped_count:1});
});
it('keeps selected SS across pages and groups, disables restricted accounts and can review/remove selections',async()=>{
 const user=userEvent.setup();render(<MemoryRouter><Form/></MemoryRouter>);
 await user.click(await screen.findByLabelText('Chọn SS SS A'));expect(screen.getByLabelText('Chọn SS SS blocked')).toBeDisabled();
 await user.click(screen.getByRole('button',{name:'Sau'}));await user.click(await screen.findByLabelText('Chọn SS SS B'));
 await user.selectOptions(screen.getByLabelText('Nhóm tài khoản gửi'),'g2');
 expect(screen.getByLabelText('selected ids')).toHaveTextContent('a1,a2');
 await user.click(screen.getByLabelText('Chỉ xem đã chọn'));expect(screen.getByLabelText('Chọn SS SS A')).toBeChecked();expect(screen.getByLabelText('Chọn SS SS B')).toBeChecked();
 await user.click(screen.getByLabelText('Chọn SS SS A'));expect(screen.getByLabelText('selected ids')).toHaveTextContent('a2');
 await user.click(screen.getByRole('button',{name:'Bỏ chọn hết'}));expect(screen.getByLabelText('selected ids')).toBeEmptyDOMElement();
});
it('selects the whole filtered group beyond the current page without dropping existing picks',async()=>{
 const user=userEvent.setup();render(<MemoryRouter><Form/></MemoryRouter>);
 await user.selectOptions(await screen.findByLabelText('Nhóm tài khoản gửi'),'g2');await waitFor(()=>expect(screen.getByRole('button',{name:'Chọn toàn bộ kết quả'})).toBeEnabled());
 await user.click(screen.getByRole('button',{name:'Chọn toàn bộ kết quả'}));
 expect(api.post).toHaveBeenCalledWith('/api/post-routes/senders',expect.objectContaining({all_matching:true,filters:expect.objectContaining({group_id:'g2'})}));
 expect(screen.getByLabelText('selected ids')).toHaveTextContent('a1,a2');expect(screen.getByText(/Bỏ qua 1 SS chưa đủ điều kiện/)).toBeVisible();
});
it('imports the Telegram account table selection with its exclusions intact',async()=>{
 const user=userEvent.setup();render(<MemoryRouter><AccountSelectionProvider><Form saved/></AccountSelectionProvider></MemoryRouter>);
 await user.click(await screen.findByRole('button',{name:'SS đã tích (2)'}));
 expect(api.post).toHaveBeenCalledWith('/api/post-routes/senders',selection);expect(screen.getByLabelText('selected ids')).toHaveTextContent('a1,a2');
});
