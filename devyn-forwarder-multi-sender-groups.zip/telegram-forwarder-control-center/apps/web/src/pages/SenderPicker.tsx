import {useState} from 'react';
import {Link} from 'react-router-dom';
import {api,ApiError} from '../api/client';
import type {Account,Page} from '../api/types';
import {Alert,SelectField,TextField} from '../components/ui';
import {useDebounced,useQuery} from '../hooks/useQuery';
import {useAccountSelection,type AccountSelection} from '../state/accountSelection';
import type {AccountGroup} from './AccountGroups';
export interface Sender {id:string;name:string;group_name?:string|null}
interface Resolved {items:Sender[];skipped_count:number;skipped:{name:string;reason:string}[]}
export function senderReason(a:Account){
 if(a.pending_deletion)return 'Đang xóa';
 if(a.auth_state!=='authorized')return 'Chưa xác thực';
 if(a.health_status==='frozen'||a.health_source==='manual')return 'Đóng băng';
 if(['limited','blocked'].includes(a.spam_status))return 'Bị spam / bị chặn';
 if(a.health_status==='dead')return 'Session hết hiệu lực';
 if(!a.assigned_worker_id)return 'Chưa gán worker';
 return '';
}
export function SenderPicker({value,onChange,disabled=false,single=false,onBusyChange}:{value:Sender[];onChange:(value:Sender[])=>void;disabled?:boolean;single?:boolean;onBusyChange?:(busy:boolean)=>void}){
 const {saved}=useAccountSelection();
 const [search,setSearch]=useState(''),[group,setGroup]=useState(''),[page,setPage]=useState(1),[busy,setBusy]=useState(false),[notice,setNotice]=useState(''),[error,setError]=useState(''),[onlySelected,setOnlySelected]=useState(false);
 const q=useDebounced(search);
 const filters={q:q||undefined,group_id:group&&group!=='ungrouped'?group:undefined,ungrouped:group==='ungrouped'?'true':undefined};
 const accounts=useQuery(signal=>api.get<Page<Account>>('/api/accounts',{...filters,page,page_size:50},signal),[q,group,page]);
 const groups=useQuery(signal=>api.get<AccountGroup[]>('/api/account-groups',undefined,signal),[]);
 const rows=accounts.data?.items??[],ids=new Set(value.map(a=>a.id));
 const locked=disabled||busy;
 const refreshing=accounts.loading||accounts.refreshing||q!==search;
 function toggle(a:Sender){if(ids.has(a.id))onChange(value.filter(x=>x.id!==a.id));else onChange(single?[a]:[...value,a]);}
 async function choose(selection:AccountSelection){
  setBusy(true);onBusyChange?.(true);setError('');setNotice('');
  try{const r=await api.post<Resolved>('/api/post-routes/senders',selection);const next=new Map(value.map(a=>[a.id,a]));r.items.forEach(a=>next.set(a.id,a));if(next.size>1000){setError('Chọn tối đa 1.000 SS trong một đợt.');return;}onChange([...next.values()]);setNotice(`${r.items.length} SS đủ điều kiện${r.skipped_count?` · Bỏ qua ${r.skipped_count} SS chưa đủ điều kiện`:''}.`);}
  catch(e){setError(e instanceof ApiError?e.message:'Không lấy được tài khoản.');}finally{setBusy(false);onBusyChange?.(false);}
 }
 const currentEligible=rows.filter(a=>!senderReason(a));
 return <section className="sender-picker stack tight" aria-label="Tài khoản gửi">
  <div className="row between"><strong className="small">Tài khoản gửi <span className="hint">· Đã chọn {value.length}</span></strong><Link to="/accounts">Quản lý tài khoản</Link></div>
  <div className="sender-filters"><TextField label="Tìm tài khoản Telegram" value={search} disabled={locked} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Tên hoặc username…"/>
   <SelectField label="Nhóm tài khoản gửi" value={group} disabled={locked} onChange={e=>{setGroup(e.target.value);setPage(1);}}><option value="">Mọi nhóm</option><option value="ungrouped">Chưa có nhóm</option>{(Array.isArray(groups.data)?groups.data:[]).map(g=><option key={g.id} value={g.id}>{g.name} ({g.count})</option>)}</SelectField></div>
  {!single&&<div className="row"><button className="btn sm" disabled={locked||refreshing} onClick={()=>void choose({all_matching:true,account_ids:[],exclude_ids:[],filters})}>Chọn toàn bộ kết quả</button><button className="btn sm" disabled={locked||!saved?.count} onClick={()=>saved&&void choose(saved.selection)}>SS đã tích ({saved?.count??0})</button></div>}
  <div className="row between"><label className="small"><input type="checkbox" checked={onlySelected} onChange={e=>setOnlySelected(e.target.checked)}/> Chỉ xem đã chọn</label><button className="btn ghost sm" disabled={locked||!value.length} onClick={()=>onChange([])}>Bỏ chọn hết</button></div>
  <div className="sender-list">
   {onlySelected?value.length?value.map(a=><label key={a.id} className="sender-item"><input type="checkbox" checked disabled={locked} aria-label={`Chọn SS ${a.name}`} onChange={()=>toggle(a)}/><span><strong>{a.name}</strong><small>{a.group_name??'Chưa có nhóm'}</small></span></label>):<p className="hint">Chưa chọn SS.</p>:<>
    {!single&&!!rows.length&&<label className="sender-item"><input type="checkbox" aria-label="Chọn SS trang này" disabled={locked||refreshing||!currentEligible.length} checked={!!currentEligible.length&&currentEligible.every(a=>ids.has(a.id))} onChange={e=>{const checked=e.target.checked;const next=new Map(value.map(a=>[a.id,a]));currentEligible.forEach(a=>checked?next.set(a.id,a):next.delete(a.id));if(next.size>1000){setError('Chọn tối đa 1.000 SS trong một đợt.');return;}onChange([...next.values()]);}}/><strong>Chọn trang này</strong></label>}
    {rows.map(a=>{const reason=senderReason(a);return <label className={`sender-item ${reason?'muted':''}`} key={a.id}><input type={single?'radio':'checkbox'} name={single?'single-sender':undefined} aria-label={`Chọn SS ${a.name}`} checked={ids.has(a.id)} disabled={locked||!!reason||accounts.refreshing||accounts.loading||!ids.has(a.id)&&value.length>=1000} onChange={()=>toggle(a)}/><span><strong>{a.name}</strong><small>{a.group_name??'Chưa có nhóm'}{a.telegram_username?` · @${a.telegram_username}`:''}</small></span><small>{reason||'Đã xác thực'}</small></label>;})}
    {accounts.loading?<p className="hint">Đang tải…</p>:!rows.length&&<p className="hint">Không có SS phù hợp.</p>}
   </>}
  </div>
  {!onlySelected&&<div className="row"><span className="hint">{accounts.data?.total??0} SS · Trang {page}</span><button className="btn ghost sm" disabled={locked||page===1||accounts.refreshing} onClick={()=>setPage(p=>p-1)}>Trước</button><button className="btn ghost sm" disabled={locked||accounts.refreshing||page*50>=(accounts.data?.total??0)} onClick={()=>setPage(p=>p+1)}>Sau</button></div>}
  {notice&&<p className="hint" role="status">{notice}</p>}{(error||accounts.error||groups.error)&&<Alert tone="bad">{error||accounts.error?.message||groups.error?.message}</Alert>}
 </section>;
}
