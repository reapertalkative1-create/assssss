"""Resolve account selections for post drafts; no Telegram connections here."""
import uuid
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from app.errors import ApiError
from app.models import AccountGroup, AccountGroupMember, TelegramAccount
from app.schemas_accounts import AccountFilters
from app.services.account_health import conditions

MAX_SENDERS = 1000

class SenderSelection(BaseModel):
    model_config = ConfigDict(extra='forbid')
    account_ids: list[uuid.UUID] = Field(default_factory=list, max_length=10000)
    all_matching: bool = False
    exclude_ids: list[uuid.UUID] = Field(default_factory=list, max_length=10000)
    filters: AccountFilters = Field(default_factory=AccountFilters)


def unavailable_reason(a):
    if a.pending_deletion: return 'Đang xóa'
    if a.auth_state != 'authorized': return 'Chưa xác thực'
    if a.health_status == 'frozen' or a.health_override == 'frozen': return 'Đóng băng'
    if a.spam_status in ('limited', 'blocked'): return 'Bị spam / bị chặn'
    if a.health_status == 'dead': return 'Session hết hiệu lực'
    if a.assigned_worker_id is None: return 'Chưa gán worker'
    return None


async def resolve_senders(db, selection, *, strict=False):
    if not selection.all_matching and not selection.account_ids:
        raise ApiError(422, 'empty_selection', 'Chọn ít nhất một tài khoản gửi.')
    where = conditions(**selection.filters.model_dump()) if selection.all_matching else [TelegramAccount.id.in_(selection.account_ids)]
    if selection.all_matching and selection.exclude_ids:
        where.append(TelegramAccount.id.not_in(selection.exclude_ids))
    rows = (await db.execute(select(TelegramAccount, AccountGroup.name)
        .outerjoin(AccountGroupMember, AccountGroupMember.account_id == TelegramAccount.id)
        .outerjoin(AccountGroup, AccountGroup.id == AccountGroupMember.group_id)
        .where(*where).order_by(TelegramAccount.name_key, TelegramAccount.id))).all()
    eligible, skipped = [], []
    for account, group_name in rows:
        reason = unavailable_reason(account)
        item = {'id': str(account.id), 'name': account.name, 'group_name': group_name}
        if reason: skipped.append({**item, 'reason': reason})
        else: eligible.append(item)
    missing = len(set(selection.account_ids)) - len(rows) if not selection.all_matching else 0
    if strict and (skipped or missing):
        raise ApiError(409, 'senders_changed', 'Có SS đã bị xóa hoặc không còn đủ điều kiện. Chọn lại tài khoản gửi; chưa tạo đợt nào.')
    if len(eligible) > MAX_SENDERS:
        raise ApiError(422, 'too_many_senders', 'Chọn tối đa 1.000 SS cho một đợt, dùng nhóm/bộ lọc để thu hẹp.')
    return {'items': eligible, 'skipped': skipped[:100], 'skipped_count': len(skipped) + missing, 'matched_count': len(rows) + missing}
