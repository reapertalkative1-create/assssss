import uuid
from app.models import TelegramAccount
from tests.conftest import run_db
from tests.unit.test_accounts_api import env


def setup(env,n=3):
    worker=env.make_worker()
    ids=[env.make_account(f'Sender {i}',worker) for i in range(n)]
    for aid in ids:env.authorize(worker,aid)
    return worker,ids


def body(ids,**extra):
    return {'request_id':str(uuid.uuid4()),'account_ids':ids,'post_link':'https://t.me/source_group/123',
            'targets_text':'@group_one\nhttps://t.me/group_one\n@group_two\n@group_three\n@group_four',
            'delay_seconds':60,'mode':'forward',**extra}


def test_multi_drafts_partition_targets_once_and_retry_is_idempotent(env):
    w,ids=setup(env)
    payload=body(ids+ids[:1]);c=env.client
    r=c.post('/api/post-routes/batches',headers=env.h,json=payload)
    assert r.status_code==201,r.text
    data=r.json();rows=data['items'];assert len(rows)==3
    targets=[t for row in rows for t in row['link_config']['targets']]
    assert len(targets)==4 and len(set(targets))==4
    assert [len(row['link_config']['targets']) for row in rows]==[2,1,1]
    assert all(row['status']=='stopped' and not row['verified'] for row in rows)
    assert 'request_signature' not in r.text
    assert c.get('/api/jobs').json()['total']==0 and w.poll()==[]
    replay=c.post('/api/post-routes/batches',headers=env.h,json=payload)
    assert [r['id'] for r in replay.json()['items']]==[r['id'] for r in rows]
    payload['targets_text']='@changed_target'
    assert c.post('/api/post-routes/batches',headers=env.h,json=payload).status_code==409
    assert c.get('/api/routes').json()['total']==3
    reopened=c.get('/api/post-routes/batches/'+data['batch_id'])
    assert len(reopened.json()['items'])==3


def test_group_selection_preserves_exclusions_and_skips_ineligible(env):
    w,ids=setup(env)
    c,h=env.client,env.h
    gid=c.post('/api/account-groups',headers=h,json={'name':'Folder'}).json()['id']
    c.post('/api/account-groups/assign',headers=h,json={'group_id':gid,'account_ids':ids})
    async def restrict(db):(await db.get(TelegramAccount,uuid.UUID(ids[1]))).__setattr__('spam_status','limited')
    run_db(env.settings,restrict)
    r=c.post('/api/post-routes/senders',headers=h,json={'all_matching':True,'filters':{'group_id':gid},'exclude_ids':[ids[2]]})
    assert r.status_code==200,r.text
    assert [a['id'] for a in r.json()['items']]==[ids[0]]
    assert r.json()['skipped_count']==1 and r.json()['items'][0]['group_name']=='Folder'
    assert c.post('/api/post-routes/batches',headers=h,json=body(ids)).status_code==409
    assert c.get('/api/routes').json()['total']==0


def test_invalid_deleted_accounts_and_bad_targets_never_create_partial_batch(env):
    w,ids=setup(env,2);c,h=env.client,env.h
    for payload,status in [(body(ids+[str(uuid.uuid4())]),409),(body(ids,targets_text='@valid_group\nhttps://evil.example/group'),422),(body(ids,post_link='https://evil.example/123'),422)]:
        r=c.post('/api/post-routes/batches',headers=h,json=payload);assert r.status_code==status,r.text
        assert c.get('/api/routes').json()['total']==0
    r=c.post('/api/post-routes/batches',headers=h,json=body(ids,targets_text='@group_one'))
    assert r.status_code==201 and len(r.json()['items'])==1 and r.json()['unused_senders']==1


def test_batch_creation_requires_admin(env,new_client,seed_user,login):
    seed_user('operator',role='operator');c=new_client();h=login(c,'operator')
    assert c.post('/api/post-routes/senders',headers=h,json={'account_ids':[str(uuid.uuid4())]}).status_code==403
    assert c.post('/api/post-routes/batches',headers=h,json=body([str(uuid.uuid4())])).status_code==403


def test_verified_batch_queues_only_assigned_groups_and_restriction_does_not_reassign(env):
    w,ids=setup(env,2);c,h=env.client,env.h
    rows=c.post('/api/post-routes/batches',headers=h,json=body(ids)).json()['items']
    for row in rows:
        assert c.post('/api/routes/'+row['id']+'/start',headers=h).status_code==409
        assert c.post('/api/routes/'+row['id']+'/verify',headers=h).status_code==202
    commands=w.poll();assert len(commands)==2
    destinations={'@group_one':-100001,'@group_two':-100002,'@group_three':-100003,'@group_four':-100004}
    for cmd in commands:
        checks=[{'index':i,'id':destinations[t],'ok':True,'can_send':True} for i,t in enumerate(cmd['payload']['targets'])]
        assert w.result(cmd['id'],result={'post':{'source_chat_id':-100999,'message_id':123,'targets':checks}}).status_code==204
    async def restrict(db):(await db.get(TelegramAccount,uuid.UUID(ids[0]))).__setattr__('spam_status','limited')
    run_db(env.settings,restrict)
    for row in rows:
        r=c.post('/api/routes/'+row['id']+'/start',headers=h)
        assert r.status_code==(409 if row['account_id']==ids[0] else 200),r.text
    jobs=c.get('/api/jobs').json();assert jobs['total']==2
    assert all(j['account_id']==ids[1] for j in jobs['items'])
    # No target is reassigned to the unrestricted account.
    assert {j['dest_chat_id'] for j in jobs['items']}=={-100002,-100004}


def test_telegram_aliases_resolving_to_same_group_cannot_send_twice(env):
    w,ids=setup(env,2);c,h=env.client,env.h
    rows=c.post('/api/post-routes/batches',headers=h,json=body(ids,targets_text='@group_one\n-100001')).json()['items']
    for row in rows:c.post('/api/routes/'+row['id']+'/verify',headers=h)
    for cmd in w.poll():
        assert w.result(cmd['id'],result={'post':{'source_chat_id':-100999,'message_id':123,'targets':[{'index':0,'id':-100001,'ok':True,'can_send':True}]}}).status_code==204
    for row in rows:
        r=c.post('/api/routes/'+row['id']+'/start',headers=h)
        assert r.status_code==409 and r.json()['error']['code']=='duplicate_batch_target',r.text
    assert c.get('/api/jobs').json()['total']==0


def test_more_than_one_page_of_senders_is_resolved_and_partitioned(env):
    w=env.make_worker();c,h=env.client,env.h
    async def seed(db):
        ids=[]
        for i in range(105):
            aid=uuid.uuid4();ids.append(str(aid));db.add(TelegramAccount(id=aid,name=f'Bulk {i:03d}',name_key=f'bulk {i:03d}',auth_state='authorized',assigned_worker_id=uuid.UUID(w.id)))
        return ids
    ids=run_db(env.settings,seed)
    assert len(c.get('/api/accounts',params={'page_size':50}).json()['items'])==50
    result=c.post('/api/post-routes/senders',headers=h,json={'all_matching':True,'filters':{'q':'Bulk'},'exclude_ids':ids[:2]})
    assert result.status_code==200,result.text
    selected=[a['id'] for a in result.json()['items']]
    assert len(selected)==103 and not set(ids[:2])&set(selected)
    result=c.post('/api/post-routes/batches',headers=h,json=body(selected,targets_text='\n'.join(f'@target_{i}' for i in range(105))))
    assert result.status_code==201,result.text
    rows=result.json()['items'];assert len(rows)==103
    assigned=[t for row in rows for t in row['link_config']['targets']]
    assert len(assigned)==len(set(assigned))==105
    assert c.get('/api/jobs').json()['total']==0
